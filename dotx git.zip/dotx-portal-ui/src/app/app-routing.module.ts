import {NgModule} from '@angular/core';
import {RouterModule, Routes} from '@angular/router';
import {AuthGuardService} from './shared/services/auth-guard.service';
import {OnboardAccessGuardService} from './shared/services/onboard-access-guard.service';
import {AccessGuardService} from './shared/services/access-guard.service';
import {HomeComponent} from './home/home.component';
import {AboutUsComponent} from './shared/component/about-us/about-us.component';
import {LoginComponent} from './home/login/login.component';
import {SignUpComponent} from './home/sign-up/sign-up.component';
import {ForgotPasswordComponent} from './home/forgot-password/forgot-password.component';
import {DefaultHomeComponent} from './home/default-home/default-home.component';
import { PrivacyPolicyComponent } from './home/privacy-policy/privacy-policy.component';
import { TermServicesComponent } from './home/term-services/term-services.component';
import { ReturnPolicyComponent } from './home/return-policy/return-policy.component';
import {BlogComponent} from './home/blog/blog.component';
import { BlogPostsComponent } from './home/blog-posts/blog-posts.component';
import { FaqsComponent } from './home/faqs/faqs.component';
import {CommunityComponent} from './home/community/community.component';
import {ChallengeComponent} from './home/challenge/challenge.component';
import {OurTeamComponent} from './home/our-team/our-team.component';
import {OurApproachComponent} from './home/our-approach/our-approach.component';

const routes: Routes = [
  {
    path: '',
    component: DefaultHomeComponent,
    children: [
      {
        path: 'home',
        component: HomeComponent
      },
      {
        path: 'explore',
        component: AboutUsComponent
      },
      {
        path: 'our-team',
        component: OurTeamComponent
      },
      {
        path: 'our-approach',
        component: OurApproachComponent
      },
      {
        path: 'community',
        component: CommunityComponent
      },
      {
        path: 'challenge',
        component: ChallengeComponent
      },
      {
        path: 'login',
        component: LoginComponent,
      },
      {
        path: 'sign-up',
        component: SignUpComponent
      },
      {
        path: 'forgot-password',
        component: ForgotPasswordComponent,
      },
      {
        path: 'privacy-policy',
        component: PrivacyPolicyComponent,
      },
      {
        path: 'terms-services',
        component: TermServicesComponent,
      },
      {
        path: 'return-policy',
        component: ReturnPolicyComponent,
      },
      {
        path: 'blog',
        component: BlogComponent
      },
      {
        path: 'blog-posts',
        component: BlogPostsComponent
      },
      {
        path: 'faqs',
        component: FaqsComponent
      },
      {
        path: '',
        redirectTo: 'home',
        pathMatch: 'full'
      }
    ]
  },
  {
    path: 'onboard',
    loadChildren: () =>
      import('.././app/modules/student-onboard/student-onboard.module').then(m => m.StudentOnboardModule),
    canActivate: [OnboardAccessGuardService]
  },
  {
    path: 'auth',
    canActivate: [AuthGuardService],
    children: [
      {
        path: '',
        canActivateChild: [AccessGuardService],
        children: [
          {
            path: 'admin',
            loadChildren: () =>
              import('./modules/admin-dashboard/admin-dashboard.module').then(m => m.AdminDashboardModule)
          },
          {
            path: 'student',
            loadChildren: () =>
              import('./modules/student-dashboard/student-dashboard.module').then(m => m.StudentDashboardModule)
          }
        ]
      }
    ]
  },
  // Fallback when no prior routes is matched
  // {
  //   path: '**',
  //   redirectTo: 'home',
  //   pathMatch: 'full'
  // }
];

@NgModule({
  imports: [RouterModule.forRoot(routes, {
    useHash: true,
    scrollPositionRestoration: 'enabled',
    scrollOffset: [0, 0],
    anchorScrolling: 'enabled'
  })],
  exports: [RouterModule]
})
export class AppRoutingModule { }
