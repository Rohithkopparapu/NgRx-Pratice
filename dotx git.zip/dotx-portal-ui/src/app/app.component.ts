import {Compiler, Component, ElementRef, OnDestroy, OnInit} from '@angular/core';
import {Store} from '@ngrx/store';
import {AuthState} from './shared/store/auth.model';
import {HelperService} from './shared/services/helper.service';
import {UserDetailsAction} from './shared/store/auth.action';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit, OnDestroy  {
  title = 'dotx-portal-ui';

  constructor(
    private elementRef: ElementRef,
    private store$: Store<AuthState>,
    private compiler: Compiler,
    private helperService: HelperService,
  ) {
  }

  ngOnInit(): void {
    this.elementRef.nativeElement.removeAttribute('ng-version');
    this.compiler.clearCache();
    const auth = JSON.parse(sessionStorage.getItem('auth'));
    if (auth && auth.userResponse && auth.userResponse['usertype'] === this.helperService.getRole(auth.userResponse['usertype'])) {
      this.store$.dispatch(new UserDetailsAction({userId: auth.userResponse['id'], _page: ''}));
      // this.studentHelperService.getUserInfo(auth.userResponse['id']).subscribe(res => {
      //   if (res) {
      //     this.store$.dispatch(new SetUserDetail(res));
      //   }
      // }, () => [new AuthLoginFail(), new AuthLogout()]);
    }
  }

  ngOnDestroy(): void {
  }
}
