/* Modules */
import {BrowserModule} from '@angular/platform-browser';
import {NgModule} from '@angular/core';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import {ToastrModule} from 'ngx-toastr';
import {HttpClientModule} from '@angular/common/http';
import {CommonInterceptorModule} from './shared/modules/common-interceptor.module';
import {MetaReducer, StoreModule} from '@ngrx/store';
import {localStorageSyncReducer, reducers} from './shared/store';
import {StoreDevtoolsModule} from '@ngrx/store-devtools';
import {EffectsModule} from '@ngrx/effects';
import {effects} from './shared/store/effect.index';
import {NgxEmojiPickerModule} from 'ngx-emoji-picker';
import {NgbDateParserFormatter} from '@ng-bootstrap/ng-bootstrap';
/* Components  */
import {AppRoutingModule} from './app-routing.module';
import {AppComponent} from './app.component';
import {SharedModule} from './shared/shared.module';
import {DefaultHomeComponent} from './home/default-home/default-home.component';
import {HomeComponent} from './home/home.component';
import {LoginComponent} from './home/login/login.component';
import {SignUpComponent} from './home/sign-up/sign-up.component';
import {ForgotPasswordComponent} from './home/forgot-password/forgot-password.component';
import {FooterComponent} from './home/footer/footer.component';
import { PrivacyPolicyComponent } from './home/privacy-policy/privacy-policy.component';
import { TermServicesComponent } from './home/term-services/term-services.component';
import { ReturnPolicyComponent } from './home/return-policy/return-policy.component';
import {CustomDateParserFormatterService} from './shared/services/custom-date-parser-formatter.service';
import { BlogComponent } from './home/blog/blog.component';
import { BlogPostsComponent } from './home/blog-posts/blog-posts.component';
import { FaqsComponent } from './home/faqs/faqs.component';
import {DatePipe} from '@angular/common';
import { CommunityComponent } from './home/community/community.component';
import { ChallengeComponent } from './home/challenge/challenge.component';
import { OurTeamComponent } from './home/our-team/our-team.component';
import { OurApproachComponent } from './home/our-approach/our-approach.component';

const metaReducers: MetaReducer<any>[] = [localStorageSyncReducer];


@NgModule({
  declarations: [
    AppComponent,
    DefaultHomeComponent,
    HomeComponent,
    LoginComponent,
    SignUpComponent,
    ForgotPasswordComponent,
    FooterComponent,
    PrivacyPolicyComponent,
    TermServicesComponent,
    ReturnPolicyComponent,
    BlogComponent,
    BlogPostsComponent,
    FaqsComponent,
    CommunityComponent,
    ChallengeComponent,
    OurTeamComponent,
    OurApproachComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    ToastrModule.forRoot({
      timeOut: 5000,
      positionClass: 'toast-top-right',
      preventDuplicates: true
    }),
    HttpClientModule,
    CommonInterceptorModule.forRoot(),
    StoreModule.forRoot(reducers, {metaReducers}),
    StoreDevtoolsModule.instrument(), // To enable NGRX REDUX DEV TOOLS comment this line
    EffectsModule.forRoot(effects),
    NgxEmojiPickerModule.forRoot(),
    SharedModule
  ],
  providers: [
    {provide: NgbDateParserFormatter, useClass: CustomDateParserFormatterService},
    DatePipe
  ],
  bootstrap: [AppComponent]
})
export class AppModule {
}
