import {AfterViewInit, Component, OnInit} from '@angular/core';
import Swiper, {Navigation, Pagination} from 'swiper';

@Component({
  selector: 'app-blog-posts',
  templateUrl: './blog-posts.component.html',
  styleUrls: ['./blog-posts.component.scss']
})
export class BlogPostsComponent implements OnInit, AfterViewInit {

  constructor() {}

  ngOnInit() {
  }

  ngAfterViewInit(): void {
    const swiper = new Swiper('.swiper.swiper-blog-featured', {
      modules: [Navigation, Pagination],
      // Optional parameters
      loop: true,
      freeMode: true,

      keyboard: {
        enabled: true,
        onlyInViewport: false,
      },

      // Navigation arrows
      navigation: {
        nextEl: '.swiper-button-next',
        prevEl: '.swiper-button-prev',
      }
    });
  }
}
