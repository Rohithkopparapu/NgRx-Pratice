import {Component, OnInit} from '@angular/core';
import Swiper, {Navigation, Pagination} from 'swiper';
import {SoloChallengeModelComponent} from '../../shared/component/solo-challenge-model/solo-challenge-model.component';
import {GroupChallengeModelComponent} from '../../shared/component/group-challenge-model/group-challenge-model.component';
import {NgbModal} from '@ng-bootstrap/ng-bootstrap';
import {StudentHelperService} from '../../modules/student-dashboard/student-helper.service';
import {HelperService} from '../../shared/services/helper.service';
import {ActivatedRoute, Router} from '@angular/router';
import {ToastrService} from 'ngx-toastr';
import * as moment from 'moment';

@Component({
  selector: 'app-challenge',
  templateUrl: './challenge.component.html',
  styleUrls: ['./challenge.component.scss']
})
export class ChallengeComponent implements OnInit {

  isHubLoading: boolean;
  isLoading: boolean;
  selectedCommunity: any;
  myCommunityInfo: any;
  evergreenChallenges: any[];
  recentChallenges: any[];
  influencerChallenges: any[];
  top10ResponsesChallenges: any[];
  upcomingChallenges: any[];
  top10ResponseCards: any[];
  influencerResponseCards: any[];
  spotLightChallenges: any[];
  isEnableTop10Responses = false;
  isEnableInfluencerResponses = false;
  communitiesList: any[];

  constructor(private modalService: NgbModal, private studentHelperService: StudentHelperService, private _uhs: HelperService,
              private router: Router, private toastrService: ToastrService) {
    const data = this.router.getCurrentNavigation().extras.state;
    if (data) {
      this.selectedCommunity = data.community;
    }
  }

  ngOnInit() {
    this.getCommunities();
  }

  getChallenges(communityId): void {
    this.isHubLoading = true;
    this.studentHelperService.getChallengesPublic(communityId).subscribe(res => {
      this.myCommunityInfo = res['community'] ? res['community'] : {};
      this.spotLightChallenges = this.initSpotlightBanner(res['spotlight_challenges']);
      this.recentChallenges = this.initChallengesSlider(res['recent_challenges'], false);
      this.influencerChallenges = this.initChallengesSlider(res['influencer_challenges'], true);
      this.evergreenChallenges = this.initChallengesSlider(res['evergreen_challenges'], false);
      this.top10ResponsesChallenges = this.initChallengesSlider(res['top10_responses'], true);
      this.upcomingChallenges = this.initChallengesSlider(res['upcoming_challenges'], false);
      this.isHubLoading = false;
    }, () => this.isHubLoading = false);
  }

  getCommunities(): void {
    this.isLoading = true;
    this.studentHelperService.getAllCommunitiesPublic().subscribe(res => {
      this.isLoading = false;
      if (res && res.length) {
        this.communitiesList = res.filter(s =>
          moment(moment(s.community_start_date).format('YYYY-MM-DD')).isSameOrBefore(moment().format('YYYY-MM-DD')) && s.num_challenges > 0);
        this.getChallenges(this.selectedCommunity ? this.selectedCommunity.community_id : this.communitiesList[0]);
      }
    }, () => this.isLoading = false);
  }


  initSpotlightBanner(spotLightChallenges: any[]) {
    spotLightChallenges = this._uhs.getImageOrVideoFromChallenges(spotLightChallenges);
    if (spotLightChallenges && spotLightChallenges.length > 1) {
      setTimeout(() => {
        const swiper = new Swiper('.swiper.swiper-banner-spotlight', {
          modules: [Navigation, Pagination],
          // Optional parameters
          // loop: true,

          // If we need pagination
          pagination: {
            clickable: true,
            el: '.swiper-pagination',
            type: 'bullets'
          },

          // autoplay: {
          //   delay: 5000,
          // },

          keyboard: {
            enabled: true,
            onlyInViewport: false,
          },

          // Navigation arrows
          navigation: {
            nextEl: '.swiper-button-next',
            prevEl: '.swiper-button-prev',
          },
        });
      });
    } else {
      setTimeout(() => {
        const swiper = new Swiper('.swiper.swiper-banner-spotlight', {
          // Optional parameters
          enabled: false,
          navigation: {
            nextEl: null,
            prevEl: null,
          },
        });
      });
    }
    return spotLightChallenges;
  }

  initChallengesSlider(challenges: any[], isStack: boolean) {
    challenges = this._uhs.getOnlyImageFromChallenges(challenges);
    if (!isStack) {
      setTimeout(() => {
        const swiperSlider = new Swiper('.swiper.swiper-slider', {
          modules: [Navigation, Pagination],
          // Optional parameters
          // loop: true,

          keyboard: {
            enabled: true,
            onlyInViewport: false,
          },

          // Navigation arrows
          navigation: {
            nextEl: '.swiper-button-next',
            prevEl: '.swiper-button-prev',
          },
          breakpoints: {
            0: {
              slidesPerView: 1,
              spaceBetween: 10,
              slidesPerGroup: 1
            },
            576: {
              slidesPerView: 2,
              spaceBetween: 20,
              slidesPerGroup: 2
            },
            992: {
              slidesPerView: 3,
              spaceBetween: 25,
              slidesPerGroup: 3
            },
            1200: {
              slidesPerView: 4,
              spaceBetween: 30,
              slidesPerGroup: 4
            }
          }
        });
      });
    } else {
      setTimeout(() => {
        const swiperSliderStack = new Swiper('.swiper.swiper-slider-stack', {
          modules: [Navigation, Pagination],
          // Optional parameters
          // loop: true,

          keyboard: {
            enabled: true,
            onlyInViewport: false,
          },

          // Navigation arrows
          navigation: {
            nextEl: '.swiper-button-next',
            prevEl: '.swiper-button-prev',
          },
          breakpoints: {
            0: {
              slidesPerView: 1,
              spaceBetween: 10,
              slidesPerGroup: 1
            },
            576: {
              slidesPerView: 2,
              spaceBetween: 30,
              slidesPerGroup: 2
            },
            992: {
              slidesPerView: 3,
              spaceBetween: 35,
              slidesPerGroup: 3
            },
            1200: {
              slidesPerView: 4,
              spaceBetween: 50,
              slidesPerGroup: 4
            }
          }
        });
      });
    }
    return challenges;
  }

  onChangeCommunity(community: any, item): void {
    if (community.community_id !== item.community_id) {
      this.getChallenges(community.community_id);
    }
  }

  getStackedResponseCards(topicId, type): void {
    this.isLoading = true;
    this.studentHelperService.getResponseCardsPublic(topicId).subscribe(res => {
      this.isLoading = false;
      if (res && res.length) {
        this.getResponseCardsByType(type, res);
      } else {
        this.toastrService.warning('No responses found...');
      }
    });
  }

  getResponseCardsByType(type, result): void {
    if (type === 'Top 10 Responses') {
      this.top10ResponseCards = [];
      result.forEach(chall => {
        if (chall.attachments && chall.attachments.length) {
          const imageObj = chall.attachments.find(attach => attach.type === 'image');
          chall['response_image'] = imageObj && imageObj.file ? imageObj.url : null;
        }
      });
      this.top10ResponseCards = result;
      this.initChallengesSlider([], false);
      this.isEnableTop10Responses = true;
    } else if (type === 'Influencer Challenges') {
      this.influencerResponseCards = [];
      result.forEach(chall => {
        if (chall.attachments && chall.attachments.length) {
          const imageObj = chall.attachments.find(attach => attach.type === 'image');
          chall['response_image'] = imageObj && imageObj.file ? imageObj.url : null;
        }
      });
      this.influencerResponseCards = result;
      this.initChallengesSlider([], false);
      this.isEnableInfluencerResponses = true;
    }
  }

  onCloseStackedResponses(type): void {
    if (type === 'Influencer Challenges') {
      this.influencerResponseCards = [];
      this.initChallengesSlider([], true);
      this.isEnableInfluencerResponses = !this.isEnableInfluencerResponses;
    } else if (type === 'Top 10 Responses') {
      this.top10ResponseCards = [];
      this.initChallengesSlider([], true);
      this.isEnableTop10Responses = !this.isEnableTop10Responses;
    }
  }

  openChallenge(challenge: any): any {
    const data = {
      challenge
    };
    const component = challenge.topic_group_size === 1 ? SoloChallengeModelComponent : GroupChallengeModelComponent;
    const modelRef = this.modalService.open(component, {
      centered: true,
      scrollable: true,
      backdrop: 'static',
      keyboard: false,
      size: 'xl',
      windowClass: 'modal-challenge'
    });
    modelRef.componentInstance.data = data;
    modelRef.componentInstance.isHomeAccess = true;
  }

  openViewResponses(challenge: any): void {
    this.toastrService.warning('Please Sign Up to explore more');
  }
}
