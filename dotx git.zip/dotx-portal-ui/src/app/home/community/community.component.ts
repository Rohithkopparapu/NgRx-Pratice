import { Component, OnInit } from '@angular/core';
import * as moment from 'moment';
import {StudentHelperService} from '../../modules/student-dashboard/student-helper.service';
import {Router} from '@angular/router';

@Component({
  selector: 'app-community',
  templateUrl: './community.component.html',
  styleUrls: ['./community.component.css']
})
export class CommunityComponent implements OnInit {

  isLoading = false;
  communitiesList: any[];
  upcomingCommunityList: any[];
  belowCommunitiesList: any[];
  bannerCommunity: any;

  constructor(private studentHelperService: StudentHelperService, private router: Router) { }

  ngOnInit() {
    this.getCommunities();
  }

  getCommunities(): void {
    let closestDate = moment('1970-01-01').format('YYYY-MM-DD');
    let closestCommunity = {};
    const upcomingList = [];
    const activeList = [];
    this.isLoading = true;
    this.studentHelperService.getAllCommunitiesPublic().subscribe(res => {
      if (res && res.length) {
        res.forEach(s => {
          s['community_image'] = s.attachments.filter(i => i.attachment_title === 'community_image')[0];
          if (moment(moment(s.community_start_date).format('YYYY-MM-DD')).isSameOrBefore(moment().format('YYYY-MM-DD')) && s.num_challenges > 0 || s.joining_fee > 0) {
            activeList.push(s);
          } else {
            upcomingList.push(s);
          }
        });
        // moment(startDate).isSameOrBefore(moment().format('YYYY-MM-DD')) &&
        activeList.forEach(item => {
          const startDate = moment(item.community_start_date).format('YYYY-MM-DD');
          if (moment(startDate).isSameOrAfter(closestDate)) {
            closestDate = item.community_start_date;
            closestCommunity = item;
          }
        });
        this.communitiesList = activeList;
        this.bannerCommunity = closestCommunity ? closestCommunity : activeList[0];
        this.belowCommunitiesList = activeList.filter(community => community.community_id !== this.bannerCommunity.community_id);
        this.upcomingCommunityList = upcomingList;
      }
      this.isLoading = false;
    }, () => this.isLoading = false);
  }

  getButtonName(community: any): string {
    return community.status.toLowerCase() === 'suspend' ? 'Have a Break...' : community.status.toLowerCase() === 'closed' ? 'Closed' : 'Explore';
  }

  isDisableCommunity(community: any): boolean {
    return community.status.toLowerCase() === 'suspend' || community.status.toLowerCase() === 'closed';
  }

  getClassName(community: any): string {
    return community.status.toLowerCase() === 'suspend' || community.status.toLowerCase() === 'closed' ? 'btn-c-secondary' : 'btn-c-primary';
  }

  gotoChallenge(communityObject: any) {
    this.router.navigate(['/challenge'], {state: {community: communityObject}});
  }
}
