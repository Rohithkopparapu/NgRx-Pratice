import {Component, OnDestroy, OnInit} from '@angular/core';
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { AuthLogout } from '../../shared/store/auth.action';
import { AuthState } from '../../shared/store/auth.model';
import {ModalUtilService} from '../../shared/services/modal-util.service';
import {takeUntil} from 'rxjs/operators';
import { userInfo } from 'src/app/shared/store/auth.selector';
import {Subject} from 'rxjs';
import {Authority} from '../../shared/constants/authority.constants';

@Component({
  selector: 'app-default-home',
  templateUrl: './default-home.component.html'
})
export class DefaultHomeComponent implements OnInit, OnDestroy {
  private subscriptions = new Subject<void>();
  userInfo: any;

  constructor(private store$: Store<AuthState>, private router: Router, private modalUtilService: ModalUtilService) {
    this.store$.select(userInfo)
      .pipe(takeUntil(this.subscriptions))
      .subscribe(res => this.userInfo = res);
  }

  ngOnInit() {
    if (this.userInfo) {
      if (this.userInfo.user_type === Authority.ADMIN) {
        this.router.navigate(['/auth/admin/home']);
      } else {
        if (this.userInfo.is_email_verified && this.userInfo.display_name && this.userInfo.avatar_image_file) {
          if (this.userInfo.is_temp_passwd === 1) {
            this.modalUtilService.openResetPasswordPopup();
          } else {
            this.router.navigate(['/auth/student/home']);
          }
        } else {
          this.router.navigate(['/onboard/confirm-email']);
        }
      }
    } else {
      // if (this.socketUtilService.getSocket().connected) {
      //   this.socketUtilService.disconnectConnection();
      // }
      // this.store$.dispatch(new AuthLogout());
    }
  }

  ngOnDestroy(): void {
    this.subscriptions.next();
    this.subscriptions.complete();
  }
}
