import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router';
import {ModalUtilService} from '../../shared/services/modal-util.service';
import {MAIN_MODULE_URL} from '../../shared/constants/constant';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-footer',
  template: `<footer class="footer">
  <div class="row">
    <div class="col-12 col-md-6 col-lg-3">
      <figure class="footer-logo">
        <img src="assets/img/w-dotx-logo.svg" alt="Image" />
      </figure>
      <span class="footer-desc">&copy; <span class="font-weight-bold">{{currentYear}} Caterpillar Wings Pvt Ltd.</span> All rights reserved.</span>
    </div>
    <div class="col-12 col-md-6 col-lg-3">
    <ul class="footer-links-list">
      <li><a href="{{homePageUrl}}about/">About</a></li>
      <li><a href="{{homePageUrl}}blog/"
           routerLinkActive="active">Blog</a></li>
      <li><a href="{{homePageUrl}}terms-of-service/"
           routerLinkActive="active">Terms of Service</a></li>
      <li><a href="{{homePageUrl}}privacy-policy/"
           routerLinkActive="active">Privacy Policy</a></li>
      <li><a href="{{homePageUrl}}return-policy/"
           routerLinkActive="active">Return Policy</a></li>
    </ul>
  </div>

    <div class="col-12 col-md-6 col-lg-3">
      <ul class="footer-links-list">
        <li><a href="javascript:void(0)"
             (click)="openContactUsForm()">Contact Us</a></li>
      </ul>
      <ul class="footer-social">
        <li>
          <span class="mb-0">Follow Us:</span>
        </li>
        <li class="footer-social-links">
          <a href="https://m.facebook.com/DotX.gg/"
             target="_blank">
            <svg class="icon icon-facebook-with-circle">
              <use xlink:href="assets/img/sprite.svg#icon-facebook-with-circle"></use>
            </svg>
          </a>
          <a href="https://twitter.com/DotX_gg"
             target="_blank">
            <svg class="icon icon-twitter-with-circle">
              <use xlink:href="assets/img/sprite.svg#icon-twitter-with-circle"></use>
            </svg>
          </a>
          <a href="https://instagram.com/dotx.gg?igshid=YmMyMTA2M2Y="
             target="_blank">
            <svg class="icon icon-instagram-with-circle">
              <use xlink:href="assets/img/sprite.svg#icon-instagram-with-circle"></use>
            </svg>
          </a>
        </li>
      </ul>
    </div>
    <div class="col-12 col-md-6 col-lg-3">
      <address class="mt-4 mt-lg-0"><span class="text-muted">Registered Office Address:</span><br><strong>
        Caterpillar Wings LLP,</strong><br>Q2-A1, 10th Floor, <br>Cyber Towers, Hitech City, <br>Hyderabad - 500081 <br> Email:
        <a href="javascript:void(0)"> admin@dotx.gg </a></address>
    </div>
  </div>
</footer>`
})
export class FooterComponent implements OnInit {
  currentYear = new Date().getFullYear();
  moduleUrl: string;
  cmsUrl:string
  homePageUrl: string;
  constructor(public route: Router, private modalUtilService: ModalUtilService) { }

  ngOnInit() {
    this.cmsUrl = environment.cmsUrl;
    this.homePageUrl = environment.homePageUrl;
   }

  gotoAboutUs(): void {
    this.moduleUrl = this.route.url.substring(0, this.route.url.lastIndexOf('/'));
    if (this.moduleUrl === '') {
      this.route.navigateByUrl(this.moduleUrl + '/explore');
    } else if (this.route.url.includes(MAIN_MODULE_URL.STUDENT)) {
      this.route.navigateByUrl(MAIN_MODULE_URL.STUDENT + '/about-us');
    } else if (this.route.url.includes(MAIN_MODULE_URL.ADMIN)) {
      this.route.navigateByUrl(MAIN_MODULE_URL.ADMIN + '/about-us');
    } else if (this.route.url.includes(MAIN_MODULE_URL.ONBOARD)) {
      this.route.navigateByUrl(MAIN_MODULE_URL.ONBOARD + '/about-us');
    }
  }

  openContactUsForm(): void {
    this.modalUtilService.openContactUsPopup();
  }
}
