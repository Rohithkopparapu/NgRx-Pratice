import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { AuthorizeService } from 'src/app/shared/services/auth.service';
import { HelperService } from 'src/app/shared/services/helper.service';
import {CustomValidator} from '../../shared/services/validators/customValidator';

@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.scss']
})
export class ForgotPasswordComponent implements OnInit {

  isLoading: boolean;
  forgotPasswordForm = this.formBuilder.group({
    user_email: ['', [Validators.required, CustomValidator.ValidateEmail]]
  });

  constructor(private formBuilder: FormBuilder,
              private router: Router,
              private toastrService: ToastrService,
              public _uhs: HelperService,
              private authService: AuthorizeService) {
  }

  ngOnInit() {
  }

  forgotPasswordSubmit() {
    if (!this.forgotPasswordForm.valid) {
      this.forgotPasswordForm.markAllAsTouched();
      this.toastrService.warning('Please enter Email Id');
      return;
    }
    const { user_email } = this.forgotPasswordForm.value;
    const body = {
      user_email
    };
    this.isLoading = true;
    this.authService.forgotPassword(body).subscribe((resp) => {
      this.isLoading = false;
      if (!resp.body['failure']) {
        this.toastrService.success('Temporary password is sent to the given Email-id.');
        this.router.navigate(['/login']);
      } else {
        this.toastrService.error('Email Id does not match');
      }
    }, () => {
      this.isLoading = false;
      this.toastrService.error('Invalid details');
    });
  }
}
