import {Component, Input} from '@angular/core';
import {Router} from '@angular/router';
import {FestModalComponent} from '../../shared/component/fest-modal/fest-modal.component';
import {NgbModal} from '@ng-bootstrap/ng-bootstrap';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent {

  @Input() onboard: any;
  cmsUrl: any;
  cmsLandingUrl: string;
  homePageUrl :string;

  constructor(
    private route: Router,
    private modalService: NgbModal
  ) {
    this.cmsUrl = environment.cmsUrl;
    this.cmsLandingUrl = environment.cmsLandingUrl;
    this.homePageUrl = environment.homePageUrl;
  }

  redirectHome() {
    // this.route.navigate(['https://dev.dotx.gg/home']);
    window.location.replace(this.homePageUrl);

  }

  joinFest(): void {
    const modelRef = this.modalService.open(FestModalComponent, {
      centered: true,
      scrollable: false,
      windowClass: 'modal-recommended',
      size: 'lg',
    });
    // modelRef.componentInstance.isLoggedIn = false;
  }
}
