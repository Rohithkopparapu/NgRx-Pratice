import {AfterViewInit, Component} from '@angular/core';
import {EMAIL} from '../shared/constants/validationConstants';
import {HelperService} from '../shared/services/helper.service';
import {ToastrService} from 'ngx-toastr';
import {AuthorizeService} from '../shared/services/auth.service';
import {FormControl} from '@angular/forms';
import {FestModalComponent} from '../shared/component/fest-modal/fest-modal.component';
import {NgbModal} from '@ng-bootstrap/ng-bootstrap';
import Swiper, {Navigation, Pagination} from 'swiper';
import {Router} from '@angular/router';
import {TESTIMONIALS_SLIDES} from '../shared/constants/constant';

declare var $: any;
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements AfterViewInit {

  emailRegexPattern = EMAIL.REGEX_EMAIL;
  isLoading = false;
  testimonialsSlides = TESTIMONIALS_SLIDES;

  constructor(public _uhs: HelperService, private toastrService: ToastrService, private authorizeService: AuthorizeService,
              private modalService: NgbModal, private router: Router) {
  }

  ngAfterViewInit(): void {
    const swiper = new Swiper('.swiper.swiper-testimonials', {
      effect: 'fade',
      slidesPerView: 3,
      fadeEffect: {
        crossFade: true
      },
      modules: [Navigation, Pagination],
      // Optional parameters
      loop: true,
      freeMode: true,

      keyboard: {
        enabled: true,
        onlyInViewport: false,
      },

      // Navigation arrows
      navigation: {
        nextEl: '.swiper-button-next',
        prevEl: '.swiper-button-prev',
      },
      breakpoints: {
        0: {
          slidesPerView: 1
        },
        576: {
          slidesPerView: 2
        },
        1199: {
          slidesPerView: 3,
          spaceBetween: 100,
        }
      }
    });
    const swiper2 = new Swiper('.swiper.swiper-our-members', {
      effect: 'fade',
      slidesPerView: 1,
      fadeEffect: {
        crossFade: true
      },
      modules: [Pagination],
      // Optional parameters
      loop: false,
      freeMode: true,

      keyboard: {
        enabled: true,
        onlyInViewport: false,
      },

      pagination: {
        el: '.swiper-pagination',
        clickable: true,
      },


      breakpoints: {
        0: {
          slidesPerView: 1
        },
        576: {
          slidesPerView: 1
        },
        1199: {
          slidesPerView: 1,
        }
      }
    });
  }

  joinToWaitList(email: any): void {
    if (email.value === '') {
      this.toastrService.warning('Please provide valid Email Id');
      return;
    }
    if (email.valid) {
      this.isLoading = true;
      const payload = {
        email: email.value
      };
      this.authorizeService.postWaitList(payload).subscribe(res => {
        this.isLoading = false;
        this.router.navigate(['/community']);
      }, (err) => this.isLoading = false);
    }
  }

  joinFest(): void {
    const modelRef = this.modalService.open(FestModalComponent, {
      centered: true,
      scrollable: false,
      windowClass: 'modal-recommended',
      size: 'lg',
    });
    // modelRef.componentInstance.isLoggedIn = false;
  }

  closeModal(email: FormControl): void {
    $('#waitListModal').modal('hide');
    email.setValue('');
  }
}
