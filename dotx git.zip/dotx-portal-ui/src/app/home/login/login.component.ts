import {Component, NgZone, OnDestroy, OnInit} from '@angular/core';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';
import {Router} from '@angular/router';
import {Store} from '@ngrx/store';
import {ToastrService} from 'ngx-toastr';
import {StudentHelperService} from 'src/app/modules/student-dashboard/student-helper.service';
import {PLEASE_FILL_EMAIL_ID_AND_PASSWORD} from 'src/app/shared/constants/error.constants';
import {AuthorizeService} from 'src/app/shared/services/auth.service';
import {HelperService} from 'src/app/shared/services/helper.service';
import {CustomValidator} from 'src/app/shared/services/validators/customValidator';
import {AuthLoginSuccess, SetUser, SetUserDetail} from 'src/app/shared/store/auth.action';
import {AuthState} from 'src/app/shared/store/auth.model';
import {ModalUtilService} from '../../shared/services/modal-util.service';
import {Subject} from 'rxjs';
import { accessToken } from 'src/app/shared/store/auth.selector';
import {takeUntil} from 'rxjs/operators';
import { environment } from 'src/environments/environment';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit, OnDestroy {

  private subscriptions = new Subject<void>();
  userId: any;
  loginForm: FormGroup;
  showPassword = false;
  isLoading: boolean;
  accessToken: any;
  errorMessage = false;
  cmsUrl: any;
  homePageUrl :any;
  inactiveMsg: any;
  inactiveMessage: boolean = false;

  constructor(private formBuilder: FormBuilder,
              private router: Router,
              private toastrService: ToastrService,
              private studentHelperService: StudentHelperService,
              public helperService: HelperService,
              private authService: AuthorizeService,
              private store$: Store<AuthState>,
              private modalUtilService: ModalUtilService,
              private ngZone:NgZone) {
    this.store$.select(accessToken)
      .pipe(takeUntil(this.subscriptions))
      .subscribe(res => this.accessToken = res);
  }

  ngOnInit(): void {
    this.loginBuildForm();
    this.cmsUrl =  environment.cmsUrl;
    this.homePageUrl = environment.homePageUrl;
    // this.loginForm.valueChanges.subscribe(value => {
    //   this.errorMessage = false;
    // });
    if (this.accessToken) {
      this.getUserDetails();
    }

    // (window as any).angularComponentRef = {
    //   component: this,
    //   zone: this.ngZone
    // };
  }

  loginBuildForm(): void {
    this.loginForm = this.formBuilder.group({
      username: ['', [Validators.required, CustomValidator.ValidateEmail]],
      password: ['', [Validators.required]]
    });
  }

  loginSubmit() {
    this.errorMessage = false;
    if (!this.loginForm.valid) {
      this.loginForm.markAllAsTouched();
      this.toastrService.warning(PLEASE_FILL_EMAIL_ID_AND_PASSWORD);
      return;
    }
    const body = {
      username: this.loginForm.value.username,
      password: btoa(this.loginForm.value.password)
    };
    sessionStorage.clear();
    this.isLoading = true;
    this.authService.loginOAuthToken(body).subscribe((resp) => {
      this.isLoading = false;
      this.errorMessage = false;
      this.store$.dispatch(new AuthLoginSuccess(resp.body));
      this.getCommunities();
    }, (err) => {
      if(err.error.error === 'Inactive user '){
        this.isLoading = false;
        this.inactiveMessage = true;
        this.inactiveMsg = err.error.error_description;

      }else if(err.error.error === 'invalid_request'){
        this.isLoading = false;
        this.errorMessage = true;
      }
      this.isLoading = false;

      // this.toastrService.error(INVALID_CREDENTIALS);
    });
  }

  getUserDetails(): void {
    this.isLoading = true;
    this.authService.getUserIdData().subscribe((resp) => {
      // if(resp.status === "approved"){
      this.userId = resp.id;
      this.store$.dispatch(new SetUser(resp));
      this.getUserInfo();
      // }else if(resp.status === "rejected"){
      //   this.toastrService.error('Authorization is denied');
      //   this.router.navigate(['/home']);
      // }else if(resp.status === "pending"){
      //   this.toastrService.error('Authorization is pending');
      //   this.router.navigate(['/home']);
      // }
    }, () => {
      this.isLoading = false;
      this.toastrService.error('Unable to get User id');
    });
  }

  getUserInfo(): void {
    this.studentHelperService.getUserInfo(this.userId).subscribe((res) => {
      this.isLoading = false;
      sessionStorage.setItem("school_name", res.school_name !== null ? res.school_name : "");
      this.store$.dispatch(new SetUserDetail(res));
      if (res.user_type === 'admin') {
        this.router.navigate(['/auth/admin/bulletin-board']);
      } else if(res.user_type === "teacher"){
        this.router.navigate(['/auth/student/home']);
      }else {
        this.screenNavigationProcess(res);
      }
    }, () => {
      this.toastrService.error('Unable to get User info');
      this.isLoading = false;
    });
  }

  
  getCommunities(): void {
    this.studentHelperService.getAllCommunitiesNew().subscribe(res => {
      if(res){
      sessionStorage.setItem('subsribedCommunities',JSON.stringify(res));
      this.getUserDetails();
      }
    })
}

    checkPrefComm(res: any): any {
      const comm = JSON.parse(sessionStorage.getItem('subsribedCommunities')).my_communities.find(x => Number(x.community_id) === Number(res.value))
      if (comm !== undefined && comm.is_competition !== undefined && comm.is_competition === 1) {
        return 1;
      } else {
        return 0;
      }
    }

  screenNavigationProcess(userResponse: any): void {
    if (userResponse.is_email_verified && userResponse.display_name && userResponse.avatar_image_file) {
      if (userResponse.is_temp_passwd === 1) {
        this.modalUtilService.openResetPasswordPopup();
      } else {
        // if (userResponse.preferences[0] !== undefined ? this.checkPrefComm(userResponse.preferences[0]) : false) {
        //   this.router.navigate(['/auth/student/challenge']);
        // } else if (userResponse.preferences[0] === undefined) {
        //   this.router.navigate(['/auth/student/community/join']);
        // }
        // else {
        this.router.navigate(['/auth/student/home']);
      // }
    }
    } else {
      this.router.navigate(['/onboard/confirm-email']);
    }
  }

  ngOnDestroy(): void {
    this.subscriptions.next();
    this.subscriptions.complete();
  }
  // public logMessage(message: string): void {
  //   console.log(`Received message from WebView: ${message}`);
  // }

  // public getJavaScriptInterface(): string {
  //   return `
  //     var MyInterface = {
  //       logMessage: function(message) {
  //         window.angularComponentRef.zone.run(() => {
  //           window.angularComponentRef.component.logMessage(message);
  //         });
  //       }
  //     };
  //     MyInterface;
  //   `;
  // }
}

