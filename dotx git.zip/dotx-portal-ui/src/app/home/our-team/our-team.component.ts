import { Component, OnInit } from '@angular/core';
import Swiper, {Navigation, Pagination} from 'swiper';

@Component({
  selector: 'app-our-team',
  templateUrl: './our-team.component.html',
  styleUrls: ['./our-team.component.scss']
})
export class OurTeamComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

  ngAfterViewInit(): void {
    const swiper = new Swiper('.swiper.swiper-board-members', {
      effect: 'fade',
      slidesPerView: 3,
      fadeEffect: {
        crossFade: true
      },
      modules: [Pagination],
      // Optional parameters
      loop: false,
      freeMode: true,

      keyboard: {
        enabled: true,
        onlyInViewport: false,
      },

      pagination: {
        el: '.swiper-pagination',
        clickable: true,
      },
      breakpoints: {
        0: {
          slidesPerView: 1,
          loop: true,
          spaceBetween: 50,
        },
        576: {
          slidesPerView: 3,
          loop: false,
          spaceBetween: 0,
        },
        1199: {
          loop: false,
          slidesPerView: 3,
          spaceBetween: 0,
        }
      }
    });
  }

}
