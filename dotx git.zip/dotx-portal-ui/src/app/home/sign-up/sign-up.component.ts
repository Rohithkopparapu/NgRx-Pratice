import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { ToastrService } from 'ngx-toastr';
import { StudentHelperService } from 'src/app/modules/student-dashboard/student-helper.service';
import { AuthorizeService } from 'src/app/shared/services/auth.service';
import { HelperService } from 'src/app/shared/services/helper.service';
import { AuthLoginSuccess, SetUser, SetUserDetail } from 'src/app/shared/store/auth.action';
import { AuthState } from 'src/app/shared/store/auth.model';
import {CustomValidator} from '../../shared/services/validators/customValidator';

@Component({
  selector: 'app-sign-up',
  templateUrl: './sign-up.component.html'
})
export class SignUpComponent implements OnInit {
  isLoading: boolean;
  signUpForm: FormGroup;
  showPassword = false;
  showConfPwd = false;
  isJoincodeVerified = false;
  joinCodeDetails: any;
  DOMAIN_REGEX = '/@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*/g';

  constructor(
    private formBuilder: FormBuilder,
    private route: Router,
    private toastrService: ToastrService,
    private studentHelperService: StudentHelperService,
    public _uhs: HelperService,
    private authService: AuthorizeService,
    private store$: Store<AuthState>) { }

  ngOnInit() {
    this.initializeSignUpForm();
    this.signUpForm.get('join_code').valueChanges.subscribe(value => {
      this.isJoincodeVerified = false;
    });
  }

  initializeSignUpForm() {
    // Validators.pattern(
    //   /(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[\d])(?=.*?[^\sa-zA-Z0-9]).{8,}$/
    // )
    this.signUpForm = this.formBuilder.group({
      email: ['', [Validators.required]],
      confirm_email:['',[Validators.required]],
      password: ['', [Validators.required, Validators.minLength(6)]],
      confirm_password: ['', [Validators.required]],
      join_code: ['']
    }, { validators:[ this.checkPassword('password', 'confirm_password') ,
                      this.checkPassword('email', 'confirm_email')]});
  }

  checkPassword(password: string, confirmPassword: string) {
    return (group: FormGroup) => {
      const passwordInput = group.controls[password];
      const passwordConfirmationInput = group.controls[confirmPassword];
      if (passwordInput.value !== passwordConfirmationInput.value) {
        return passwordConfirmationInput.setErrors({ notSame: true });
      } else {
        return passwordConfirmationInput.setErrors(null);
      }
    };
  }

  verifyJoinCode() {
    const joincode = this.signUpForm.get('join_code').value;
    this.isLoading = true;
    this.authService.loginWithJoincode({joincode}).subscribe((resp) => {
      this.isLoading = false;
      if (resp.body['Error']) {
        this.isJoincodeVerified = false;
        this.joinCodeDetails = null;
        this.signUpForm.get('join_code').setValue('');
        this.toastrService.warning(resp.body.Error);
        return;
      } else {
        this.isJoincodeVerified = true;
        this.joinCodeDetails = resp.body;
      }
    }, (err) => {
      this.isLoading = false;
      this.toastrService.error('Invalid details');
    });
  }

  submitSignUpForm() {
    const { email, password, confirm_password } = this.signUpForm.value;
    if (this.signUpForm.value.join_code && !this.isJoincodeVerified) {
      this.toastrService.warning('Please verify Join code');
      return;
    }
    if (!this.signUpForm.valid) {
      this.toastrService.warning('Please fill details');
      return;
    }
    const body = {
      user_email: email,
      new_password: password,
      confirm_password
    };
    const payload = this.isJoincodeVerified ? { ...body, user_id: this.joinCodeDetails.user_id } : body;
    this.isLoading = true;
    this.authService.createUser(payload).subscribe((resp) => {
      if (resp && !resp['error']) {
        this.toastrService.success('Your account has been created successfully');
        this.store$.dispatch(new SetUserDetail(resp));
        const oAuthPayload = {username: email, password};
        this.oAuthLogin(oAuthPayload);
      }
    }, () => {
      this.isLoading = false;
      this.toastrService.error('Invalid details');
    });
  }

  oAuthLogin(payload): void {
    this.isLoading = true;
    this.authService.loginOAuthToken(payload).subscribe((res) => {
      this.store$.dispatch(new AuthLoginSuccess(res.body));
      this.getUserDetails();
    }, () => {
      this.isLoading = false;
    });
  }

  getUserDetails(): void {
    this.isLoading = true;
    this.authService.getUserIdData().subscribe((resp) => {
      this.isLoading = false;
      this.store$.dispatch(new SetUser(resp));
      this.gotoEmailConfirmation();
    }, () => {
      this.isLoading = false;
      this.toastrService.error('Unable to get User id');
    });
  }

  gotoEmailConfirmation(): void {
    this.route.navigate(['/onboard/confirm-email']);
  }
}
