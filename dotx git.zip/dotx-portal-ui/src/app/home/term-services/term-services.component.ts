import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-term-services',
  templateUrl: './term-services.component.html',
  styleUrls: ['./term-services.component.scss']
})
export class TermServicesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
