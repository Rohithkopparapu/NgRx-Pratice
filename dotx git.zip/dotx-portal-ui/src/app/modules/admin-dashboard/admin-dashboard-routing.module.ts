import {NgModule} from '@angular/core';
import {RouterModule, Routes} from '@angular/router';
import {AdminDashboardComponent} from './admin-dashboard.component';
import {HomePanelComponent} from './home-panel/home-panel.component';
import {ChallengeComponent} from './challenge/challenge.component';
import {CreateChallengeComponent} from './challenge/create-challenge/create-challenge.component';
import {QuestComponent} from './quest/quest.component';
import {CreateQuestComponent} from './quest/create-quest/create-quest.component';
import {CommunityComponent} from './community/community.component';
import {CreateCommunityComponent} from './community/create-community/create-community.component';
import {DailyDotsComponent} from './daily-dots/daily-dots.component';
import {AboutUsComponent} from '../../shared/component/about-us/about-us.component';
import {BulletinBoardComponent} from './bulletin-board/bulletin-board.component';
import {CreateBulletinBoardComponent} from './bulletin-board/create-bulletin-board/create-bulletin-board.component';
import { ReportsComponent } from './reports/reports.component';
import {CouponComponent} from './coupon/coupon.component';
import {CreateCouponComponent} from './coupon/create-coupon/create-coupon.component';
import { DotStoreComponent } from './dot-store/dot-store.component';
import { CreateDotStoreComponent } from './dot-store/create-dot-store/create-dot-store.component';
import { SchoolDashboardComponent } from './school-dashboard/school-dashboard.component';
import { RegisterSchoolComponent } from './school-dashboard/register-school/register-school.component';
import { SchoolAdminComponent } from './school-dashboard/school-admin/school-admin.component';
import { UserActionComponent } from './school-dashboard/school-admin/user-action/user-action.component';
import { SubscribeCommunityComponent } from './school-dashboard/subscribe-community/subscribe-community.component';
import { SubscribedCommunityAssignToClassComponent } from './school-dashboard/subscribed-community-assign-to-class/subscribed-community-assign-to-class.component';
const routes: Routes = [
  {
    path: '',
    component: AdminDashboardComponent,
    children: [
      {
        path: 'home',
        component: HomePanelComponent,
      },
      {
        path: 'challenge',
        component: ChallengeComponent,
      },
      {
        path: 'challenge/:type',
        component: CreateChallengeComponent,
      },
      {
        path: 'challenge/:type/:id',
        component: CreateChallengeComponent,
      },
      {
        path: 'quest',
        component: QuestComponent,
      },
      {
        path: 'quest/:type',
        component: CreateQuestComponent,
      },
      {
        path: 'community',
        component: CommunityComponent,
      },
      {
        path: 'community/:type',
        component: CreateCommunityComponent,
      },
      {
        path: 'community/:type/:id',
        component: CreateCommunityComponent,
      },
      {
        path: 'coupon',
        component: CouponComponent,
      },
      {
        path: 'coupon/:type',
        component: CreateCouponComponent,
      },
      {
        path: 'coupon/:type/:id',
        component: CreateCouponComponent,
      },
      {
        path: 'bulletin-board',
        component: BulletinBoardComponent,
      },
      {
        path: 'bulletin-board/:type',
        component: CreateBulletinBoardComponent,
      },
      {
        path: 'bulletin-board/:type/:id',
        component: CreateBulletinBoardComponent,
      },
      {
        path: 'reports',
        component: ReportsComponent,
      },
      {
        path: 'daily-dots',
        component: DailyDotsComponent,
      },
      {
        path: 'about-us',
        component: AboutUsComponent
      },
      {
        path: 'dot-store',
        component: DotStoreComponent
      },
      {
        path: 'dot-store/:type',
        component: CreateDotStoreComponent
      },
      {
        path: 'dot-store/:type/:id',
        component: CreateDotStoreComponent
      },
      {
        path: 'school-reg',
        component: SchoolDashboardComponent
      },
      {
        path: 'school-reg/:type',
        component: RegisterSchoolComponent,
      },
      {
        path: 'school-reg/:type/:id',
        component: RegisterSchoolComponent,
      },
      {
        path: 'schooladmin',
        component: SchoolAdminComponent,
      },
      {
        path: 'schooladmin/user-details',
        component: UserActionComponent,
      },
      {
        path: 'subscribe/:type/:rgid/:sid',
        component: SubscribeCommunityComponent
      },
      {
        path: 'your-plan',
        component: SubscribedCommunityAssignToClassComponent
      },
      // {
      //   path: 'schooladmin/create',
      //   component: UserActionComponent,
      // },
      // {
      //   path: 'schooladmin/:type/:id',
      //   component: UserActionComponent,
      // },
      
    ]
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AdminDashboardRoutingModule { }
