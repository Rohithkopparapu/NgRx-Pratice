import { Component, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';
import { AuthState } from 'src/app/shared/store/auth.model';
import { userInfo } from '../../shared/store/auth.selector';
import { takeUntil } from 'rxjs/operators';
import { Subject } from 'rxjs';

@Component({
  selector: 'app-admin-dashboard',
  templateUrl: './admin-dashboard.component.html'
})
export class AdminDashboardComponent implements OnInit {
  private subscriptions = new Subject<void>();
  isActive:any;
  userInfo: any;
  isShow: boolean=false;
  registrationId: any;
  constructor(private store$: Store<AuthState>) { 
    // this.isActive=localStorage.getItem('tabVal')
    // console.log(this.isActive,"hello");
    this.store$.select(userInfo)
    .pipe(takeUntil(this.subscriptions))
    .subscribe(res => {
      if (res) {
        this.registrationId = res.dot_registration_id;
      }
    });
  }
 
  doSomething(val: any='configTab'):void {
    this.isActive=val? val:'configTab'
    // console.log('Picked date: ', val);
    this.isShow=true
}
showHide(){
  this.isShow=false
}
  ngOnInit() {
    this.isActive='configTab';
    
  }
}
