/* Modules */
import {NgModule} from '@angular/core';
import {SharedModule} from 'src/app/shared/shared.module';
import {NgMultiSelectDropDownModule} from 'ng-multiselect-dropdown';
// import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
/* Components  */
import {AdminDashboardComponent} from './admin-dashboard.component';
import {AdminHeaderComponent} from './header-section/admin-header/admin-header.component';
import {ChallengeComponent} from './challenge/challenge.component';
import {QuestComponent} from './quest/quest.component';
import {DailyDotsComponent} from './daily-dots/daily-dots.component';
import {HomePanelComponent} from './home-panel/home-panel.component';
import {JoinCodesPopupComponent} from './header-section/join-codes-popup/join-codes-popup.component';
import {CommunityComponent} from './community/community.component';
import {CreateCommunityComponent} from './community/create-community/create-community.component';
import {CreateQuestComponent} from './quest/create-quest/create-quest.component';
import {CreateChallengeComponent} from './challenge/create-challenge/create-challenge.component';
import {AdminDashboardRoutingModule} from './admin-dashboard-routing.module';
import {AnnouncementBroadcastComponent} from './header-section/announcement-broadcast/announcement-broadcast.component';
import {CreateUserComponent} from './home-panel/create-user/create-user.component';
import { BulletinBoardComponent } from './bulletin-board/bulletin-board.component';
import { CreateBulletinBoardComponent } from './bulletin-board/create-bulletin-board/create-bulletin-board.component';
import { ReportsComponent } from './reports/reports.component';
import { CouponComponent } from './coupon/coupon.component';
import { CreateCouponComponent } from './coupon/create-coupon/create-coupon.component';
import { ActivitePopupComponent } from './quest/activite-popup/activite-popup.component';
import { LevelCreationPopupComponent } from './quest/level-creation-popup/level-creation-popup.component';
import { DotStoreComponent } from './dot-store/dot-store.component';
import { CreateDotStoreComponent } from './dot-store/create-dot-store/create-dot-store.component';
import { SchoolDashboardComponent } from './school-dashboard/school-dashboard.component';
import { RegisterSchoolComponent } from './school-dashboard/register-school/register-school.component';
import { SchoolAdminComponent } from './school-dashboard/school-admin/school-admin.component';
import { UserActionComponent } from './school-dashboard/school-admin/user-action/user-action.component';
import { ConfirmationPopupComponent } from './school-dashboard/school-admin/confirmation-popup/confirmation-popup.component';
import { SubscribeCommunityComponent } from './school-dashboard/subscribe-community/subscribe-community.component';
import { SubscribedCommunityAssignToClassComponent } from './school-dashboard/subscribed-community-assign-to-class/subscribed-community-assign-to-class.component';
import { StudentActivityInformationComponent } from '../admin-dashboard/activitiy-information/activity-information.component';
import{SearchPipe} from '../../shared/pipes/table-column-search.pipe';
import{EmailSearchPipe} from '../../shared/pipes/table-column-mailsearch.pipe';
import{PhoneSearchPipe} from '../../shared/pipes/table-column-phonesearch.pipe';
import{StatusSearchPipe} from '../../shared/pipes/table-column-statussearch.pipe';
import {ClassSearchPipe} from '../../shared/pipes/table-column-classsearch.pipe'
@NgModule({
  declarations: [
    AdminDashboardComponent,
    AdminHeaderComponent,
    ChallengeComponent,
    QuestComponent,
    DailyDotsComponent,
    HomePanelComponent,
    JoinCodesPopupComponent,
    CommunityComponent,
    CreateCommunityComponent,
    CreateQuestComponent,
    CreateChallengeComponent,
    AnnouncementBroadcastComponent,
    CreateUserComponent,
    BulletinBoardComponent,
    CreateBulletinBoardComponent,
    ReportsComponent,
    CouponComponent,
    CreateCouponComponent,
    ActivitePopupComponent,
    LevelCreationPopupComponent,
    ConfirmationPopupComponent,
    DotStoreComponent,
    CreateDotStoreComponent,
    SchoolDashboardComponent,
    RegisterSchoolComponent,
    SchoolAdminComponent,
    UserActionComponent,
    SubscribeCommunityComponent,
    StudentActivityInformationComponent,
    SubscribedCommunityAssignToClassComponent,
    SearchPipe,
    EmailSearchPipe,
    PhoneSearchPipe,
    StatusSearchPipe,
    ClassSearchPipe],
  imports: [
    SharedModule,
    AdminDashboardRoutingModule,
    NgMultiSelectDropDownModule,
    // NgbModule,
  ],
  entryComponents: [
    CreateUserComponent,
    JoinCodesPopupComponent,
    AnnouncementBroadcastComponent,
    ActivitePopupComponent,
    LevelCreationPopupComponent,
    ConfirmationPopupComponent,
    StudentActivityInformationComponent
  ]
})
export class AdminDashboardModule {
}
