import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import {BehaviorSubject, Observable, throwError} from 'rxjs';
import { catchError } from 'rxjs/operators';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class AdminHelperService {

  private static USER_DETAILS_URL = `${environment.baseURL}/dot-user-details`;
  private static TOPIC_DETAILS_URL = `${environment.baseURL}/dot-topic-details`;
  private static TOPIC_GROUP_URL = `${environment.baseURL}/dot-topic-group`;
  private static COMMUNITY_URL = `${environment.baseURL}/dot-community`;
  private static COMMUNITY_URL_CLONE = `${environment.baseURL}/dot-community/cloneCommunity`;
  private static COMMUNITY_CHILD_URL = `${environment.baseURL}/dot-community-childs`;
  private static QUEST_URL = `${environment.baseURL}/dot-quest-level`;
  private static QUEST_ADD_ACTIVITIES_URL = `${environment.baseURL}/dot-quest-level-activities`
  // private static QUEST_ADD_DELETE_MATERIAL_URL = `${environment.baseURL}/dot-quest-level-activities`
  private static QUEST_ActiviyList_URL = `${environment.baseURL}/dot-quest-activity`;
  private static ANNOUNCEMENT_URL = `${environment.baseURL}/dot-announcements`;
  private static REPORT_URL = `${environment.baseURL}/dot-ajax`;
  private static NOTIFICATION_URL = `${environment.baseURL}/dot-notifications`;
  private static COUPON_URL = `${environment.baseURL}/dot-discount-coupons`;
  private static QUESTLEVELS_URL = `${environment.baseURL}/dot-quest-level`;
  private static DOTSTORE_URL = `${environment.baseURL}/dot-store-category`;
  private static DOTSTORE_ITEM_URL = `${environment.baseURL}/dot-store-item`;
  private static DOTSTORE_REG_SCHOOL_URL = `${environment.baseURL}/dot-registration`;
  private static EXCEL_URL = `${environment.baseURL}/dot-user-details`;
  private static SUBSCRIPTION_URL = `${environment.baseURL}/dot-subscription`;
  private static SAVE_SUBSCRIPTION_URL = `${environment.baseURL}/dot-subscription-details`;
  isLoading$ = new BehaviorSubject<boolean>(false);

  constructor(public http: HttpClient) { }

  public isAuthenticated(): boolean {
    const userInfo = sessionStorage.getItem('userInfo');
    return (userInfo && userInfo['user_type'] === 'admin');
  }

  public setLoading(value: boolean): void {
    this.isLoading$.next(value);
  }

  public getLoading(): Observable<boolean> {
    return this.isLoading$.asObservable();
  }

  /* User Tab services */

  getUsers(): Observable<any> {
    return this.http.get(AdminHelperService.USER_DETAILS_URL);
  }

  getAdminUsersByFilter(payload): Observable<any> {
    const url = `${AdminHelperService.USER_DETAILS_URL}/filter`;
    return this.http.post(url, payload);
  }

  updateUserRecords(data: any): Observable<any> {
    return this.http.put(AdminHelperService.USER_DETAILS_URL, data).pipe(catchError(err => throwError(err)));
  }

  saveRecord(data: any): Observable<any> {
    return this.http.post(AdminHelperService.USER_DETAILS_URL, data).pipe(catchError(err => throwError(err)));
  }

  delete(id: number): Observable<any> {
    return this.http.delete(`${AdminHelperService.USER_DETAILS_URL}/${id}`);
  }

  /* Challenge Tab services */

  getChallengesList(): Observable<any> {
    const url = `${AdminHelperService.TOPIC_DETAILS_URL}/filter`;
    return this.http.post(url, { topic_type: 'Challenge' });
  }

  getChallengesByFilter(payload, page): Observable<any> {
    const url = `${AdminHelperService.TOPIC_DETAILS_URL}/filter?page=${page}&per_page=10`;
    return this.http.post(url, payload);
  }

  saveChallengeData(data: any): Observable<any> {
    const url = `${AdminHelperService.TOPIC_DETAILS_URL}/create_challenge`;
    return this.http.post(url, data).pipe(catchError(err => throwError(err)));
  }

  updateChallenge(data: any): Observable<any> {
    const url = `${AdminHelperService.TOPIC_DETAILS_URL}/update_challenge`;
    return this.http.put(url, data).pipe(catchError(err => throwError(err)));
  }

  deleteChallenge(id: any): Observable<any> {
    return this.http.delete(`${AdminHelperService.TOPIC_DETAILS_URL}/${id}`);
  }

  getBuddiesList(): Observable<any> {
    const url = `${AdminHelperService.USER_DETAILS_URL}/filter`;
    return this.http.post(url, { user_type: 'student' });
  }

  getTopicDetailsById(id: number): Observable<any> {
    const url = `${AdminHelperService.TOPIC_DETAILS_URL}/edit/${id}`;
    return this.http.get(url);
  }

  /* Group services */

  getGroupsList(): Observable<any> {
    return this.http.post(AdminHelperService.TOPIC_GROUP_URL + '/filter', {});
  }

  saveGroup(data: any): Observable<any> {
    const url = `${AdminHelperService.TOPIC_GROUP_URL}/create_challenge_group`;
    return this.http.post(url, data).pipe(catchError(err => throwError(err)));
  }

  updateGroup(data: any): Observable<any> {
    const url = `${AdminHelperService.TOPIC_GROUP_URL}/update_challenge_group`;
    return this.http.put(url, data).pipe(catchError(err => throwError(err)));
  }

  deleteGroup(id: any): Observable<any> {
    return this.http.delete(`${AdminHelperService.TOPIC_GROUP_URL}/${id}`);
  }

  /* Create && update Group services */

  getGroupData(id: number) {
    const url = `${AdminHelperService.TOPIC_GROUP_URL}/${id}`;
    return this.http.get(url);
  }

  generateJoinCodes(payload): Observable<any> {
    const url = `${AdminHelperService.USER_DETAILS_URL}/generate_joincodes`;
    return this.http.post(url, payload);
  }

  /* Community services */

  getAllCommunities(): Observable<any> {
    const url = `${AdminHelperService.COMMUNITY_URL}`;
    return this.http.get(url);
  }

  getCommunitiesByFilter(payload): Observable<any> {
    const url = `${AdminHelperService.COMMUNITY_URL}/filter`;
    return this.http.post(url, payload);
  }

  deleteCommunityById(communityId): Observable<any> {
    const url = `${AdminHelperService.COMMUNITY_URL}/${communityId}`;
    return this.http.delete(url);
  }

  getCommunityById(communityId): Observable<any> {
    const url = `${AdminHelperService.COMMUNITY_URL}/${communityId}`;
    return this.http.get(url);
  }

  saveCommunity(payload): Observable<any> {
    const url = `${AdminHelperService.COMMUNITY_URL}`;
    return this.http.post(url, payload);
  }

  updateCommunity(payload): Observable<any> {
    const url = `${AdminHelperService.COMMUNITY_URL}`;
    return this.http.put(url, payload);
  }
  cloneCommunity(paylod:any): Observable<any>{
    const url = `${AdminHelperService.COMMUNITY_URL_CLONE}/${paylod}`;
    return this.http.get(url);
  }
  /* Community Child Services */

  getCommunityChildById(communityChildId): Observable<any> {
    const url = `${AdminHelperService.COMMUNITY_CHILD_URL}/${communityChildId}`;
    return this.http.get(url);
  }

  saveCommunityChild(payload): Observable<any> {
    const url = `${AdminHelperService.COMMUNITY_CHILD_URL}`;
    return this.http.post(url, payload);
  }

  updateCommunityChild(payload): Observable<any> {
    const url = `${AdminHelperService.COMMUNITY_CHILD_URL}`;
    return this.http.put(url, payload);
  }

  /* Broadcast services */

  createAnnouncement(payload): Observable<any> {
    const url = `${AdminHelperService.NOTIFICATION_URL}/create_announcements`;
    return this.http.post(url, payload);
  }

  /* Bulletin Board services */

  getBulletinBoardList(page,per_page,name): Observable<any> {
    const url = `${AdminHelperService.ANNOUNCEMENT_URL}?name=${name}&page=${page}&per_page=${per_page}`;
    return this.http.get(url);
  }

  saveBulletin(data: any): Observable<any> {
    const url = `${AdminHelperService.ANNOUNCEMENT_URL}`;
    return this.http.post(url, data).pipe(catchError(err => throwError(err)));
  }

  updateBulletin(data: any): Observable<any> {
    const url = `${AdminHelperService.ANNOUNCEMENT_URL}`;
    return this.http.put(url, data).pipe(catchError(err => throwError(err)));
  }

  getBulletinBoardDetailsById(id: number): Observable<any> {
    const url = `${AdminHelperService.ANNOUNCEMENT_URL}/${id}`;
    return this.http.get(url);
  }

  deleteBulletinById(id: number): Observable<any> {
    const url = `${AdminHelperService.ANNOUNCEMENT_URL}/${id}`;
    return this.http.delete(url);
  }

  /* Report services */

  getReportBy(query): Observable<any> {
    const url = `${AdminHelperService.REPORT_URL}/${query}`;
    return this.http.get(url);
  }


  /* Coupon Code services */

  getCouponCodesList(): Observable<any> {
    const url = `${AdminHelperService.COUPON_URL}`;
    return this.http.get(url);
  }

  saveCouponCode(data: any): Observable<any> {
    const url = `${AdminHelperService.COUPON_URL}`;
    return this.http.post(url, data).pipe(catchError(err => throwError(err)));
  }

  updateCouponCode(data: any): Observable<any> {
    const url = `${AdminHelperService.COUPON_URL}`;
    return this.http.put(url, data).pipe(catchError(err => throwError(err)));
  }

  getCouponCodesById(id: number): Observable<any> {
    const url = `${AdminHelperService.COUPON_URL}/${id}`;
    return this.http.get(url);
  }

  deleteCouponCodeById(id: number): Observable<any> {
    const url = `${AdminHelperService.COUPON_URL}/${id}`;
    return this.http.delete(url);
  }

  
  // ------------------------- QUEST Info ----------------------------
  
  questLevelsLists( id:any): Observable<any>{
    const url = `${AdminHelperService.QUEST_URL}/levels-list/${id}`;
    return this.http.get(url);
  }

  saveLevelData(payload:any): Observable<any>{
    const url = `${AdminHelperService.QUEST_URL}/create-levels`;
    return this.http.post(url, payload);
  }

  deleteLevelData(id:number): Observable<any>{
    const url = `${AdminHelperService.QUEST_URL}/${id}`;
    return this.http.delete(url);
  }

  getActivityList():Observable<any>{
    const url= `${AdminHelperService.QUEST_ActiviyList_URL}`
    return this.http.get(url);
  }

  addActivities(payload):Observable<any>{
    const url= `${AdminHelperService.QUEST_ADD_ACTIVITIES_URL}/create-activities`;
    return this.http.post(url, payload);
  }

  deleteActivities(id):Observable<any>{
    const url= `${AdminHelperService.QUEST_ADD_ACTIVITIES_URL}/${id}`;
    return this.http.delete(url);
  }

  updateLevel(data:any):Observable<any>{
    const url= `${AdminHelperService.QUEST_URL}/update-levels`;
    return this.http.put(url, data);
  }

  deleteMaterial(payload):Observable<any>{
    const url= `${AdminHelperService.QUEST_URL}/delete-level-attachment`;
    return this.http.post(url, payload);
  }
  updateActivitydata(data:any){
    const url = `${AdminHelperService.QUEST_ADD_ACTIVITIES_URL}/update-activities`;
    return this.http.put(url, data);
  }

  getQuestLevelsById(id: number): Observable<any>{

    const url = `${AdminHelperService.QUESTLEVELS_URL}/levels-list/${id}`;

    return this.http.get(url)

    }

    //=================== Dot-Store ==============
    getDotStoreCatDetails(params): Observable<any>{
      const url =`${AdminHelperService.DOTSTORE_URL}/categoryInfo`;
      return this.http.get(url);
    }
    addDotStoreCategory(payload): Observable<any>{
      const url = `${AdminHelperService.DOTSTORE_URL}/create-category`;
      return this.http.post(url, payload);
    }
    updateDotstoreCategory(payload): Observable<any>{
      const url = `${AdminHelperService.DOTSTORE_URL}/update-category`;
      return this.http.put(url, payload)
    }
    addDotStoreItem(payload): Observable<any>{
      const url= `${AdminHelperService.DOTSTORE_ITEM_URL}/create-item`;
      return this.http.post(url, payload);
    }

    updateDotstoreItem(payload): Observable<any>{
      const url = `${AdminHelperService.DOTSTORE_ITEM_URL}/update-item`;
      return this.http.put(url,payload);
    }

    getListOfItems(id:number):Observable<any>{
      const url = `${AdminHelperService.DOTSTORE_ITEM_URL}/single-item-list/${id}`;
      return this.http.get(url);
    }
  
    // getTotalListOfItems(payload):Observable<any>{
    //   const url = `${AdminHelperService.DOTSTORE_ITEM_URL}/items-list`;
    //   return this.http.post(url,payload);
    // }
    getAllItemsList(payload):Observable<any>{
      const url = `${AdminHelperService.DOTSTORE_ITEM_URL}/all-item-list/${payload.category_id}`;
      return this.http.get(url);
    }
    deleteCategoryById(categoryId): Observable<any> {
      const url = `${AdminHelperService.DOTSTORE_URL}/delete-category/${categoryId}`;
      return this.http.delete(url);
    }

    deleteItemById(itemId): Observable<any>{
      const url = `${AdminHelperService.DOTSTORE_ITEM_URL}/delete-item/${itemId}`;
      return this.http.delete(url);
    }
    // ----------School Registration-------------
    // DOTSTORE_REG_SCHOOL_URL
    addSchool(payload): Observable<any>{
      const url= `${AdminHelperService.DOTSTORE_REG_SCHOOL_URL}`;
      return this.http.post(url, payload);
    }

    updateSchool(payload): Observable<any>{
      const url = `${AdminHelperService.DOTSTORE_REG_SCHOOL_URL}`;
      return this.http.put(url,payload);
    }
    getSchool(payload): Observable<any>{
      const url = `${AdminHelperService.DOTSTORE_REG_SCHOOL_URL}`;
      return this.http.get(url);
    }
    getSchoolPage(page,per_page): Observable<any>{
      const url = `${AdminHelperService.DOTSTORE_REG_SCHOOL_URL}?page=${page}&per_page=${per_page}`;
      return this.http.get(url);
    }
    getSchoolbyId(payload): Observable<any>{
      const url = `${AdminHelperService.DOTSTORE_REG_SCHOOL_URL}/${payload}`;
      return this.http.get(url);
    }

    getAllList(payload): Observable<any>{
      const url = `${AdminHelperService.USER_DETAILS_URL}/similar-school/${payload}`;
      return this.http.get(url);
    }
    getSchoolsList(payload): Observable<any>{
      const url = `${AdminHelperService.DOTSTORE_REG_SCHOOL_URL}/${payload}`;
      return this.http.get(url);
    }

    getSchoolsListForSuperAdmin(payload): Observable<any>{
      const url = `${AdminHelperService.DOTSTORE_REG_SCHOOL_URL}`;
      return this.http.get(url);
    }

    authorizeRequest(payload): Observable<any>{
      const url= `${AdminHelperService.USER_DETAILS_URL}/authorize`;
      return this.http.post(url, payload); 
    }

    getAllTeacherStudentList(payload): Observable<any>{
      const url = `${AdminHelperService.USER_DETAILS_URL}/approved-userslist/${payload}`;
      return this.http.get(url);
    }
    // creating the school users by school admin
    addBulkUserDetails(payload): Observable<any> {
      const url = `${AdminHelperService.USER_DETAILS_URL}/bulk-user-registration`;
      return this.http.post(url, payload);
    }
  //  --------------------------upload Excel data------------------------------
  addExcelFile(payload): Observable<any> {
    const url = `${AdminHelperService.EXCEL_URL}`;
    return this.http.post(url, payload);
  }
  // subscription model
  saveSubscription(data: any): Observable<any> {
    const url = `${AdminHelperService.SUBSCRIPTION_URL}`;
    return this.http.post(url, data).pipe(catchError(err => throwError(err)));
  }

  saveSubscriptionEdit(data: any): Observable<any> {
    const url = `${AdminHelperService.SUBSCRIPTION_URL}`;
    return this.http.put(url, data).pipe(catchError(err => throwError(err)));
  }

  getSubscribeCommunityData(reg_id,s_id): Observable<any>{
    let url = ``;
    if(reg_id === "" && s_id !== "" ){
       url = `${AdminHelperService.SUBSCRIPTION_URL}/subscriptionList?subscription_id=${s_id}`;
    }else if(reg_id !== "" && s_id === ""){
       url = `${AdminHelperService.SUBSCRIPTION_URL}/subscriptionList?dot_registration_id=${reg_id}`;
    }else if(reg_id !== "" && s_id !== ""){
       url = `${AdminHelperService.SUBSCRIPTION_URL}/subscriptionList?subscription_id=${s_id}&dot_registration_id=${reg_id}`;
    }
    return this.http.get(url);
  }
  //-----------------saving subscription--------
  saveSubscriptionGrade(data: any): Observable<any> {
    const url = `${AdminHelperService.SAVE_SUBSCRIPTION_URL}`;
    return this.http.post(url, data).pipe(catchError(err => throwError(err)));
  }
  getSubscriptionGrade(data: any): Observable<any> {
    const url = `${AdminHelperService.SAVE_SUBSCRIPTION_URL}`;
    return this.http.get(url).pipe(catchError(err => throwError(err)));
  }
  updateSubscriptionGrade(data: any): Observable<any> {
    const url = `${AdminHelperService.SAVE_SUBSCRIPTION_URL}`;
    return this.http.put(url,data).pipe(catchError(err => throwError(err)));
  }

  getClassSubscription(data: any): Observable<any> {
    const url = `${AdminHelperService.SAVE_SUBSCRIPTION_URL}/filterBysubscriptionId?subscription_id=${data}`;
    return this.http.get(url).pipe(catchError(err => throwError(err)));
  }
  
}
