import {Component, OnInit} from '@angular/core';
import {Router} from '@angular/router';
import {NgbModal, NgbModalOptions} from '@ng-bootstrap/ng-bootstrap';
import {ToastrService} from 'ngx-toastr';
import {DeleteComponent} from 'src/app/shared/component/delete/delete.component';
import {AdminHelperService} from '../admin-helper.service';
import {SUCCESS_MESSAGE} from 'src/app/shared/constants/constant';
import {HelperService} from '../../../shared/services/helper.service';
import {AnnouncementResponsesComponent} from '../../../shared/component/announcement-responses/announcement-responses.component';

@Component({
  selector: 'app-bulletin-board',
  templateUrl: './bulletin-board.component.html',
  styleUrls: ['./bulletin-board.component.scss']
})
export class BulletinBoardComponent implements OnInit {

  userResponse: any;
  bulletinBoardList: [];
  searchChallenge = '';
  dateFormatKeys = ['start_date', 'end_date'];
  pageSearch = 1;
  selectedFilter = 'Last 6 Months';
  isLoading: boolean;
  page=1
  perpage: any=10;

  ngbModalOptions: NgbModalOptions = {
    backdrop: 'static',
    keyboard: false,
    size: 'xl'
  };
  number_of_records: any;

  constructor(
    private router: Router,
    private service: AdminHelperService,
    private modalService: NgbModal,
    private toastrService: ToastrService,
    private _uhs: HelperService
  ) {
  }

  ngOnInit() {
    this.loadBulletinBoard(this.page);
  }

  loadBulletinBoard(page) {
    this.isLoading = true;
    // this.resetValues();
    // this.bulletinBoardList = [];
    this.service.getBulletinBoardList(page, this.perpage, this.searchChallenge).subscribe(res => {
      this.isLoading = false;
      if(res){
        this.bulletinBoardList = res[0];
        this.number_of_records=res[1].number_of_records;
      }
      
    }, err => this.isLoading = false);
  }

  onNew(): void {
    this.router.navigate(['/auth/admin/bulletin-board', 'create']);
  }

  onEdit(bulletin: any): any  {
    this.router.navigate(['/auth/admin/bulletin-board/', 'edit', bulletin.id]);
  }

  onView(bulletin: any): any {
    const modelRef = this.modalService.open(AnnouncementResponsesComponent, {
      centered: true,
      scrollable: true,
      backdrop: 'static',
      size: 'xl',
      windowClass: 'modal-challenge'
    });
    modelRef.componentInstance.data = bulletin;
    modelRef.componentInstance.userType = 'admin';
  }

  onDelete(bulletinId: any) {
    const deleteModelRef = this.modalService.open(DeleteComponent, { centered: true, backdrop: 'static' });
    deleteModelRef.componentInstance.message = 'Are you sure you want to delete this Announcement?';
    deleteModelRef.result.then((res) => {
      if (res) {
        this.deleteRecord(bulletinId);
      }
    }, (reason) => {
      if (reason) {
        this.deleteRecord(bulletinId);
      }
    });
  }

  deleteRecord(bulletinId: number): any {
    this.isLoading = true;
    this.service.deleteBulletinById(bulletinId).subscribe(res => {
      this.isLoading = false;
      if (res) {
        this.toastrService.success(`Bulletin ${SUCCESS_MESSAGE.RECORD_DELETED}`);
        this.loadBulletinBoard(this.page);
      }
    }, err => this.isLoading = false);
  }

  resetValues() {
    this.bulletinBoardList = [];
    this.pageSearch = 1;
  }

  setSearchValue($event: any): void {
    this.searchChallenge = $event;
    this.loadBulletinBoard(this.page);
  }

  // onChangeFilter(value): void {
  //   this.selectedFilter = value;
  //   this.loadBulletinBoard();
  // }

  onPageChange(offset: number) {
    console.log(offset);
    // this.page = offset;
    this.loadBulletinBoard(offset)
  }
}

