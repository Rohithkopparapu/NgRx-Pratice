import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CreateBulletinBoardComponent } from './create-bulletin-board.component';

describe('CreateBulletinBoardComponent', () => {
  let component: CreateBulletinBoardComponent;
  let fixture: ComponentFixture<CreateBulletinBoardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CreateBulletinBoardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CreateBulletinBoardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
