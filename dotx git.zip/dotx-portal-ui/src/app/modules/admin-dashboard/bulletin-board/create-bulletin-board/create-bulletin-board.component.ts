import {Component, OnInit} from '@angular/core';
import {FormBuilder, Validators} from '@angular/forms';
import {ActivatedRoute, Router} from '@angular/router';
import {ERROR_MESSAGE, SUCCESS_MESSAGE} from '../../../../shared/constants/constant';
import {HelperService} from '../../../../shared/services/helper.service';
import { ToastrService } from 'ngx-toastr';
import {NgbModal} from '@ng-bootstrap/ng-bootstrap';
import {AdminHelperService} from '../../admin-helper.service';
import {FileUploadComponent} from '../../../../shared/component/file-upload/file-upload.component';
import {ImageVideoViewComponent} from '../../../../shared/component/image-video-view/image-video-view.component';
import { takeUntil } from 'rxjs/operators';
import { userInfo } from 'src/app/shared/store/auth.selector';
import { AuthState } from 'src/app/shared/store/auth.model';
import { Store } from '@ngrx/store';
import { Subject } from 'rxjs';
import { IDropdownSettings } from 'ng-multiselect-dropdown';

@Component({
  selector: 'app-create-bulletin-board',
  templateUrl: './create-bulletin-board.component.html',
  styleUrls: ['./create-bulletin-board.component.scss']
})
export class CreateBulletinBoardComponent implements OnInit {
  private subscriptions = new Subject<void>();
  isLoading = false;
  bulletinForm = this.fb.group({
    name: ['', [Validators.required]],
    description: ['', [Validators.required]],
    start_date: ['', [Validators.required]],
    end_date: ['', [Validators.required]],
    is_pinned: [true],
    is_comments_enabled: [true],
    thumbnail_image: [''],
    original_image: [''],
    video: [''],
    status: ['', [Validators.required]],
    categories:[''],
    dot_registration_ids:[]
  });
  bulletInBoardData: any;
  isSaving: boolean;
  setStartMinDate: any;
  setEndMinDate: any;
  bulletinId: any;
  backButton = 'Create a Bulletin';
  isDisabled = false;
  userInfo: any;
  schoolsList: any;
  SINGLE_DROPDOWN_SETTINGS: IDropdownSettings = {
    singleSelection: true,
    idField: 'id',
    textField: 'name',
    // selectAllText: 'Select All',
    // unSelectAllText: 'UnSelect All',
    // enableCheckAll: true,
    // itemsShowLimit: 2,
    allowSearchFilter: true,
    closeDropDownOnSelection: true
  };
  responsiblityList: any[];
  schoolList: any;
  selectedItems: any = [];
  mandateSchool: boolean = false;
  constructor(private fb: FormBuilder, public _uhs: HelperService, private toastrService: ToastrService,
              private modalService: NgbModal, private adminHelperService: AdminHelperService, private router: Router,
              private route: ActivatedRoute,
              private store$: Store<AuthState>) {
      this.store$.select(userInfo)
      .pipe(takeUntil(this.subscriptions))
      .subscribe(res => {
        if (res) {
          this.userInfo = res;
        }
      });
      this.getSchoolsData();
  }
  

  ngOnInit() {
    this.setStartMinDate = this._uhs.getSpotlightFormattedStartMinDate();
    if (this.route.snapshot.paramMap.get('type') === 'edit') {
      this.bulletinId = this.route.snapshot.paramMap.get('id');
      this.backButton = 'Update a Bulletin';
      this.getBulletInDetailsById();
    }
    if(this.userInfo.dot_registration_id === null){
      this.bulletinForm.get('categories').setValidators([Validators.required]);
      this.bulletinForm.get('categories').updateValueAndValidity();
    }else{
      this.bulletinForm.get('categories').clearValidators();
      this.bulletinForm.get('categories').updateValueAndValidity();
    }
    // this.getSchoolList();
  }

  getBulletInDetailsById(): void {
    this.isLoading = true;
    this.adminHelperService.getBulletinBoardDetailsById(this.bulletinId).subscribe(res => {
      this.isLoading = false;
      if (res) {
        this.bulletInBoardData = res;
        this.updateForm(res);
      }
    }, err => this.isLoading = false);
  }

  onChangeSchool(){
    if(this.bulletinForm.controls['categories'].value === "B2B"){
      this.mandateSchool = true;
      this.bulletinForm.get('dot_registration_ids').setValidators([Validators.required]);
      this.bulletinForm.get('dot_registration_ids').updateValueAndValidity();
    }else{
      this.mandateSchool = false;
      this.bulletinForm.get('dot_registration_ids').setValue(null);
      this.bulletinForm.get('dot_registration_ids').clearValidators();
      this.bulletinForm.get('dot_registration_ids').updateValueAndValidity();
    }
  }

  updateForm(res): void {
    const today = new Date().toISOString().slice(0, 10);
    this.getSchoolsData();

    this.bulletinForm.patchValue({
      name: res.name,
      description:  res.description,
      start_date: res.start_date ? this._uhs.getFormattedDateForAdminChall(res.start_date) : '',
      end_date: res.end_date ? this._uhs.getFormattedDateForAdminChall(res.end_date) : '',
      is_pinned:  res.is_pinned,
      is_comments_enabled : res.is_comments_enabled,
      thumbnail_image: res.thumbnail_image,
      original_image: res.original_image,
      video: res.video,
      status: res.status,
      categories:res.categories
      // dot_registration_ids: obj,
    });
    if(res.categories === "B2B"){
      this.mandateSchool = true;
    }else{
      this.mandateSchool = false;
    }
    if (this.userInfo.dot_registration_id !== null) {
      this.isLoading = true;
      this.adminHelperService.getSchoolsList(this.userInfo.dot_registration_id).subscribe(result => {
        this.schoolsList = this.userInfo.details.responsibilities;
        this.isLoading = false;
       this.selectedItems= this.schoolsList.filter(x => x.id === res.dot_registration_ids);    

      })
    } else {
      const payload={}
      this.adminHelperService.getSchoolsListForSuperAdmin(payload).subscribe(result => {
        this.schoolsList = result.sort((a, b) => a.name.localeCompare(b.name));
       this.selectedItems= this.schoolsList.filter(x => x.id === res.dot_registration_ids);    

      })
    }


    if(res.responsiblity){
      this.responsiblityList=[]
      const payload ={}
      this.adminHelperService.getSchool(payload).subscribe(result => {
        if (result) {
          this.schoolList = result.sort((a, b) => a.name.localeCompare(b.name));
          this.responsiblityList= this.schoolList.filter(i=>i.id != this.userInfo.dot_registration_id)
          const arr = []
          const itemdata = res.responsibilities;
          itemdata.forEach(element => {
            const obj=[] = this.responsiblityList.find(x => x.id == element);
            arr.push(obj);
          });
          this.selectedItems = arr;
        }
      }, err => this.isLoading = false);
    }
    if (res.start_date && res.start_date.slice(0, 10) < today) {
      this.setStartMinDate = this._uhs.getFormattedDateForAdminChall(res.start_date);
      this.isDisabled = true;
    }
  }

  submitForm() {
    if (this.bulletinForm.valid) {
      // const {responsibilities}=this.bulletinForm.value
      const bulletinFormData = this.processPayload();
      if (bulletinFormData['video'] === '' && bulletinFormData['original_image'] === '') {
        this.toastrService.warning('Please Upload an image/video');
        return;
      }
      if (!this.bulletinId) {
        this.isSaving = true;
        this.adminHelperService.saveBulletin(bulletinFormData).subscribe(result => {
          this.isSaving = false;
          if (result) {
            this.toastrService.success(SUCCESS_MESSAGE.RECORD_ADDED);
            this.router.navigate(['/auth/admin/bulletin-board']);
          }
        }, err => this.isSaving = false);
      } else {
        const payload = {
          id: this.bulletinId,
          ...bulletinFormData
        };
        this.isSaving = true;
        this.adminHelperService.updateBulletin(payload).subscribe(result => {
          this.isSaving = false;
          if (result) {
            this.toastrService.success(SUCCESS_MESSAGE.RECORD_UPDATED);
            this.router.navigate(['/auth/admin/bulletin-board']);
          }
        }, err => this.isSaving = false);
      }
    } else {
      this.toastrService.warning(ERROR_MESSAGE.FIELDS_REQUIRED);
      this._uhs.validateAllFormFields(this.bulletinForm);
    }
  }

  uploadDocument(type: string, title: string, fileCategory: any) {
    const modalData = {
      headerName: title,
      fileType: type,
      fileCategory,
      isMultipleFile: false
    };

    const modalRef = this.modalService.open(FileUploadComponent, {
      keyboard: false,
      backdrop: 'static',
      scrollable: true,
      windowClass: 'modal-cover modal-cover-fluid modal-upload'
    });
    modalRef.componentInstance.data = modalData;
    modalRef.result.then((res) => {
      // console.log(res);
    }, (reason) => {
      if (reason) {
        // console.log(reason);
        if (reason) {
          this.setFileName(reason, fileCategory);
          this.bulletinForm.markAsTouched({ onlySelf: true });
        }
      }
    });
  }

  setFileName(res: any, title: string): void {
    if (res && res.length) {
      if (title === 'bulletin_image') {
        this.bulletinForm.get('original_image').setValue(res[0].fileUrl);
      } else if (title === 'bulletin_video') {
        this.bulletinForm.get('video').setValue(res[0].fileUrl);
      }
    }
  }

  deleteFile(event: Event, type: string) {
    event.stopPropagation();
    this.bulletinForm.markAsTouched({ onlySelf: true });
    if (type === 'bulletin_image') {
      this.bulletinForm.get('original_image').setValue('');
    } else if (type === 'bulletin_video') {
      this.bulletinForm.get('video').setValue('');
    }
  }

  openViewerModel(type: string, url: string): void {
    const modalRef = this.modalService.open(ImageVideoViewComponent, {
      centered: true,
      size: 'lg'
    });
    modalRef.componentInstance.fileType = type;
    modalRef.componentInstance.fileUrl = url;
  }

  setEndDate(event: any) {
    this.setEndMinDate = this._uhs.getSpotlightFormattedEndMinDate(event, 1);
  }

  processPayload() {
    const bulletinForm = JSON.parse(JSON.stringify(this.bulletinForm.getRawValue()));
    bulletinForm.start_date = this._uhs.getFormattedDateToBind(bulletinForm.start_date);
    bulletinForm.end_date = this._uhs.getFormattedDateToBind(bulletinForm.end_date);
    bulletinForm.is_pinned  = bulletinForm.is_pinned  ? 1 : 0;
    if (this.bulletinForm.controls['dot_registration_ids'].value !== null) {
      if (this.bulletinForm.controls['dot_registration_ids'].value.length !== 0) {
        bulletinForm.dot_registration_ids = this.bulletinForm.controls['dot_registration_ids'].value[0].id;
      } else {
        bulletinForm.dot_registration_ids = null;
      }
    }else{
      bulletinForm.dot_registration_ids = this.userInfo.dot_registration_id;
    }
    bulletinForm.is_comments_enabled = bulletinForm.is_comments_enabled ? 1 : 0;
    if(this.userInfo.dot_registration_id !== null){
      bulletinForm['categories'] = "B2B"
    }
    return bulletinForm;
  }

  getSchoolsData() {
    if (this.userInfo.dot_registration_id !== null) {
      this.isLoading = true;
      this.adminHelperService.getSchoolsList(this.userInfo.dot_registration_id).subscribe(result => {
        this.schoolsList = this.userInfo.details.responsibilities;
        this.isLoading = false;
      })
    } else {
      const payload={}
      this.adminHelperService.getSchoolsListForSuperAdmin(payload).subscribe(result => {
        this.schoolsList = result.sort((a, b) => a.name.localeCompare(b.name));;
      })
    }
  }
  
}
