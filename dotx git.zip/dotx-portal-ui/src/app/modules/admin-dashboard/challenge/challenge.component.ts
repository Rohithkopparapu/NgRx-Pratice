import {AfterContentChecked, ChangeDetectionStrategy, ChangeDetectorRef, Component, OnDestroy, OnInit} from '@angular/core';
import {Router} from '@angular/router';
import {NgbModal, NgbModalOptions} from '@ng-bootstrap/ng-bootstrap';
import {ToastrService} from 'ngx-toastr';
import {DeleteComponent} from 'src/app/shared/component/delete/delete.component';
import {AdminHelperService} from '../admin-helper.service';
import {SUCCESS_MESSAGE} from 'src/app/shared/constants/constant';
import {Store} from '@ngrx/store';
import {AuthState} from '../../../shared/store/auth.model';
import { SoloChallengeModelComponent } from '../../../shared/component/solo-challenge-model/solo-challenge-model.component';
import { GroupChallengeModelComponent } from '../../../shared/component/group-challenge-model/group-challenge-model.component';
import {ChallengeViewTab} from '../../../shared/store/auth.action';
import {HelperService} from '../../../shared/services/helper.service';
import {Subject} from 'rxjs';
import {takeUntil} from 'rxjs/operators';
import {challengeView, userResponse} from '../../../shared/store/auth.selector';
import { FormBuilder, FormGroup} from '@angular/forms';


@Component({
  changeDetection: ChangeDetectionStrategy.OnPush,
  selector: 'app-challenge',
  templateUrl: './challenge.component.html'
})
export class ChallengeComponent implements OnInit, AfterContentChecked, OnDestroy {
  private subscriptions = new Subject<void>();
  userResponse: any;
  challengesList: any[] = [];
  searchChallenge = '';
  dateFormatKeys = ['created_date'];
  page =1;
  pageSearch = 1;
  userName: any;
  selectedFilter = 'Last 6 Months';
  selectedChallengeView = 'Created By Admin';
  isLoading: boolean;
  communitiesList: any = [];
  searchForm: FormGroup;

  ngbModalOptions: NgbModalOptions = {
    backdrop: 'static',
    keyboard: false,
    size: 'xl'
  };
  communitiesListB2B: any =[];
  communitiesListB2C: any =[];
  communitiesListCommon :any =[];
  communityinformation:any;
  levelsList: any =[];
  total_record: any;

  constructor(
    private router: Router,
    private service: AdminHelperService,
    private modalService: NgbModal,
    private toastrService: ToastrService,
    private cdr: ChangeDetectorRef,
    private store$: Store<AuthState>,
    private _uhs: HelperService,
    private fb: FormBuilder,
    
  ) {
    this.store$.select(userResponse)
      .pipe(takeUntil(this.subscriptions))
      .subscribe(res => this.userResponse = res);
    this.store$.select(challengeView)
      .pipe(takeUntil(this.subscriptions))
      .subscribe(res => this.selectedChallengeView = res);
  }

  ngOnInit() {
    this.userName = this.userResponse.username;
    // this.loadChallenges();
    this.getCommunities();
    this.createForm();
  }

  createForm() {
    this.searchForm = this.fb.group({
      community_id:[''],
      type:[''],
      Category:["B2B"],
      challengeSearch:[''],
      level:[''],
      status:['']
    });
  }

  search(){
    this.loadChallenges();
  }

  ngAfterContentChecked() {
    this.cdr.detectChanges();
  }

  resetValues() {
    this.challengesList = [];
    // this.pageSearch = 1;
  }

  getCommunities(): void {
    this.isLoading = true;
    this.service.getAllCommunities().subscribe(res => {
      this.isLoading = false;
      if (res && res.length) {
        this.communitiesListB2B = res.filter(item => item.categories === "B2B");
        this.communitiesListB2C = res.filter(item => item.categories === "B2C");
        this.communitiesListCommon = res.filter(item => item.categories === "Common");
        if(this.searchForm.controls['Category'].value === "B2B"){
          this.communitiesList = this.communitiesListB2B;
        }else if(this.searchForm.controls['Category'].value === "B2C"){
          this.communitiesList = this.communitiesListB2C;
        }else if(this.searchForm.controls['Category'].value === "Common"){
          this.communitiesList = this.communitiesListCommon;
        }

      }
    }, () => this.isLoading = false);
  }

  onCategoryChange(data:any){
    if(data === "B2B"){
      this.communitiesList = this.communitiesListB2B;
      this.searchForm.patchValue({
        community_id : "",
        level: ""
      });
    }else if(data === "B2C"){
      this.communitiesList = this.communitiesListB2C;
      this.searchForm.patchValue({
        community_id : "",
        level:""
      });
    }else if(data === "Common"){
      this.communitiesList = this.communitiesListCommon;
      this.searchForm.patchValue({
        community_id : "",
        level:""
      });
    }
  }

  onCommChange(){
    const commId = this.searchForm.controls['community_id'].value.community_id;
    this.service.getQuestLevelsById(commId).subscribe(res => {
      this.levelsList = res;
    })
  }

  onPageChange(offset: number) {
    console.log(offset);
    this.page = offset;
    this.loadChallenges();
 
  }

  loadChallenges() {
    this.isLoading = true;
    // this.resetValues();
    // this.challengesList =[];
    const payload = this.processPayload();
    this.service.getChallengesByFilter(payload,this.page).subscribe(res => {
      this.isLoading = false;
      this.total_record = res[1].total_records;
      if (res && res.length) {
        if (this.selectedChallengeView === 'Created By User') {
          const filterList = res.filter(s => s.topic_status !== 'Pending' && s.topic_status !== 'Rejected');
          this.challengesList = this._uhs.getOnlyImageFromChallenges(filterList[0]);
        } else {
          this.challengesList = this._uhs.getOnlyImageFromChallenges(res[0]);
        }
      }
    }, err => this.isLoading = false);
  }

  onNew(): void {
    this.router.navigate(['/auth/admin/challenge', 'create']);
  }

  onEdit(challenge: any): any  {
    this.router.navigate(['/auth/admin/challenge', 'edit', challenge.topic_id]);
  }

  onView(challenge: any): any {
    const data = {
      challenge
    };
    const component = challenge.topic_group_size === 1 ? SoloChallengeModelComponent : GroupChallengeModelComponent;
    const modelRef = this.modalService.open(component, {
      centered: true,
      scrollable: true,
      backdrop: 'static',
      keyboard: false,
      size: 'xl',
      windowClass: 'modal-challenge'
    });
    modelRef.componentInstance.data = data;
    modelRef.componentInstance.userType = 'admin';

  }

  onDelete(topicId: any) {
    const deleteModelRef = this.modalService.open(DeleteComponent, { centered: true, backdrop: 'static' });
    deleteModelRef.componentInstance.message = 'Are you sure you want to delete this challenge?';
    deleteModelRef.result.then((res) => {
      if (res) {
        this.deleteRecord(topicId);
      }
    }, (reason) => {
      if (reason) {
        this.deleteRecord(topicId);
      }
    });
  }

  deleteRecord(topicId: number): any {
    this.isLoading = true;
    this.service.deleteChallenge(topicId).subscribe(res => {
      this.isLoading = false;
      if (res) {
        this.toastrService.success(`Challenge ${SUCCESS_MESSAGE.RECORD_DELETED}`);
        this.loadChallenges();
      }
    }, err => this.isLoading = false);
  }

  onChangeChallenge(value): void {
    if (value !== 'Created By Admin\n\nCreated By User\n\nChallenge Approval') {
      this.selectedChallengeView = value;
      this.store$.dispatch(new ChallengeViewTab(value));
      this.loadChallenges();
    }
  }

  onChangeFilter(value): void {
    this.selectedFilter = value;
    this.loadChallenges();
  }

  processPayload() {
    if(this.searchForm.controls['community_id'].value !== "" && this.searchForm.controls['Category'].value !== ""){
    let payload = {};
    // payload = this.selectedFilter !== 'All' ? { time_filter: this.selectedFilter } : payload;
    if (this.selectedChallengeView === 'Created By Admin') {
      payload['user_type'] = 'admin';
    } else if (this.selectedChallengeView === 'Created By User') {
      payload['user_type'] = 'student';
    } else if (this.selectedChallengeView === 'Challenge Approval') {
      payload['status'] = 'Pending';
    }
    if(this.searchForm.controls['community_id'].value.community_name !== ""){
      payload['community_name'] = this.searchForm.controls['community_id'].value.community_name;
    }
    if(this.searchForm.controls['level'].value !== ""){
      payload['name'] = this.searchForm.controls['level'].value;
    } 
    if(this.searchForm.controls['status'].value !== ""){
      payload['status'] = this.searchForm.controls['status'].value;
    }
    if(this.searchForm.controls['type'].value !== ""){
      payload['is_mandatory'] = Number(this.searchForm.controls['type'].value);
    }
    if(this.searchForm.controls['Category'].value !== ""){
      payload['categories'] = this.searchForm.controls['Category'].value;
    }
    if(this.searchForm.controls['challengeSearch'].value !== ""){
      payload['topic_name'] = this.searchForm.controls['challengeSearch'].value;
    }
    // payload['name'] = "Exc"
    return payload;
  }else{
    this.toastrService.warning("Category and Community is Required")
  }
  }

  setSearchValue($event: any): void {
    this.searchChallenge = $event;
  }
  reset(){
    this.createForm();
    this.pageSearch = 1;
    this.page = 1;
    this.levelsList = [];
    this.challengesList = [];
    this.communitiesList = this.communitiesListB2B;
  }
  ngOnDestroy(): void {
    this.subscriptions.next();
    this.subscriptions.complete();
    if (!this.router.url.includes('/challenge') && this.selectedChallengeView !== 'Created By Admin') {
      this.store$.dispatch(new ChallengeViewTab('Created By Admin'));
    }
  }
}
