import {Component, ElementRef, OnDestroy, OnInit, ViewChild} from '@angular/core';
import {FormArray, FormBuilder, FormGroup, Validators} from '@angular/forms';
import {ActivatedRoute, Router} from '@angular/router';
import {ERROR_MESSAGE, SUCCESS_MESSAGE} from '../../../../shared/constants/constant';
import {HelperService} from '../../../../shared/services/helper.service';
import { ToastrService } from 'ngx-toastr';
import {NgbModal} from '@ng-bootstrap/ng-bootstrap';
import {AdminHelperService} from '../../admin-helper.service';
import {FileUploadComponent} from '../../../../shared/component/file-upload/file-upload.component';
import {ImageVideoViewComponent} from '../../../../shared/component/image-video-view/image-video-view.component';
import {SendMessagePopupComponent} from '../../../../shared/component/send-message-popup/send-message-popup.component';
import {ChallengeViewTab} from '../../../../shared/store/auth.action';
import {ViewOtherProfileComponent} from '../../../../shared/component/view-other-profile/view-other-profile.component';
import {Store} from '@ngrx/store';
import {AuthState} from '../../../../shared/store/auth.model';
import {challengeView, userInfo} from '../../../../shared/store/auth.selector';
import {takeUntil} from 'rxjs/operators';
import {Subject} from 'rxjs';
import { StudentHelperService } from '../../../student-dashboard/student-helper.service';
@Component({
  selector: 'app-create-challenge',
  templateUrl: './create-challenge.component.html',
  styleUrls: ['./create-challenge.component.scss']
})
export class CreateChallengeComponent implements OnInit, OnDestroy {
  private subscriptions = new Subject<void>();
  isLoading = false;
  @ViewChild('searchTag', { static: false }) searchTag: ElementRef;
  defaultRoleImage = 'assets/img/role-img.png';
  roles: FormArray;
  challengeForm = this.fb.group({
    category:['B2B',Validators.required],
    community_id: ['', [Validators.required]],
    topic_name: ['', [Validators.required]],
    topic_description: ['', [Validators.required]],
    topic_short_description: ['', [Validators.required]],
    is_spotlight: [false],
    is_influencer_challenge: [false],
    influencer_name: [''],
    topic_start_date: ['', [Validators.required]],
    topic_end_date: ['', [Validators.required]],
    published_date: [null],
    topic_group_size: ['', [Validators.required, Validators.min(1), Validators.max(4), Validators.pattern('^[0-9]*$')]],
    topic_level: ['', [Validators.required]],
    attachments: this.fb.array([]),
    topic_image: [''],
    topic_video: [''],
    topic_audio: [''],
    topic_document: [''],
    topic_earning_badge: [''],
    topic_earning_badge_url: [''],
    topic_earning_title: [''],
    topic_dot_coins: ['', [Validators.required, Validators.pattern('^[0-9]*$')]],
    participation_dot_coins: ['', [Validators.required, Validators.pattern('^[0-9]*$')]],
    auto_assign_by_attr: ['', [Validators.required]],
    topic_status: [''],
    roles: this.fb.array([]),
    tags: this.fb.array([]),
    topic_comments: [''],
    level_id: [''],
    is_mandatory: [false],
    is_classroom_reflection: [false],
    show_response:[true],
    topic_guidelines:['',[Validators.required]]
  });
  challengeData: any;
  isEnable = false;
  tagsList: any[] = [];
  communitiesList: any;
  selectedType: string;
  isSaving: boolean;
  setStartMinDate: any;
  setEndMinDate: any;
  setPublishMaxDate: any;
  challengeId: any;
  challengeView: string;
  backButton: string;
  videoList: any[] = [];
  audioList: any[] = [];
  imageList: any[] = [];
  docList: any[] = [];
  isDisabled = false;
  userInfo: any;
  levelsList: any = [];
  selectedCommunity: any;
  selectedlevel: any = "";
  communitiesListB2B: any;
  communitiesListB2C: any;
  communitiesListCommon:any
  constructor(private fb: FormBuilder, public _uhs: HelperService, private toastrService: ToastrService,
              private modalService: NgbModal, private adminHelperService: AdminHelperService, private studentHelperService: StudentHelperService,
              private router: Router, private route: ActivatedRoute, private store$: Store<AuthState>) {
    this.store$.select(challengeView)
      .pipe(takeUntil(this.subscriptions))
      .subscribe(res => this.challengeView = res);
      this.store$.select(userInfo)
      .pipe(takeUntil(this.subscriptions))
      .subscribe(res => {
        if (res) {
          this.userInfo = res;
        }
      });
  }
  ngOnInit() {
    this.setStartMinDate = this._uhs.getSpotlightFormattedStartMinDate();
    this.setChallengeType();
    if (this.route.snapshot.paramMap.get('type') === 'edit') {
      this.challengeId = this.route.snapshot.paramMap.get('id');
      this.getChallengeDetails();
    }else{
      this.getCommunities();
    }
  }
  onChange(community:any){
    this.selectedCommunity = Number(community.target.value.slice(-2));
      if(this.selectedCommunity){
        // const payload = {community_id: this.selectedCommunity, user_id: this.userInfo.user_id  };
        const payload = this.selectedCommunity;
        this.levelsList=[];
        this.adminHelperService.getQuestLevelsById(payload).subscribe(res => {          
              this.levelsList = res;
              this.challengeForm.patchValue({
                level_id : ""
              });
        });
      }
  }
  getChallengeDetails(): void {
    this.isLoading = true;
    this.adminHelperService.getTopicDetailsById(this.challengeId).subscribe(res => {
      this.isLoading = false;
      if (res) {
        this.challengeData = res;
        const payload= res.community_id;
        this.adminHelperService.getQuestLevelsById(payload).subscribe(x =>{
          this.levelsList = x;
          if(x){
            this.updateForm(res);
          }
        })
        this.populateAttachments(res.attachments);
        this.populateRoles(res.roles);
        this.tagsList = res.tags;
      }
    }, err => this.isLoading = false);
  }
  
  populateAttachments(attachments) {
    if (attachments && attachments.length) {
      attachments.forEach(element => {
        if (element.attachment_title === 'challenge_document' && element.file !== '') {
          this.docList.push(element);
        } else if (element.attachment_title === 'challenge_audio' && element.file !== '') {
          this.audioList.push(element);
        } else if (element.attachment_title === 'challenge_image' && element.file !== '') {
          this.imageList.push(element);
        } else if (element.attachment_title === 'challenge_video' && element.file !== '') {
          this.videoList.push(element);
        }
      });
    }
  }
  updateForm(res): void {
    const selectLevel= this.levelsList.find(x=>x.id === res.level_id)
    const today = new Date().toISOString().slice(0, 10);
    if(selectLevel !== undefined){
      this.challengeForm.patchValue({
        level_id: selectLevel.id,
      })
    }
    this.challengeForm.patchValue({
      category: res.community.categories,
      community_id: res.community_id,
      topic_name: res.topic_name,
      topic_description: res.topic_description,
      topic_short_description: res.topic_short_description,
      is_influencer_challenge: res.is_influencer_challenge,
      is_spotlight: res.is_spotlight,
      influencer_name: res.influencer_name,
      topic_start_date: res.topic_start_date ? this._uhs.getFormattedDateForAdminChall(res.topic_start_date) : '',
      topic_end_date: res.topic_end_date ? this._uhs.getFormattedDateForAdminChall(res.topic_end_date) : '',
      published_date: res.published_date ? this._uhs.getFormattedDateForAdminChall(res.published_date) : null,
      topic_group_size: res.topic_group_size,
      topic_level: res.topic_level,
      topic_earning_title: res.topic_earning_title,
      topic_earning_badge: res.topic_earning_badge,
      topic_earning_badge_url: res.topic_earning_badge_url,
      topic_dot_coins: res.topic_dot_coins,
      participation_dot_coins: res.participation_dot_coins,
      auto_assign_by_attr: res.auto_assign_by_attr,
      topic_status: res.topic_status,
      is_mandatory:res.is_mandatory,
      is_classroom_reflection: res.is_classroom_reflection,
      show_response: res.show_response === 1 ? 1 : 0,
      topic_guidelines: res.topic_guidelines
    });
    this.getCommunities();
    if (res.topic_start_date && res.topic_start_date.slice(0, 10) < today) {
      this.setStartMinDate = this._uhs.getFormattedDateForAdminChall(res.topic_start_date);
      this.isDisabled = true;
    }
    this.challengeForm.get('published_date').clearValidators();
    this.challengeForm.get('published_date').updateValueAndValidity();
  }
  populateRoles(rolesList) {
    if (rolesList && rolesList.length) {
      this.isEnable = true;
      rolesList.forEach((role, _index) => {
        this.addRole();
        role.tags.forEach(tag => {
          this.addSkillTag(_index);
        });
      });
      this.challengeForm.patchValue({
        roles: rolesList.map(({role_img, role_img_url, role_name, tags, role_id}) => ({role_img, role_img_url, role_name, tags, role_id}))
      });
    }
  }
  getCommunities(): void {
    this.isLoading = true;
    this.adminHelperService.getAllCommunities().subscribe(res => {
      this.isLoading = false;
      if (res && res.length) {
        // this.communitiesList = res;
        this.communitiesListB2B = res.filter(item => item.categories === "B2B");
        this.communitiesListB2C = res.filter(item => item.categories === "B2C");
        this.communitiesListCommon = res.filter(item => item.categories === "Common");
        if(this.challengeForm.controls['category'].value === "B2B"){
          this.communitiesList = this.communitiesListB2B;
        }else if(this.challengeForm.controls['category'].value === "B2C"){
          this.communitiesList = this.communitiesListB2C;
        }else if(this.challengeForm.controls['category'].value === "Common"){
          this.communitiesList = this.communitiesListCommon;
        }
      }
    }, () => this.isLoading = false);
  }

  onCategoryChange(data:any){
    if(data === "B2B"){
      this.communitiesList = this.communitiesListB2B;
      this.challengeForm.patchValue({
        community_id : "",
        level_id: ""
      });
      this.levelsList = [];
    }else if(data === "B2C"){
      this.communitiesList = this.communitiesListB2C;
      this.challengeForm.patchValue({
        community_id : "",
        level_id:""
      });
      this.levelsList =[];
    } else if(data === "Common"){
      this.communitiesList = this.communitiesListCommon;
      this.challengeForm.patchValue({
        community_id : "",
        level_id:""
      });
      this.levelsList =[];
    }
  }
  onChangeInfluencer(): void {
    this.challengeForm.get('is_influencer_challenge').value ?
      this.challengeForm.get('is_spotlight').setValue(true) :
      this.challengeForm.get('is_spotlight').setValue(false);
  }
  submitForm() {
    if (this.challengeForm.valid) {
      let challengeFormData = this.processPayload();
      challengeFormData['level_id'] = typeof(this.challengeForm.controls['level_id'].value) === 'object' ? this.challengeForm.controls['level_id'].value.id : this.challengeForm.controls['level_id'].value;
      if (!this.challengeId) {
        this.isSaving = true;
        this.adminHelperService.saveChallengeData(challengeFormData).subscribe(result => {
          this.isSaving = false;
          if (result) {
            this.toastrService.success(SUCCESS_MESSAGE.RECORD_ADDED);
            this.router.navigate(['/auth/admin/challenge']);
          }
        }, err => this.isSaving = false);
      } else {
        const payload = {
          topic_id: this.challengeId,
          ...challengeFormData
        };
        this.isSaving = true;
        this.adminHelperService.updateChallenge(payload).subscribe(result => {
          this.isSaving = false;
          if (result) {
            this.challengeView === 'Challenge Approval'
              ? this.toastrService.success(SUCCESS_MESSAGE.RECORD_APPROVED) : this.toastrService.success(SUCCESS_MESSAGE.RECORD_UPDATED);
            this.router.navigate(['/auth/admin/challenge']);
          }
        }, err => this.isSaving = false);
      }
    } else {
      this.toastrService.warning(ERROR_MESSAGE.FIELDS_REQUIRED);
      this._uhs.validateAllFormFields(this.challengeForm);
    }
  }
  uploadDocument(type: string, title: string, fileCategory: any) {
    this.selectedType = title;
    const modalData = {
      headerName: title,
      fileType: type,
      fileCategory,
      isMultipleFile: false
    };
    const modalRef = this.modalService.open(FileUploadComponent, {
      keyboard: false,
      backdrop: 'static',
      scrollable: true,
      windowClass: 'modal-cover modal-cover-fluid modal-upload'
    });
    modalRef.componentInstance.data = modalData;
    modalRef.result.then((res) => {
      // console.log(res);
    }, (reason) => {
      if (reason) {
        // console.log(reason);
        if (reason) {
          this.setFileName(reason, fileCategory);
          this.challengeForm.markAsTouched({ onlySelf: true });
        }
      }
    });
  }
  setFileName(res: any, title: string): void {
    if (res && res.length) {
      if (this.selectedType === 'Document') {
        this.addOrReplaceAttachment(this.docList, res, title);
      } else if (this.selectedType === 'Image') {
        this.addOrReplaceAttachment(this.imageList, res, title);
      } else if (this.selectedType === 'Audio') {
        this.addOrReplaceAttachment(this.audioList, res, title);
      } else if (this.selectedType === 'Video') {
        this.addOrReplaceAttachment(this.videoList, res, title);
      } else if (this.selectedType === 'Badge') {
        this.challengeForm.controls.topic_earning_badge.setValue(res[0].file);
        this.challengeForm.controls.topic_earning_badge_url.setValue(res[0].fileUrl);
      }
    }
  }
  addOrReplaceAttachment(attachmentList, res, title): void {
    while (attachmentList.length > 0) {
      attachmentList.pop();
    }
    attachmentList.push({attachment_title: title, file: res[0].file, name: res[0].display_name, url: res[0].fileUrl});
  }
  deleteFile(event: Event, item: any, type: string) {
    event.stopPropagation();
    this.challengeForm.markAsTouched({ onlySelf: true });
    if (type === 'challenge_document') {
      this.docList = this.docList.filter(doc => doc.file !== item.file);
    } else if (type === 'challenge_image') {
      this.imageList = this.imageList.filter(img => img.file !== item.file);
    } else if (type === 'challenge_audio') {
      this.audioList = this.audioList.filter(audio => audio.file !== item.file);
    } else if (type === 'challenge_video') {
      this.videoList = this.videoList.filter(video => video.file !== item.file);
    }
  }
  openViewerModel(type: string, url: string): void {
    const modalRef = this.modalService.open(ImageVideoViewComponent, {
      centered: true,
      size: 'lg'
    });
    modalRef.componentInstance.fileType = type;
    modalRef.componentInstance.fileUrl = url;
  }
  openAvatarModal(roleIndex) {
    const modalData = {
      headerName: 'Role Image',
      fileType: 'image',
      fileCategory: 'role',
      isMultipleFile: false
    };
    const modalRef = this.modalService.open(FileUploadComponent, {
      keyboard: false,
      backdrop: 'static',
      scrollable: true,
      windowClass: 'modal-cover modal-cover-fluid modal-upload'
    });
    modalRef.componentInstance.data = modalData;
    modalRef.result.then((res) => {
      // console.log(res);
    }, (reason) => {
      if (reason && reason.length) {
        this.roles.at(roleIndex).patchValue({
          role_img: reason[0].file,
          role_img_url: reason[0].fileUrl
        });
      }
    });
  }
  addTag() {
    if ( this.tagsList.length < 5) {
      if(this.searchTag.nativeElement.value.length>0){
        let addTag = this.searchTag.nativeElement.value.split(/[\.\,-]/)
        addTag.forEach(i=>{this.tagsList.push({ tag: i})})
        // this.tagsList.push({ tag: this.searchTag.nativeElement.value });
        this.searchTag.nativeElement.value = '';
      }else{this.toastrService.warning('You entered empty tag...');}
    } else {
      this.toastrService.warning('Please refine search tags upto 5');
    }
  }
  removeTag(tag) {
    this.tagsList = this.tagsList.filter(item => item['tag'] !== tag.tag);
  }
  createSkillTag(value): FormGroup {
    return this.fb.group({
      tag: [value],
    });
  }
  deleteSkillTag(mainIndex: number, subIndex: number) {
    const skillTags = this.challengeForm.get('roles')['controls'][mainIndex].get('tags') as FormArray;
    skillTags.removeAt(subIndex);
  }
  addSkillTag(index: number) {
    const skillTags = this.challengeForm.get('roles')['controls'][index].get('tags') as FormArray;
    const roles = this.challengeForm.get('roles') as FormArray;
    const skillTag = roles.at(index).get('dummyTag').value;
    skillTag.split(/(?:, |,| #|#)+/).filter(s => s).forEach(tag => {
      skillTags.push(this.createSkillTag(tag));
    });
    roles.at(index).get('dummyTag').setValue('');
  }
  addRole(roleImage: string = ''): void {
    this.roles = this.challengeForm.get('roles') as FormArray;
    this.roles.push(this.createRole(roleImage));
  }
  createRole(roleImage: string = ''): FormGroup {
    return this.fb.group({
      role_name: ['', [Validators.required]],
      role_img: [roleImage],
      role_img_url: ['assets/img/' + roleImage],
      dummyTag: [''],
      tags: this.fb.array([]),
      role_id: ['']
    });
  }
  deleteRole(i: number): void {
    this.roles.removeAt(i);
  }
  onChangeGroupSize(): void {
    this.roles = this.challengeForm.get('roles') as FormArray;
    const groupSize = this.challengeForm.get('topic_group_size').value;
    if (groupSize === '1') {
      this.isEnable = false;
      this.roles.clear();
    } else {
      this.isEnable = true;
      if (!this.roles || this.roles && Number(groupSize) >= this.roles.length) {
        for (let i = this.roles && this.roles.length || 0; i <= Number(groupSize) - 1; i++) {
          this.addRole('group-' + (i + 1) + '.png');
        }
      } else {
        for (let i = this.roles.length - 1; i >= Number(groupSize); i--) {
          this.roles.removeAt(i);
        }
      }
    }
  }
  onImgError(event) {
    event.target.src = this.defaultRoleImage;
  }
  setEndDate(event: any) {
    this.setEndMinDate = this._uhs.getSpotlightFormattedEndMinDate(event, 1);
    this.setPublishMaxDate = this._uhs.getSpotlightFormattedEndMinDate(event, 0);
  }
  processPayload() {
    const challengeForm = JSON.parse(JSON.stringify(this.challengeForm.value));
    challengeForm['level_id'] = typeof(this.challengeForm.controls['level_id'].value) === 'object' ? this.challengeForm.controls['level_id'].value.id : this.challengeForm.controls['level_id'].value;
    const defaultPublishDate = new Date(challengeForm.topic_start_date.year, challengeForm.topic_start_date.month, challengeForm.topic_start_date.day);
    const v_startDate = challengeForm.topic_start_date;
    challengeForm.topic_start_date = this._uhs.getFormattedDateToBind(challengeForm.topic_start_date);
    challengeForm.topic_end_date = this._uhs.getFormattedDateToBind(challengeForm.topic_end_date);
    challengeForm.published_date = this._uhs.getFormattedDateToBind(challengeForm.published_date ? challengeForm.published_date : v_startDate);
    challengeForm.topic_status = challengeForm.topic_status ? challengeForm.topic_status : 'Open';
    challengeForm.topic_group_size = Number(challengeForm.topic_group_size);
    challengeForm.topic_dot_coins = Number(challengeForm.topic_dot_coins);
    challengeForm.participation_dot_coins = Number(challengeForm.participation_dot_coins);
    challengeForm.is_spotlight = challengeForm.is_spotlight ? 1 : 0;
    challengeForm.is_influencer_challenge = challengeForm.is_influencer_challenge ? 1 : 0;
    challengeForm.attachments = [...this.imageList, ...this.videoList, ...this.audioList, ...this.docList];
    challengeForm.tags = this.tagsList;
    challengeForm.is_mandatory = challengeForm.is_mandatory ? 1 : 0; 
    challengeForm.is_classroom_reflection = challengeForm.is_classroom_reflection ? 1 : 0; 
    challengeForm.show_response = challengeForm.show_response? 1 : 0;
    challengeForm.roles = challengeForm.roles.map(({role_img, role_name, tags, role_id}) => ({role_img, role_name, tags, role_id}));
    return challengeForm;
  }
  setChallengeType(): void {
    if (this.challengeView === 'Created By Admin') {
      this.backButton = this.route.snapshot.paramMap.get('type') === 'edit' ? 'Update a Challenge' : 'Create a Challenge';
    } else if (this.challengeView === 'Created By User') {
      this.backButton = 'Created By User';
    } else if (this.challengeView === 'Challenge Approval') {
      this.backButton = 'Challenge Approval';
    }
  }
  ngOnDestroy(): void {
    this.subscriptions.next();
    this.subscriptions.complete();
    if (!this.router.url.includes('/challenge') && this.challengeView !== 'Created By Admin') {
      this.store$.dispatch(new ChallengeViewTab('Created By Admin'));
    }
  }
  approveOrRejectChallenge(value: string): void {
    if (value === 'Approve') {
      this.challengeForm.value.topic_status = this.challengeForm.value.topic_status === 'Pending' ? 'Open' : this.challengeForm.value.topic_status;
      this.challengeForm.value.topic_comments = 'Approved';
      this.submitForm();
    } else if (value === 'Reject') {
      this.rejectForm();
    }
  }
  rejectForm(): void {
    const data = {
      userDetails: this.challengeData.created_user_details,
      popupType: 'Feedback'
    };
    const modalRef = this.modalService.open(SendMessagePopupComponent, {
      centered: true,
      keyboard: false,
      backdrop: 'static',
      windowClass: 'modal-cover modal-cover-fluid'
    });
    modalRef.componentInstance.data = data;
    modalRef.result.then(res => {
      if (res && res.result === 'Rejected') {
        this.rejectChallenge(res.message);
      }
    });
  }
  rejectChallenge(message: any): void {
    if (this.challengeId) {
      const payload = {
        topic_id: this.challengeId,
        topic_status: 'Rejected',
        topic_comments: message
      };
      this.isSaving = true;
      this.adminHelperService.updateChallenge(payload).subscribe(result => {
        this.isSaving = false;
        if (result) {
          this.toastrService.success(SUCCESS_MESSAGE.RECORD_REJECTED);
          this.router.navigate(['/auth/admin/challenge']);
        }
      }, err => this.isSaving = false);
    }
  }
  openBuddyProfile(buddie): void {
    const modalRef = this.modalService.open(ViewOtherProfileComponent, {
      centered: true,
      size: 'xl',
      windowClass: 'custom-modal'
    });
    modalRef.componentInstance.data = { userId: buddie.user_id };
  }
}