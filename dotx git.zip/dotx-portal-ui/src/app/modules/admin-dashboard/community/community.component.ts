import { Component, OnInit } from '@angular/core';
import {AdminHelperService} from '../admin-helper.service';
import {DeleteComponent} from '../../../shared/component/delete/delete.component';
import {NgbModal} from '@ng-bootstrap/ng-bootstrap';
import {SUCCESS_MESSAGE} from '../../../shared/constants/constant';
import {ToastrService} from 'ngx-toastr';
import {Router} from '@angular/router';
import {HelperService} from '../../../shared/services/helper.service';

@Component({
  selector: 'app-community',
  templateUrl: './community.component.html',
  styleUrls: ['./community.component.scss']
})
export class CommunityComponent implements OnInit {

  isLoading =  false;
  communityList: any[] = [];
  searchChallenge = '';
  dateFormatKeys = ['created_date'];
  pageSearch = 1;
  selectedFilter = 'Last Week';
  list: any;
  activatedFlag: string;
  selectedCommunity: any;
  communityListdata: any;

  constructor(private adminHelperService: AdminHelperService, private modalService: NgbModal, private toastrService: ToastrService,
              private router: Router, private helperService: HelperService) { 
                this.activatedFlag = "B2BCommunity";
              }

  ngOnInit() {
    this.getCommunities();
  }

  getCommunities(): void {
    this.isLoading = true;
    this.resetValues();
    const payload = {
      // time_filter: this.selectedFilter
    };
    this.adminHelperService.getCommunitiesByFilter(payload).subscribe(res => {
      this.isLoading = false;
      if (res && res.length) {
        res.forEach(community => {
          const imageList = community.attachments.flatMap(i => i.attachment_title === 'community_image' ? i.url : []);
          community['community_image'] = imageList && imageList.length ? imageList[0] : null;
        });
        this.communityListdata = res;
        if(this.activatedFlag === "B2BCommunity"){
          this.communityList = this.communityListdata.filter(x => x.categories === "B2B");
        }else if(this.activatedFlag === "B2CCommunity"){
          this.communityList = this.communityListdata.filter(x => x.categories === "B2C");
        }else if(this.activatedFlag === "CommonCommunity"){
          this.communityList = this.communityListdata.filter(x => x.categories === "Common");
        }
      }
    }, () => this.isLoading = false);
  }

  onEdit(community: any) {
    this.router.navigate(['/auth/admin/community', 'edit', community.community_id]);
  }
// for clone the community
  forCloneCommunity(community: any){
    // const paylod={:community}
    const deleteModelRef = this.modalService.open(DeleteComponent, { centered: true, backdrop: 'static' });
    deleteModelRef.componentInstance.message = 'Are you sure you want to CLONE this community?';
    deleteModelRef.result.then((res) => {
      if (res) {
        this.adminHelperService.cloneCommunity(community).subscribe(result =>{
          this.isLoading = false;
            if (result ) {
              this.getCommunities();
              if(result.status === "Community name already exist!"){
                this.toastrService.error(result.status);
              }else{
                this.toastrService.success(result.status);
              }
            }
          }, err => this.isLoading = false); 
      }
    }, (reason) => {
      if (reason) {
        this.getCommunities();
      }
    });
    
  }

  onChangeDotstore(value): void {
    this.selectedCommunity = value;
    // if (this.selectedDotstoreView === 'Categories') {
    //   this.activatedFlag = "CategoryActivated";
    //   this.catlist = true;
    //   this.itemlist = false;
    //   this.cat = true;
    // }
    if (this.selectedCommunity === 'B2BCommunity') {
      this.activatedFlag = "B2BCommunity";
      this.communityList = [];
      this.communityList = this.communityListdata.filter(x => x.categories === "B2B")
      
    }
    if (this.selectedCommunity === 'B2CCommunity') {
      this.activatedFlag = "B2CCommunity";
      this.communityList = [];
      this.communityList = this.communityListdata.filter(x => x.categories === "B2C")

    }
    if (this.selectedCommunity === 'CommonCommunity') {
      this.activatedFlag = "CommonCommunity";
      this.communityList = [];
      this.communityList = this.communityListdata.filter(x => x.categories === "Common")

    }
  }
  onEditQuest(communityId :any){
    this.isLoading = true;
    this.resetValues();
    // const payload = this.processPayload();
    this.adminHelperService.questLevelsLists(communityId).subscribe(result =>{
      console.log('result',result);
      
    this.isLoading = false;
      if (result ) {
            this.list = result;
            this.router.navigate(['/auth/admin/quest/create'], {state: {data: this.list, communityId: communityId}});
      }
    }, err => this.isLoading = false);   

  }

  onDelete(communityId: any) {
    const deleteModelRef = this.modalService.open(DeleteComponent, { centered: true, backdrop: 'static' });
    deleteModelRef.componentInstance.message = 'Are you sure you want to delete this community?';
    deleteModelRef.result.then((res) => {
      if (res) {
        this.deleteRecord(communityId);
      }
    }, (reason) => {
      if (reason) {
        this.deleteRecord(communityId);
      }
    });
  }

  deleteRecord(communityId: any) {
    this.isLoading = true;
    this.adminHelperService.deleteCommunityById(communityId).subscribe(res => {
      this.isLoading = false;
      if (res) {
        this.toastrService.success(`Community ${SUCCESS_MESSAGE.RECORD_DELETED}`);
        this.getCommunities();
      }
    }, err => this.isLoading = false);

    // (err: any) => {
    //   this.showToaster(toastHeader, err['error']['errors'], 'error');
    
    // });
  }

  onChangeFilter(value): void {
    this.selectedFilter = value;
    this.getCommunities();
  }

  setSearchValue($event: any): void {
    this.searchChallenge = $event;
  }

  checkOffer(community: any): boolean {
    return this.helperService.checkOfferDate(community);
  }

  resetValues(): void {
    this.communityList = [];
    this.pageSearch = 1;
  }

  
}
