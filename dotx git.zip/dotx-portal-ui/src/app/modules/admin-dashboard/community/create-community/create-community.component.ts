import { Component, OnInit } from '@angular/core';
import {HelperService} from '../../../../shared/services/helper.service';
import {FormBuilder, Validators} from '@angular/forms';
import {FileUploadComponent} from '../../../../shared/component/file-upload/file-upload.component';
import {NgbModal} from '@ng-bootstrap/ng-bootstrap';
import {ActivatedRoute, Router} from '@angular/router';
import {AdminHelperService} from '../../admin-helper.service';
import {ERROR_MESSAGE, SUCCESS_MESSAGE} from '../../../../shared/constants/constant';
import {ToastrService} from 'ngx-toastr';
import {ImageVideoViewComponent} from '../../../../shared/component/image-video-view/image-video-view.component';
import {IDropdownSettings} from 'ng-multiselect-dropdown/multiselect.model';
@Component({
  selector: 'app-create-community',
  templateUrl: './create-community.component.html',
  styleUrls: ['./create-community.component.scss']
})
export class CreateCommunityComponent implements OnInit {
  isLoading = false;
  MULTI_DROPDOWN_SETTINGS: IDropdownSettings = {
    singleSelection: false,
    idField: 'community_id',
    textField: 'community_name',
    selectAllText: 'Select All',
    unSelectAllText: 'UnSelect All',
    enableCheckAll: true,
    itemsShowLimit: 3,
    allowSearchFilter: true
  };
  communityForm = this.fb.group({
    community_name: ['', [Validators.required]],
    community_desc: ['', [Validators.required]],
    // is_combo: [false],
    is_intro: [false],
    is_competition:[false],
    community_start_date: ['', [Validators.required]],
    attachments: this.fb.array([]),
    community_guideline: ['', [Validators.required]],
    redemption_dotcoins: ['', [Validators.required, Validators.pattern('^[0-9]*$')]],
    joining_fee: [0, [Validators.required]],
    offer_name: [''],
    offer_discount: [0],
    offer_end_date: [null],
    status: ['', [Validators.required]],
    categories: ['', Validators.required],
    child_community_ids: [[]]
  });
  communitiesList: any[] = [];
  attachmentsList: any[] = [];
  selectedType: string;
  isSaving = false;
  communityId: any;
  setStartMinDate: any;
  backButton = 'Create a Community';
  defaultcheckboxs: boolean;
  isDisable: boolean = false;
  constructor(public _uhs: HelperService, private fb: FormBuilder, private modalService: NgbModal,
              private route: ActivatedRoute, private adminHelperService: AdminHelperService,
              private toastrService: ToastrService, private router: Router) { }
  ngOnInit() {
    this.defaultcheckboxs = true;
    this.setStartMinDate = this._uhs.getSpotlightFormattedStartMinDate();
    if (this.route.snapshot.paramMap.get('type') === 'edit') {
      this.communityId = this.route.snapshot.paramMap.get('id');
      this.backButton = 'Update a Community';
      this.getCommunity();
    } else {
      this.getCommunities();
    }
  }
  getCommunities(communityData?: any): void {
    // this.isLoading = true;
    // this.adminHelperService.getAllCommunities().subscribe(res => {
    //   this.isLoading = false;
    //   if (res && res.length) {
    //     this.communitiesList = res.filter(_child => !_child.is_combo);
    //     if (this.route.snapshot.paramMap.get('type') === 'edit') {
    //       this.communityForm.get('child_community_ids')
    //         .setValue(communityData.is_combo ?
    //           this.communitiesList.filter(_c => communityData.child_community_ids.some(_child => _child === _c.community_id)) : []
    //         );
    //     }
    //   }
    // }, () => this.isLoading = false);
  }
  selectDefaultcheckbox(){
    if (this.communityForm.controls.is_intro.value == true || this.communityForm.controls.is_intro.value == 1) 
    {
      this.isDisable = false
      this.defaultcheckboxs = this.communityForm.controls.is_intro.value;
      this.communityForm.get('community_start_date').clearValidators();
      this.communityForm.get('community_start_date').updateValueAndValidity();
      
      if (this.communityForm.controls.community_start_date.value === null || this.communityForm.controls.community_start_date.value === '') {
        this.communityForm.controls['community_start_date'].setValue('');
      } else {
        this.communityForm.controls['community_start_date'].setValue(this.communityForm.controls.community_start_date.value);
        this.setStartMinDate=this.communityForm.controls.community_start_date.value
      }
    } else {
      this.defaultcheckboxs = this.communityForm.controls.is_intro.value;
      if (this.communityForm.controls.community_start_date.value === null || this.communityForm.controls.community_start_date.value === '') {
        this.communityForm.controls['community_start_date'].setValue(this.setStartMinDate);
      } else {
        this.communityForm.controls['community_start_date'].setValue(this.communityForm.controls.community_start_date.value);
      }
      this.isDisable = true;
      this.communityForm.get('community_start_date').clearValidators();
      this.communityForm.get('community_start_date').updateValueAndValidity();
      this.communityForm.controls['community_start_date'].setValue(this.communityForm.controls.community_start_date.value);
      // if(this.communityForm.controls.community_start_date.value === this.setStartMinDate )
      //   this.communityForm.controls['community_start_date'].setValue(null);
    }
  }
  getCommunity(): void {
    this.isLoading = true;
    this.adminHelperService.getCommunityById(this.communityId).subscribe(res => {
      this.isLoading = false;
      if (res) {
        this.getCommunities(res);
        this.communityForm.patchValue({
          community_name: res.community_name,
          community_desc: res.community_desc,
          // is_combo: res.is_combo,
          is_intro: res.is_intro,
          is_competition : res.is_competition,
          community_start_date: res.community_start_date ? this._uhs.getFormattedDateForAdminChall(res.community_start_date) : '',
          community_guideline: res.community_guideline,
          redemption_dotcoins: res.redemption_dotcoins,
          joining_fee: res.joining_fee,
          offer_name: res.offer_name,
          offer_discount: res.offer_discount,
          offer_end_date: res.offer_end_date ? this._uhs.getFormattedDateForAdminChall(res.offer_end_date) : null,
          status: res.status,
          categories: res.categories
        });
        if(this.communityForm.controls.is_intro.value){
          this.isDisable = !this.isDisable;
          if(this.communityForm.controls.community_start_date.value === null || this.communityForm.controls.community_start_date.value ==='' ){
            this.communityForm.controls['community_start_date'].setValue(this.setStartMinDate);
          }
        }
        this.attachmentsList = res.attachments;
        this.communityForm.get('community_start_date').clearValidators();
        this.communityForm.get('community_start_date').updateValueAndValidity();
        this.communityForm.get('offer_end_date').clearValidators();
        this.communityForm.get('offer_end_date').updateValueAndValidity();
      }
    }, () => this.isLoading = false);
  }
  uploadDocument(type: string, title: string, fileCategory: any): void {
    this.selectedType = title;
    const modalData = {
      headerName: title,
      fileType: type,
      fileCategory,
      isMultipleFile: false
    };
    const modalRef = this.modalService.open(FileUploadComponent, {
      keyboard: false,
      backdrop: 'static',
      scrollable: true,
      windowClass: 'modal-cover modal-cover-fluid modal-upload'
    });
    modalRef.componentInstance.data = modalData;
    modalRef.result.then((res) => {
      // console.log(res);
    }, (reason) => {
      if (reason) {
        // console.log(reason);
        if (reason) {
          this.setFileName(reason, fileCategory);
          this.communityForm.markAsTouched({ onlySelf: true });
        }
      }
    });
  }
  openViewerModel(type: string, url: string): void {
    const modalRef = this.modalService.open(ImageVideoViewComponent, {
      centered: true,
      size: 'lg'
    });
    modalRef.componentInstance.fileType = type;
    modalRef.componentInstance.fileUrl = url;
  }
  deleteFile(event, item, type: string) {
    event.stopPropagation();
    this.communityForm.markAsTouched({ onlySelf: true });
    while (this.attachmentsList.length > 0) {
      this.attachmentsList.pop();
    }
    if (type === 'community_image') {
      this.attachmentsList = this.attachmentsList.filter(img => img.attachment_file_path !== item.attachment_file_path);
    }
  }
  setFileName(res: any, fileCategory: string): void {
    if (res && res.length) {
      if (this.selectedType === 'Image') {
        this.addOrReplaceAttachment(res, fileCategory);
      }
    }
  }
  addOrReplaceAttachment(res, title): void {
    this.attachmentsList = [];
    this.attachmentsList.push({attachment_file_path: res[0].file, attachment_title: title, name: res[0].display_name, url: res[0].fileUrl});
  }
  submitForm(): void {
    if (this.communityForm.valid) {
      if (this.attachmentsList.length === 0 || this.attachmentsList.findIndex(i => i.attachment_file_path === '') !== -1) {
        this.toastrService.warning('Please Upload an image');
        return;
      }
      if (Number(this.communityForm.get('offer_discount').value) > Number(this.communityForm.get('joining_fee').value)) {
        this.toastrService.warning('Discounted Price should be less than or equal to Joining fee');
        return;
      }
      const communityFormData = this.processPayload();
      if (!this.communityId) {
        this.isSaving = true;
        this.adminHelperService.saveCommunity(communityFormData).subscribe(res => {
          this.isSaving = false;
          // if (res.status === false) {
          //   this.toastrService.warning("You have already default community enable it");
          // }else 
          if(res){
            this.toastrService.success(SUCCESS_MESSAGE.RECORD_ADDED);
            this.router.navigate(['/auth/admin/community']);
          }
        }, () => this.isSaving = false);
      } else {
        this.isSaving = true;
        const payload = {
          community_id: this.communityId,
          ...communityFormData
        };
        this.adminHelperService.updateCommunity(payload).subscribe(res => {
          this.isSaving = false;
          if (res) {
            this.toastrService.success(SUCCESS_MESSAGE.RECORD_UPDATED);
            this.router.navigate(['/auth/admin/community']);
          }
        }, () => this.isSaving = false);
      }
    } else {
      this.toastrService.warning(ERROR_MESSAGE.FIELDS_REQUIRED);
      this._uhs.validateAllFormFields(this.communityForm);
    }
  }
  processPayload(): any {
    const communityForm = JSON.parse(JSON.stringify(this.communityForm.value));
    // communityForm.child_community_ids = communityForm.is_combo ? communityForm.child_community_ids.map(_c => _c.community_id) : [];
    // communityForm.is_combo = communityForm.is_combo ? 1 : 0;
    communityForm.is_intro = communityForm.is_intro ? 1 : 0;
    communityForm.is_competition = communityForm.is_competition ? 1 :0
    communityForm.attachments = this.attachmentsList;
    communityForm.offer_end_date = communityForm.offer_end_date ? this._uhs.getFormattedDateToBind(communityForm.offer_end_date) : null;
    communityForm.community_start_date = communityForm.community_start_date ? this._uhs.getFormattedDateToBind(communityForm.community_start_date): this.setStartMinDate;
    return communityForm;
  }
}