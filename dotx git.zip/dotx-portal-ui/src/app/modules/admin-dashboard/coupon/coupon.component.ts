import { Component, OnInit } from '@angular/core';
import {AdminHelperService} from '../admin-helper.service';
import {NgbModal} from '@ng-bootstrap/ng-bootstrap';
import {ToastrService} from 'ngx-toastr';
import {Router} from '@angular/router';
import {DeleteComponent} from '../../../shared/component/delete/delete.component';
import {SUCCESS_MESSAGE} from '../../../shared/constants/constant';

@Component({
  selector: 'app-coupon',
  templateUrl: './coupon.component.html',
  styleUrls: ['./coupon.component.scss']
})
export class CouponComponent implements OnInit {

  isLoading =  false;
  couponList: any[] = [];
  searchChallenge = '';
  dateFormatKeys = ['created_date'];
  pageSearch = 1;
  selectedFilter = 'Last 6 Months';

  constructor(private adminHelperService: AdminHelperService, private modalService: NgbModal,
              private toastrService: ToastrService, private router: Router) { }

  ngOnInit() {
    this.loadCouponCodes();
  }

  loadCouponCodes() {
    this.isLoading = true;
    this.resetValues();
    this.adminHelperService.getCouponCodesList().subscribe(res => {
      this.isLoading = false;
      this.couponList = res;
    }, err => this.isLoading = false);
  }

  onNew(): void {
    this.router.navigate(['/auth/admin/coupon', 'create']);
  }

  onEdit(coupon: any): any  {
    this.router.navigate(['/auth/admin/coupon/', 'edit', coupon.id]);
  }

  onDelete(couponId: any) {
    const deleteModelRef = this.modalService.open(DeleteComponent, { centered: true, backdrop: 'static' });
    deleteModelRef.componentInstance.message = 'Are you sure you want to delete this Coupon Code?';
    deleteModelRef.result.then((res) => {
      if (res) {
        this.deleteRecord(couponId);
      }
    }, (reason) => {
      if (reason) {
        this.deleteRecord(couponId);
      }
    });
  }

  deleteRecord(couponId: number): any {
    this.isLoading = true;
    this.adminHelperService.deleteCouponCodeById(couponId).subscribe(res => {
      this.isLoading = false;
      if (res) {
        this.toastrService.success(`Coupon Code ${SUCCESS_MESSAGE.RECORD_DELETED}`);
        this.loadCouponCodes();
      }
    }, err => this.isLoading = false);
  }

  resetValues() {
    this.couponList = [];
    this.pageSearch = 1;
  }

  setSearchValue($event: any): void {
    this.searchChallenge = $event;
  }

  onChangeFilter(value): void {
    this.selectedFilter = value;
    this.loadCouponCodes();
  }
}
