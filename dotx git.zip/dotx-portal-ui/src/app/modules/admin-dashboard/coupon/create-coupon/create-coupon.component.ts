import { Component, OnInit } from '@angular/core';
import {FormBuilder, Validators} from '@angular/forms';
import {HelperService} from '../../../../shared/services/helper.service';
import {NgbModal} from '@ng-bootstrap/ng-bootstrap';
import {ActivatedRoute, Router} from '@angular/router';
import {AdminHelperService} from '../../admin-helper.service';
import {ToastrService} from 'ngx-toastr';
import {ERROR_MESSAGE, SUCCESS_MESSAGE} from '../../../../shared/constants/constant';
import {FileUploadComponent} from '../../../../shared/component/file-upload/file-upload.component';
import {ImageVideoViewComponent} from '../../../../shared/component/image-video-view/image-video-view.component';
import {IDropdownSettings} from 'ng-multiselect-dropdown/multiselect.model';

@Component({
  selector: 'app-create-coupon',
  templateUrl: './create-coupon.component.html',
  styleUrls: ['./create-coupon.component.scss']
})
export class CreateCouponComponent implements OnInit {

  isLoading = false;
  MULTI_DROPDOWN_SETTINGS: IDropdownSettings = {
    singleSelection: false,
    idField: 'community_id',
    textField: 'community_name',
    selectAllText: 'Select All',
    unSelectAllText: 'UnSelect All',
    enableCheckAll: true,
    itemsShowLimit: 3,
    allowSearchFilter: true
  };
  communitiesList: any;
  couponForm = this.fb.group({
    object_type: [''],
    object_id: [null],
    code: ['', [Validators.required]],
    description: ['', [Validators.required]],
    is_public: [false],
    is_combo: [false],
    is_auto_apply: [false],
    effective_date: ['', [Validators.required]],
    expiry_date: ['', [Validators.required]],
    uom: ['', [Validators.required]],
    coupon_type: ['', [Validators.required]],
    value: ['', [Validators.required, Validators.pattern('^[0-9]*$')]],
    min_value: [null, [Validators.pattern('^[0-9]*$')]],
    max_value: [null, [Validators.pattern('^[0-9]*$')]],
    applicable_limit: [null, [Validators.pattern('^[0-9]*$')]],
    image: [''],
    is_active: [true]
  });
  couponCodeData: any;
  isSaving: boolean;
  setStartMinDate: any;
  setEndMinDate: any;
  couponId: any;
  backButton = 'Create a Coupon';
  isDisabled = false;
  couponMaxPrice = 0;

  constructor(public _uhs: HelperService, private fb: FormBuilder, private modalService: NgbModal,
              private route: ActivatedRoute, private adminHelperService: AdminHelperService, private toastrService: ToastrService,
              private router: Router) { }

  ngOnInit() {
    this.setStartMinDate = this._uhs.getSpotlightFormattedStartMinDate();
    if (this.route.snapshot.paramMap.get('type') === 'edit') {
      this.couponId = this.route.snapshot.paramMap.get('id');
      this.backButton = 'Update a Coupon';
      this.getCouponCodeDetailsById();
    } else {
      this.getCommunities();
    }

    this.couponForm.get('uom').valueChanges.subscribe(v => {
      if (v === 'Percentage') {
        this.couponForm.get('value').setValidators([Validators.required, Validators.pattern('^[1-9][0-9]?$|^100$')]);
        this.couponForm.get('value').updateValueAndValidity();
      } else {
        this.couponForm.get('value').setValidators([Validators.required, Validators.pattern('^[0-9]*$')]);
        this.couponForm.get('value').updateValueAndValidity();
      }
    });

    // this.couponForm.get('coupon_type').valueChanges.subscribe(v => {
    //   if (v === 'Cart Level') {
    //     this.couponForm.get('value').setValidators([Validators.required, Validators.pattern('^[0-9]*$')]);
    //     this.couponForm.get('value').updateValueAndValidity();
    //   }
    // });
  }

  getCommunities(couponData?: any): void {
    this.isLoading = true;
    this.adminHelperService.getAllCommunities().subscribe(res => {
      this.isLoading = false;
      if (res && res.length) {
        this.communitiesList = res;
        if (this.route.snapshot.paramMap.get('type') === 'edit') {
          this.couponForm.get('object_id')
            .setValue(couponData.object_type === 'dot_community'
              ? this.communitiesList.filter(_c => couponData.object_id.split(',').some(_s => Number(_s) === _c.community_id)) : null);
        }
      }
    }, () => this.isLoading = false);
  }

  getCouponCodeDetailsById(): void {
    this.isLoading = true;
    this.adminHelperService.getCouponCodesById(this.couponId).subscribe(res => {
      this.isLoading = false;
      if (res) {
        this.getCommunities(res);
        this.couponCodeData = res;
        this.updateForm(res);
      }
    }, err => this.isLoading = false);
  }

  updateForm(res): void {
    const today = new Date().toISOString().slice(0, 10);
    this.couponForm.patchValue({
      code: res.code,
      description:  res.description,
      effective_date: res.effective_date ? this._uhs.getFormattedDateForAdminChall(res.effective_date) : '',
      expiry_date: res.expiry_date ? this._uhs.getFormattedDateForAdminChall(res.expiry_date) : '',
      uom: res.uom,
      coupon_type: res.coupon_type,
      value: res.value,
      min_value: res.min_value,
      max_value: res.max_value,
      applicable_limit: res.applicable_limit,
      is_public:  res.is_public,
      is_combo : res.is_combo,
      is_auto_apply : res.is_auto_apply,
      image: res.image,
      is_active: res.is_active,
    });
    if (res.effective_date && res.effective_date.slice(0, 10) < today) {
      this.setStartMinDate = this._uhs.getFormattedDateForAdminChall(res.effective_date);
      this.isDisabled = true;
    }
  }

  submitForm() {
    if (this.couponForm.valid) {
      const couponFormData = this.processPayload();
      if (!this.couponId) {
        this.isSaving = true;
        this.adminHelperService.saveCouponCode(couponFormData).subscribe(result => {
          this.isSaving = false;
          if (result) {
            this.toastrService.success(SUCCESS_MESSAGE.RECORD_ADDED);
            this.router.navigate(['/auth/admin/coupon']);
          }
        }, err => this.isSaving = false);
      } else {
        const payload = {
          id: this.couponId,
          ...couponFormData
        };
        this.isSaving = true;
        this.adminHelperService.updateCouponCode(payload).subscribe(result => {
          this.isSaving = false;
          if (result) {
            this.toastrService.success(SUCCESS_MESSAGE.RECORD_UPDATED);
            this.router.navigate(['/auth/admin/coupon']);
          }
        }, err => this.isSaving = false);
      }
    } else {
      this.toastrService.warning(ERROR_MESSAGE.FIELDS_REQUIRED);
      this._uhs.validateAllFormFields(this.couponForm);
    }
  }

  uploadDocument(type: string, title: string, fileCategory: any) {
    const modalData = {
      headerName: title,
      fileType: type,
      fileCategory,
      isMultipleFile: false
    };

    const modalRef = this.modalService.open(FileUploadComponent, {
      keyboard: false,
      backdrop: 'static',
      scrollable: true,
      windowClass: 'modal-cover modal-cover-fluid modal-upload'
    });
    modalRef.componentInstance.data = modalData;
    modalRef.result.then((res) => {
      console.log(res);
    }, (reason) => {
      if (reason) {
        console.log(reason);
        if (reason) {
          this.setFileName(reason, fileCategory);
          this.couponForm.markAsTouched({ onlySelf: true });
        }
      }
    });
  }

  setFileName(res: any, title: string): void {
    if (res && res.length) {
      if (title === 'coupon_image') {
        this.couponForm.get('image').setValue(res[0].fileUrl);
      }
    }
  }

  deleteFile(event: Event, type: string) {
    event.stopPropagation();
    this.couponForm.markAsTouched({ onlySelf: true });
    if (type === 'coupon_image') {
      this.couponForm.get('image').setValue('');
    }
  }

  openViewerModel(type: string, url: string): void {
    const modalRef = this.modalService.open(ImageVideoViewComponent, {
      centered: true,
      size: 'lg'
    });
    modalRef.componentInstance.fileType = type;
    modalRef.componentInstance.fileUrl = url;
  }

  setEndDate(event: any) {
    this.setEndMinDate = this._uhs.getSpotlightFormattedEndMinDate(event, 1);
  }

  processPayload() {
    const couponForm = JSON.parse(JSON.stringify(this.couponForm.value));
    couponForm.object_type = couponForm.coupon_type === 'Community Level' ? 'dot_community' : null;
    couponForm.object_id = couponForm.object_type === 'dot_community' ? couponForm.object_id.map(_c => _c.community_id).join(',') : null;
    couponForm.effective_date = this._uhs.getFormattedDateToBind(couponForm.effective_date);
    couponForm.expiry_date = this._uhs.getFormattedDateToBind(couponForm.expiry_date);
    couponForm.min_value = couponForm.min_value ? couponForm.min_value : null;
    couponForm.max_value = couponForm.max_value ? couponForm.max_value : null;
    couponForm.applicable_limit = couponForm.applicable_limit ? couponForm.applicable_limit : null;
    couponForm.is_public  = couponForm.is_public  ? 1 : 0;
    couponForm.is_combo = couponForm.is_combo ? 1 : 0;
    couponForm.is_auto_apply = couponForm.is_auto_apply ? 1 : 0;
    couponForm.is_active = couponForm.is_active ? 1 : 0;
    return couponForm;
  }

  calculateAndValidateCouponValue(event: any): void {
    this.couponMaxPrice += this.checkOffer(event) ? event.offer_discount : event.joining_fee;
    // validate coupon value
  }

  checkOffer(community: any): boolean {
    return this._uhs.checkOfferDate(community);
  }
}
