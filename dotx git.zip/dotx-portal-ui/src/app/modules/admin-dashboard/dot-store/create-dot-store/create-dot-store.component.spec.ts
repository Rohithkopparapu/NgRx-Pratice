import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CreateDotStoreComponent } from './create-dot-store.component';

describe('CreateDotStoreComponent', () => {
  let component: CreateDotStoreComponent;
  let fixture: ComponentFixture<CreateDotStoreComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CreateDotStoreComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CreateDotStoreComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
