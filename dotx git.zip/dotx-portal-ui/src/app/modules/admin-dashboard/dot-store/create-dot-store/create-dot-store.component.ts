import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { AdminHelperService } from '../../admin-helper.service';
import { ToastrService } from 'ngx-toastr';
import { HelperService } from 'src/app/shared/services/helper.service';
import { FileUploadComponent } from 'src/app/shared/component/file-upload/file-upload.component';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { IDropdownSettings } from 'ng-multiselect-dropdown/multiselect.model';
import { Router, Params, ActivatedRoute } from '@angular/router';
import { ERROR_MESSAGE, SUCCESS_MESSAGE } from 'src/app/shared/constants/constant';
import { ImageVideoViewComponent } from 'src/app/shared/component/image-video-view/image-video-view.component';
import { formatDate } from '@angular/common';
@Component({
  selector: 'app-create-dot-store',
  templateUrl: './create-dot-store.component.html',
  styleUrls: ['./create-dot-store.component.scss']
})
export class CreateDotStoreComponent implements OnInit {
  isLoading: boolean;
  categoryCard: any;
  errorMessage: boolean;
  selectedId: any;
  isShowUpadate: boolean = true;
  MULTI_DROPDOWN_SETTINGS: IDropdownSettings = {
    singleSelection: false,
    idField: 'item_id',
    textField: 'name',
    selectAllText: 'Select All',
    unSelectAllText: 'UnSelect All',
    enableCheckAll: true,
    itemsShowLimit: 3,
    allowSearchFilter: true
  };
  createCategoryForm = this.fb.group({
    name: ['', [Validators.required]],
    description: [''],
    type: ['', [Validators.required]],
    icon: ['']

  })
  createItemForm = this.fb.group({
    category_id: ['', [Validators.required]],
    name: ['', [Validators.required]],
    type: ['', [Validators.required]],
    unit_rate: ['', [Validators.pattern('^[0-9]*$')]],
    start_date: ['', [Validators.required]],
    end_date: [],
    item_list: [[]],
    is_active: [false]
  });
  isHeading: string = 'Create';
  isSave: boolean;
  itemsList: any[] = [];
  imageFile: any;
  setStartMinDate: any;
  setEndMinDate: any;
  setPublishMaxDate: any;
  selectedType: string;
  isShowItemDropdown: boolean;
  typeId: any;
  category: any;
  id: any;

  isDisplayCreateCategory: boolean;
  heading: string;
  edit: boolean = false;
  attachmentList: any[] = [];
  isDisplayCreateItem: boolean;
  listOfCategories: any[];
  listOfItems: any;
  head: string;
  imageUpdate: any;
  urlUpdate: any;
  // uploading image variables
  // imageStorageUrl:any = 'dotstore';
  selectedItems: any = [];
  isDisabled = false;
  CurrentTime: string;

  constructor(private modalService: NgbModal,
    private toastrService: ToastrService,
    private fb: FormBuilder,
    public _uhs: HelperService,
    private adminHelperService: AdminHelperService,
    private route: ActivatedRoute,
    private router: Router) {
    this.category = this.router.getCurrentNavigation().extras.state;
  }

  ngOnInit() {
    
    this.setStartMinDate = this._uhs.getSpotlightFormattedStartMinDate();
    this.getStoreCategory();
    this.route.params.subscribe((param: Params) => {
      this.typeId = param['type'];
      if (this.typeId === 'create-category') {
        this.isDisplayCreateCategory = false;
        this.head = 'Category';
        this.heading = "Category Essentials";
      } else if (this.typeId === 'create-item') {
        this.isDisplayCreateCategory = true;
        this.heading = "Item Essentials";
        this.head = 'Item';
      }
    });
    if (this.route.snapshot.paramMap.get('type') === 'edit') {
      this.id = this.route.snapshot.paramMap.get('id');
      this.head = 'Category';
      this.isDisplayCreateCategory = false;
      if (this.category !== undefined) {
        this.updateCategory(this.category.category);
      }
    }
    if (this.route.snapshot.paramMap.get('type') === 'edit-item') {
      this.id = this.route.snapshot.paramMap.get('id');
      this.head = 'Item';

      this.isDisplayCreateCategory = true;
      if (this.category !== undefined) {
        this.updateItem(this.category.itemData);
      }
    }
    this.onChange(this.category.itemData.category_id);
  }

  onChange(category_id: any) {
    this.selectedItems = [];
    if(category_id.target !== undefined){
      this.selectedId = Number(category_id.target.value.split(": ")[1]);
    }else{
      this.selectedId = category_id;
    }
    if (this.selectedId) {
      const id = this.selectedId;
      this.itemsList = [];
      this.adminHelperService.getListOfItems(id).subscribe(res => {
        if (res) {
          this.itemsList = res;
        }
      });
    } 
  }
  getStoreCategory() {
    this.isLoading = true;
    const payload = {}
    this.adminHelperService.getDotStoreCatDetails(payload).subscribe(res => {
      this.isLoading = false;
      if (res) {
        this.categoryCard = res.sort((a,b) => a.category_name.localeCompare(b.category_name));
      }
      else {
      };
    }, () => {
      this.isLoading = false;
      this.errorMessage = true;
    });;
  }
  submitCategory() {
    if (this.createCategoryForm.valid) {
      const createItemFormData = {
        code: (this.createCategoryForm.value.name).toUpperCase(),
        description: this.createCategoryForm.value.description,
        icon: this.createCategoryForm.value.icon,
        type: this.createCategoryForm.value.type,
      }
      if (!this.id && this.attachmentList.length !== 0) {
        createItemFormData['attachment_filepath'] = this.attachmentList[0].file,
          createItemFormData['attachment_name'] = this.attachmentList[0].name,

          this.isSave = true;
          let attalength=this.attachmentList[0].name
          if(attalength.length < 50 )
          {  this.adminHelperService.addDotStoreCategory(createItemFormData).subscribe(result => {
              if (result) {
                this.toastrService.success(SUCCESS_MESSAGE.RECORD_ADDED);
                this.router.navigate(['/auth/admin/dot-store'],  { state: { data: 'CategoryActivated'} });
              }
            }, 
            // (err) =>{ this.isSave = false;
            //   console.log(err);
            );
          }else{
            this.toastrService.warning("Media name is too long")
          }
      } else {
        if (((this.attachmentList.length !== 0 || this.imageUpdate !== undefined) && (this.attachmentList.length !== 0 || this.urlUpdate !== undefined))) {
          const payload = {
            category_id: this.id,
            ...createItemFormData
          };
          if (this.attachmentList.length !== 0) {
            payload['attachment_name'] = this.attachmentList[0].name;
            payload['attachment_filepath'] = this.attachmentList[0].file;
          } else {
            payload['attachment_name'] = this.imageUpdate;
            if ((this.urlUpdate !== "" && this.urlUpdate !== null)) {
              if (this.urlUpdate.includes('http')) {
                payload['attachment_filepath'] = this.urlUpdate.split('uploads/')[1];
              }
            } else {
              if (this.urlUpdate === null) {
                payload['attachment_filepath'] = this.urlUpdate === null ? "" : this.urlUpdate;
              } else if (this.urlUpdate === "") {
                payload['attachment_filepath'] = this.urlUpdate === "" ? "" : this.urlUpdate;

              }
            }
          }
          this.isSave = true;
          if(this.attachmentList.length !== 0){
          let attalength=this.attachmentList[0].name
          if(attalength.length < 50 ){
          this.adminHelperService.updateDotstoreCategory(payload).subscribe(result => {
            this.isSave = false;
            if (result) {
              this.toastrService.success(SUCCESS_MESSAGE.RECORD_UPDATED);
              this.router.navigate(['/auth/admin/dot-store'],  { state: { data: 'CategoryActivated'} });
            }
          });
          }else{
            this.toastrService.warning("Media name is too long")
          }
        }else{
          this.adminHelperService.updateDotstoreCategory(payload).subscribe(result => {
            this.isSave = false;
            if (result) {
              this.toastrService.success(SUCCESS_MESSAGE.RECORD_UPDATED);
              this.router.navigate(['/auth/admin/dot-store'],  { state: { data: 'CategoryActivated'} });
            }
          });
        }
        } else {
          this._uhs.validateAllFormFields(this.createCategoryForm);
          this.toastrService.warning("Please Upload Media");
        }
      }
    } else {
      this._uhs.validateAllFormFields(this.createCategoryForm);
      this.toastrService.warning(ERROR_MESSAGE.FIELDS_REQUIRED);
    }
  }

  updateCategory(category: any) {
    this.edit = true;
    this.createCategoryForm.patchValue({
      name: (category.category_name).toUpperCase(),
      description: category.category_description,
      type: category.category_type,
      icon: category.category_icon
    });
    this.imageUpdate = this.category.category.attachment_name;
    this.urlUpdate = this.category.category.category_image;
  }
  // validateuploadDocument(type: string, title: string, fileCategory: any, selectedOption:any){
  //   if(selectedOption === "Item"){
  //     if(this.createItemForm.controls['category_id'].value !== ""){
  //       const selectedCategoryName = this.categoryCard.find(category => category.category_id === this.createItemForm.controls['category_id'].value )
        
  //       this.imageStorageUrl = "dotstore/"+ 
  //       this.uploadDocument(type, title, fileCategory);
  //     }else{
        // this.toastrService.warning("Select Category to proceed further");
  //     }
  //   }else{
  //     this.uploadDocument(type, title, fileCategory);
  //   }


  // }


  uploadDocument(type: string, title: string, fileCategory: any) {
    this.selectedType = title;
    const modalData = {
      headerName: title,
      fileType: type,
      fileCategory,
      isMultipleFile: false
    };
    const modalRef = this.modalService.open(FileUploadComponent, {
      keyboard: false,
      backdrop: 'static',
      scrollable: true,
      windowClass: 'modal-cover modal-cover-fluid modal-upload'
    });
    modalRef.componentInstance.data = modalData;
    modalRef.result.then((res) => {
      console.log(res);
    }, (reason) => {
      if (reason) {
          console.log("upload", reason);
          if (reason) {
            this.setFileName(reason, title);
            this.createItemForm.markAsTouched({ onlySelf: true });
          }
      }
    });
  }
  setFileName(res: any, title: string): void {
    if (res && res.length) {
      if (this.selectedType === 'Image') {
        this.addOrReplaceAttachment(this.attachmentList, res, title);
      }
    }
  }
  addOrReplaceAttachment(attachmentList, res, title): void {
    while (attachmentList.length > 0) {
      attachmentList.pop();
    }
    this.patchImageEmpty();
    this.isShowUpadate = false;
    this.attachmentList.push({ attachment_title: title, file: res[0].file, name: res[0].display_name, url: res[0].fileUrl });
  }
  deleteFile(event: Event, item: any, type: string) {
    event.stopPropagation();
    this.createItemForm.markAsTouched({ onlySelf: true });
    if (type === 'dotstore') {
      this.attachmentList = this.attachmentList.filter(img => img.file !== item.file);
    }
  }

  patchImageEmpty(): void {
    this.imageUpdate = '';
    this.urlUpdate = '';
  }

  openViewerModel(type: string, url: string): void {
    const modalRef = this.modalService.open(ImageVideoViewComponent, {
      centered: true,
      size: 'lg'
    });
    modalRef.componentInstance.fileType = type;
    modalRef.componentInstance.fileUrl = url;
  }

  changeType(e) {
    if (e.target.value === "GROUP") {
      this.isShowItemDropdown = true;
      this.createItemForm.get('item_list').setValidators([Validators.required]);
      this.createItemForm.get('item_list').markAllAsTouched();
      this.createItemForm.get('item_list').updateValueAndValidity();
    } else {
      this.isShowItemDropdown = false;
      this.selectedItems = [];
      this.createItemForm.get('item_list').clearValidators();
      this.createItemForm.get('item_list').updateValueAndValidity();

    }
  }
  setEndDate(event: any) {
    this.setEndMinDate = this._uhs.getSpotlightFormattedEndMinDate(event, 1);
    this.setPublishMaxDate = this._uhs.getSpotlightFormattedEndMinDate(event, 0);
  }

  submitItem() {
    if (this.createItemForm.valid) {
      const dotStoreItems = this.processPayload();
      if (this.createItemForm.value.type === 'GROUP') {
        const obj = {};
        obj['item'] = this.createItemForm.value.item_list !== '' ? this.createItemForm.value.item_list.map(_l => _l.item_id) : [],
        // dotStoreItems['item_list'] = JSON.stringify(obj);
        dotStoreItems['item_list'] = obj;
        
      } else {
        dotStoreItems['item_list'] = [];
      }
      if (!this.id) {
        dotStoreItems['attachment_filepath'] = this.attachmentList[0].file,
          dotStoreItems['attachment_name'] = this.attachmentList[0].name,
          this.isSave = true;
          let attalength=this.attachmentList[0].name
          if(attalength.length < 50 ){
            this.adminHelperService.addDotStoreItem(dotStoreItems).subscribe(res => {
          if (res) {
            this.toastrService.success(SUCCESS_MESSAGE.RECORD_ADDED);
            this.router.navigate(['/auth/admin/dot-store'], { state: { data: 'ItemActivated'} });
          }
        }, err => this.isSave = false);
        }else{
          this.toastrService.warning("Media name is too long")
        }

      } else {
        if (((this.attachmentList.length !== 0 || this.imageUpdate !== null) && (this.attachmentList.length !== 0 || this.urlUpdate !== ""))) {
          const payload = {
            item_id: this.id,
            ...dotStoreItems
          };
          if (this.attachmentList.length !== 0) {
            payload['attachment_name'] = this.attachmentList[0].name;
            payload['attachment_filepath'] = this.attachmentList[0].file;
          } else {
            payload['attachment_name'] = this.imageUpdate;
            if ((this.urlUpdate !== "" && this.urlUpdate !== null)) {
              if (this.urlUpdate.includes('http')) {
                payload['attachment_filepath'] = this.urlUpdate.split('uploads/')[1];
              }
            } else {
              if (this.urlUpdate === null) {
                payload['attachment_filepath'] = this.urlUpdate === null ? "" : this.urlUpdate;
              } else if (this.urlUpdate === "") {
                payload['attachment_filepath'] = this.urlUpdate === "" ? "" : this.urlUpdate;

              }
            }
          }
          this.isSave = true;
          let attalength;
          if(this.attachmentList.length !== 0){
           attalength=this.attachmentList[0].name
          }
          if(attalength !== undefined ? attalength.length < 50 : payload.attachment_filepath !== undefined ){
          this.adminHelperService.updateDotstoreItem(payload).subscribe(result => {
            this.isSave = false;
            if (result) {
              this.toastrService.success(SUCCESS_MESSAGE.RECORD_UPDATED);
              this.router.navigate(['/auth/admin/dot-store'], { state: { data: 'ItemActivated'} });
            }
          }, err => this.isSave = false);
        }else{
          this.toastrService.warning("Media name is too long")
        }
        } else {
          this._uhs.validateAllFormFields(this.createItemForm);
          this.toastrService.warning("Please Upload Media");
        }
      }
    } else {
      this._uhs.validateAllFormFields(this.createItemForm);
      this.toastrService.warning(ERROR_MESSAGE.FIELDS_REQUIRED);
    }
  }
  processPayload() {
    let currentDate = new Date();
    currentDate.setFullYear( currentDate.getFullYear() + 1 );

    let defaultEndDate = formatDate(currentDate, 'yyyy-MM-dd hh:mm:ss', 'en-US');
    const createItemForm = JSON.parse(JSON.stringify(this.createItemForm.value));
    this.CurrentTime = new Date().getHours() + ':' + new Date().getMinutes() + ':' + new Date().getSeconds();
    createItemForm.category_id = this.createItemForm.value.category_id,
      createItemForm.start_date = this._uhs.getFormattedDateToBind(createItemForm.start_date) + " " + this.CurrentTime,
      createItemForm.end_date = createItemForm.end_date? (this._uhs.getFormattedDateToBind(createItemForm.end_date) + " " + this.CurrentTime) : "4712-12-31 23:59:59",
      createItemForm.description = createItemForm.name,
      createItemForm.UOM = 'Dotcoins',
      createItemForm.code = 'SK11',
      createItemForm.name = (this.createItemForm.value.name).charAt(0).toUpperCase() +(this.createItemForm.value.name).slice(1).toLowerCase(),
      createItemForm.type = this.createItemForm.value.type,
      createItemForm.unit_rate = this.createItemForm.value.unit_rate||0,
      createItemForm.is_active = this.createItemForm.value.is_active ? 1 : 0

    return createItemForm;

  }

  updateItem(item: any) {
    const today = new Date().toISOString().slice(0, 10);
    this.edit = true;
    this.createItemForm.patchValue({
      category_id: item.category_id,
      name: (item.item_name).charAt(0).toUpperCase() + (item.item_name).slice(1).toLowerCase(),
      description: item.item_description,
      type: item.item_type,
      icon: item.item_icon,
      is_active: item.is_active,
      unit_rate: item.unit_rate,
      start_date: item.start_date ? this._uhs.getFormattedDateForAdminChall(item.start_date) : '',
      end_date: item.end_date !== null ? this._uhs.getFormattedDateForAdminChall(item.end_date) : ''
    });
    if (item.item_type === "GROUP") {
      this.isShowItemDropdown = true;
      this.adminHelperService.getListOfItems(item.category_id).subscribe(res => {
        if (res) {
          const arr = []
          this.itemsList = res;
          const itemdata = JSON.parse(item.item_list);
          itemdata.forEach(element => {
           const obj = this.itemsList.find(x => x.item_id === element);
           arr.push(obj);
         
          });
          this.selectedItems = arr;
          // console.log("dropdown items", this.selectedItems);
        }
      });
    }
    this.selectedId = item.category_id,
    this.imageUpdate = item.attachment_name;
    this.urlUpdate = item.item_image;
    if (item.start_date && item.start_date.slice(0, 10) < today) {
      this.setStartMinDate = this._uhs.getFormattedDateForAdminChall(item.start_date);
      this.isDisabled = true;
    }
  }

  cancelCategory(){
    this.router.navigate(['/auth/admin/dot-store'],  { state: { data: 'CategoryActivated'} });
  }
  cancelItem(){
    this.router.navigate(['/auth/admin/dot-store'], { state: { data: 'ItemActivated'} });
  }
}
