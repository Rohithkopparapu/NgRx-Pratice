import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DotStoreComponent } from './dot-store.component';

describe('DotStoreComponent', () => {
  let component: DotStoreComponent;
  let fixture: ComponentFixture<DotStoreComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DotStoreComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DotStoreComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
