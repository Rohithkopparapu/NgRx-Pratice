import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AdminHelperService } from '../admin-helper.service';
import { DeleteComponent } from 'src/app/shared/component/delete/delete.component';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ToastrService } from 'ngx-toastr';
import { SUCCESS_MESSAGE } from 'src/app/shared/constants/constant';

@Component({
  selector: 'app-dot-store',
  templateUrl: './dot-store.component.html',
  styleUrls: ['./dot-store.component.scss']
})
export class DotStoreComponent implements OnInit {
  isDisplayListOfCategory: boolean = true;
  isLoading: boolean;
  categoryList: any = [];
  errorMessage: boolean;
  searchChallenge = '';
  dateFormatKeys = ['created_date'];
  pageSearch = 1;
  itemlist:boolean=false
  catlist:boolean=false
  totalItemsList: any =[];
  head:any="Dot Store"
  cat: boolean=true;
  selectedDotstoreView: string = "Catetories";
  category_ids: number;
  activatedFlag: any;

  constructor(private adminHelperService: AdminHelperService,
              private router: Router,
              private modalService: NgbModal,
              private toastrService: ToastrService) {
                const data = this.router.getCurrentNavigation().extras.state;
                this.activatedFlag = "CategoryActivated";
                if (data !== undefined) {
                  this.activatedFlag = data.data;
                  if (this.activatedFlag === "CategoryActivated") {
                    this.cat = true;
                  } else {
                    this.itemlist = true
                  }
                }
               }

  ngOnInit() {
    this.getStoreCategory();
  }

  onChangeDotstore(value): void {
      this.selectedDotstoreView = value;
      if (this.selectedDotstoreView === 'Categories') {
        this.activatedFlag = "CategoryActivated";
        this.catlist = true;
        this.itemlist = false;
        this.cat = true;
        this.getStoreCategory();
      }
      if(this.selectedDotstoreView === 'Items'){
        this.activatedFlag = "ItemActivated";
        this.catlist=false;
        this.itemlist=true;
        this.cat=false;
      // this.getTotalListOfItems()
      this.totalItemsList=[]
      }
  }
  getTotalListOfItems() {
    if (this.category_ids) {
      this.isLoading = true;
      const payload = {};
      payload['category_id'] = Number(this.category_ids);
      this.adminHelperService.getAllItemsList(payload).subscribe(res => {
        this.isLoading = false;
        if (res) {
          this.totalItemsList = res
        }
      }, () => {
        this.isLoading = false;
        this.errorMessage = true;
      });
    } else {
      this.toastrService.warning("Please select valide category from the list")
    }
  }
  
  // serching
  setSearchValue($event: any): void {
    this.searchChallenge = $event;
  }

  getStoreCategory() {
    this.isLoading = true;
    const payload = {}
    this.adminHelperService.getDotStoreCatDetails(payload).subscribe(res => {
      this.isLoading = false;
      if (res) {
        this.categoryList = res.sort((a,b) => a.category_name.localeCompare(b.category_name));
      }
      else {
        console.log("empty");
      };
    }, () => {
      this.isLoading = false;
      this.errorMessage = true;
    });;
  }
  onChange(event: any){
    this.category_ids = event.target.value;
    // console.log(event.target.value);
  }

  onEditCat(category:any) {
    this.router.navigate(['/auth/admin/dot-store/', 'edit', category.category_id ], {state : {category : category}});
   }
   onEditItems(item){
    this.router.navigate(['/auth/admin/dot-store/', 'edit-item', item.item_id ], {state : {itemData : item}});
   }

  onDelete(categoryId: any) {
    const deleteModelRef = this.modalService.open(DeleteComponent, { centered: true, backdrop: 'static' });
    deleteModelRef.componentInstance.message = 'Are you sure you want to delete this Category?';
    deleteModelRef.result.then((res) => {
      if (res) {
        this.deleteRecord(categoryId);
      }
    }, (reason) => {
      if (reason) {
        this.deleteRecord(categoryId);
      }
    });
  }
  deleteRecord(categoryId: any) {
    this.isLoading = true;
    this.adminHelperService.deleteCategoryById(categoryId).subscribe(res => {
      this.isLoading = false;
      if (res.success== true) {
        this.toastrService.success(`Category ${SUCCESS_MESSAGE.RECORD_DELETED}`);
        this.getStoreCategory();
      }else{
        this.toastrService.warning( res.msg)
      }
    }, err => this.isLoading = false );

  }
  onDeleteItem(itemId):void{
    const deleteModelRef = this.modalService.open(DeleteComponent, { centered: true, backdrop: 'static' });
    deleteModelRef.componentInstance.message = 'Are you sure you want to delete this Item?';
    deleteModelRef.result.then((res) => {
      if (res) {
        this.itemDeleteRecord(itemId);
      }
    }, (reason) => {
      if (reason) {
        this.itemDeleteRecord(itemId);
      }
    });
  }
  itemDeleteRecord(itemId:any){
    this.isLoading = true;
    this.adminHelperService.deleteItemById(itemId).subscribe(res => {
      this.isLoading = false;
      if (res.success == true) {
        this.toastrService.success(`Item ${SUCCESS_MESSAGE.RECORD_DELETED}`);
        this.isLoading = true;
        this.getTotalListOfItems();
      }else{
        this.toastrService.warning(res.msg);
        // this.toastrService.warning("Grouped item cannot be deleted");
      }
    }, err => this.isLoading = false );

  }
}
