import {Component, EventEmitter, OnDestroy, OnInit, Output} from '@angular/core';
import { Router } from '@angular/router';
import {AdminHelperService} from '../../admin-helper.service';
import {ToastrService} from 'ngx-toastr';
import {NgbModal} from '@ng-bootstrap/ng-bootstrap';
import { AuthState } from 'src/app/shared/store/auth.model';
import { Store } from '@ngrx/store';
import { AuthLogout } from 'src/app/shared/store/auth.action';
import { JoinCodesPopupComponent } from '../join-codes-popup/join-codes-popup.component';
import {AnnouncementBroadcastComponent} from '../announcement-broadcast/announcement-broadcast.component';
import {ModalUtilService} from '../../../../shared/services/modal-util.service';
import {takeUntil} from 'rxjs/operators';
import { userResponse,userInfo } from 'src/app/shared/store/auth.selector';
import {Subject} from 'rxjs';
import { environment } from 'src/environments/environment';
import { StudentHelperService } from '../../../student-dashboard/student-helper.service';
import { DataService } from '../../../../shared/services/data.service';

@Component({
  selector: 'app-admin-header',
  templateUrl: './admin-header.component.html'
})
export class AdminHeaderComponent implements OnInit, OnDestroy {
  private subscriptions = new Subject<void>();
  displayName = 'Admin';
  isLoading = false;
  userResponse: any;
  @Output() tabChange = new EventEmitter<any>();
  tabChanges: any;
  cmsLandingUrl: any;
  userDetail: any;
  logedAdmin: any;
  homepageUrl: string;
  schoolList: any;
  toggleSchoolList: boolean = false;
  searchSchool: any = "";
  currentSchool: any;
  constructor(private adminHelperService: AdminHelperService, private toastrService: ToastrService,    private studentHelperService: StudentHelperService,
              private modalService: NgbModal,private router: Router,
              private store$: Store<AuthState>, private modalUtilService: ModalUtilService, private dataService: DataService) {
    this.store$.select(userResponse)
      .pipe(takeUntil(this.subscriptions))
      .subscribe(res => this.userResponse = res);
      this.store$.select(userInfo)
      .pipe(takeUntil(this.subscriptions))
      .subscribe(res => this.userDetail = res);
    this.logedAdmin = this.userDetail.dot_registration_id;
    if(this.userDetail.user_type !== 'student' && this.userDetail.details !== null && this.userDetail.details !== undefined && this.userDetail.details.responsibilities !== undefined){
      this.schoolList = this.userDetail.details.responsibilities;
      if(this.logedAdmin !== null){
        this.currentSchool = this.schoolList.find((x) => 
          x.id === this.logedAdmin
        )
      }
    }else if(this.userDetail.user_type === 'student'){
      this.router.navigate(['/auth/student/community/join']);
    }
   
  }

  ngOnInit() {
    if (this.userResponse && this.userResponse.display_name) {
      this.displayName = this.userResponse.display_name;
    }
    this.cmsLandingUrl=environment.cmsUrl;
    this.homepageUrl = environment.homePageUrl;
  }
  activeTabs(val){
    // localStorage.setItem('tabVal',val)
    this.tabChange.emit(val)
    this.tabChanges= val;
  }
  
  logout(): void {
    this.store$.dispatch(new AuthLogout());
    window.location.replace(this.homepageUrl);
    // window.location.replace(this.cmsLandingUrl);
  }

  generateJoinCodes() {
  this.modalService.open(JoinCodesPopupComponent, {
      backdrop: 'static',
      keyboard: false,
      size: 'lg',
      windowClass: 'modal-holder',
      centered: true
    });
  }

  openResetPassword(): void {
    this.modalUtilService.openResetPasswordPopup();
  }
  setSearchValue($event: any): void {
    this.searchSchool = $event;
  }

  showDiv() {
    this.toggleSchoolList = true;
  }

  hideDiv() {
    this.toggleSchoolList = false;
  }

  switchSchool(data: any) {
    const payload = {
      "user_id": this.userDetail.user_id,
      "registration_id": data.id,
      "school_name": data.name
    }
    this.studentHelperService.SwitchSchool(payload).subscribe(res => {
      if (res) {
        sessionStorage.setItem("school_name", data.name);
        this.dataService.triggerRefresh();
        console.log(res);
      }
    })
  }

  openAnnouncementPopup(): void {
    const modalRef = this.modalService.open(AnnouncementBroadcastComponent, {
      centered: true,
      backdrop: 'static',
      keyboard: false,
      size: 'sm'
    });
  }

  ngOnDestroy(): void {
    this.subscriptions.next();
    this.subscriptions.complete();
  }
}
