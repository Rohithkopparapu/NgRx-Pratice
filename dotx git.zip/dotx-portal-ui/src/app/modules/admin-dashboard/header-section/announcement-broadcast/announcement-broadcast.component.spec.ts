import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AnnouncementBroadcastComponent } from './announcement-broadcast.component';

describe('AnnouncementBoardcastComponent', () => {
  let component: AnnouncementBroadcastComponent;
  let fixture: ComponentFixture<AnnouncementBroadcastComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AnnouncementBroadcastComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AnnouncementBroadcastComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
