import { Component, OnInit } from '@angular/core';
import {NgbActiveModal} from '@ng-bootstrap/ng-bootstrap';
import {AdminHelperService} from '../../admin-helper.service';
import {ToastrService} from 'ngx-toastr';

@Component({
  selector: 'app-announcement-broadcast',
  templateUrl: './announcement-broadcast.component.html',
  styleUrls: ['./announcement-broadcast.component.scss']
})
export class AnnouncementBroadcastComponent implements OnInit {

  isLoading = false;

  constructor(private activeModal: NgbActiveModal, private adminHelperService: AdminHelperService, private toastrService: ToastrService) { }

  ngOnInit() {
  }

  closeModal() {
    this.activeModal.close();
  }

  publishAnnouncement(message: string): void {
    if (message === '') {
      this.toastrService.warning('Please type a message');
      return;
    }
    this.isLoading = true;
    const payload = {
      message
    };
    this.adminHelperService.createAnnouncement(payload).subscribe(() => {
      this.isLoading = false;
      this.toastrService.success('Announcement sent successfully');
      this.activeModal.close();
    }, () => this.isLoading = false);
  }
}
