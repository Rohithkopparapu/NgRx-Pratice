import { Component, OnInit } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { ToastrService } from 'ngx-toastr';
import { AdminHelperService } from '../../admin-helper.service';

@Component({
  selector: 'app-join-codes-popup',
  templateUrl: './join-codes-popup.component.html',
  styleUrls: ['./join-codes-popup.component.scss']
})
export class JoinCodesPopupComponent implements OnInit {
  size = [5, 10, 15, 20, 25, 50, 100];
  constructor(private activeModal: NgbActiveModal,
              private adminHelperService: AdminHelperService,
              private toastrService: ToastrService) { }

  ngOnInit() {
  }

  closeModal(): void {
    this.activeModal.close();
  }

  generateJoinCodes(count: any): void {
    const data = { count: Number(count) };
    this.toastrService.success('Joincodes will be shared to your registered email');
    this.adminHelperService.generateJoinCodes(data).subscribe(() => {
    });
    this.activeModal.close();
  }

}
