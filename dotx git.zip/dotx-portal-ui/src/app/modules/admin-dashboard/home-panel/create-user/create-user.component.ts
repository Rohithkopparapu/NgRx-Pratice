import {Component, Input, OnDestroy, OnInit} from '@angular/core';
import {Subject} from 'rxjs';
import {FormBuilder, Validators} from '@angular/forms';
import {CustomValidator} from '../../../../shared/services/validators/customValidator';
import {NgbActiveModal} from '@ng-bootstrap/ng-bootstrap';
import {HelperService} from '../../../../shared/services/helper.service';
import {AdminHelperService} from '../../admin-helper.service';
import {ToastrService} from 'ngx-toastr';
import {Store} from '@ngrx/store';
import {AuthState} from '../../../../shared/store/auth.model';
import {takeUntil} from 'rxjs/operators';
import {ERROR_MESSAGE} from '../../../../shared/constants/constant';
import { userResponse } from 'src/app/shared/store/auth.selector';
import { IDropdownSettings } from 'ng-multiselect-dropdown';

@Component({
  selector: 'app-create-user',
  templateUrl: './create-user.component.html',
  styleUrls: ['./create-user.component.scss']
})
export class CreateUserComponent implements OnInit, OnDestroy {

  private subscriptions = new Subject<void>();
  userResponse: any;
  @Input() data;
  isLoading: boolean;
  headerName: string;
  userInfo: any;
  isViewMode: boolean;
  userId: any;
  userType:any;
  createProfileForm = this.fb.group({
    displayName: [null, [Validators.required]],
    avatarImageFile: ['admin-user-icon.png'],
    userPhoneNum: [null, [Validators.required, CustomValidator.AllowNumericOnly]],
    userEmail: ['', [Validators.required, CustomValidator.ValidateEmail]],
    userType: ['admin'],
    dot_registration_id: [''],
    user_type:['',[Validators.required]],
    responsiblity:[]
  });
  schoolList: any;
  super_admin: any;
  responsiblityList:any=[]
  adminList=[{
    user_type:'admin',
    name:'Super Admin'
  },
  {
    user_type:'school_admin',
    name:'School Admin'
  }
]
  updateschool: any=0;
  school: any ="";
  selectedItems: any = [];
  MULTI_DROPDOWN_SETTINGS: IDropdownSettings = {
    singleSelection: false,
    idField: 'id',
    textField: 'name',
    selectAllText: 'Select All',
    unSelectAllText: 'UnSelect All',
    enableCheckAll: true,
    itemsShowLimit: 2,
    allowSearchFilter: true
  };
  constructor(public activeModal: NgbActiveModal,
              public _uhs: HelperService,
              private fb: FormBuilder,
              private service: AdminHelperService,
              private toastrService: ToastrService,
              private store$: Store<AuthState>) {
    this.store$.select(userResponse)
      .pipe(takeUntil(this.subscriptions))
      .subscribe(res => this.userResponse = res);
    this.userId = this.userResponse.id;
  }

  ngOnInit() {
    this.headerName = this.data.headerName;
    this.userInfo = this.data.userInfo;
    this.isViewMode = this.headerName === 'User Details';
    if (this.userInfo) {
      this.updateForm(this.userInfo, this.userId);
    }
    this.getSchoolList();
    this.createProfileForm.patchValue({
      user_type : this.userType
    })
    if(this.userType === "school_admin"){
      this.onChange('school_admin');
    }else{
      this.onChange('admin');
    }
  }
  getSchoolList(){
    this.responsiblityList=[]
    const payload ={}
    this.service.getSchool(payload).subscribe(result => {
      if (result) {
        this.schoolList = result.sort((a, b) => a.name.localeCompare(b.name));
        this.responsiblityList= this.schoolList.filter(i=>i.id != this.userInfo.dot_registration_id)
      }
    }, err => this.isLoading = false);
    
  }
  onChangeS(school_id: any) {
    this.responsiblityList=[]
    let sId=school_id.target.value.split(":")[1];
    this.schoolList.forEach((element,index)=> {
      if(index+1==school_id.currentTarget.options.selectedIndex){
        this.school=element.name
    }
  })
  this.responsiblityList= this.schoolList.filter(i=>i.id !=sId)
}
  onChange(school_id: any) {
    let school = "";
    if(school_id === "school_admin"){
      school = "school_admin";
    }else if(school_id === "admin"){
      school = "admin";
    }else {
      school=school_id.target.value.split(':')[1]?school_id.target.value.split(':')[1].trim():'';
    }
    // let school=school_id.target.value.split(':')[1]?school_id.target.value.split(':')[1].trim():''
     if(school == "school_admin"){
      this.updateschool=1
      this.super_admin = school;
      this.createProfileForm.controls['dot_registration_id'].setValidators(Validators.required);
      this.createProfileForm.controls['dot_registration_id'].updateValueAndValidity();
    }else{
      this.updateschool=0
      this.super_admin=school
      this.createProfileForm.controls['dot_registration_id'].setValue('');
      this.createProfileForm.get('dot_registration_id').clearValidators();
      this.createProfileForm.get('dot_registration_id').updateValueAndValidity();

      // this.school_name = school_id.target.value.split(": ")[1];
    }
  }
  updateForm(userInfo: any , userId): void {
    this.createProfileForm.patchValue({
      displayName: userInfo.display_name,
      avatarImageFile: "admin-user-icon.png",
      userEmail: userInfo.user_email,
      userPhoneNum: userInfo.user_phone_num,
      dot_registration_id: userInfo.dot_registration_id,
      user_type: userInfo.dot_registration_id?"school_admin":userInfo.user_type,
      // responsiblity:userInfo.details
    });
    if(userInfo.details){
        this.responsiblityList=[]
        const payload ={}
        this.service.getSchool(payload).subscribe(result => {
          if (result) {
            this.schoolList = result.sort((a, b) => a.name.localeCompare(b.name));
            this.responsiblityList= this.schoolList.filter(i=>i.id != this.userInfo.dot_registration_id)
            // to getting data of selected responsibilities
            const arr = []
            const itemdata = userInfo.details.responsibilities;
            itemdata.forEach(element => {
              const obj=[] = this.responsiblityList.find(x => x.id == element);
              if(obj)
                arr.push(obj);
            
            });
            this.selectedItems = arr;
          }
        }, err => this.isLoading = false);
      
    }
    
    this.updateschool= userInfo.dot_registration_id;
    this.school= userInfo.school_name !== null?userInfo.school_name : this.school;
  }

  submitCreateProfile(): any {
    const {displayName, avatarImageFile, userEmail, userPhoneNum,dot_registration_id,responsiblity} = this.createProfileForm.value;
    let reid:any =[];
    const resposblt={}
    if(responsiblity){
      reid.push(dot_registration_id)
    }
    if(responsiblity !== null){
      responsiblity.filter(i=> reid.push(i.id))
    }
    // resposblt['responsibilities']= reid;
    if(reid){ resposblt['responsibilities']= reid}
    const payload = {
      displayName,
      avatarImageFile,
      userEmail,
      userPhoneNum,
      user_id: this.userInfo.user_id,
      dot_registration_id: dot_registration_id !== "" ?dot_registration_id:null,
      school_name: this.school?this.school:'',
      details:resposblt //:reid
    };
    if (!this.userInfo && !this.userInfo.user_id) {
      payload['userType'] = 'admin';
    }
    
    
    if (this.createProfileForm.valid) {
      this.isLoading = true;
    // return
      if (this.userInfo) {
        // update records
        this.service.updateUserRecords(payload).subscribe(result => {
          if (result) {
            this.showSuccessMessage('UPDATE', result);
          }
        }, err => this.isLoading = false);

      } else {
        // save records
        this.service.saveRecord(payload).subscribe(result => {
          if (result) {
            this.showSuccessMessage('SAVE', result);
          }
        }, err => this.isLoading = false);
      }
    } else {
      this.toastrService.warning(ERROR_MESSAGE.FIELDS_REQUIRED);
      return false;
    }
  }

  showSuccessMessage(type: string, result): void {
    if (type === 'UPDATE') {
      this.toastrService.success(ERROR_MESSAGE.RECORD_UPDATED);
    } else {
      this.toastrService.success(ERROR_MESSAGE.USER_CREATED);
    }
    this.activeModal.dismiss(result);
  }

  ngOnDestroy(): void {
    this.subscriptions.next();
    this.subscriptions.complete();
  }
}
