import {Component, OnDestroy, OnInit} from '@angular/core';
import { NgbModal, NgbModalOptions } from '@ng-bootstrap/ng-bootstrap';
import { ToastrService } from 'ngx-toastr';
import { DeleteComponent } from 'src/app/shared/component/delete/delete.component';
import { AdminHelperService } from '../admin-helper.service';
import { SUCCESS_MESSAGE } from 'src/app/shared/constants/constant';
import {takeUntil} from 'rxjs/operators';
import {Store} from '@ngrx/store';
import {AuthState} from '../../../shared/store/auth.model';
import {userResponse,userInfo} from '../../../shared/store/auth.selector';
import {Subject} from 'rxjs';
import {CreateUserComponent} from './create-user/create-user.component';


export class IUser {
  displayName: string;
  user_phone_num: string;
  user_email: string;
  user_id?: number;
}
@Component({
  selector: 'app-admin-home',
  templateUrl: './home-panel.component.html'
})
export class HomePanelComponent implements OnInit, OnDestroy {
  private subscriptions = new Subject<void>();
  userResponse: any;
  usersList?: IUser[] = [];
  isLoading: boolean;
  dateFormatKeys = [];
  page = 1;
  ngbModalOptions: NgbModalOptions = {
    centered: true,
    backdrop : 'static',
    keyboard : false,
    windowClass: 'admin-s-modal'
  };
  userName = '';
  selectedFilter = 'Last 6 Months';
  activatedFlag: string="ItemActivated";
  selectedAdminView: any;
  adminType: any="admin";
  allUsers: any = []
  userDetail: any;
  logedAdmin: any;
  constructor(
    private service: AdminHelperService,
    private modalService: NgbModal,
    private toastrService: ToastrService,
    private store$: Store<AuthState>
  ) {
    this.store$.select(userResponse)
      .pipe(takeUntil(this.subscriptions))
      .subscribe(res => this.userResponse = res);
    this.userName = this.userResponse.username;
    this.store$.select(userInfo)
      .pipe(takeUntil(this.subscriptions))
      .subscribe(res => this.userDetail = res);
    this.logedAdmin = this.userDetail.dot_registration_id;
    
  }

  ngOnInit() {
    this.loadRecords();
  }

  loadRecords() {
    this.isLoading = true;
    this.reloadRecords();
    const payload = {
      // time_filter: this.selectedFilter,
      user_type: 'admin'
    };
    this.service.getAdminUsersByFilter(payload).subscribe((res: IUser[]) => {
      this.isLoading = false;
      if (res) {
        this.allUsers=res
        if(this.logedAdmin || this.activatedFlag == "CategoryActivated"){
          this.usersList = this.allUsers.filter(item => item.dot_registration_id);
          this.selectedAdminView='school_admin'
        } 
        else{
          this.selectedAdminView='super_admin'
          this.usersList = this.allUsers.filter(item => !item.dot_registration_id);
        }
      }
    }, err => this.isLoading = false);
  }

  onChangeUserList(value): void {

    this.selectedAdminView = value;
    if (this.selectedAdminView === 'school_admin') {
      this.activatedFlag = "CategoryActivated";
      this.adminType="schoolAdmin"
      this.usersList = this.allUsers.filter(item => item.dot_registration_id);
    }
    if(this.selectedAdminView === 'admin'){
      this.activatedFlag = "ItemActivated";
      this.adminType="admin"
      this.usersList = this.allUsers.filter(item => !item.dot_registration_id);
    }
    
}

  onImgError(event) {
    event.target.src = 'assets/img/pic-1.png';
  }

  createUser(): void {
    const modalData = {
      headerName: 'Create User',
      userInfo: ''
    };

    const modalRef = this.modalService.open(CreateUserComponent, this.ngbModalOptions);
    modalRef.componentInstance.data = modalData;
    if(this.activatedFlag === 'ItemActivated' ){
      modalRef.componentInstance.userType = 'admin';
    } else if(this.activatedFlag === 'CategoryActivated'){
      modalRef.componentInstance.userType ='school_admin';
    }
    modalRef.result.then((res) => {
      if (res) {
        this.loadRecords();
      }
    }, (reason) => {
      if (reason) {
        this.loadRecords();
      }
    });
  }

  onView(user: any) {
    const data = {
      headerName: 'User Details',
      userInfo: user,
    };
    const modalRef = this.modalService.open(CreateUserComponent, this.ngbModalOptions);
    modalRef.componentInstance.data = data;
    if(this.activatedFlag === 'ItemActivated' ){
      modalRef.componentInstance.userType = 'admin';
    } else if(this.activatedFlag === 'CategoryActivated'){
      modalRef.componentInstance.userType ='school_admin';
    }
  }

  onEdit(user: any) {
    const data = {
      headerName: 'Edit User',
      userInfo: user
    };
    const modalRef = this.modalService.open(CreateUserComponent, this.ngbModalOptions);
    modalRef.componentInstance.data = data;
    if(this.activatedFlag === 'ItemActivated' ){
      modalRef.componentInstance.userType = 'admin';
    } else if(this.activatedFlag === 'CategoryActivated'){
      modalRef.componentInstance.userType ='school_admin';
    }
    modalRef.result.then((res) => {
      if (res) {
        this.loadRecords();
      }
    }, (reason) => {
      if (reason) {
        this.loadRecords();
      }
    });
  }

  reloadRecords() {
    this.page = 1;
    this.usersList = [];
    this.logedAdmin= this.logedAdmin?this.logedAdmin:''
    if(this.activatedFlag == "ItemActivated")
          this.activatedFlag = "ItemActivated";
    else 
      this.activatedFlag = "CategoryActivated";
  }

  onDelete(userID: any) {
    const deleteModelRef = this.modalService.open(DeleteComponent, { centered: true, backdrop: 'static' });
    deleteModelRef.componentInstance.message = 'Are you sure you want to delete this user?';
    deleteModelRef.result.then((res) => {
      if (res) {this.deleteRecord(userID); }
    }, (reason) => {
      if (reason) {this.deleteRecord(userID); }
    });
  }

  deleteRecord(userID: number): any {
    if (!userID) {
      this.toastrService.warning('User details not available');
    }
    this.isLoading = true;
    this.service.delete(userID).subscribe(res => {
      this.isLoading = false;
      if (res) {
        this.toastrService.success(`User ${SUCCESS_MESSAGE.RECORD_DELETED}`);
        this.loadRecords();
      }
    }, err => this.isLoading = false);
  }

  onChangeFilter(value) {
    this.selectedFilter = value;
    this.loadRecords();
  }

  ngOnDestroy(): void {
    this.subscriptions.next();
    this.subscriptions.complete();
  }
}
