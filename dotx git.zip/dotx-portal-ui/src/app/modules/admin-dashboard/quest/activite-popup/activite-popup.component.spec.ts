import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ActivitePopupComponent } from './activite-popup.component';

describe('ActivitePopupComponent', () => {
  let component: ActivitePopupComponent;
  let fixture: ComponentFixture<ActivitePopupComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ActivitePopupComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ActivitePopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
