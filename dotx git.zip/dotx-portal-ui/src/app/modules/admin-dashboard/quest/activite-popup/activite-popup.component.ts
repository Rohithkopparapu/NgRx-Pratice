import { sequence } from '@angular/animations';
import { Component, Input, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ModalDismissReasons, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import {NgbActiveModal} from '@ng-bootstrap/ng-bootstrap';
import { ToastrService } from 'ngx-toastr';
import { FileUploadComponent } from 'src/app/shared/component/file-upload/file-upload.component';
import { HelperService } from 'src/app/shared/services/helper.service';
import { AdminHelperService } from '../../admin-helper.service';

@Component({
  selector: 'app-activite-popup',
  templateUrl: './activite-popup.component.html',
  styleUrls: ['./activite-popup.component.scss']
})
export class ActivitePopupComponent implements OnInit {
  isLoading: boolean = false;
  headerName:string;
  community_name:any;
  communitiesList: any;
  @Input() communitydata;
  @Input() levelData: any;
  @Input() data:any;
  @Input() createdActivities:any;
  createActivityForm=this.fb.group({
    community_id: [''],
    name:['', [Validators.required]],
    activity_id:['',[Validators.required]],
    sequence:['',[Validators.required, Validators.pattern('^[0-9]*$')]],
    dependency:[''],
    dotcoins:['', [Validators.pattern('^[0-9]*$')]],
    is_mandatory: [false],
    is_intro: [false],
    topic_earning_badge: [''],
    topic_earning_badge_url: [''],
    earning_title:[''],
    level_id: ['']
  });
  closeResult = '';
  activityList: any[];
  profileImageList: any[]=[];
  selectedType: string;
  activityInfo: boolean;
  edit: boolean=false;
  badgeurl: any[]=[];
  profilename: any[]=[];

  constructor(private modalService: NgbModal, 
              private fb:FormBuilder,
              public _uhs:HelperService,
              private adminHelperService: AdminHelperService,
              private ngbActiveModal: NgbActiveModal,
              private router: Router,
              private toastrService: ToastrService,
              ) { }

  ngOnInit() {
    this.getCommunities();
    this.levelData;
    this.data;
    this.createdActivities;
    this.adminHelperService.getActivityList().subscribe(res=>{
      this.isLoading=false;
      if(res && res.length){
        this.activityList = res;
        this.activityList.sort((a, b) => a.title.localeCompare(b.title))

      }
    });
    if(this.data != undefined && this.headerName === 'Update Activity'){
      this.activityInfo = true;
      this.edit = true;
      if(this.data ){
        this.updateActivity(this.data.selectedActivity);
       
      }
    }
  }
  getCommunities(): void {
    this.isLoading = true;
    this.adminHelperService.getAllCommunities().subscribe(res => {
      this.isLoading = false;
      if (res && res.length) {
        this.communitiesList = res;
        this.createActivityForm.patchValue({
          community_id : Number(this.communitydata),
        })
      }
    }, () => this.isLoading = false);
  }
  submit(){
    // if(this.createActivityForm.controls.sequence.value !== null){
    if(this.headerName === 'Add Activity'){
      this.submitcreateActivity();
    //  this.createdActivities.find(x => x.sequence === Number(this.createActivityForm.controls.sequence.value))? this.toastrService.warning('Please enter a unique sequence'): this.submitcreateActivity();
    }
    if(this.headerName === 'Update Activity'){
      this.updateActivitydata();
      // this.createdActivities.find(x => x.sequence === Number(this.createActivityForm.controls.sequence.value))? this.toastrService.warning('Please enter a unique sequence'): this.updateActivitydata();
    }
  //  }
  }
  navigateClosebtn(){
    this.ngbActiveModal.close({status: 'Failed', levelData: {} });
    this.router.navigate(['/auth/admin/community', 'create']);
  }
  open(content) {
    this.modalService.open(content, {ariaLabelledBy: 'modal-basic-title'}).result.then((result) => {
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }
  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return `with: ${reason}`;
    }
  }
  submitcreateActivity():void{
    if(this.createActivityForm.valid){
      if(this.profileImageList.length !== 0){
    const payload = {
      community_id : Number(this.communitydata),
      dot_quest_level_id: Number(this.levelData.id),
      name : this.createActivityForm.controls.name.value,
      wp_activity_id : Number(this.createActivityForm.controls.activity_id.value),
      sequence: Number(this.createActivityForm.controls.sequence.value),
      dependency : Number(this.createActivityForm.controls.dependency.value),
      completion_dotcoins : Number(this.createActivityForm.controls.dotcoins.value),
      badge_name : this.createActivityForm.controls.earning_title.value,
      badges: this.createActivityForm.controls.topic_earning_badge.value,
      is_mandatory : (this.createActivityForm.controls.is_mandatory.value) ? 1 : 0,
      is_intro : (this.createActivityForm.controls.is_intro.value)? 1 : 0,  
    };

    if(this.profileImageList.length !== 0){
      payload['attachment_filepath'] = this.profileImageList[0].file ? this.profileImageList[0].file: "";
      payload['display_name'] = this.profileImageList[0].name ? this.profileImageList[0].name : this.data.selectedActivity.display_name;
     }

    this.adminHelperService.addActivities(payload).subscribe(res=>{
      if(res){
        this.ngbActiveModal.close({status:'Success', activityData:res});
        this.toastrService.success("Activity added successfully");
      }else{
        this.ngbActiveModal.close({status:'Failed', activityData:''});
        this.toastrService.warning("Failed to add activity ");
      }
    },err=> this.isLoading = false);
  }else{
    this._uhs.validateAllFormFields(this.createActivityForm);
    this.toastrService.warning('Profile image is required');
  }
  }else{
    this._uhs.validateAllFormFields(this.createActivityForm);
    this.toastrService.warning('Please enter all required fields');
  }
  }
  updateActivity(activity){
    this.createActivityForm.patchValue({
      name: activity.name,
      activity_id:activity.wp_activity_id,
      sequence:activity.sequence,
      dependency:activity.dependency,
      dotcoins:activity.completion_dotcoins,
      is_mandatory: activity.is_mandatory,
      is_intro: activity.is_intro,
      topic_earning_badge_url: activity.badges,
      topic_earning_badge : activity.badges,
      earning_title: activity.badge_name,
    })
  }
  updateActivitydata(){
    if(this.createActivityForm.valid){
   const data={
     community_id : Number(this.communitydata),
      dot_quest_level_id: Number(this.levelData.id),
      name : this.createActivityForm.controls.name.value,
      wp_activity_id : Number(this.createActivityForm.controls.activity_id.value),
      sequence: Number(this.createActivityForm.controls.sequence.value),
      dependency : Number(this.createActivityForm.controls.dependency.value),
      completion_dotcoins : Number(this.createActivityForm.controls.dotcoins.value),
      is_mandatory : (this.createActivityForm.controls.is_mandatory.value) ? 1 : 0,
      is_intro : (this.createActivityForm.controls.is_intro.value)? 1 : 0,
      id:this.data.selectedActivity.id,
   }
   if(this.profileImageList.length !== 0){
    data['attachment_filepath'] =  this.profileImageList[0].file;
    data['display_name']=  this.profileImageList[0].name;
   }else{
    if(this.data.selectedActivity.attachment_filepath !== null && this.data.selectedActivity.attachment_filepath !== ""){
    if(this.data.selectedActivity.attachment_filepath.includes('http')){
      data['attachment_filepath'] = this.data.selectedActivity.attachment_filepath.split('uploads/')[1];
    }else{
      data['attachment_filepath'] = this.data.selectedActivity.attachment_filepath;
    }
    }else{
      data['attachment_filepath'] = this.data.selectedActivity.attachment_filepath === null ? "": this.data.selectedActivity.attachment_filepath;
    } 
    data['display_name']= this.data.selectedActivity.display_name ;
   }
  if(this.createActivityForm.controls.topic_earning_badge_url.value !== "" && this.createActivityForm.controls.topic_earning_badge_url.value !== null){
   if(this.createActivityForm.controls.topic_earning_badge_url.value.includes('http')){
    data['badges']  = this.createActivityForm.controls.topic_earning_badge_url.value.split('uploads/')[1];
   }else{
    data['badges'] = this.createActivityForm.controls.topic_earning_badge_url.value;
   }
  }else{
    if(this.createActivityForm.controls.topic_earning_badge_url.value === null){
    data['badges']  = "";
    }else if(this.createActivityForm.controls.topic_earning_badge_url.value === ""){
      data['badges']  = "";

    }
  }

   if(this.createActivityForm.controls.earning_title.value !== ''){
    data['badge_name']  = this.createActivityForm.controls.earning_title.value;
   }else{
    data['badge_name']  = this.data.selectedActivity.badge_name;
   }
   this.adminHelperService.updateActivitydata(data).subscribe(res=>{
    if(res){
      this.ngbActiveModal.close({status:'Success', activityData:res});
      this.toastrService.success("Activity updated successfully");
    }else{
      this.ngbActiveModal.close({status:'Failed', activityData:''});
      this.toastrService.warning("Failed to update activity");
    }
  },err=> this.isLoading = false);
}else{
  this._uhs.validateAllFormFields(this.createActivityForm);
  this.toastrService.warning('Please enter all required fields');
}
  }
  uploadDocument(type: string, title: string,fileCategory: any) {
    this.selectedType = title;
    const modalData = {
      headerName: title,
      fileType: type,
      fileCategory,
      isMultipleFile: false
    };
    const modalRef = this.modalService.open(FileUploadComponent, {
      keyboard: false,
      backdrop: 'static',
      scrollable: true,
      windowClass: 'modal-cover modal-cover-fluid modal-upload'
    });
    modalRef.componentInstance.data = modalData;
    modalRef.result.then((res) => {
      console.log(res);
    }, (reason) => {
      if (reason) {
        console.log("upload",reason);
        if (reason) {
          this.setFileName(reason, title);
          this.createActivityForm .markAsTouched({ onlySelf: true });
        }
      }
    });
  }
  setFileName(res: any, title: string): void {
    if (res && res.length) {
      if (this.selectedType === 'profileImage') {
        this.addOrReplaceAttachment(this.profileImageList, res, title);
      } else if (this.selectedType === 'activity_badge') {
        this.createActivityForm.controls.topic_earning_badge.setValue(res[0].file);
        this.createActivityForm.controls.topic_earning_badge_url.setValue(res[0].fileUrl);
      }
    }
  }
  addOrReplaceAttachment(attachmentList, res, title): void {
    while (attachmentList.length > 0) {
      attachmentList.pop();
    }
    attachmentList.push({attachment_title: title, file: res[0].file, name: res[0].display_name, url: res[0].fileUrl});
  }
  deleteFile(event: Event, item: any, type: string) {
    event.stopPropagation();
    this.createActivityForm.markAsTouched({ onlySelf: true });
    if (type === 'quest_profile_image') {
      this.profileImageList = this.profileImageList.filter(img => img.file !== item.file);
      
    }
  }
  closeModal(): void {
    this.ngbActiveModal.close({status: 'Failed', activityData: {} });
  }

}
