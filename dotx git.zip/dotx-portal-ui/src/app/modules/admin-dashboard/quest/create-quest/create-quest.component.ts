import { Component, Input, OnInit } from '@angular/core';
import { AdminHelperService } from '../../admin-helper.service';
import { FormArray, FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { NgbModal, NgbModalOptions } from '@ng-bootstrap/ng-bootstrap';
import { ActivitePopupComponent } from '../activite-popup/activite-popup.component';
import { LevelCreationPopupComponent } from '../level-creation-popup/level-creation-popup.component';
import { ToastrService } from 'ngx-toastr';
import { Subject } from 'rxjs';
import { DeleteComponent } from 'src/app/shared/component/delete/delete.component';
import { Router } from '@angular/router';


@Component({
  selector: 'app-create-quest',
  templateUrl: './create-quest.component.html',
  styleUrls: ['./create-quest.component.scss']
})
export class CreateQuestComponent implements OnInit {
  private subscriptions = new Subject<void>();
  isLoading: boolean = true;
  headerName: string = 'Create a Quest';
  levelInfo: any;
  communitiesList: any;
  createLevels: boolean = false;
  levelsform: FormGroup;
  formcommunitydata: FormGroup;
  levelData: any = [];
  createActivity: boolean = false;
  activityArray: any = [];
  questData: any = [];
  levelId: Number;
  returnedindex: Number;
  showQuestTree : boolean = true;
  ngbModalOptions: NgbModalOptions = {
    centered: true,
    scrollable: true,
    backdrop: 'static',
    keyboard: false,
    size: 'lg',
    windowClass: 'modal-challenge'
  }
  selectedLevel: any;
  isedit: boolean = true;
  communityId: any;
  commId: any;

  constructor(private adminHelperService: AdminHelperService,
    private modalService: NgbModal,
    private fb: FormBuilder,
    private toastrService: ToastrService,
    private router: Router) {
    const data = this.router.getCurrentNavigation().extras.state;
    if (data) {
      this.selectedLevel = data.data;
      this.communityId = data.communityId;
      this.headerName = "Edit a Quest";
      // this.isedit = false;
    }else{
      this.router.navigate(['/auth/admin/community']);
    }
  }

  closeResult = '';

  ngOnInit() {
    this.getCommunities();
    this.formcommunitydata = this.fb.group({
      community_id: [''],
    });
    this.levelsform = new FormGroup({
      levels: new FormArray([])
    });
    console.log("test1",this.selectedLevel);
    
  }

  toggleTreeView(event:any,x, i){
    console.log(event.target);
    console.log(event.target.getAttribute('data-sectionvalue'));
    this.showQuestTree = x; 
    this.returnedindex = i ;  
  }
  showQuest(){
    return this.showQuestTree;
  }

  get level(): FormArray {
    return this.levelsform.get('levels') as FormArray;
  }

  levelCreation() {
    if (this.formcommunitydata.get('community_id').value !== "") {
      this.levelPopup();
    } else {
      this.toastrService.warning("Select any community to proceed further");
    }
  }

  closeLevel(){
    this.createLevels;
  }

  addActivity(i) {
    this.activityPopUp(i);
  }

  // setValues(){
  //   this.level.at(0).get(this.level['name']).setValue(this.selectedLevel.name); 
  // }

  updateLeveldata(i) {
    const selectedLevel = this.levelsform.controls['levels'].value[i]
      let smaterial=this.selectedLevel[i].students_lesson;
      let tmaterial=this.selectedLevel[i].teachers_lesson;
      let Tdata=tmaterial.filter(element=> (element.material_name!="" && element.material_file_path!=""));
      let Sdata=smaterial.filter(element=> (element.material_name!="" && element.material_file_path!=""))
    const data = {
      headerName: 'Update Level',
      levelInfo: 'Update',
      selectedLevel: selectedLevel,
      leverInfoTecher:Tdata,//this.selectedLevel[i].teachers_lesson,
      leverInfoStudent:Sdata//this.selectedLevel[i].students_lesson
    };
    const modalRef = this.modalService.open(LevelCreationPopupComponent, this.ngbModalOptions);
    modalRef.componentInstance.data = data;
    modalRef.componentInstance.communitydata = this.formcommunitydata.get('community_id').value;
    modalRef.result.then((result) => {
      if (result.status === "success") {
        this.refreshData(this.communityId)
        this.levelData = result.levelData;
        this.createLevels = true;
        this.level.removeAt(i);
        this.level.insert(i,
          new FormGroup({
            community_id: new FormControl(this.levelData.community_id),
            name: new FormControl(this.levelData.name),
            code: new FormControl(this.levelData.code),
            description: new FormControl(this.levelData.description),
            sequence: new FormControl(this.levelData.sequence),
            id: new FormControl(this.levelData.id),
            banner_filepath: new FormControl(this.levelData.banner_filepath),
            attachment_filepath: new FormControl(this.levelData.attachment_filepath),
            display_name:new FormControl(this.levelData.display_name),
            banner_name:new FormControl(this.levelData.banner_name),
            activities: new FormArray([]),
          })
        );
        const activityArray = this.level.controls[i].get('activities') as FormArray; 
        this.createActivity = true;
        this.showQuestTree = false;
        const activtesArr = this.levelData.activities;
        activtesArr.forEach(res => {
          activityArray.push(this.fb.group({
            community_id: [res.community_id],
            dot_quest_level_id: [res.dot_quest_level_id],
            name: [res.name],
            wp_activity_id: [res.wp_activity_id],
            sequence: [res.sequence],
            dependency: [res.dependency],
            completion_dotcoins: [res.completion_dotcoins],
            badges: [res.badges],
            badge_name: [res.badge_name],
            is_mandatory: [res.is_mandatory],
            is_intro: [res.is_intro],
            attachment_filepath: [res.attachment_filepath],
            display_name: [res.display_name],
            id: [res.id]
          }));
        });    
      }else{
        
      }
    });

  }

  refreshData(communityId:any){
    this.selectedLevel = [];
    this.isLoading = true;
    this.adminHelperService.questLevelsLists(communityId).subscribe(result =>{
      this.isLoading = false;
        if (result && result.length) {
              this.selectedLevel = result;
              // this.getCommunities();
        }
      }, err => this.isLoading = false);  
    
    }

  deleteLevel(i) {
    const selectId = this.levelsform.controls['levels'].value[i].id;
    const deleteModelRef = this.modalService.open(DeleteComponent, { centered: true, backdrop: 'static' });
    deleteModelRef.componentInstance.message = 'Are you sure you want to delete this level?';
    deleteModelRef.result.then((res) => {
      if (res) {
        this.deleteRecord(selectId, i);
      }
    }, (reason) => {
      if (reason) { this.deleteRecord(selectId, i); }
    });
  }

  deleteRecord(selectId, i) {
    const id = selectId;
    this.adminHelperService.deleteLevelData(id).subscribe(res => {
      this.isLoading = false;
      if (res.message !== "To delete this level first delete the mapped challenge(s)") {
        this.level.removeAt(i);
        this.toastrService.success('Level deleted successfully');
      }else{
        this.toastrService.error('To delete this level first delete the mapped challenge')
      }
    }, err => this.isLoading = false);
  }

  getCommunities(): void {
    this.isLoading = true;
    this.adminHelperService.getAllCommunities().subscribe(res => {
      this.isLoading = false;
      if (res && res.length) {
        this.communitiesList = res;
        this.getLevelData();
      }
    }, () => this.isLoading = false);
  }

  getLevelData(): any {
    if (this.selectedLevel ) {
      this.setLevelData();
    }
  }

  setLevelData(): any {
   
    this.formcommunitydata.get('community_id').setValue(this.communityId);
    this.createLevels = true;
    this.selectedLevel.forEach((element, index) => {
      const levelArray = this.levelsform.get('levels') as FormArray;
      this.level.push(
        new FormGroup({
          community_id: new FormControl(element.community_id),
          name: new FormControl(element.name),
          code: new FormControl(element.code),
          description: new FormControl(element.description),
          sequence: new FormControl(element.sequence),
          id: new FormControl(element.id),
          banner_filepath: new FormControl(element.banner_filepath),
          attachment_filepath: new FormControl(element.attachment_filepath),
          display_name:new FormControl(element.display_name),
          banner_name:new FormControl(element.banner_name),
          activities: new FormArray([]),
        })

      );
      const activityArray = this.level.controls[index].get('activities') as FormArray;
      this.createActivity = true;
      if (element.activities && element.activities.length) {
        this.showQuestTree = false;
        const activtesArr = element.activities;
        activtesArr.forEach(res => {
          activityArray.push(this.fb.group({
            community_id: [res.community_id],
            dot_quest_level_id: [res.dot_quest_level_id],
            name: [res.name],
            wp_activity_id: [res.wp_activity_id],
            sequence: [res.sequence],
            dependency: [res.dependency],
            completion_dotcoins: [res.completion_dotcoins],
            badges: [res.badges],
            badge_name: [res.badge_name],
            is_mandatory: [res.is_mandatory],
            is_intro: [res.is_intro],
            attachment_filepath: [res.attachment_filepath],
            display_name: [res.display_name],
            id: [res.id]
          }));
        });
      }
    });
    
   
  }

  levelPopup() {
    const component = LevelCreationPopupComponent;
    const modelRef = this.modalService.open(component, this.ngbModalOptions);
    modelRef.componentInstance.userType = 'admin';
    modelRef.componentInstance.communitydata = this.formcommunitydata.get('community_id').value;
    // modelRef.componentInstance.createLevels = 
    modelRef.result.then((result) => {
      if (result.status === "success") {
        this.showQuestTree = false;
        this.returnedindex = this.level.length; 
        this.levelData = result.levelData;
        this.createLevels = true;
        this.level.push(
          new FormGroup({
            community_id: new FormControl(this.levelData.community_id),
            name: new FormControl(this.levelData.name),
            code: new FormControl(this.levelData.code),
            description: new FormControl(this.levelData.description),
            sequence: new FormControl(this.levelData.sequence),
            id: new FormControl(this.levelData.id),
            banner_filepath: new FormControl(this.levelData.banner_filepath),
            attachment_filepath: new FormControl(this.levelData.attachment_filepath),
            display_name:new FormControl(this.levelData. display_name),
            banner_name:new FormControl(this.levelData. banner_name),
            activities: new FormArray([]),
          })
        );
        // console.log("levels", this.level);
      }
    });
  }

  activityPopUp(i): any {
    const component = ActivitePopupComponent;
    const modelRef = this.modalService.open(component, this.ngbModalOptions);
    modelRef.componentInstance.userType = 'admin';
    modelRef.componentInstance.levelData = this.level.controls[i].value;
    modelRef.componentInstance.headerName = "Add Activity";
    modelRef.componentInstance.communitydata = this.formcommunitydata.get('community_id').value;
    modelRef.componentInstance.createdActivities = this.level.controls[i].get('activities').value;
    modelRef.result.then((res: any) => {
      if (res.status === "Success") {
        const activityArray = this.level.controls[i].get('activities') as FormArray;
        this.createActivity = true;
        activityArray.push(this.fb.group({
          community_id: [res.activityData.community_id],
          dot_quest_level_id: [res.activityData.dot_quest_level_id],
          name: [res.activityData.name],
          wp_activity_id: [res.activityData.wp_activity_id],
          sequence: [res.activityData.sequence],
          dependency: [res.activityData.dependency],
          completion_dotcoins: [res.activityData.completion_dotcoins],
          badge_name: [res.activityData.badge_name],
          badges: [res.activityData.badges],
          is_mandatory: [res.activityData.is_mandatory],
          is_intro: [res.activityData.is_intro],
          attachment_filepath: [res.activityData.attachment_filepath],
          display_name:[res.activityData.display_name],
          id: [res.activityData.id]

        }));
      }
    });
  }

  updateActivity(i, j) {
    const activityArray = this.level.controls[i].get('activities') as FormArray;
    const selectedActivity = activityArray.controls[j].value;
    const data = {
      headerName: 'Update Activity',
      activityInfo: 'Update',
      selectedActivity: selectedActivity,
    };
    const modalRef = this.modalService.open(ActivitePopupComponent, this.ngbModalOptions);
    modalRef.componentInstance.data = data;
    modalRef.componentInstance.levelData = this.level.controls[i].value;
    modalRef.componentInstance.headerName = "Update Activity";
    modalRef.componentInstance.communitydata = this.formcommunitydata.get('community_id').value;
    modalRef.componentInstance.createdActivities = this.level.controls[i].get('activities').value;
    console.log(this.level.controls[i].get('activities').value);
    modalRef.result.then((res: any) => {
      if (res.status === "Success") {
        const activityArray = this.level.controls[i].get('activities') as FormArray;
        this.createActivity = true;
        (<FormArray>this.level.controls[i].get('activities')).controls.forEach((el, index) => {
          if (index === j) {
            (<FormArray>this.level.controls[i].get('activities')).removeAt(index);
            activityArray.insert(index,this.fb.group({
              community_id: [res.activityData.community_id],
              dot_quest_level_id: [res.activityData.dot_quest_level_id],
              name: [res.activityData.name],
              wp_activity_id: [res.activityData.wp_activity_id],
              sequence: [res.activityData.sequence],
              dependency: [res.activityData.dependency],
              completion_dotcoins: [res.activityData.completion_dotcoins],
              badges: [res.activityData.badges],
              badge_name: [res.activityData.badge_name],
              is_mandatory: [res.activityData.is_mandatory],
              is_intro: [res.activityData.is_intro],
              attachment_filepath: [res.activityData.attachment_filepath],
              display_name: [res.activityData.display_name],
              id: [res.activityData.id]
            }));
          }
        });
      }
    }

    );
  }
  deleteActivity(i, j) {
    const activityArray = this.level.controls[i].get('activities') as FormArray;
    const selectedActivity = activityArray.controls[j].value;
    const deleteModelRef = this.modalService.open(DeleteComponent, { centered: true, backdrop: 'static' });
    deleteModelRef.componentInstance.message = 'Are you sure you want to delete this Activity?';
    deleteModelRef.result.then((res) => {
      if (res) {
        this.deleteActivityRecord(selectedActivity, i, j);
      }
    }, (reason) => {
      if (reason) { this.deleteActivityRecord(selectedActivity, i, j); }
    });
  }

  deleteActivityRecord(selectedActivity, i, j) {
    const id = selectedActivity.id;
    this.adminHelperService.deleteActivities(id).subscribe(res => {
      this.isLoading = false;
      if (res) {
        (<FormArray>this.level.controls[i].get('activities')).controls.forEach((el, index) => {
          if (index === j) {
            (<FormArray>this.level.controls[i].get('activities')).removeAt(index);
          }
        });
          this.toastrService.success('Activity deleted successfully');
        }
    }, err => this.isLoading = false);
  }

  questEdit() {
    this.isLoading = false;
  }

}
