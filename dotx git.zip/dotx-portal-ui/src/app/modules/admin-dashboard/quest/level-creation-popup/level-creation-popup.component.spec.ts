import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LevelCreationPopupComponent } from './level-creation-popup.component';

describe('LevelCreationPopupComponent', () => {
  let component: LevelCreationPopupComponent;
  let fixture: ComponentFixture<LevelCreationPopupComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LevelCreationPopupComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LevelCreationPopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
