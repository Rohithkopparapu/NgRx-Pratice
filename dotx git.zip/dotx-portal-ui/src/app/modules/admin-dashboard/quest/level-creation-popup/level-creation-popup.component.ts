import { ThrowStmt } from '@angular/compiler';
import { Component, Input, OnInit} from '@angular/core';
import { AbstractControl, FormArray, FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ModalDismissReasons, NgbActiveModal, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ToastrService } from 'ngx-toastr';
import { FileUploadComponent } from 'src/app/shared/component/file-upload/file-upload.component';
import { HelperService } from 'src/app/shared/services/helper.service';
import { AdminHelperService } from '../../admin-helper.service';
import { CreateNewField } from 'src/app/shared/constants/input.constants'
import { ImageVideoViewComponent } from 'src/app/shared/component/image-video-view/image-video-view.component';
import { DeleteComponent } from 'src/app/shared/component/delete/delete.component';
@Component({
  selector: 'app-level-creation-popup',
  templateUrl: './level-creation-popup.component.html',
  styleUrls: ['./level-creation-popup.component.scss']
})
export class LevelCreationPopupComponent implements OnInit {
  closeResult = '';
  teacherRows: FormArray;
  studentrRows: FormArray;
  testTemplate:CreateNewField[]=[]
  testTemplates:CreateNewField = <CreateNewField>{}
  template=[]
  createLevelForm = this.fb.group({
    community_id: [''],
    code: ['',[Validators.required]],
    description: [''],
    name:['',Validators.required],
    sequence:['',[Validators.required, Validators.pattern('^[0-9]*$')]],
    // role_name: this.fb.array([
    //   this.fb.control(null)
    // ]),
    // dummyTag: this.fb.array([
    //   this.fb.control(null)
    // ]),
    roles: this.fb.array([]),
    // phones: this.fb.array([
    //   this.fb.control(null)
    // ])
    teacherRows: this.fb.array([this.initRows()]),
    studentrRows: this.fb.array([this.initRowsS()]),
    is_teacher:[''],
    is_student:['']
  });
  isLoading: boolean = false;
  profileImageList: any[] = [];
  bannerImageList: any[] = [];
  lessonImageList: any[] = [];
  selectedType: string;
  community_name:any;
  @Input() communitydata;
  communitiesList: any;
  leveldetails: any;
  headerName: string= "Create Level";
  levelInfo:boolean = false;
  edit:boolean = false;
 @Input() data: any;
  communityId: number;
  profilename: any[];
  bannername: any[];
  bannernameFlag: boolean = true;
  profilenameFlag: boolean = true;


  constructor(private modalService:NgbModal,
              private fb: FormBuilder, 
              private ngbActiveModal:NgbActiveModal,
              private adminHelperService: AdminHelperService,
              public _uhs: HelperService,
              private router: Router, 
              private toastrService: ToastrService){ 
             
              }

  ngOnInit() {
    this.data;
    
    this.getCommunities();
    if(this.data != undefined && this.data.headerName === 'Update Level'){
      this.updateLeveldata();
    }
  console.log('test le',this.data);

  }

  getCommunities(): void {
    this.isLoading = true;
    this.adminHelperService.getAllCommunities().subscribe(res => {
      this.isLoading = false;
      if (res && res.length) {
        this.communitiesList = res;
        this.communityId= Number(this.communitydata);
        this.createLevelForm.patchValue({
          community_id : Number(this.communitydata),
        })
      }
    }, () => this.isLoading = false);
  
  }

  submit(){
    if(this.headerName === 'Create Level'){
      this.submitCreatelevel();
    }
    if(this.headerName === 'Update Level'){
      this.submitUpdateLevel();
    }
  }

  submitCreatelevel():void{
   
    if(this.createLevelForm.valid ){
      if(this.bannerImageList.length !== 0 && this.profileImageList.length !== 0){
        let SFdata= this.createLevelForm.controls.studentrRows.value
        let Sdata=SFdata.filter(element=> (element.material_name!="" && element.material_file_path!=""));
        let tFdata= this.createLevelForm.controls.teacherRows.value
        let Tdata=tFdata.filter(element=> (element.material_name!="" && element.material_file_path!=""))
    const payload = {
      community_id	: Number(this.communitydata),
      code	:	this.createLevelForm.controls.code.value,
      description	:	this.createLevelForm.controls.description.value,
      name	:	this.createLevelForm.controls.name.value,
      sequence	:	this.createLevelForm.controls.sequence.value,
      display_name: this.profileImageList[0].name,
      attachment_filepath: this.profileImageList[0].file,
      banner_name: this.bannerImageList[0].name,
      banner_filepath: this.bannerImageList[0].file,
      students_lesson:Sdata, //this.createLevelForm.controls.studentrRows.value,
      teachers_lesson:Tdata //this.createLevelForm.controls.teacherRows.value
    }
    // console.log("ghgf",fdataa);
    // return
    this.adminHelperService.saveLevelData(payload).subscribe(res =>{
      if (res) {
        this.ngbActiveModal.close({status:'success',levelData: res});
        this.toastrService.success("Level created successfully");
        
      }else{
        this.ngbActiveModal.close({status:'fail',levelData: {} });
        this.toastrService.warning("Failed to create level");
      }
    },err => this.isLoading = false);
    }else{
      this._uhs.validateAllFormFields(this.createLevelForm);
    this.toastrService.warning('Profile/Banner Image is required');
    } 
    }else{
      this._uhs.validateAllFormFields(this.createLevelForm);
      this.toastrService.warning('Please enter all required fields');
    }
  }

  submitUpdateLevel(){
    // console.log("ghgf",this.createLevelForm);
    // return
    let condit:boolean=true
    let condis:boolean=true
    let checkTM = this.createLevelForm.controls.teacherRows.value;
    let checkSM = this.createLevelForm.controls.studentrRows.value;
    checkSM.forEach(element=>{ if(element.material_name && !element.material_file_path){
        this.toastrService.warning("Please upload student material file")
        condis=false
      }
      if(!element.material_name && element.material_file_path){
        this.toastrService.warning("Please enter student materials")
        condis=false
      }
      
    })
    checkTM.forEach(element=>{ if(element.material_name && !element.material_file_path){
        this.toastrService.warning("Please upload teacher material file")
        condit=false
      }
      if(!element.material_name && element.material_file_path){
        this.toastrService.warning("Please enter teacher materials")
        condis=false
      }
      
    })
      let Sdata=checkSM.filter(element=> (element.material_name!="" && element.material_file_path!=""));
      let Tdata=checkTM.filter(element=> (element.material_name!="" && element.material_file_path!=""))
    if(condit && condis){
      if(this.createLevelForm.valid ){
        if(((this.bannerImageList.length !== 0 || this.data.selectedLevel.banner_name !== null )&&(this.bannerImageList.length !== 0 || this.data.selectedLevel.banner_name !== "" )) &&
         ((this.profileImageList.length !== 0 || this.data.selectedLevel.display_name !== null )&&(this.profileImageList.length !== 0 || this.data.selectedLevel.display_name !== "")))
         {
    
        const payload={
          community_id  : Number(this.communitydata),
          // banner_filepath : this.bannerImageList[0].file === undefined ? this.data.selectedLevel.banner_filepath : this.bannerImageList[0].file,
          // attachment_filepath : this.profileImageList[0].file === undefined? this.data.selectedLevel.attachment_filepath: this.profileImageList[0].file,
          code  : this.createLevelForm.controls.code.value,
          description : this.createLevelForm.controls.description.value,
          name  : this.createLevelForm.controls.name.value,
          sequence  : this.createLevelForm.controls.sequence.value,
          id: this.data.selectedLevel.id,
          // banner_name: this.data.selectedLevel.banner_name === "" ?  this.bannerImageList[0].name : this.data.selectedLevel.banner_name,
          // display_name:  this.data.selectedLevel.display_name === "" ?  this.profileImageList[0].name : this.data.selectedLevel.display_name,
          students_lesson: Sdata,//this.createLevelForm.controls.studentrRows.value,
          teachers_lesson:Tdata,//this.createLevelForm.controls.teacherRows.value
        }
          if(this.bannerImageList.length !== 0 ){
            payload['banner_name']= this.bannerImageList[0].name;
            payload['banner_filepath'] = this.bannerImageList[0].file;
          }else{
            payload['banner_name']= this.data.selectedLevel.banner_name;
            if((this.data.selectedLevel.banner_filepath !== "" && this.data.selectedLevel.banner_filepath !== null )){
              if(this.data.selectedLevel.banner_filepath.includes('http')){
                payload['banner_filepath'] = this.data.selectedLevel.banner_filepath.split('uploads/')[1];
              }
            }else{
            payload['banner_filepath'] = this.data.selectedLevel.banner_filepath === null? "" : this.data.selectedLevel.banner_filepath;
            }
          }
    
          if(this.profileImageList.length !== 0 ){
            payload['display_name']= this.profileImageList[0].name;
            payload['attachment_filepath'] = this.profileImageList[0].file;
          }else{
            payload['display_name']= this.data.selectedLevel.display_name;
            if((this.data.selectedLevel.attachment_filepath !== "" && this.data.selectedLevel.attachment_filepath !== null) ){
              if(this.data.selectedLevel.attachment_filepath.includes('http')){
              payload['attachment_filepath'] = this.data.selectedLevel.attachment_filepath.split('uploads/')[1];
              }
            }else{
              if(this.data.selectedLevel.attachment_filepath === null){
              payload['attachment_filepath'] = this.data.selectedLevel.attachment_filepath === null ? "" : this.data.selectLevel.attachment_filepath;
              }else if(this.data.selectedLevel.attachment_filepath === ""){
                payload['attachment_filepath'] = this.data.selectedLevel.attachment_filepath === "" ? "" : this.data.selectLevel.attachment_filepath;
    
              }
            }
          }
    
    
        // if(this.bannernameFlag === false && this.bannerImageList.length === 0 ){
        //   data['banner_name']= this.data.selectedLevel.banner_name === null ?  this.bannerImageList[0].name : this.data.selectedLevel.banner_name;
        // }else{
        //   this._uhs.validateAllFormFields(this.createLevelForm);
        //   this.toastrService.warning('Profile/Banner Image is required');
        //   return;
        // }
    
        // if(this.profilenameFlag === false && this.profileImageList.length === 0 ){
        //   data['display_name']= this.data.selectedLevel.display_name === null ?  this.profileImageList[0].name : this.data.selectedLevel.display_name;
        // }else{
        //   this._uhs.validateAllFormFields(this.createLevelForm);
        //   this.toastrService.warning('Profile/Banner Image is required');
        //   return;
        // }
        console.log("new ",payload);
        // return
        this.adminHelperService.updateLevel(payload).subscribe(res =>{
          if (res) {
            res['activities'] = this.data.selectedLevel.activities;
            this.ngbActiveModal.close({status:'success',levelData: res});
            this.toastrService.success("Level updated successfully");
            
          }else{
            this.ngbActiveModal.close({status:'fail',levelData: {} });
            this.toastrService.warning("Failed to update level");
          }
        },err => this.isLoading = false);
      }else{
        this._uhs.validateAllFormFields(this.createLevelForm);
        this.toastrService.warning('Profile/Banner Image is required');
      }
      }else{
        this._uhs.validateAllFormFields(this.createLevelForm);
        this.toastrService.warning('Please enter all required fields');
      }
    }
    
  }

  navigateClosebtn(){
    this.ngbActiveModal.close({status: 'Failed', levelData: {} });
    this.router.navigate(['/auth/admin/community', 'create']);
  }

  
  updateLeveldata(){
    if(this.data != undefined && this.data.headerName === 'Update Level'){
      this.headerName = this.data.headerName;
      this.levelInfo = this.data.levelInfo==='Update';
      this.edit = true;
    }
      this.createLevelForm.patchValue({
        code:  this.data.selectedLevel.code,
        description: this.data.selectedLevel.description,
        name: this.data.selectedLevel.name,
        sequence:this.data.selectedLevel.sequence,
        community_id	: this.data.selectedLevel.community_id,
        // teacherRows:this.data.leverInfoTecher,
        // studentrRows:this.data.leverInfoStudent
      })

      this.data.leverInfoTecher.forEach((element,index) => {
        const activityArray = this.createLevelForm.controls['teacherRows'] as FormArray;
        activityArray.insert(index,this.fb.group({
          binary_image_name:element.binary_image_name,
          binary_image_path: element.binary_image_path,
          material_display_name: element.material_display_name, 
          material_file_path: element.material_file_path,
          material_name:element.material_name,
          attachment_id:element.attachment_id
          // role_img: element.role_img, 
          // role_imgPlan: element.role_imgPlan,
        }));
      });

      this.data.leverInfoStudent.forEach((element,index) => {
        const activityArray = this.createLevelForm.controls['studentrRows'] as FormArray;
        activityArray.insert(index,this.fb.group({
          binary_image_name:element.binary_image_name,
          binary_image_path: element.binary_image_path,
          material_display_name: element.material_display_name, 
          material_file_path: element.material_file_path,
          material_name:element.material_name,
          attachment_id:element.attachment_id
          // role_img: element.role_img, 
          // role_imgPlan: element.role_imgPlan,
        }));
      });

      
  }

  

  open(content) {
    this.modalService.open(content, {ariaLabelledBy: 'modal-basic-title'}).result.then((result) => {
    }, (reason) => {
      this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
    });
  }

  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return `with: ${reason}`;
    }
  }
  closeModal(): void {
    this.ngbActiveModal.close({status: 'Failed', levelData: {} });
  }

  uploadDocument(type: string, title: string,fileCategory: any) {
    this.selectedType = title;
    const modalData = {
      headerName: title,
      fileType: type,
      fileCategory,
      isMultipleFile: false
    };
    const modalRef = this.modalService.open(FileUploadComponent, {
      keyboard: false,
      backdrop: 'static',
      scrollable: true,
      windowClass: 'modal-cover modal-cover-fluid modal-upload'
    });
    modalRef.componentInstance.data = modalData;
    modalRef.result.then((res) => {
      console.log(res);
    }, (reason) => {
      if (reason) {
        console.log("upload",reason);
        if (reason) {
          this.setFileName(reason, title);
          this.createLevelForm .markAsTouched({ onlySelf: true });
        }
      }
    });
  }
  setFileName(res: any, title: string): void {
    if (res && res.length) {
      if (this.selectedType === 'profileImage') {
        this.addOrReplaceAttachment(this.profileImageList, res, title);
       
      }
      if (this.selectedType === 'bannerImage'){
        this.addOrReplaceAttachment(this.bannerImageList, res, title);
        
      }
    }
  }
  addOrReplaceAttachment(attachmentList, res, title): void {
    while (attachmentList.length > 0) {
      attachmentList.pop();
    }
    attachmentList.push({attachment_title: title, file: res[0].file, name: res[0].display_name, url: res[0].fileUrl});
  }

  deleteFile(event: Event, item: any, type: string) {
    event.stopPropagation();
    this.createLevelForm.markAsTouched({ onlySelf: true });
    if (type === 'quest_profile_image') {
      this.profileImageList = this.profileImageList.filter(img => img.file !== item.file);
      
    }else if(type === 'quest_banner_image') {
      this.bannerImageList = this.bannerImageList.filter(img => img.file !== item.file);      
    }
    // if(type==)
  }

  deleteBanner(){
    this.bannernameFlag = false;
  }

  deleteProfileImage(){
    this.profilenameFlag = false;
  }
  // upload image for lesson ploanuploadLessonPlan
  // teacher material
    uploadLessonPlanTchr(roleIndex) {
      // this.selectedType = title;
      const modalData = {
        headerName: "Upload Plan",
        fileType: "docnew",
        fileCategory: "lesson_document",
        isMultipleFile: false,
        planfor:"Teachers Hands out"
      };
      const modalRef = this.modalService.open(FileUploadComponent, {
        keyboard: false,
        backdrop: 'static',
        scrollable: true,
        windowClass: 'modal-cover modal-cover-fluid modal-upload'
      });
      modalRef.componentInstance.data = modalData;
      modalRef.result.then((res) => {
        console.log(res);
      }, (reason) => {
        if (reason) {
          console.log("upload", reason);
          if (reason) {
            this.teacherRows = this.createLevelForm.get('teacherRows') as FormArray;
            this.teacherRows.at(roleIndex).patchValue({
              role_imgPlan: reason[0].file,
              material_file_path: reason[0].fileUrl,
              material_display_name:reason[0].name
            });
            console.log(this.teacherRows);
            
          }
        }
      });
    }
    uploadImageTchr(roleIndex) {
      const modalData = {
        headerName: 'Role Image',
        fileType: 'image',
        fileCategory: 'role',
        isMultipleFile: false
      };
      const modalRef = this.modalService.open(FileUploadComponent, {
        keyboard: false,
        backdrop: 'static',
        scrollable: true,
        windowClass: 'modal-cover modal-cover-fluid modal-upload'
      });
      modalRef.componentInstance.data = modalData;
      modalRef.result.then((res) => {
        console.log(res);
      }, (reason) => {
        if (reason && reason.length) {
          this.teacherRows = this.createLevelForm.get('teacherRows') as FormArray;
          this.teacherRows.at(roleIndex).patchValue({
            role_img: reason[0].file,
            binary_image_path: reason[0].fileUrl,
            binary_image_name:reason[0].name
          });
        }
        console.log(this.teacherRows);

      });
    }
    get formArr() {
      return this.createLevelForm.get('teacherRows') as FormArray;
    }
    initRows() {
      let roleImage = 'image-icon.png'
      return this.fb.group({
        material_name: [''],
        binary_image_name: [''],
        role_img: [roleImage],
        binary_image_path: ['assets/img/' + roleImage],
        role_imgPlan: [roleImage],
        material_file_path: [''],
        material_display_name:['']

      });
    }

    addNewRow() {
      this.formArr.push(this.initRows());
    }

    deleteRow(index: number) {
      this.formArr.removeAt(index);
    }
    // activity.material_display_name,activity.material_name,activity.category_type
    openViewerModel(type: string, url: string,material,mtype): void {
      const modalRef = this.modalService.open(ImageVideoViewComponent, {
        centered: true,
        size: 'lg'
      });
      let fileTypes= material.split('.')
      if(fileTypes[1] == "docx" || fileTypes[1] == "doc"){
        type="doc"
      }
      if(fileTypes[1]=='xlsx'|| fileTypes[1]=='xls'|| fileTypes[1]=='csv'){
        type="excel"
      }
      modalRef.componentInstance.fileType = type;
      modalRef.componentInstance.fileUrl = url;
      modalRef.componentInstance.materialName = "Materials";
      modalRef.componentInstance.mtype = mtype;
    }
    // student materials
    get formArrS() {
      return this.createLevelForm.get('studentrRows') as FormArray;
    }
    initRowsS() {
      let roleImage = 'image-icon.png'
      return this.fb.group({
        material_name: [''],
        binary_image_name: [''],
        role_img: [roleImage],
        binary_image_path: ['assets/img/' + roleImage],
        role_imgPlan: [roleImage],
        material_file_path: [''],
        material_display_name:['']
      });
    }

    addNewRowS() {
      this.formArrS.push(this.initRowsS());
    }
    deleteRowS(index: number,itemrow,type) {
      if(!this.edit){
        if(type=='student'){this.formArrS.removeAt(index); }
        if(type=='teacher'){this.formArr.removeAt(index); }
      }
       
      
      if(this.edit){
        if(itemrow.controls['material_file_path'].value){
          let id:any;
          if(itemrow.controls['attachment_id']){
            id= itemrow.controls['attachment_id'].value;
          }else{
            id= 0;
          }
          
          const deleteModelRef = this.modalService.open(DeleteComponent, { centered: true, backdrop: 'static' });
            deleteModelRef.componentInstance.message = 'Are you sure, want to delete this Material?';
            deleteModelRef.result.then((res) => {
              if (res) {
                this.deleteRecord(id);
                if(type=='student'){this.formArrS.removeAt(index); }
                if(type=='teacher'){this.formArr.removeAt(index); }
              }
            }, (reason) => {
              if (reason) {
                this.deleteRecord(id);
                if(type=='student'){this.formArrS.removeAt(index); }
                if(type=='teacher'){this.formArr.removeAt(index); }
              }
            });
          
        }
        if(!itemrow.controls['material_file_path'].value){
          if(type=='student'){this.formArrS.removeAt(index); }
          if(type=='teacher'){this.formArr.removeAt(index); }
        }
      }
    }
    deleteRecord(topicId: number): any {
      const payload={"attachment_id":topicId}
      this.isLoading = true;
      this.adminHelperService.deleteMaterial(payload).subscribe(res => {
        this.isLoading = false;
        if (res) {
          this.toastrService.success(`Material DELETED successfully`);
          // this.loadChallenges();
        }
      }, err => this.isLoading = false);
    }
    uploadImageStd(roleIndex) {
      const modalData = {
        headerName: 'Role Image',
        fileType: 'image',
        fileCategory: 'role',
        isMultipleFile: false
      };
      const modalRef = this.modalService.open(FileUploadComponent, {
        keyboard: false,
        backdrop: 'static',
        scrollable: true,
        windowClass: 'modal-cover modal-cover-fluid modal-upload'
      });
      modalRef.componentInstance.data = modalData;
      modalRef.result.then((res) => {
        console.log(res);
      }, (reason) => {
        if (reason && reason.length) {
          this.studentrRows = this.createLevelForm.get('studentrRows') as FormArray;
          this.studentrRows.at(roleIndex).patchValue({
            role_img: reason[0].file,
            binary_image_path: reason[0].fileUrl,
            binary_image_name:reason[0].display_name
          });
        }
        console.log(this.studentrRows);

      });
    }
    uploadLessonPlanStdnt(roleIndex) {
      // this.selectedType = title;
      const modalData = {
        headerName: "Upload Plan",
        fileType: "docnew",
        fileCategory: "lesson_document",
        isMultipleFile: false,
        planfor:"Students Hands out"
      };
      const modalRef = this.modalService.open(FileUploadComponent, {
        keyboard: false,
        backdrop: 'static',
        scrollable: true,
        windowClass: 'modal-cover modal-cover-fluid modal-upload'
      });
      modalRef.componentInstance.data = modalData;
      modalRef.result.then((res) => {
        console.log(res);
      }, (reason) => {
        if (reason) {
          console.log("upload", reason);
          if (reason) {
            this.studentrRows = this.createLevelForm.get('studentrRows') as FormArray;
            this.studentrRows.at(roleIndex).patchValue({
              role_imgPlan: reason[0].file,
              material_file_path: reason[0].fileUrl,
              material_display_name:reason[0].name
            });
          }
        }
      });
    }

    deleteTSfile(event: Event, item: any, type: string,i) {
      console.log(event,item)
      event.stopPropagation();
      // this.createLevelForm.markAsTouched({ onlySelf: true });
      if (type === 'teacher_material') {
        this.teacherRows = this.createLevelForm.get('teacherRows') as FormArray;
        this.teacherRows.at(i).patchValue({
          material_file_path: '',
          material_display_name:''
        });
        // this.profileImageList = this.profileImageList.filter(img => img.file !== item.file);
        
      }else if(type === 'student_material') {
        this.studentrRows = this.createLevelForm.get('studentrRows') as FormArray;
        this.studentrRows.at(i).patchValue({
          material_file_path: '',
          material_display_name:''
        });
        // this.bannerImageList = this.bannerImageList.filter(img => img.file !== item.file);      
      }
      // if(type==)
    }
  }

  
  // populateRolesTchr(rolesList) {
  //   if (rolesList && rolesList.length) {
  //     this.isEnable = true;
  //     rolesList.forEach((role, _index) => {
  //       this.addRole();
  //       role.tags.forEach(tag => {
  //         this.addSkillTag(_index);
  //       });
  //     });
  //     this.challengeForm.patchValue({
  //       roles: rolesList.map(({role_img, role_img_url, role_name, tags, role_id}) => ({role_img, role_img_url, role_name, tags, role_id}))
  //     });
  //   }
  // }