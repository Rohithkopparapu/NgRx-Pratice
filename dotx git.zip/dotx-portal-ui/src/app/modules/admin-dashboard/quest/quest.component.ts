import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ToastrService } from 'ngx-toastr';
import { DeleteComponent } from 'src/app/shared/component/delete/delete.component';
import { HelperService } from 'src/app/shared/services/helper.service';
import { AdminHelperService } from '../admin-helper.service';


@Component({
  selector: 'app-quest',
  templateUrl: './quest.component.html',
  styleUrls: ['./quest.component.scss']
})
export class QuestComponent implements OnInit {

  isLoading = false;
  list:any;
  selectedFilter = 'Last 6 Months';
  searchQuest: any='';
  dateFormatKeys = ['created_date'];
  pageSearch = 1;
  communityList: any;

  constructor(public route: ActivatedRoute,
              private adminHelperService: AdminHelperService, 
              private modalService: NgbModal,
              private toastrService: ToastrService,
              private router : Router,  private helperService: HelperService ) { }

  ngOnInit() {
    // this.listData();
    this.getCommunities();
  }
  processPayload() {
    let payload = {};
    payload = this.selectedFilter !== 'All' ? { time_filter: this.selectedFilter } : payload;
    return payload;
  }


  listData() {
    this.isLoading = true;
    this.resetValues();
    const payload = this.processPayload();
    this.adminHelperService.questLevelsLists(payload).subscribe(result =>{
    this.isLoading = false;
      if (result && result.length) {
            this.list = result;
      }
    }, err => this.isLoading = false);
  }


  getCommunities(): void {
    this.isLoading = true;
    this.resetValues();
    const payload = {
      // time_filter: this.selectedFilter
    };
    this.adminHelperService.getCommunitiesByFilter(payload).subscribe(res => {
      this.isLoading = false;
      if (res && res.length) {
        res.forEach(community => {
          const imageList = community.attachments.flatMap(i => i.attachment_title === 'community_image' ? i.url : []);
          community['community_image'] = imageList && imageList.length ? imageList[0] : null;
        });
        this.communityList = res;
      }
    }, () => this.isLoading = false);
  }



  resetValues() {
    this.list = [];
    this.pageSearch = 1;
  }
  onChangeFilter(value): void {
    this.selectedFilter = value;
    this.listData();
  }

  // listData(){
  //   this.adminHelperService.questLevelsLists().subscribe(result =>{
  //     this.list = result;
  //   })
  // }

  setSearchValue($event: any): void {
    this.searchQuest = $event;
  }

  onEdit(communityId :any){
    this.isLoading = true;
    this.resetValues();
    const payload = this.processPayload();
    this.adminHelperService.questLevelsLists(communityId).subscribe(result =>{
    this.isLoading = false;
      if (result && result.length) {
            this.list = result;
            this.router.navigate(['/auth/admin/quest/create'], {state: {data: this.list, communityId: communityId}});
      }
    }, err => this.isLoading = false);
    

  }
  checkOffer(community: any): boolean {
    return this.helperService.checkOfferDate(community);
  }

  onDelete(id) {
    const deleteModelRef = this.modalService.open(DeleteComponent, { centered: true, backdrop: 'static' });
    deleteModelRef.componentInstance.message = 'Are you sure you want to delete this level?';
    deleteModelRef.result.then((res) => {
      if (res) {
        this.deleteRecord(id);
      }
    }, (reason) => {
      if (reason) { this.deleteRecord(id); }
    });
  }

  deleteRecord(i) {
    const id = i;
    this.adminHelperService.deleteLevelData(id).subscribe(res => {
      this.isLoading = false;
      if (res === "you cannot delete this Level") {
        this.toastrService.warning("Failed to delete level(Activities are mapped to this level)");
        this.listData()
      }else{
        this.toastrService.success("Quest deleted successfully")
        this.listData();
      }
    }, err => this.isLoading = false);
  }

}
