import { Component, ElementRef, OnInit, QueryList, ViewChild, ViewChildren } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { AdminHelperService } from '../admin-helper.service';
import { HelperService } from '../../../shared/services/helper.service';
import { ColumnViewDetails, REPORT_SERVICE_LIST } from '../../../shared/constants/input.constants';
import { FormBuilder, Validators } from '@angular/forms';
import { ExportFileService } from '../export-file.service';
import { SplitCamelCasePipe } from '../../../shared/pipes/split-camel-case.pipe';
import { zipWith, cloneDeep, map, partialRight, pick } from 'lodash';
import { StudentHelperService } from '../../student-dashboard/student-helper.service';
import { onlineSocketUsers, userInfo } from 'src/app/shared/store/auth.selector';
import { Subject } from 'rxjs';
import { AuthState } from 'src/app/shared/store/auth.model';
import { Store } from '@ngrx/store';
import { takeUntil } from 'rxjs/operators';
import * as moment from 'moment';
import { HttpClient } from '@angular/common/http';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { StudentActivityInformationComponent } from '../activitiy-information/activity-information.component';
// import { Subscription } from 'rxjs';
// import { DataService } from '../../../shared/services/data.service';
@Component({
  selector: 'app-reports',
  templateUrl: './reports.component.html',
  styleUrls: ['./reports.component.scss']
})
export class ReportsComponent implements OnInit {
  private subscriptions = new Subject<void>();
  // private subscription: Subscription;
  @ViewChild('reportRef', { static: false }) reportRef: ElementRef;
  reportServiceList = REPORT_SERVICE_LIST;
  @ViewChildren('newsFeedPosts') newsFeedPostsElement: QueryList<any>;
  selectedReport: any;
  headerMap: Map<string, ColumnViewDetails>;
  columnHeaders: any[] = [];
  reportForm = this.fb.group({
    startDate: ['', Validators.required],
    endDate: ['']
  });
  queryData: string;
  minDate = { month: 12, year: 2021, day: 5 };
  maxDate = this._uhs.getSpotlightFormattedStartMinDate();
  dateFormatKeys = [];
  isLoading: boolean;
  isShow: boolean = false;
  page = 1;
  total_record: any;
  userInfo: any;
  classListData: any[];
  communitiesList: any[];
  selectedFilter: any = '';
  selectedGroup: any = '';
  selectedClass: any = '';
  selectCommunityId: any;
  groupListData: any;
  groupId: any;
  dataList: any[] = [];
  finalData: any[] = []
  groupedPeople: any;
  totalLevels: any;
  subscribedCommunitiesList: any = [];
  totalActivities: any;
  totalChallenges: any;
  actvitiesinformation: Object;
  thName: boolean = true;
  thClass: boolean = false;
  thComm: boolean = false;
  thLevel: boolean = false;
  thActivity: boolean = false;
  thChallenge: boolean = false;
  namedesc: boolean = false;
  nameasc: boolean = true;
  classdesc: boolean = false;
  classasc: boolean = true;
  comdesc: boolean = false;
  comasc: boolean = true;
  leveldesc: boolean = false;
  levelasc: boolean = true;
  activitydesc: boolean = false;
  activityasc: boolean = true;
  challengedesc: boolean = false;
  challengeasc: boolean = true;
  dNameSort: boolean = false;
  dClassSort: boolean = true;
  dCommSort: boolean = true;
  dLevelSort: boolean = true;
  dActivitySort: boolean = true;
  dChallengeSort: boolean = true;
  SchoolList: any = [];
  selectedSchool: any;

  constructor(
    private adminHelperService: AdminHelperService,
    private toastrService: ToastrService,
    private _uhs: HelperService,
    private fb: FormBuilder,
    private exportFileService: ExportFileService,
    private http: HttpClient, private studentHelperService: StudentHelperService,
    private store$: Store<AuthState>, private helperService: HelperService, private modalService: NgbModal
    // private dataService: DataService
  ) {
    this.store$.select(userInfo)
      .pipe(takeUntil(this.subscriptions))
      .subscribe(res => {
        this.userInfo = res;
      });
    // this.subscription = this.dataService.refreshComponent$.subscribe(() => {
    //   this.refreshComponentLogic();
    // });
  }
  header: any
  check: boolean = false;
  id: any;
  isBlockScroll: boolean;
  isLastPage: boolean;
  startDate: { month: number; year: number; day: number };
  setStartDate: { month: number; year: number; day: number };
  setEndDate: { month: number; year: number; day: number };
  data: any[] = []
  reportData: any[] = []
  reportDataCommunity: any[] =[];
  pageSearch = 1;
  teacheDashbrdForm = this.fb.group({
    startDate: [''],
    endDate: [''],
    Certified: ['']
  });

  ngOnInit() {
    this.selectedReport = this.reportServiceList[0];
    if (this.userInfo.dot_registration_id !== null) {
      this.setStartDate = this.helperService.getLastDateByDays(1);
      this.setEndDate = this.minDate;
      this.getMyClass();
      this.getSubscribedCommunities();
      if (this.userInfo.dot_registration_id !== null) {
        const payload = {
          "user_type": "admin"
        }
        this.studentHelperService.getTeacherDashboardData(payload, this.page).subscribe(res => {
          this.classListData = res.classes_list;
        })
      }
    }
    if(this.userInfo.details.responsibilities !== undefined){
      this.SchoolList = this.userInfo.details.responsibilities;
    }
    // this.callReportsService(this.selectedReport.queryName);
  }

  // refreshComponentLogic(){
  //   this.getSubscribedCommunities();
  //   this.getMyClass();
  // }

  callReportsService(queryForm: string) {
    this.reportData =[];
    this.resetValues();
    this.isLoading = true;
    this.adminHelperService.getReportBy(queryForm).subscribe(res => {
      this.isLoading = false;
      if (this.selectedReport !== 4) {
        this.isLoading = false;
        this.columnHeaders = Object.keys(res.data[0]);
        this.headerMap = this._uhs.extractColumnNamesFromObject(this.columnHeaders);
        this.reportData = res.data;
      } else {
        this.isLoading = false;
        this.columnHeaders = Object.keys(res.data[0]);
        this.headerMap = this._uhs.extractColumnNamesFromObject(this.columnHeaders);
        this.reportData = res.data;
      }
      this.isLoading = false;
    }, () => this.isLoading = false);
  }

  // CommunitycallReportsService(queryForm: string) {
  //   this.reportDataCommunity = [];
  //   this.resetValues();
  //   this.isLoading = true;
  //   this.adminHelperService.getReportBy(queryForm).subscribe(res => {
  //     this.isLoading = false;
  //     if (this.selectedReport !== 4) {
  //       this.columnHeaders = Object.keys(res.data[0]);
  //       this.headerMap = this._uhs.extractColumnNamesFromObject(this.columnHeaders);
  //       this.reportDataCommunity = res.data;
  //     } else {
  //       this.columnHeaders = Object.keys(res.data[0]);
  //       this.headerMap = this._uhs.extractColumnNamesFromObject(this.columnHeaders);
  //       this.reportDataCommunity = res.data;
  //     }

  //   }, () => this.isLoading = false);
  // }

  resetValues() {
    // this.reportData = [];
    this.columnHeaders = [];
    this.headerMap = new Map<string, ColumnViewDetails>();
    this.pageSearch = 1;
  }

  onChangeDropdown(report: any): void {
    this.selectedReport = report;
    this.reportForm.reset();
    if (report.id === 4) {
      if(this.SchoolList.length !== 0){
        this.selectedSchool = this.SchoolList[0];
      }
    }
    // this.callReportsService(this.selectedReport.queryName);
  }

  onChangeSchool(school: any) {
    this.selectedSchool = school;
    this.reportForm.reset();
  }

  onSearch(): void {

    if (this.selectedReport.id) {
      if (this.reportForm.controls['startDate'].value !== null) {
        const reportFormData = this.reportForm.value;
        let query = this.selectedReport.queryName;
        if (this.selectedReport.id === 4) {
          query += '?registration_id=' + this.selectedSchool.id
        }
        query += reportFormData['startDate'] ?  this.getSDateKey(this.selectedReport.id) + this._uhs.getFormattedDateToBind(reportFormData['startDate']) : '';
        query += reportFormData['startDate'] && reportFormData['endDate']
          ? '&end_date=' + this._uhs.getFormattedDateToBind(reportFormData['endDate']) : reportFormData['endDate'] ?
            '?end_date=' + this._uhs.getFormattedDateToBind(reportFormData['endDate']) : '';

        // if(this.selectedReport.id !== 4){
          this.callReportsService(query);
        // }else{
        // this.CommunitycallReportsService(query);
        // }
        this.isShow = true;
      } else {
        this.toastrService.warning('Please Select From Date');
      }
    } else {
      this.toastrService.warning('Please Select valid filter');
    }
  }

  getSDateKey(id:any){
    if(id === 4){
    return  '&start_date='
    }else{
     return '?start_date='
    }

  }

  exportFile(): void {
    let customizedList: any = [];
    if (this.columnHeaders.length) {
      const displayNamesList = this.columnHeaders.map(element => {
        if (this.headerMap.get(element).isActive) {
          return SplitCamelCasePipe.prototype.transform(this.headerMap.get(element).displayName);
        }
      });
      const exportWith = zipWith(this.columnHeaders, displayNamesList, (key, value) => ({ key, value }));
      let listData: any[] = cloneDeep(this.reportData);
      const DateTimeKeysList: any[] = this.columnHeaders.filter(ele => (this.headerMap.get(ele).available && this.headerMap.get(ele).isActive && (this.headerMap.get(ele).type === 'DATETIME' || this.headerMap.get(ele).type === 'DATE')));
      listData = this._uhs.formatDateTimeInListIfExists(listData, DateTimeKeysList);
      customizedList = map(listData, partialRight(pick, this.columnHeaders));
      this.exportFileService.exportAsFile(customizedList, exportWith, this.selectedReport.name, 'EXCEL');
    } else {
      this.toastrService.warning('No Data found...');
    }
  }

  onPageChange(offset: number) {
    console.log(offset);
    this.page = offset;
    this.onSearch();
  }

  openPopup(data) {
    this.isLoading = true;
    this.studentHelperService.getActivitiesInfo(data.userId, data.community_id).subscribe(res => {
      this.actvitiesinformation = res;
      this.isLoading = false;
      if (res) {
        const modelRef = this.modalService.open(StudentActivityInformationComponent, {
          centered: true,
          scrollable: true,
          backdrop: 'static',
          keyboard: false,
          size: 'xl',
          windowClass: 'modal-challenge'
        });
        modelRef.componentInstance.data = res;
        modelRef.componentInstance.studentName = data.studentName;
      }
    }, (err) => {
      this.isLoading = false;
    });


  }

  getNoOfActivites(MA, OA) {
    return MA + OA;
  }

  getTeacherDashboardData(payload) {
    if (this.thName) {
      payload["column_name"] = "name";
      if (this.nameasc) {
        payload["sort_by"] = "asc";
      } else if (this.namedesc) {
        payload["sort_by"] = "desc";
      }
    } else if (this.thClass) {
      payload["column_name"] = "class";
      if (this.classasc) {
        payload["sort_by"] = "asc";
      } else if (this.classdesc) {
        payload["sort_by"] = "desc";
      }
    } else if (this.thComm) {
      payload["column_name"] = "communities";
      if (this.comasc) {
        payload["sort_by"] = "asc";
      } else if (this.comdesc) {
        payload["sort_by"] = "desc";
      }
    } else if (this.thLevel) {
      payload["column_name"] = "levels";
      if (this.levelasc) {
        payload["sort_by"] = "asc";
      } else if (this.leveldesc) {
        payload["sort_by"] = "desc";
      }
    } else if (this.thActivity) {
      payload["column_name"] = "activities";
      if (this.activityasc) {
        payload["sort_by"] = "asc";
      } else if (this.activitydesc) {
        payload["sort_by"] = "desc";
      }
    } else if (this.thChallenge) {
      payload["column_name"] = "challenges";
      if (this.challengeasc) {
        payload["sort_by"] = "asc";
      } else if (this.challengedesc) {
        payload["sort_by"] = "desc";
      }
    }
    const Certified = this.teacheDashbrdForm.controls['Certified'].value;
    if (Certified === true) {
      payload['is_certified'] = true;
    } else if (Certified === false) {
      payload['is_certified'] = false;
    }
    this.isLoading = true;
    this.studentHelperService.getTeacherDashboardData(payload, this.page).subscribe(res => {
      if (res) {
        this.isLoading = false;
        if (res.content !== undefined) {
          let dataList1 = res.content;
          let totalInfo = res.questInfo;

          this.total_record = 0
          if (dataList1.length !== 0) {
            this.dataList = dataList1;
            this.total_record = res.total_records;
            this.totalLevels = totalInfo.total_levels;
            this.totalActivities = totalInfo.total_activities;
            this.totalChallenges = totalInfo.total_challenges;
          } else {
            this.dataList = dataList1;
            this.total_record = res.total_records;
          }
        } else {
          this.toastrService.error(res.message);
        }

        console.log(this.dataList);
      }
    }, (err) => {
      this.isLoading = false;
    });
    // this.isLoading=false;

  }

  onPageChange1(offset: number) {
    console.log(offset);
    this.page = offset;
    const reportFormData = this.teacheDashbrdForm.value;
    const payload = {}
    let start_date = reportFormData['startDate'] ? this._uhs.getFormattedDateToBind(reportFormData['startDate']) : '';
    let end_date = reportFormData['startDate'] && reportFormData['endDate'] ? this._uhs.getFormattedDateToBind(reportFormData['endDate']) : '';
    if (this.groupId) payload['group_id'] = this.groupId;
    if (this.selectedClass) payload['selected_class'] = this.selectedClass;
    if (this.selectCommunityId) payload['community_id'] = this.selectCommunityId;
    if (end_date) payload['end_date'] = end_date;
    if (start_date) payload['start_date'] = start_date;
    if (!end_date && start_date) {
      payload['end_date'] = this._uhs.getFormattedDateToBind(this.maxDate);
    }
    payload['user_type'] = "admin";
    // this.dataList=[]
    this.getTeacherDashboardData(payload)
    // this.reset();
  }

  getTeacherDashboardStudentData(user_id, name, i) {
    // let community_id= this.selectCommunityId ? this.selectCommunityId:''
    //   "community_id":community_id
    let Certified = this.teacheDashbrdForm.controls['Certified'].value;
    const payload = {
      "user_id": user_id
    }
    if (Certified === true) {
      payload['is_certified'] = 1
    } else if (Certified === false) {
      payload['is_certified'] = 0
    }
    if (this.selectCommunityId) {
      payload['community_id'] = this.selectCommunityId
    }
    this.isLoading = true;
    this.studentHelperService.getTeacherDashboardStudentData(payload).subscribe(res => {
      this.isLoading = false
      if (res.data) {
        const bar = new Promise<void>((resolve) => {
          if (res.data.length !== 0) {
            res.data.forEach((element, index, array) => {
              element['userId'] = user_id;
              element['studentName'] = name;
              if (index === array.length - 1) resolve();
            });
          }
        });

        bar.then(() => {
          this.dataList[i].childTable = res.data;
        });
        // this.groupedPeople = res.data;
      } else {
        this.groupedPeople = ''
      }
    }, (err) => {
      this.isLoading = true;
    });
  }

  onChangeStartDate(event: any): void {
    if (event) {
      this.setEndDate = this.helperService.getSpotlightFormattedEndMinDate(event, 1);
    }
  }

  onChangeEndDate(event: any) {
    if (event) {
      this.setStartDate = this.helperService.getSpotlightFormattedEndMinDate(event, -1);
    }
  }
  getMyGroups() {
    const payload = {
      id: this.userInfo.user_id
    }
    this.studentHelperService.getGroupDetails(payload).subscribe(res => {
      console.log("res", res)
      if (res.length > 0) {
        this.groupListData = res.sort((a: { group_name: string; }, b: { group_name: any; }) => a.group_name.localeCompare(b.group_name));
      }

    });
  }
  getMyClass() {
    if (this.userInfo.user_type === "teacher") {
      this.store$.select(userInfo)
        .pipe(takeUntil(this.subscriptions))
        .subscribe(res => {
          this.userInfo = res;
        });
      this.classListData = this.userInfo.details.responsibilities;
      if (this.classListData.length) {
        this.classListData = this.classListData;
      }
    }

  }
  getCommunities(): void {
    this.isLoading = true;
    this.studentHelperService.getAllCommunities().subscribe(res => {
      this.isLoading = false;
      if (res && res.length !== 0) {
        this.communitiesList = res.filter(s =>
          !s.combo && moment(moment(s.community_start_date).format('YYYY-MM-DD')).isSameOrBefore(moment().format('YYYY-MM-DD')) && s.num_challenges > 0);
        this.communitiesList = this.communitiesList.sort((a, b) => a.community_name.localeCompare(b.community_name))

      }
    }, () => this.isLoading = false);
  }

  getSubscribedCommunities(): void {
    this.isLoading = true;
    this.studentHelperService.getAllCommunitiesNew().subscribe(res => {
      this.isLoading = false;
      if (res && res.length !== 0) {
        sessionStorage.setItem('subsribedCommunities',JSON.stringify(res));
        this.subscribedCommunitiesList = res.my_communities.sort((a, b) => a.community_name.localeCompare(b.community_name));
      }
    }, () => this.isLoading = false);
  }

  parseFloat(value: any): number {
    return parseFloat(value);
  }
  roundToInt(value: any): number {
    return Math.round(value);
  }

  getPercentage(MA: any, TMA: any, OA: any, TOA: any, MC: any, TMC: any, OC: any, TOC: any) {
    const activitiespercentage = ((MA + OA) / (TMA + TOA)) * 100;
    const challengespercentage = ((MC + OC) / (TMC + TOC)) * 100;

    const totalpercentage = Math.round((activitiespercentage + challengespercentage) / 2);

    if (totalpercentage > 0) {
      return totalpercentage + '%';
    } else {
      return '-';
    }
  }

  getPercentagewithScore(AS: any, MC: any, TMC: any, OC: any, TOC: any) {
    const activitiespercentage = this.parseFloat(AS);
    const challengespercentage = ((MC + OC) / (TMC + TOC)) * 100;

    const totalpercentage = Math.round((activitiespercentage + challengespercentage) / 2);

    if (totalpercentage > 0) {
      return totalpercentage + '%';
    } else {
      return '-';
    }
  }

  onChangeFilter(value): void {
    if (value.target.innerText == "Select") {
      this.selectedFilter = '';
      this.selectCommunityId = ''
    } else {
      this.selectedFilter = value.target.innerText;
      this.selectCommunityId = value.target.id ? value.target.id : ""
    }
  }
  onChangeMyclass(value): void {

    if (value == "Select") {
      this.selectedClass = '';
    } else {
      this.selectedClass = value;
    }
  }
  onChangeMygroup(value): void {
    if (value.target.innerText == "Select") {
      this.selectedGroup = value.target.innerText;
      this.groupId = ''
    } else {
      this.selectedGroup = value.target.innerText;
      this.groupId = value.target.id ? value.target.id : "All"
    }

  }
  onSearch1() {
    this.page = 1;
    const reportFormData = this.teacheDashbrdForm.value;
    const payload = {}
    let start_date = reportFormData['startDate'] ? this._uhs.getFormattedDateToBind(reportFormData['startDate']) : '';
    let end_date = reportFormData['startDate'] && reportFormData['endDate'] ? this._uhs.getFormattedDateToBind(reportFormData['endDate']) : '';
    if (this.groupId) payload['group_id'] = this.groupId;
    if (this.selectedClass) payload['selected_class'] = this.selectedClass;
    if (this.selectCommunityId) payload['community_id'] = this.selectCommunityId;
    if (end_date) payload['end_date'] = end_date;
    if (start_date) payload['start_date'] = start_date;
    if (!end_date && start_date) {
      // console.log(this._uhs.getFormattedDateToBind(this.maxDate));
      payload['end_date'] = this._uhs.getFormattedDateToBind(this.maxDate);
    }
    payload["user_type"] = "admin";

    if (!start_date && end_date) this.toastrService.warning("Please select start date...");
    this.getTeacherDashboardData(payload)
  }
  reset() {
    this.dataList =[];
    this.selectedClass = ''
    this.groupId = ''
    this.selectedGroup = ''
    this.selectCommunityId = ''
    this.selectedFilter = '';
    this.page = 1;
    this.teacheDashbrdForm.controls['startDate'].setValue('');
    this.teacheDashbrdForm.controls['endDate'].setValue('');
    this.teacheDashbrdForm.controls['Certified'].setValue('');
  }

  toggleNameSort() {
    this.nameasc = !this.nameasc;
    this.namedesc = !this.namedesc;
    this.thName = true;
    this.thClass = false;
    this.thComm = false;
    this.thLevel = false;
    this.thActivity = false;
    this.thChallenge = false;
    this.dNameSort = false;
    this.dClassSort = true;
    this.dCommSort = true;
    this.dLevelSort = true;
    this.dActivitySort = true;
    this.dChallengeSort = true;
    this.onSearch1();
  }

  toggleClassSort() {
    this.classasc = !this.classasc;
    this.classdesc = !this.classdesc;
    this.thClass = true;
    this.thName = false;
    this.thComm = false;
    this.thLevel = false;
    this.thActivity = false;
    this.thChallenge = false;
    this.dNameSort = true;
    this.dClassSort = false;
    this.dCommSort = true;
    this.dLevelSort = true;
    this.dActivitySort = true;
    this.dChallengeSort = true;
    this.onSearch1();
  }

  toggleCommSort() {
    this.comdesc = !this.comdesc;
    this.comasc = !this.comasc;
    this.thComm = true;
    this.thClass = false;
    this.thName = false;
    this.thLevel = false;
    this.thActivity = false;
    this.thChallenge = false;
    this.dNameSort = true;
    this.dClassSort = true;
    this.dCommSort = false;
    this.dLevelSort = true;
    this.dActivitySort = true;
    this.dChallengeSort = true;
    this.onSearch1();
  }

  toggleLevelSort() {
    this.levelasc = !this.levelasc;
    this.leveldesc = !this.leveldesc;
    this.thLevel = true;
    this.thComm = false;
    this.thClass = false;
    this.thName = false;
    this.thActivity = false;
    this.thChallenge = false;
    this.dNameSort = true;
    this.dClassSort = true;
    this.dCommSort = true;
    this.dLevelSort = false;
    this.dActivitySort = true;
    this.dChallengeSort = true;
    this.onSearch1();
  }

  toggleActivitySort() {
    this.activitydesc = !this.activitydesc;
    this.activityasc = !this.activityasc;
    this.thActivity = true;
    this.thComm = false;
    this.thClass = false;
    this.thName = false;
    this.thLevel = false;
    this.thChallenge = false;
    this.dNameSort = true;
    this.dClassSort = true;
    this.dCommSort = true;
    this.dLevelSort = true;
    this.dActivitySort = false;
    this.dChallengeSort = true;
    this.onSearch1();
  }

  toggleChallegeSort() {
    this.challengedesc = !this.challengedesc;
    this.challengeasc = !this.challengeasc;
    this.thChallenge = true;
    this.thActivity = false;
    this.thComm = false;
    this.thClass = false;
    this.thName = false;
    this.thLevel = false;
    this.dNameSort = true;
    this.dClassSort = true;
    this.dCommSort = true;
    this.dLevelSort = true;
    this.dActivitySort = true;
    this.dChallengeSort = false;
    this.onSearch1();

  }
}
