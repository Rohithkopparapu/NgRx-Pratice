import { Component, ElementRef, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ToastrService } from 'ngx-toastr';
import { ERROR_MESSAGE, SUCCESS_MESSAGE } from 'src/app/shared/constants/constant';
import { HelperService } from 'src/app/shared/services/helper.service';
import { CustomValidator } from 'src/app/shared/services/validators/customValidator';
import { AdminHelperService } from '../../admin-helper.service';
// import { Country, State, City } from 'country-state-city';
import { ImageVideoViewComponent } from 'src/app/shared/component/image-video-view/image-video-view.component';
import { FileUploadComponent } from 'src/app/shared/component/file-upload/file-upload.component';
@Component({
  selector: 'app-register-school',
  templateUrl: './register-school.component.html',
  styleUrls: ['./register-school.component.scss']
})
export class RegisterSchoolComponent implements OnInit {

  // @ViewChild('country') country: ElementRef;
  // @ViewChild('city') city: ElementRef;
  // @ViewChild('state') state: ElementRef;
  isLoading = false;
  
  communitiesList: any;
  schoolName = this.fb.group({
    // object_type: [''],
    // object_id: [null],
    schoolcode: ['', [Validators.required]],
    schoolname: ['', [Validators.required]],
    
    area: ['',[Validators.required]],
    address_line_1: ['',[Validators.required]],
    city: ['',[Validators.required]],
    country: ['',[Validators.required]],
    state: ['',[Validators.required]],
    name: ['',[Validators.required]],
    role: ['', [Validators.required]],
    email: ['', [Validators.required,CustomValidator.ValidateEmail]],
    contactno: ['', [Validators.required, CustomValidator.AllowNumericOnly]],
    zipcode: ['', [Validators.pattern('^[0-9]*$'),Validators.required]],
    website: [''],
    altname: [''],
    altrole: [''],
    altcontactno: ['',[ CustomValidator.AllowNumericOnly]],
    altemail:['',[CustomValidator.ValidateEmail]],
    is_active: [true],
    thumbnail_image: [''],
    logo: [''],
  });
  primary_contact: any=[]
  alternate_contact:any=[]
  address:any=[]
  couponCodeData: any;
  isSaving: boolean;
  setStartMinDate: any;
  setEndMinDate: any;
  schoolId: any;
  backButton = "Register a School";
  isDisabled = false;
  couponMaxPrice = 0;
  // countries = Country.getAllCountries();
  states = null;
  cities = null;
  schooldata: any[];
  schoolUpdatedata: any;
  attachmentList: any[] = [];
  logoNameUpdate: any;
  logoUrlUpdate: any;
  selectedType: string;
  isShowUpadate: boolean = true;
  edit: boolean = false;

  // selectedCountry = {
  //   isoCode: 'IN',
  //   name: 'India',
  //   phonecode: '91',
  //   flag: '🇮🇳',
  //   currency: 'INR',
  //   latitude: '20.00000000',
  //   longitude: '77.00000000',
  //   timezones: [
  //     {
  //       zoneName: 'Asia/Kolkata',
  //       gmtOffset: 19800,
  //       gmtOffsetName: 'UTC+05:30',
  //       abbreviation: 'IST',
  //       tzName: 'Indian Standard Time',
  //     },
  //   ],
  // };
  // selectedState;
  // selectedCity;
  // country: any;
  // city: any;
  constructor(public _uhs: HelperService, private fb: FormBuilder, private modalService: NgbModal,
              private route: ActivatedRoute, private adminHelperService: AdminHelperService, private toastrService: ToastrService,
              private router: Router) { 
    //             this.states = State.getStatesOfCountry(this.selectedCountry.isoCode);
    // this.cities = this.selectedState = this.selectedCity = null;
              }

  ngOnInit() {
    this.setStartMinDate = this._uhs.getSpotlightFormattedStartMinDate();
    if (this.route.snapshot.paramMap.get('type') === 'edit') {
      this.schoolId = this.route.snapshot.paramMap.get('id');
      this.backButton = 'Update a School';
      this.getSchoolbyId();
    } else {
      // this.getCommunities();
    }
    
  
}
getSchoolbyId(): void {
  this.isLoading = true;
  this.adminHelperService.getSchoolbyId(this.schoolId).subscribe(res => {
    this.isLoading = false;
    if (res) {
      this.schoolUpdatedata = res;
      this.updateForm(res);
    }
  }, err => this.isLoading = false);
}
  updateForm(res:any): void {
    this.edit = true;
    console.log("ddd",res);
    const today = new Date().toISOString().slice(0, 10);
    this.schoolName.patchValue({
      schoolcode: res.code,
      schoolname: res.name,
      website:  res.website,
      name: res.primary_contact.name,
      role: res.primary_contact.role,
      contactno: res.primary_contact.contact_no,
      email: res.primary_contact.email,
      address_line_1: res.address.address_line_1,
      area: res.address.area,
      city: res.address.city,
      state: res.address.state,
      country: res.address.country,
      zipcode: res.address.zip_code,
      altname: res.alternate_contact.name,
      altrole: res.alternate_contact.role,
      altcontactno: res.alternate_contact.contact_no,
      altemail: res.alternate_contact.email,
      is_active: res.is_active,
      // thumbnail_image: res.thumbnail_image,
      // logo_image: res.original_image,
    });
    this.logoNameUpdate = res.logo_name;
    this.logoUrlUpdate = res.logo;
    // if (res.effective_date && res.effective_date.slice(0, 10) < today) {
    //   this.setStartMinDate = this._uhs.getFormattedDateForAdminChall(res.effective_date);
    //   this.isDisabled = true;
    // }
  }
  // onStateChange($event): void {
  //   debugger;
  //   this.cities = City.getCitiesOfState(
  //     this.selectedCountry.isoCode,
  //     JSON.parse(this.schoolName.controls['state'].value).isoCode
  //   );
  //   console.log("");
    
  //   this.selectedState = JSON.parse(this.states.nativeElement.value);
  //   this.selectedCity = null;
  // }

  // onCityChange($event): void {
  //   this.selectedCity = JSON.parse(this.city.nativeElement.value);
  // }
  submitForm() {
    if (this.schoolName.valid) {
      const schoolNameData = this.processPayload();
      if (!this.schoolId) {
        schoolNameData['logo'] = this.attachmentList.length > 0? this.attachmentList[0].file : null;
        schoolNameData['logo_name'] = this.attachmentList.length > 0? this.attachmentList[0].name : null; 
        this.isSaving = true;
        this.adminHelperService.addSchool(schoolNameData).subscribe(result => {
          this.isSaving = false;
          if (result) {
            this.toastrService.success(SUCCESS_MESSAGE.RECORD_ADDED);
            this.router.navigate(['/auth/admin/school-reg']);
          }
        }, err => this.isSaving = false);
      } else {
        const payload = {
          id: this.schoolId,
          ...schoolNameData
        };
        if (this.attachmentList.length !== 0) {
          payload['logo_name'] = this.attachmentList.length > 0? this.attachmentList[0].name : null; 
          payload['logo'] = this.attachmentList.length > 0? this.attachmentList[0].file : null;
        } else {
          payload['logo_name'] = this.logoNameUpdate === null ? '' : this.logoNameUpdate;
          if ((this.logoUrlUpdate !== "" && this.logoUrlUpdate !== null)) {
            if (this.logoUrlUpdate.includes('http')) {
              payload['logo'] = this.logoUrlUpdate.split('uploads/')[1];
            }
          } else {
            if (this.logoUrlUpdate === null) {
              payload['logo'] = this.logoUrlUpdate === null ? "" : this.logoUrlUpdate;
            } else if (this.logoUrlUpdate === "") {
              payload['logo'] = this.logoUrlUpdate === "" ? "" : this.logoUrlUpdate;

            }
          }
        }
        this.isSaving = true;
        this.adminHelperService.updateSchool(payload).subscribe(result => {
          this.isSaving = false;
          if (result) {
            this.toastrService.success(SUCCESS_MESSAGE.RECORD_UPDATED);
            this.router.navigate(['/auth/admin/school-reg']);
          }
        }, err => this.isSaving = false);
      }
    } else {
      this.toastrService.warning(ERROR_MESSAGE.FIELDS_REQUIRED);
      this._uhs.validateAllFormFields(this.schoolName);
    }
  }
  uploadDocument(type: string, title: string, fileCategory: any) {
    this.selectedType = title;
    const modalData = {
      headerName: title,
      fileType: type,
      fileCategory,
      isMultipleFile: false
    };

    const modalRef = this.modalService.open(FileUploadComponent, {
      keyboard: false,
      backdrop: 'static',
      scrollable: true,
      windowClass: 'modal-cover modal-cover-fluid modal-upload'
    });
    modalRef.componentInstance.data = modalData;
    modalRef.result.then((res) => {
      console.log(res);
    }, (reason) => {
      if (reason) {
        console.log(reason);
        if (reason) {
          this.setFileName(reason, fileCategory);
          this.schoolName.markAsTouched({ onlySelf: true });
        }
      }
    });
  }
  setFileName(res: any, title: string): void {
    if (res && res.length) {
      if (this.selectedType === 'Image') {
        this.addOrReplaceAttachment(this.attachmentList, res, title);
      }
    }
  }
  addOrReplaceAttachment(attachmentList, res, title): void {
    while (attachmentList.length > 0) {
      attachmentList.pop();
    }
    this.patchImageEmpty();
    this.isShowUpadate = false;
    this.attachmentList.push({ attachment_title: title, file: res[0].file, name: res[0].display_name, url: res[0].fileUrl });
  }

  deleteFile(event: Event, item: any, type: string) {
    event.stopPropagation();
    this.schoolName.markAsTouched({ onlySelf: true });
    if (type === 'school_logo_image') {
      this.attachmentList = this.attachmentList.filter(img => img.file !== item.file);
    }
  }

  patchImageEmpty(): void {
    this.logoNameUpdate = '';
    this.logoUrlUpdate = '';
  }

  openViewerModel(type: string, url: string): void {
    const modalRef = this.modalService.open(ImageVideoViewComponent, {
      centered: true,
      size: 'lg'
    });
    modalRef.componentInstance.fileType = type;
    modalRef.componentInstance.fileUrl = url;
  }
  processPayload() {
    this.alternate_contact=[]
    this.address=[]
    this.primary_contact=[]
    this.primary_contact = {
      "name" :this.schoolName.controls['name'].value, 
      "role":this.schoolName.controls['role'].value , 
      "contact_no" : this.schoolName.controls['contactno'].value, 
      "email":this.schoolName.controls['email'].value
    }
    
    this.address= {
      "address_line_1" :this.schoolName.controls['address_line_1'].value, 
      "area":this.schoolName.controls['area'].value , 
      "city" : this.schoolName.controls['city'].value, 
      "state":this.schoolName.controls['state'].value,
      "country":this.schoolName.controls['country'].value,
      "zip_code":this.schoolName.controls['zipcode'].value
    }
    // schoolNameData['primary_contact'] 
     
    this.alternate_contact= {
      "name" :this.schoolName.controls['altname'].value, 
      "role":this.schoolName.controls['altrole'].value , 
      "contact_no" : this.schoolName.controls['altcontactno'].value, 
      "email":this.schoolName.controls['altemail'].value
    }
    
    // const schoolName = JSON.parse(JSON.stringify(this.schoolName.value));
    let schoolName ={};
    schoolName['code'] = this.schoolName.controls['schoolcode'].value ? this.schoolName.controls['schoolcode'].value : null;
    schoolName['name'] = this.schoolName.controls['schoolname'].value ? this.schoolName.controls['schoolname'].value : null;
    schoolName['website']  = this.schoolName.controls['website'].value  ? this.schoolName.controls['website'].value : null;
    schoolName['primary_contact']  = this.primary_contact  ? this.primary_contact : null;
    schoolName['address']  = this.address  ? this.address : null;
    schoolName['alternate_contact']  = this.alternate_contact  ? this.alternate_contact : null;
    schoolName['is_active'] = this.schoolName.controls['is_active'].value ? this.schoolName.controls['is_active'].value :null
    return schoolName;
  }

}
