import { Component, Input, OnInit } from '@angular/core';
import {NgbActiveModal} from '@ng-bootstrap/ng-bootstrap';
import { takeUntil } from 'rxjs/operators';
import { Subject } from 'rxjs';
import { Store } from '@ngrx/store';
import { AuthState } from 'src/app/shared/store/auth.model';
import { ActivatedRoute, Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { userInfo} from '../../../../../shared/store/auth.selector';
import { AdminHelperService } from '../../../admin-helper.service';


@Component({
  selector: 'app-confirmation-popup',
  templateUrl: './confirmation-popup.component.html',
  styleUrls: ['./confirmation-popup.component.scss']
})
export class ConfirmationPopupComponent implements OnInit {
  @Input() request;
  @Input() status;
  requestList: any;
  userInfo: any;
  private subscriptions = new Subject<void>();
  statusdata: any;


  constructor(private adminHelperService: AdminHelperService, private ngbActiveModal: NgbActiveModal,private toastrService: ToastrService,
    private store$: Store<AuthState>,
    private router: Router,private route: ActivatedRoute,) { 
    this.store$.select(userInfo)
      .pipe(takeUntil(this.subscriptions))
      .subscribe(res => {
        if (res) {
          this.userInfo = res;
        }
      });
  }

  ngOnInit() {
    this.requestList = this.request;
    this.statusdata = this.status; 
  }

  Reject(){
    // const data = {"admin_id": this.userInfo.user_id,
    // "user_id":this.request.user_id,
    // "status":"rejected"}
    // this.adminHelperService.authorizeRequest(data).subscribe(res =>{
    //   if(res){
    //     this.toastrService.success("Request is Rejected")
    //   }
    // })

    this.ngbActiveModal.close({ status: "success" });
  }

  closeModal(): void {
    this.ngbActiveModal.close({ status: "Fail" });
  }

}
