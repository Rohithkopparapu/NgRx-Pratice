import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AdminHelperService } from '../../admin-helper.service';
import { DeleteComponent } from 'src/app/shared/component/delete/delete.component';
import { NgbModal, NgbModalOptions } from '@ng-bootstrap/ng-bootstrap';
import { ToastrService } from 'ngx-toastr';
import { ConfirmationPopupComponent } from './confirmation-popup/confirmation-popup.component';
import { Store } from '@ngrx/store';
import { AuthState } from 'src/app/shared/store/auth.model';
import { userInfo } from '../../../../shared/store/auth.selector';
import { elementAt, takeUntil } from 'rxjs/operators';
import { Subject } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { saveAs } from 'file-saver'
import { FileUploadComponent } from 'src/app/shared/component/file-upload/file-upload.component';
import { ColumnViewDetails } from 'src/app/shared/constants/input.constants';
import { SplitCamelCasePipe } from 'src/app/shared/pipes/split-camel-case.pipe';
import {zipWith, cloneDeep, map, partialRight, pick} from 'lodash';
import { HelperService } from 'src/app/shared/services/helper.service';
import {ExportFileService} from '../../export-file.service';
import * as XLSX from 'xlsx';
import { formatDate } from '@angular/common';
import * as moment from 'moment';
import {SubscribedCommunityAssignToClassComponent} from '../subscribed-community-assign-to-class/subscribed-community-assign-to-class.component';
@Component({
  selector: 'app-school-admin',
  templateUrl: './school-admin.component.html',
  styleUrls: ['./school-admin.component.scss']
})

export class SchoolAdminComponent implements OnInit {
  private subscriptions = new Subject<void>();
  isDisplayListOfCategory: boolean = true;
  isLoading: boolean;
  categoryList: any = [];
  columnHeaders: any[] = [];
  errorMessage: boolean;
  searchChallenge = '';
  dateFormatKeys = ['created_date'];
  pageSearch = 1;
  itemlist: boolean = false
  catlist: boolean = false
  totalItemsList: any = [];
  head: any = "Dot Store"
  cat: boolean = true;
  selectedDotstoreView: string = "Catetories";
  category_ids: number;
  activatedFlag: any;
  result: any;
  pendingRequstList: any;
  searchRequest: '';
  states: ({ emp: number; sowId?: undefined; } | { emp: number; sowId: number; })[];
  studentsList: any = [];
  teacherList: any = [];
  userInfo: any;
  schoolsList: any;
  selectedType: string;
  schoolsNames: any[];
  headerMap: Map<string, ColumnViewDetails>;
  schoolsListSub: any;
  subscriptionDetail: any=[];
  isSaving: boolean;
  showAdvanceFilter:boolean = false;
  ngbModalOptions: NgbModalOptions = {
    centered: true,
    scrollable: true,
    backdrop: 'static',
    keyboard: false,
    size: 'lg',
    windowClass: 'modal-challenge'
  }
  schooladdress: any ="";
  searchTerm: string;
  filteredItems: any[];
  // status:string ="";
  status1:string ="";
  name:string = "";
  email:string ="";
  phone:string ="";
  status:any;
  name1:any;
  email1:any;
  class1:any;
  phone1:any;
  constructor(private adminHelperService: AdminHelperService,
    private router: Router,
    private modalService: NgbModal,
    private toastrService: ToastrService,
    private http: HttpClient,
    private store$: Store<AuthState>,
    private _uhs: HelperService,private exportFileService: ExportFileService) {
    const data = this.router.getCurrentNavigation().extras.state;
    this.activatedFlag = "TeacherActivated";
    if (data !== undefined) {
      this.activatedFlag = data.data;
      // this.getTeacherStudentList(data.schId)
    }
    
    this.store$.select(userInfo)
      .pipe(takeUntil(this.subscriptions))
      .subscribe(res => {
        if (res) {
          this.userInfo = res;
        }
      });
    this.getSchoolsData();
  }

  ngOnInit() {
    // if(this.userInfo.dot_registration_id){
      // this.getAllPendingList();
      // this.getTeacherStudentList(0);
      // this.getSubscribeCommunityData(this.userInfo.dot_registration_id,'')
    // }
  }

  createUserPop(schoolsList: any, role : string){
    if(this.schoolsList.name || this.userInfo.dot_registration_id){
      this.router.navigate(['auth/admin/schooladmin', 'user-details'], {state : {schoolsList: this.schoolsList.name, Role : role, schId:this.schoolsList.id ,schooladdr: this.schooladdress} });
    }else{
      this.toastrService.warning("Please Select a school to create Teachers/Students!")
    }
    
  }

  getSchoolsData() {
    if (this.userInfo.dot_registration_id !== null) {
      this.isLoading = true;
      this.adminHelperService.getSchoolsList(this.userInfo.dot_registration_id).subscribe(result => {
        this.schoolsList = result;
        this.isLoading = false;
      })
      // const payload={}
      // this.adminHelperService.getSchoolsListForSuperAdmin(payload).subscribe(result => {
      //   let filterData= this.userInfo.details.responsibilities;
      //   console.log("filterData",filterData,result);
        
      //   const myArrayFiltered = result.filter((el) => {
      //     return filterData.some((f) => {
      //       return f.id == el.id ;
      //     });
      //   });
      //   this.schoolsListSub = myArrayFiltered
      //   console.log(this.schoolsListSub)
      // })
    } else {
      const payload={}
      this.adminHelperService.getSchoolsListForSuperAdmin(payload).subscribe(result => {
        this.schoolsList = result.sort((a, b) => a.name.localeCompare(b.name));;
      })
    }
  }
  onSuperlAdmin(event){
    let name :any;
    this.schoolsList.forEach(element =>{element.id==event.target.value ? name=element.name :''});
    this.schoolsList.name = name;
    const school = this.schoolsList.find(item => item.id === Number(event.target.value) );
    if(school.address.area !== undefined){
      this.schooladdress  = school.address.area
    }
    this.schoolsList.id = event.target.value
    if(event.target.value){
      this.getTeacherStudentList(Number(event.target.value))
      this.getSubscribeCommunityData(Number(event.target.value),'')
    }else{
      this.studentsList = [];
      this.teacherList = [];
      this.toastrService.warning("Please select the school..!")
    }
  }
  onSchoolAdmin(event){
    let name :any;
    this.userInfo.details.responsibilities.forEach(element =>{element.id==event.target.value ? name=element.name :''})
    this.schoolsList.name = name;
    this.schoolsList.id = event.target.value;
    let school = this.schoolsList;
    if(school.address.area !== undefined){
      this.schooladdress  = school.address.area
    }
    if(event.target.value){
      this.getTeacherStudentList(Number(event.target.value))
      this.getSubscribeCommunityData(Number(event.target.value),'')
    }else{
      this.studentsList = [];
      this.teacherList = [];
      this.toastrService.warning("Please select the school..!")
    }
    
  }
  getAllPendingList() {
    this.adminHelperService.getAllList(this.userInfo.dot_registration_id).subscribe(result => {
      this.pendingRequstList = result;
    })
  }

  onChangeDotstore(value): void {
    this.selectedDotstoreView = value;
    // if (this.selectedDotstoreView === 'Categories') {
    //   this.activatedFlag = "CategoryActivated";
    //   this.catlist = true;
    //   this.itemlist = false;
    //   this.cat = true;
    // }
    if (this.selectedDotstoreView === 'Teacher') {
      this.activatedFlag = "TeacherActivated";
      this.catlist = false;
      this.itemlist = true;
      this.cat = false;
      this.totalItemsList = []
    }
    if (this.selectedDotstoreView === 'Student') {
      this.activatedFlag = "StudentActivated";
      this.catlist = false;
      this.itemlist = true;
      this.cat = false;
      this.totalItemsList = []
    }
    if (this.selectedDotstoreView === 'Planning') {
      this.activatedFlag = "PlanningtActivated";
      this.catlist = false;
      this.itemlist = true;
      this.cat = false;
      this.totalItemsList = []
    }
  }
  exportTemplate(): void {
    this.http.get('assets/excel/Add_user_template.xlsx', { responseType: 'blob' })
      .subscribe((blob: Blob) => {
        saveAs(blob, 'Add_user_template.xlsx');
      });
  }

  uploadDocument(type: string, title: string, fileCategory: any) {
    if(this.schoolsList.id){
      this.selectedType = title;
      const modalData = {
        headerName: title,
        fileType: type,
        fileCategory,
        schoolNames : this.schoolsList.name,
        isMultipleFile: false,
        schoolId:this.schoolsList.id
      };
      const modalRef = this.modalService.open(FileUploadComponent, {
        keyboard: false,
        backdrop: 'static',
        scrollable: true,
        windowClass: 'modal-cover modal-cover-fluid modal-upload'
      });
      modalRef.componentInstance.data = modalData;
      modalRef.componentInstance.fromPage = 'Excel_upload';
      modalRef.result.then((res) => {
        // console.log(res);
        if(res==='Excel_upload'){
          this.getTeacherStudentList(this.schoolsList.id)
        }
      }, (reason) => {
        this.getTeacherStudentList(this.schoolsList.id)
        if (reason) {
            // console.log("Excel", reason);
        }
      });
    }else{
      this.toastrService.warning("Please Select School to upload Excel Data.!")
    }
    
  }

  // uploadDocument() {
  //   const payload = {}
  //   this.adminHelperService.addBulkUserDetails(payload).subscribe(res => {
  //     this.isLoading = false;
  //  });
  // }
  getSubscribeCommunityData(reg_id,s_id){
    // this.isLoading=false
    let payload={};
    this.subscriptionDetail=[];
    this.adminHelperService.getSubscribeCommunityData(reg_id,s_id).subscribe(result => {
      this.isSaving = false;
      // this.isLoading=true
      if (result) {
        this.subscriptionDetail=result.filter(x => x.status === "Activated");
        // console.log("school datann",this.subscriptionDetail);
      }
    }, err => this.isSaving = false);
    
  }
  planning(post: any,type:any): void {
    console.log(post)
    const modelRef = this.modalService.open(SubscribedCommunityAssignToClassComponent, {
      centered: true,
      scrollable: true,
      size: 'lg',
      windowClass: 'modal-challenge'
    });
    let headerNmae
    if(type){
      headerNmae="Update"
    }else{
      headerNmae="Add"
    }
    modelRef.componentInstance.data = {...post,type:type,headerNmae:headerNmae};
    modelRef.componentInstance.fromPage = 'schooladmin';
    // modelRef.componentInstance._page = 'MyChallenges';
    modelRef.componentInstance.isResponseSelect = true;
    modelRef.result.then(res => {
      if (res === 'schooladmin') {
        // this.page = 1;
        // this.newsFeedData = [];
        // this.callNewsFeedDataService();
        // this.getLatestChallengeComments(this.newsFeedData)
      }
    });
  }
  getTeacherStudentList(id) {
    this.isLoading=true
    let sId:number
    if(id){
      sId = id;
    }else{
      sId = this.userInfo.dot_registration_id;
    }
    
    this.adminHelperService.getAllTeacherStudentList(sId).subscribe(res => {
      this.isLoading=false
      this.studentsList = res.student;
      this.teacherList = res.teacher;
      let columnName={"user_type":"user_type",
      "name":"name","gender":"gender","class":"class","section":"section",
      "date_of_birth":"date_of_birth","parent":"parent","parent_number":"parent_number",
      "admission_number":"admission_number","employee_number":"employee_number",
      "phone_number":"phone_number","email":"email", "responsibilities":"responsibilities"}
      this.columnHeaders = Object.keys(columnName);
      this.headerMap = this._uhs.extractColumnNamesFromObject(this.columnHeaders);
    })
  }
  takeAction(request: any, role: any) {
    this.router.navigate(['auth/admin/schooladmin', 'user-details'], { state: { data: request, edit: "Approve", activeroute: "pendinglist", Role: role } });
  }

  Reject(request: any, role: any) {
    this.router.navigate(['auth/admin/schooladmin/user-details'], { state: { data: request, edit: "Reject", activeroute: "pendinglist", Role: role,schoolsList: this.schoolsList.name, schId: this.schoolsList.id, schooladdr: this.schooladdress} });
  }

  // serching
  resetValues() {
    this.pendingRequstList = [];
    this.pageSearch = 1;
  }

  setSearchValue($event: any): void {
    this.searchRequest = $event;
  }
  exportFile(): void {
    let downloadData: any=[];
    let tempNmae: any;
    if(this.activatedFlag === 'TeacherActivated'){
      // this.resetValues();
      tempNmae="Teacher List"
      downloadData = this.teacherList;
      // .filter(item => item['date_of_birth']= item.date_of_birth ? moment(item.date_of_birth).format('YYYY-MM-DD') :'')
    }if(this.activatedFlag === 'StudentActivated'){
      tempNmae="Student List" 
      downloadData= this.studentsList.filter(item => item['date_of_birth']= item.date_of_birth ? moment(item.date_of_birth).format('YYYY-MM-DD') :'')
      // downloadData = this.studentsList.map(item=> {return {date_of_birth: item.date_of_birth ? moment(item.date_of_birth).format('YYYY-MM-DD') :'',} } );
    }
    let customizedList: any = [];
    if (this.columnHeaders.length && downloadData.length) {
      const displayNamesList = this.columnHeaders.map(element => {
        if (this.headerMap.get(element).isActive) {
          return element
          // return SplitCamelCasePipe.prototype.transform(this.headerMap.get(element).displayName);
        }
      });
      const exportWith = zipWith(this.columnHeaders, displayNamesList, (key, value) => ({key, value}));
      let listData: any[] = cloneDeep(downloadData);
      const DateTimeKeysList: any[] = this.columnHeaders.filter(ele => (this.headerMap.get(ele).available && this.headerMap.get(ele).isActive && (this.headerMap.get(ele).type === 'DATETIME' || this.headerMap.get(ele).type === 'DATE')));
      listData = this._uhs.formatDateTimeInListIfExists(listData, DateTimeKeysList);
      customizedList = map(listData, partialRight(pick, this.columnHeaders));
      this.exportFileService.exportAsFile(customizedList, exportWith, tempNmae, 'EXCEL');
    } else {
      this.exportTemplate()
      this.toastrService.warning('No Data found, Please Use this format to Upload Users details...');
    }
  }

  toggleFilter(){
    this.showAdvanceFilter = !this.showAdvanceFilter;
  }

  filterItems() {
    this.filteredItems = this.teacherList.filter((item) => {
      return (
        item.name.toLowerCase().includes(this.searchTerm.toLowerCase())
      );
    });
  }
}

