import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { Store } from '@ngrx/store';
import { ToastrService } from 'ngx-toastr';
import { AuthState } from 'src/app/shared/store/auth.model';
import { AdminHelperService } from '../../../admin-helper.service';
import { userInfo } from '../../../../../shared/store/auth.selector';
import { takeUntil } from 'rxjs/operators';
import { Subject } from 'rxjs';
import { ConfirmationPopupComponent } from '../confirmation-popup/confirmation-popup.component';
import { HelperService } from 'src/app/shared/services/helper.service';
// import { CustomValidator } from 'src/app/shared/services/validators/customValidator';
import { SetUserDetail } from 'src/app/shared/store/auth.action';



@Component({
  selector: 'app-user-action',
  templateUrl: './user-action.component.html',
  styleUrls: ['./user-action.component.scss']
})

export class UserActionComponent implements OnInit {
  private subscriptions = new Subject<void>();
  @ViewChild('searchTag', { static: false }) searchTag: ElementRef;
  selectedRequest: any;
  request: any;
  flag: boolean = false;
  userInfo: any;
  state: any;
  activatedRoute: string;
  activeRoute: any;
  dobMaxDate: any;
  isLoading: boolean;
  minYear: number;
  regId: any;
  userType: string = '';
  userId: any;
  tagsList: any[] = [];
  isShow: boolean = false;
  studentOnboardService: any;
  addUserForm = this.fb.group({
    name: ['', [Validators.required]],
    email: ['', [Validators.required]],
    date_of_birth: [''],
    user_no: [''],
    class: [''],
    section: [''],
    gender: ['', [Validators.required]],
    phone_number: ['', [Validators.pattern('^[0-9]*$')]],
    is_active: [true],
    school_name: [''],
    parent: [''],
    parent_email: [''],
    parent_number: ['', [Validators.pattern('^[0-9]*$')]],
    user_type: ['', [Validators.required]],
    // parent_email: ['', [CustomValidator.ValidateEmail]],
    // parent_contact_no: ['', [CustomValidator.AllowNumericOnly]],
  });
  nameOfLable: string;
  typeId: any;
  user_id: any;
  schoolsList: any;
  schId:any;
  titleName: string;
  updateFoem: boolean=false
  addr: any ="";
  constructor(private adminHelperService: AdminHelperService,
    private modalService: NgbModal,
    private fb: FormBuilder,
    public _uhs: HelperService,
    private toastrService: ToastrService,
    private store$: Store<AuthState>,
    private router: Router,
    private route: ActivatedRoute) {
    const data = this.router.getCurrentNavigation().extras.state;
    // this.schId =data.schId
    if (data.data) {
      this.request = data.data;
      this.state = data.edit;
      this.schoolsList= data.schoolsList;
      this.schId = data.schId;
      this.addr = data.schooladdr;
      this.activeRoute = data.Role;
      this.userId = data.data.user_id;
      this.titleName = this.activeRoute;
      if (this.request.user_type === 'student') {
        this.nameOfLable = "Admission Number";
        this.userType = 'student'
      } else {
        this.nameOfLable = "Employee Number";
        this.userType = 'teacher'
      }
      this.flag = true;
    } else {
      this.schoolsList = data.schoolsList;
      this.activeRoute = data.Role;
      this.addr = data.schooladdr;
      this.schId = data.schId
      if (this.schoolsList) {
        this.titleName = this.activeRoute;
        this.flag = true;
      }
    }
    this.store$.select(userInfo)
      .pipe(takeUntil(this.subscriptions))
      .subscribe(res => {
        if (res) {
          this.userInfo = res;
        }
      });
  }

  ngOnInit() {
    this.dobMaxDate = this._uhs.getTodaysFormattedDate();
    this.minYear = this.dobMaxDate.year - 8;
    if (this.state) {
      this.updateFoem= true
      if(this.request && this.request.responsibilities)
        this.request.responsibilities.split(",").forEach(item => this.tagsList.push({ tag: item }) )
      
      this.updateInfo()
    } else {
      this.updateFoem= false
      this.userId = '';
    }
    this.dobMaxDate = this._uhs.getTodaysFormattedDate();
    this.minYear = this.dobMaxDate.year - 8;
  }

  updateInfo() {
    // console.log(this.request.class_details,'fdf');
    this.addUserForm.patchValue({
      name: this.request.name,
      email: this.request.email,
      date_of_birth: this.request.date_of_birth !== null ? this._uhs.getFormattedDateForAdminChall(this.request.date_of_birth) : null,
      user_no: this.request.user_type === 'teacher' ? this.request.employee_number : this.request.user_type === 'student' ? this.request.admission_number : '',
      // class: this.request.class_details ? this.request.class_details.replace(/ /, '') : null,
     
      phone_number: this.request.phone_number,
      gender: this.request.gender ? (this.request.gender).charAt(0).toUpperCase() + (this.request.gender).slice(1).toLowerCase() : null,
      school_name: this.request.school_name,
      parent: this.request.parent,
      parent_email: this.request.parent_email,
      parent_number: this.request.parent_number,
      user_type: this.request.user_type,
      is_active: this.request.is_active,
      
    })
    if(this.request.user_type !== 'teacher'){
      this.addUserForm.patchValue({
      class: this.request.class !== null ? this.request.class : null,
      section: this.request.section !== "" ? this.request.section.toUpperCase(): "",
      })
    }
    this.user_id = this.request.user_id;
    this.flag = true;
  }

  onUserChange(event: any) {
    let timedata = event.target.value
    this.userType = timedata.trim();
    if (this.userType == 'teacher') {
      this.isShow = true;
      this.nameOfLable = "Employee Number";
      // this.addUserForm.controls['parent_name'].setValue('');
      // this.addUserForm.controls['parent_contact_no'].setValue('');
      // this.addUserForm.controls['parent_email'].setValue('');
      this.addUserForm.get('date_of_birth').clearValidators();
      this.addUserForm.get('date_of_birth').updateValueAndValidity();
      this.addUserForm.get('class').clearValidators();
      this.addUserForm.get('class').updateValueAndValidity();
      // this.addUserForm.get('section').clearValidators();
      // this.addUserForm.get('section').updateValueAndValidity();
      // this.addUserForm.get('parent_email').clearValidators();
      // this.addUserForm.get('parent_email').updateValueAndValidity();
    } if (this.userType == 'student') {
      this.isShow = true;
      this.nameOfLable = "Admission Number";
      this.addUserForm.controls['date_of_birth'].setValidators(Validators.required);
      this.addUserForm.controls['date_of_birth'].updateValueAndValidity();
      this.addUserForm.controls['class'].setValidators(Validators.required);
      this.addUserForm.controls['class'].setValidators(Validators.required);
      // this.addUserForm.controls['section'].setValidators(Validators.required);
      // this.addUserForm.controls['section'].setValidators(Validators.required);
      // this.addUserForm.controls['parent_contact_no'].updateValueAndValidity();
      // this.addUserForm.controls['parent_email'].setValidators(CustomValidator.ValidateEmail);
      // this.addUserForm.controls['parent_email'].updateValueAndValidity();
    }


  }

  Approve() {
    const modelref = this.modalService.open(ConfirmationPopupComponent, {
      centered: true,
      backdrop: 'static',
      size: 'md',
      windowClass: 'modal-challenge',
      scrollable: true
    });
    modelref.componentInstance.request = this.request;
    modelref.componentInstance.status = 'Approve';
    modelref.result.then(res => {
      if (res.status === 'success') {
        const data = {
          "admin_id": this.userInfo.user_id,
          "user_id": this.request.user_id,
          "status": "approved"
        }
        this.adminHelperService.authorizeRequest(data).subscribe(res => {
          if (res) {
            this.toastrService.success("Request is Approved");
            this.router.navigate(['/auth/admin/schooladmin']);

          }
        })
      }
    });

  }
  Reject() {
    const modelref = this.modalService.open(ConfirmationPopupComponent, {
      centered: true,
      backdrop: 'static',
      size: 'md',
      windowClass: 'modal-challenge',
      scrollable: true
    });
    modelref.componentInstance.request = this.request;
    modelref.componentInstance.status = 'Reject';
    modelref.result.then(res => {
      if (res.status === 'success') {
        const data = {
          "admin_id": this.userInfo.user_id,
          "user_id": this.request.user_id,
          "status": "rejected"
        }
        this.adminHelperService.authorizeRequest(data).subscribe(res => {
          if (res) {
            this.toastrService.success("Request is Rejected");
            this.router.navigate(['/auth/admin/schooladmin']);
          }
        })
      }
    });

  }
  profileMarkAsTouched() {
    Object.values(this.addUserForm.controls).forEach((control: any) => {
      control.markAsTouched();
    });
  }
  // submitBtn(approved){
  //   const heading =approved;
  //   if(heading === "approved"){

  //   }
  // }
  submitAddUser(): void {
    if (this.addUserForm.valid) {
      const payload = this.processPayload();
      this.isLoading = true;
      payload['school_name'] = this.schoolsList?this.schoolsList:this.userInfo.school_name.trim(),
        payload['registration_id'] = Number(this.schId)? Number(this.schId):this.userInfo.dot_registration_id
      if (this.addUserForm.controls.user_type.value === 'student') {
        const admissino_number={}
        admissino_number['admission_number'] = this.addUserForm.controls.user_no.value
        payload['details'] = admissino_number;
        // payload['admission_number'] = this.addUserForm.controls.user_no.value;
      } else if (this.addUserForm.controls.user_type.value === 'teacher') {
        const employee_number={}
        employee_number['employee_number'] = this.addUserForm.controls.user_no.value
        payload['details'] = employee_number;
        if(this.tagsList !== null){
          let responsibilities = this.tagsList.map(function (obj){
            return obj.tag
          })
          // payload['responsibilities']= responsibilities;
          const admissino_number={}
          admissino_number['responsibilities'] = responsibilities
          // payload['details'] = admissino_number;
          payload['responsibilities']= responsibilities.join(',');
        }else{
          this.toastrService.warning('Please enter class details required fields')
        }
      } 
      // console.log(payload);
      
      // return
      this.adminHelperService.addBulkUserDetails(payload).subscribe(res => {
        this.isLoading = false;
        if (res.status === 'success') {
          if (!this.user_id) {
            // this.store$.dispatch(new SetUserDetail(res));
            this.toastrService.success('Added Successfully');
            this.cancelItem();
          } else {
            // this.store$.dispatch(new SetUserDetail(res));
            this.toastrService.success(' Update Successfully');
            this.cancelItem();
          }
        }
      }, (err) => {
        this.isLoading = false;
        this.toastrService.clear();
        if(this.toastrService.toasts.length !== 0){
          this.toastrService.remove(this.toastrService.toasts[0].toastId);
        }
        this.toastrService.error(err.error.msg);
      });
    } else {
      this.profileMarkAsTouched();
      this.toastrService.warning('Please enter all required fields');
    }
  }

  processPayload() {
    const addUserForm = {
      date_of_birth: this.addUserForm.controls.date_of_birth.value !== '' && this.addUserForm.controls.date_of_birth.value !== null ?
      this._uhs.getFormattedDateToBind(this.addUserForm.controls.date_of_birth.value) : null,
      name: this.addUserForm.controls.name.value.charAt(0).toUpperCase() + (this.addUserForm.value.name).slice(1).toLowerCase(),
      email: this.addUserForm.controls.email.value,
      class: this.addUserForm.controls.class.value !=='' && this.addUserForm.controls.class.value !== null ? this.addUserForm.controls.class.value  : null,
      section: this.addUserForm.controls.section.value !=='' && this.addUserForm.controls.section.value !== null ? this.addUserForm.controls.section.value  : "",
      gender: this.addUserForm.controls.gender.value,
      school_name: this.addUserForm.controls.school_name.value,
      parent: this.addUserForm.controls.parent.value,
      phone_number: this.addUserForm.controls.phone_number.value,
      parent_email: this.addUserForm.controls.parent_email.value,
      parent_number: this.addUserForm.controls.parent_number.value,
      user_type: this.addUserForm.controls.user_type.value,
      is_active: this.addUserForm.controls.is_active.value === true || this.addUserForm.controls.is_active.value === 1 ? 1 : 0
    };
    return addUserForm;

  }
  addTag() {
    if (this.searchTag.nativeElement.value.length>0) {
        let addTag = this.searchTag.nativeElement.value.split(/[\.\,-]/)
        addTag.forEach(i=>{this.tagsList.push({ tag: i})})
        // this.tagsList.push({ tag: this.searchTag.nativeElement.value });
        this.searchTag.nativeElement.value = '';
    } else {
      this.toastrService.warning('Please type valid class name like 6A,7B, 8C...');
    }
  }
  removeTag(tag) {
    this.tagsList = this.tagsList.filter(item => item['tag'] !== tag.tag);
  }

  cancelItem() {
    if (this.activeRoute === "Student") {
      this.activatedRoute = 'StudentActivated';

    } else if (this.activeRoute === "Teacher") {
      this.activatedRoute = 'TeacherActivated';

    } else if (this.activeRoute === "Approvals") {
      this.activatedRoute = 'ApprovalsActivated';
    }
    this.router.navigate(['/auth/admin/schooladmin'], { state: { data: this.activatedRoute, schId:this.schId} });
  }

}

