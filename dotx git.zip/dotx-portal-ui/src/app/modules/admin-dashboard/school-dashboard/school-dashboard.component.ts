import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ToastrService } from 'ngx-toastr';
import { ERROR_MESSAGE, SUCCESS_MESSAGE } from 'src/app/shared/constants/constant';
import { HelperService } from 'src/app/shared/services/helper.service';
import { AdminHelperService } from '../admin-helper.service';

@Component({
  selector: 'app-school-dashboard',
  templateUrl: './school-dashboard.component.html',
  styleUrls: ['./school-dashboard.component.scss']
})
export class SchoolDashboardComponent implements OnInit {
  isLoading = false;
  schooldata: any[];
  isSaving: boolean;
  searchChallenge: '';
  pageSearch = 1;
  dateFormatKeys = ['start_date', 'end_date'];
  subscriptionDetail: any[];
  page=1
  perpage: any=10;
  number_of_records: any;
  constructor(private router: Router,private adminHelperService: AdminHelperService,) { }

  ngOnInit() { 
    this.getSchoolData(this.page);
  }
 getSchoolData(page){
  this.isLoading = true;
  let payload={};
    // this.schooldata=[];
    this.adminHelperService.getSchoolPage(page, this.perpage).subscribe(result => {
      this.isSaving = false;
      this.isLoading = false;
      if (result) {
        this.schooldata=result[0]
        this.number_of_records=result[1].number_of_records
        // console.log("school datann",this.schooldata);
      }
    }, err => this.isSaving = false);
    // console.log("school data",this.schooldata);
    
 }
  onNew(): void {
    this.router.navigate(['/auth/admin/school-reg', 'create']);
  }
  onEdit(bulletin: any): any  {
    this.router.navigate(['/auth/admin/school-reg/', 'edit', bulletin.id]);
  }
  onSubscrib(reg_id:any,sub_id: any): any  {
    this.router.navigate(['/auth/admin/subscribe/', 'subscribe', reg_id,sub_id]);
  }
  getSubscribeCommunityData(reg_id,s_id,i){
    // this.isLoading=false
    let payload={};
    this.subscriptionDetail=[];
    this.adminHelperService.getSubscribeCommunityData(reg_id,s_id).subscribe(result => {
      this.isSaving = false;
      // this.isLoading=true
      if (result) {
        this.subscriptionDetail=result
        this.schooldata[i].childTable= result;
        // console.log("school datann",this.schooldata);
      }
    }, err => this.isSaving = false);
    
  }
  communitf(data){
    console.log(data)
  }
  onView(bulletin: any): any {
    // const modelRef = this.modalService.open(AnnouncementResponsesComponent, {
    //   centered: true,
    //   scrollable: true,
    //   backdrop: 'static',
    //   size: 'xl',
    //   windowClass: 'modal-challenge'
    // });
    // modelRef.componentInstance.data = bulletin;
    // modelRef.componentInstance.userType = 'admin';
  }

  // onDelete(bulletinId: any) {
    // const deleteModelRef = this.modalService.open(DeleteComponent, { centered: true, backdrop: 'static' });
    // deleteModelRef.componentInstance.message = 'Are you sure you want to delete this Announcement?';
    // deleteModelRef.result.then((res) => {
    //   if (res) {
    //     this.deleteRecord(bulletinId);
    //   }
    // }, (reason) => {
    //   if (reason) {
    //     this.deleteRecord(bulletinId);
    //   }
    // });
  // }

  deleteRecord(bulletinId: number): any {
    // this.isLoading = true;
    // this.service.deleteBulletinById(bulletinId).subscribe(res => {
    //   this.isLoading = false;
    //   if (res) {
    //     this.toastrService.success(`Bulletin ${SUCCESS_MESSAGE.RECORD_DELETED}`);
    //     this.loadBulletinBoard();
    //   }
    // }, err => this.isLoading = false);
  }

  resetValues() {
    this.schooldata = [];
    this.pageSearch = 1;
  }

  setSearchValue($event: any): void {
    this.searchChallenge = $event;
  }

  onPageChange(offset: number) {
    console.log(offset);
    // this.page = offset;
    this.getSchoolData(offset)
  }
}

