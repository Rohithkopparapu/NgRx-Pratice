import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SubscribeCommunityComponent } from './subscribe-community.component';

describe('SubscribeCommunityComponent', () => {
  let component: SubscribeCommunityComponent;
  let fixture: ComponentFixture<SubscribeCommunityComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SubscribeCommunityComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SubscribeCommunityComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
