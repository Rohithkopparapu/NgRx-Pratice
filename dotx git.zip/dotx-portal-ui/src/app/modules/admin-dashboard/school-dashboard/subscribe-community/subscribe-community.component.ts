import { DatePipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import * as moment from 'moment';
import { IDropdownSettings } from 'ng-multiselect-dropdown';
import { ToastrService } from 'ngx-toastr';
import { ERROR_MESSAGE, SUCCESS_MESSAGE } from 'src/app/shared/constants/constant';
import { HelperService } from 'src/app/shared/services/helper.service';
import { AdminHelperService } from '../../admin-helper.service';

@Component({
  selector: 'app-subscribe-community',
  templateUrl: './subscribe-community.component.html',
  styleUrls: ['./subscribe-community.component.scss']
})
export class SubscribeCommunityComponent implements OnInit {
  MULTI_DROPDOWN_SETTINGS: IDropdownSettings = {
    singleSelection: false,
    idField: 'community_id',
    textField: 'community_name',
    selectAllText: 'Select All',
    unSelectAllText: 'UnSelect All',
    enableCheckAll: true,
    itemsShowLimit: 2,
    allowSearchFilter: true
  };
  isLoading: boolean=false;
  communityList: any=[];
  schoolId:any
  backButton: string;
  schoolUpdatedata: any;
  // ------Form---------
  subcriptionForm = this.fb.group({
    name: [''],
    is_active: [true],
    start_date:['', [Validators.required]],
    end_date:['', [Validators.required]],
    community:['', [Validators.required]],
    status:['Draft',[Validators.required]],
    students_license_limit:['',[Validators.required,Validators.pattern("^[0-9]*$")]],
    teachers_license_limit:['',[Validators.required,Validators.pattern("^[0-9]*$")]],
    admin_license_limit:['',[Validators.required,Validators.pattern("^[0-9]*$")]],
    
  });
  // ----End----------
  setStartMinDate: { year: number; month: number; day: number; };
  setEndMinDate: { year: number; month: number; day: number; };
  isSaving: boolean;
  currentDateTime: string;
  subcriptionId: string;
  subscriptionDetail: any[];
  selectedItems: any[];
  isDisabled:boolean=false
  constructor(public _uhs: HelperService, private fb: FormBuilder, private modalService: NgbModal,
    private route: ActivatedRoute, private adminHelperService: AdminHelperService, private toastrService: ToastrService,
    private router: Router,public datepipe: DatePipe) { 
       this.currentDateTime =this.datepipe.transform((new Date), 'yyyy-MM-dd h:mm:ss');

    }

  ngOnInit() {
    this.getCommunities();
    this.setStartMinDate = this._uhs.getSpotlightFormattedStartMinDate();
    if (this.route.snapshot.paramMap.get('type') === 'subscribe') {
      // console.log("hello",this.route.snapshot.paramMap.get('id'));
      this.schoolId=this.route.snapshot.paramMap.get('rgid')
      this.subcriptionId=this.route.snapshot.paramMap.get('sid')
      this.backButton = !this.subcriptionId ? 'Create Subscription' : 'Update Subscription';
      this.getSchoolbyId(this.schoolId);
      if(this.subcriptionId && this.schoolId){
        this.getSubscribeCommunityData(this.schoolId,this.subcriptionId);
      }
    } else {
      // this.getCommunities();
    }
     
  }

  getSubscribeCommunityData(reg_id,s_id){
    let payload={};
    this.subscriptionDetail=[];
    this.adminHelperService.getSubscribeCommunityData(reg_id,s_id).subscribe(result => {
      this.isSaving = false;
      if (result) {
        this.subscriptionDetail=result[0]
        setTimeout(() => {this.updateForm(result[0])},500);
        // this.updateForm(result[0])
      }
    }, err => this.isSaving = false);
    
  }
  setEndDate(event: any) {
    this.setEndMinDate = this._uhs.getSpotlightFormattedEndMinDate(event, 1);
  }
  getSchoolbyId(schoolId): void {
    this.isLoading = true;
    this.adminHelperService.getSchoolbyId(schoolId).subscribe(res => {
      this.isLoading = false;
      if (res) {
        this.schoolUpdatedata = res;
        // this.updateForm(res);
      }
    }, err => this.isLoading = false);
  }
  getCommunities(): void {
    this.isLoading = true;
    const payload = {};
    this.adminHelperService.getCommunitiesByFilter(payload).subscribe(res => {
      this.isLoading = false;
      if (res && res.length) {
        this.communityList = res.filter(s =>
          !s.combo && moment(moment(s.community_start_date).format('YYYY-MM-DD')).isSameOrBefore(moment().format('YYYY-MM-DD')) && s.num_challenges > 0 && s.categories=='B2B');
      }
        
        // this.communityList = res;
      
    }, () => this.isLoading = false);
  }

  updateForm(res): void {
    const today = new Date().toISOString().slice(0, 10);
    const arr = []
    this.setStartMinDate = this._uhs.getFormattedDateForAdminChall(res.start_date);
    // if(this.communityList){
      
      let itemdata= JSON.parse(res.details).communities
      itemdata.forEach(element => {
        const obj=[] = this.communityList.find(x => x.community_id == element);
        if(obj)
          arr.push(obj);
      
      });
    this.selectedItems = arr;
    if(this.selectedItems.length >0){
      console.log(this.selectedItems = arr,'bvcnb')
      this.subcriptionForm.patchValue({
        name: res.name,
        // description:  res.description,
        start_date: res.start_date ? this._uhs.getFormattedDateForAdminChall(res.start_date) : '',
        end_date: res.end_date ? this._uhs.getFormattedDateForAdminChall(res.end_date) : '',
        // community:  res.details,
        students_license_limit : res.students_license_limit,
        teachers_license_limit: res.teachers_license_limit,
        admin_license_limit: res.admin_license_limit,
        
        status: res.status,
        is_active:res.is_active
      });
    }
    // if (res.start_date && res.start_date.slice(0, 10) < today) {
    //   this.setStartMinDate = this._uhs.getFormattedDateForAdminChall(res.start_date);
    //   this.isDisabled = true;
    // }

  }

  submitForm() {
    if (this.subcriptionForm.valid) {
      // const {responsibilities}=this.bulletinForm.value
      const bulletinFormData = this.processPayload();
      console.log("cdc",bulletinFormData)
      if (!this.subcriptionId) {
        this.isSaving = true;
        this.adminHelperService.saveSubscription(bulletinFormData).subscribe(result => {
          this.isSaving = false;
          if (result) {
            this.toastrService.success(SUCCESS_MESSAGE.RECORD_ADDED);
            this.router.navigate(['/auth/admin/school-reg']);
          }
        }, err => this.isSaving = false);
      } else {
        const payload = {
          subscription_id: this.subcriptionId,
          ...bulletinFormData
        };
        this.isSaving = true;
        // payload['subscription_id']=this.subcriptionId
        this.adminHelperService.saveSubscriptionEdit(payload).subscribe(result => {
          this.isSaving = false;
          if (result) {
            this.toastrService.success(SUCCESS_MESSAGE.RECORD_UPDATED);
            this.router.navigate(['/auth/admin/school-reg']);
          }
        }, err => this.isSaving = false);
      }
    } else {
      this.toastrService.warning(ERROR_MESSAGE.FIELDS_REQUIRED);
      this._uhs.validateAllFormFields(this.subcriptionForm);
    }
  }
  processPayload() {
    const payload={}
    const subcriptionForm = JSON.parse(JSON.stringify(this.subcriptionForm.value));
    this.currentDateTime =this._uhs.getFormattedDateToBind(subcriptionForm.start_date);//this.currentDateTime
    payload['start_date'] = this._uhs.getFormattedDateToBind(subcriptionForm.start_date);
    payload['end_date'] = this._uhs.getFormattedDateToBind(subcriptionForm.end_date);
    payload['status']  = subcriptionForm.status  ;
    payload['name'] = subcriptionForm.name ;
    payload['dot_registration_id']=this.schoolId;
    payload['subscription_date']=this.datepipe.transform((this.currentDateTime), 'yyyy-MM-dd h:mm:ss');//this.currentDateTime
    payload['students_license_limit']=subcriptionForm.students_license_limit
    payload['teachers_license_limit']=subcriptionForm.teachers_license_limit
    payload['admin_license_limit']=subcriptionForm.admin_license_limit
    payload['is_active']=subcriptionForm.is_active
    // this.currentDateTime =this.datepipe.transform((new Date), 'yyyy-MM-dd h:mm:ss');
    let comArr =[]
    const details={}
    let com =subcriptionForm.community;
    com.forEach(element => {comArr.push(element.community_id)})
    details['communities']= comArr;
    payload['details']=details
    return payload;
  }
}
