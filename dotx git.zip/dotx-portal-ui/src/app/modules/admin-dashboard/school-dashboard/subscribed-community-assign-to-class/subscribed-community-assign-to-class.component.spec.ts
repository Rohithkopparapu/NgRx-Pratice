import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SubscribedCommunityAssignToClassComponent } from './subscribed-community-assign-to-class.component';

describe('SubscribedCommunityAssignToClassComponent', () => {
  let component: SubscribedCommunityAssignToClassComponent;
  let fixture: ComponentFixture<SubscribedCommunityAssignToClassComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SubscribedCommunityAssignToClassComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SubscribedCommunityAssignToClassComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
