import { Component, OnInit } from '@angular/core';
import { FormArray, FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { NgbActiveModal, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import * as moment from 'moment';
import { IDropdownSettings } from 'ng-multiselect-dropdown';
import { ToastrService } from 'ngx-toastr';
import { DeleteComponent } from 'src/app/shared/component/delete/delete.component';
import { HelperService } from 'src/app/shared/services/helper.service';
import { AdminHelperService } from '../../admin-helper.service';
import { AuthState } from 'src/app/shared/store/auth.model';
import { Store } from '@ngrx/store';
import { userInfo } from '../../../../shared/store/auth.selector';
import { Subject } from 'rxjs';
import { elementAt, takeUntil } from 'rxjs/operators';
@Component({
  selector: 'app-subscribed-community-assign-to-class',
  templateUrl: './subscribed-community-assign-to-class.component.html',
  styleUrls: ['./subscribed-community-assign-to-class.component.scss']
})
export class SubscribedCommunityAssignToClassComponent implements OnInit {
  private subscriptions = new Subject<void>();
  data: any;
  userInfo: any;
  teacherRows: FormArray;
  createLevelForm = this.fb.group({
    
    teacherRows: this.fb.array([this.initRows()]),
    
  });

  MULTI_DROPDOWN_SETTINGS: IDropdownSettings = {
    singleSelection: false,
    idField: 'community_id',
    textField: 'community_name',
    selectAllText: 'Select All',
    unSelectAllText: 'UnSelect All',
    enableCheckAll: true,
    itemsShowLimit: 2,
    showSelectedItemsAtTop: true,
    allowSearchFilter: true
  };
  isLoading: boolean=false;
  communityList: any;
  edit: any;
  suncribeData: any;
  selectedItems:any=[];
  sucripId:any;
  dotRegistration: any;
  
  constructor(private modalService:NgbModal,
    private fb: FormBuilder, 
    private ngbActiveModal:NgbActiveModal,
    private adminHelperService: AdminHelperService,
    public _uhs: HelperService,
    private router: Router,
    private store$: Store<AuthState>,
    private toastrService: ToastrService) { 
      this.store$.select(userInfo)
      .pipe(takeUntil(this.subscriptions))
      .subscribe(res => {
        if (res) {
          this.userInfo = res;
          this.dotRegistration = res.dot_registration_id;
        }
      });
    }
  headers:any="Subscription"
  ngOnInit() {
    this.getCommunities()
    
  }
  getCommunities(): void {
    this.isLoading = true;
    const payload = {};
    this.adminHelperService.getCommunitiesByFilter(payload).subscribe(res => {
      this.isLoading = false;
      if (res && res.length) {
        this.communityList = res.filter(s =>
          !s.combo && moment(moment(s.community_start_date).format('YYYY-MM-DD')).isSameOrBefore(moment().format('YYYY-MM-DD')) && s.num_challenges > 0);
      }
        let result = res;
        if(result){
         const myArrayFiltered = result.filter((el) => {
          return JSON.parse(this.data.details).communities.some((f) => {
            return f == el.community_id ;
          });
          });
          this.communityList = myArrayFiltered
          console.log("communityList",this.communityList)
          this.getClassSubscription()
        }
      
    }, () => this.isLoading = false);
  }
  getClassSubscription(){
    let payload=this.data.subscription_id
    this.adminHelperService.getClassSubscription(payload).subscribe(res => {
      if(res.length){
        this.sucripId=res[0].id
        this.suncribeData = res[0].details.subscription;
        console.log("res",res[0].details.subscription)
        this.updateSubscription()
      }
    
    },() => this.isLoading = false)
  }
  initRows() {
    return this.fb.group({
      communityName: [],
      classNames:['']
      
    });
  }
  get formArr() {
    return this.createLevelForm.get('teacherRows') as FormArray;
  }

  addNewRow() {
    console.log(this.data)
    this.formArr.push(this.initRows());
  }

  // deleteRow(index: number) {
  //   this.formArr.removeAt(index);
  // }
  close(): void {
    this.ngbActiveModal.close('center_panel');
  }
  // onKey(x) { 
  //   let tFdata= this.createLevelForm.controls.teacherRows.value
  //   let Tdata=tFdata.filter(element=> (element.classNames == x.target.value))
  //   if(Tdata)
  //   {
  //     this.toastrService.warning("duplicat")
  //   }
  // }
  submitForm(){
    
    if(this.createLevelForm.valid ){
      let tFdata= this.createLevelForm.controls.teacherRows.value
      let Tdata=tFdata.filter(element=> (element.classNames!="" && element.communityName!=""))
      // let duplicate=tFdata.filter(element=> (element.classNames == x.target.value))
      var valueArr = tFdata.map(function(item){ return item.classNames });
      var isDuplicate = valueArr.some(function(item, idx){ 
          return valueArr.indexOf(item) != idx 
      });
      if(isDuplicate)
      {
        this.toastrService.warning("You have enterd duplicat Class")
      }
      // return
      else{
        if(Tdata.length){
          const details={}
          details['details']=this.processPayload()
          
          const payload= Object.assign(details)
          payload['subscription_id']=this.data.subscription_id
          // payload['id'] = `${this.sucripId.id}`
          // ------------- saving data --------------
          if(!this.suncribeData && !this.sucripId){
            this.adminHelperService.saveSubscriptionGrade(payload).subscribe(res => {
              this.isLoading = false;
              if (res) {
                this.toastrService.success(`Subscription Added successfully`);
                // this.loadChallenges();
              }
            }, err => this.isLoading = false);
            this.close()
          }else{
            payload['id'] = this.sucripId
            this.adminHelperService.updateSubscriptionGrade(payload).subscribe(res => {
              this.isLoading = false;
              if (res) {
                this.toastrService.success(`Subscription Updated successfully`);
                // this.loadChallenges();
              }
            }, err => this.isLoading = false);
            this.close()
          }
            console.log("Tdata",payload)
        }else{
          this.toastrService.warning("Please enter all field")
        }
      }
      
      console.log(Tdata,"Tdata")
    }else{
      this._uhs.validateAllFormFields(this.createLevelForm);
      this.toastrService.warning('Please enter all required fields');
    }

  }

  isDropdownDisabled(){
    if(this.dotRegistration !== null){
      return true;
    }else{
      return false;
    }
  }
  updateSubscription(){
    if(this.data != undefined && this.data.headerName === 'Update'){
      this.headers = this.data.headerName;
      this.headers = this.data.levelInfo==='Update';
      this.edit = true;
    }
      
      this.suncribeData.forEach((element,index) => {
        let data= this.communityList.filter((x) =>{ return element.communities.some((f) => {
          return f == x.community_id})
        });
        const activityArray = this.createLevelForm.controls['teacherRows'] as FormArray;
        activityArray.insert(index,this.fb.group({
          communityName:data,
          classNames: element.grade,
        }));
        if(this.dotRegistration !== null){
          activityArray.controls.forEach(control => {
            control.disable();
          });
        }
        this.selectedItems[index] = data;
      });
      if(this.dotRegistration !== null){
      const activityArray = this.createLevelForm.controls['teacherRows'] as FormArray;
      for (let i =activityArray.length - 1; i >= 0; i--) {
        const control =activityArray.at(i);
        const value = control.value.classNames;
        const value1 = control.value.communityName;        
        if (value1 === undefined && value === "") {
         activityArray.removeAt(i);
        }
      }
    }
      
  }

  // selectedItems(){
  //   this.suncribeData.forEach((element,index) => {
  //     let data= this.communityList.filter((x) =>{ return element.communities.some((f) => {
  //       return f == x.community_id})
  //     });
  //     return data[index];
  //   });
  // }

  processPayload(){
    const createLevelForm = JSON.parse(JSON.stringify(this.createLevelForm.value));
    let data = createLevelForm.teacherRows.filter(x => x.communityName !== "" && x.classNames !== "") ;
    const subscription=[]
    const com ={}
    data.forEach(element =>{
      const level1 ={}
      let community=[]
      level1['grade']=element.classNames
      element.communityName.forEach(elt => {
        community.push(elt.community_id)
      });
      level1['communities']=community;
      subscription.push(level1)

    })
    com['subscription']=subscription
    return com;
    // console.log('createLevelForm',com)
  }
  deleteRow(index: number,itemrow) {
    if(!itemrow.controls['classNames'].value || !itemrow.controls['communityName'].value){
      this.formArr.removeAt(index); 
    }
    
    if (itemrow.controls['classNames'].value || itemrow.controls['communityName'].value) {
      let tFdata = this.createLevelForm.controls.teacherRows.value
      let Tdata = tFdata.filter(element => (element.classNames != "" && element.communityName != ""))
      if (Tdata.length) {
        const deleteModelRef = this.modalService.open(DeleteComponent, { centered: true, backdrop: 'static' });
        deleteModelRef.componentInstance.message = 'Are you sure, want to delete this Item?';
        deleteModelRef.result.then((res) => {
          if (res) {
            this.formArr.removeAt(index);
            const details = {}
            details['details'] = this.processPayload()
            const payload = Object.assign(details)
            payload['subscription_id'] = this.data.subscription_id
            payload['id'] = this.sucripId
            this.adminHelperService.updateSubscriptionGrade(payload).subscribe(res => {
              this.isLoading = false;
              if (res) {
                this.toastrService.success(`Item deleted successfully`);
                // this.loadChallenges();
              }
            }, err => this.isLoading = false);
            

          }
        }, (reason) => {
          if (reason) {
            this.formArr.removeAt(index);
            const details = {}
            details['details'] = this.processPayload()
            const payload = Object.assign(details)
            payload['subscription_id'] = this.data.subscription_id
            payload['id'] = this.sucripId
            this.adminHelperService.updateSubscriptionGrade(payload).subscribe(res => {
              this.isLoading = false;
              if (res) {
                this.toastrService.success(`Item deleted successfully`);
                // this.loadChallenges();
              }
            }, err => this.isLoading = false);
            
          }
        });
      }
    }
    // }
  }
  // deleteRecord(topicId: number): any {
  //   const payload={"attachment_id":topicId}
  //   this.isLoading = true;
  //   this.adminHelperService.deleteMaterial(payload).subscribe(res => {
  //     this.isLoading = false;
  //     if (res) {
  //       this.toastrService.success(`Item DELETED successfully`);
  //       // this.loadChallenges();
  //     }
  //   }, err => this.isLoading = false);
  // }
  // this.activeModal.dismiss(result)
}
