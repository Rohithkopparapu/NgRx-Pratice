import { Component, OnInit, QueryList, ViewChildren } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import {HelperService} from '../../../shared/services/helper.service';
import { StudentHelperService } from '../student-helper.service';
import { AuthState } from 'src/app/shared/store/auth.model';
import { Store } from '@ngrx/store';
import { ToastrService } from 'ngx-toastr';
import { HttpClient } from '@angular/common/http';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-activity-dashboard',
  templateUrl: './activity-information.component.html',
  styleUrls: ['./activity-information.component.scss']
})
export class ActivityInformationComponent implements OnInit {
  data:any;
  studentName:any;
  community: any;
  dataListinfo: any;
  userName: any;
  constructor(private activeModel: NgbActiveModal,private http: HttpClient,private studentHelperService: StudentHelperService,private _uhs: HelperService,
    private toastrService: ToastrService,private helperService: HelperService,private fb: FormBuilder) {
   }
 
  teacheDashbrdForm = this.fb.group({
      startDate: [''],
      endDate: [''],
    });
  ngOnInit() {
    console.log(this.data);
    this.community = this.data.community_name;
    this.userName = this.data.user_name;
    this.dataListinfo = this.data.quest;
    const payload={}
  
//     this.dataListinfo= [
 
//   { community_id:2,community_name:"The Time Keepers",level_id:1,level_name:"The Story of Time",
//   activities:[{ "activity_name":"Drag the word",
//    "is_mandatory": "Optional",
//    "completed_on":"22-12-2022 02:05",
//    "numberofattempts":"2",
//    "score":"57%"
//   }, 
//   {
//     "activity_name":"This or That or More!",
//      "is_mandatory": "Mandatory",
//      "completed_on":"22-12-2022 02:05",
//      "numberofattempts":"2",
//      "score":"67%"
//     }, 
//     { "activity_name":"Memory Game", 
//     "is_mandatory": "Optional",
//     "completed_on":"22-12-2022 02:05",
//     "numberofattempts":"2",
//     "score":"100%"
//   },
//     {     
//     "activity_name":"Find the missing word", 
//     "is_mandatory": "Optional",
//     "completed_on":"22-12-2022 02:05",
//     "numberofattempts":"4",
//     "score":"100%"
//   }
//   ] 
// }
//     ]
}

getSort(activities){
  const act = activities.sort((a, b) => {
    if (a.is_mandatory === 1 && b.is_mandatory === 0) {
      return -1; // A comes before B
    } else if (a.is_mandatory === 0 && b.is_mandatory === 1) {
      return 1; // B comes before A
    }
  
    return 0;
  });
  return act;
  }

close(): void {
  this.activeModel.close();
}
  
}
