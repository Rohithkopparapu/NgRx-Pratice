import {Component, OnDestroy, OnInit} from '@angular/core';
import {NgbActiveModal, NgbModal} from '@ng-bootstrap/ng-bootstrap';
import {StudentHelperService} from '../../student-helper.service';
import {ToastrService} from 'ngx-toastr';
import {ChallengeWorkAreaComponent} from '../challenge-work-area/challenge-work-area.component';
import {Subject} from 'rxjs';
import {takeUntil} from 'rxjs/operators';
import {Store} from '@ngrx/store';
import {AuthState} from '../../../../shared/store/auth.model';
import { userInfo } from 'src/app/shared/store/auth.selector';

@Component({
  selector: 'app-assign-role',
  templateUrl: './assign-role.component.html',
  styleUrls: ['./assign-role.component.scss']
})
export class AssignRoleComponent implements OnInit, OnDestroy {

  private subscriptions = new Subject<void>();
  isLoading = false;
  challenge: any;
  rolesList: any[];
  selectedRole: any;
  userInfo: string;

  constructor(private activeModal: NgbActiveModal, private studentHelperService: StudentHelperService,
              private toastrService: ToastrService, private store$: Store<AuthState>, private modalService: NgbModal) {
    this.store$.select(userInfo)
      .pipe(takeUntil(this.subscriptions))
      .subscribe(res => this.userInfo = res);
  }

  ngOnInit() {
    this.getRolesForChallenge();
  }

  backToChallenge(): void {

  }

  closeModal(): void {
    this.activeModal.close();
  }

  assignRole(): void {
    if (!this.selectedRole) {
      this.toastrService.warning('Please select a role');
      return;
    }
    this.isLoading = true;
    const payload = {
      role: this.selectedRole.role_id,
      role_name: this.selectedRole.role_name,
      role_assigned_to: this.userInfo['user_email'],
      role_avatar: this.selectedRole.role_img,
      group: this.challenge.group_id,
      topic_id: this.challenge.topic_id
    };
    this.studentHelperService.postSelectedRole(payload).subscribe(res => {
      this.isLoading = false;
      if (res) {
        this.toastrService.success('Role has been submitted successfully');
        this.activeModal.close('Assign Role');
        this.gotoChallengeWorkArea();
      }
    }, err => this.isLoading = false);
  }

  gotoChallengeWorkArea(): void {
    const modelRef = this.modalService.open(ChallengeWorkAreaComponent, {
      centered: true,
      backdrop: 'static',
      scrollable: true,
      size: 'xl',
      // windowClass: 'modalChallengeStoryTelling'
      windowClass: 'modal-challenge'
    });
    modelRef.componentInstance.challenge = this.challenge;
  }

  onSelectRole(role): void {
    this.selectedRole = role;
  }

  getRolesForChallenge(): void {
    this.isLoading = true;
    const payload = {
      group_id: this.challenge.group_id,
      topic_id: this.challenge.topic_id
    };
    this.studentHelperService.roles(payload).subscribe(res => {
      this.isLoading = false;
      if (res) {
        this.rolesList = res;
      }
    }, () => this.isLoading = false);
  }

  ngOnDestroy(): void {
    this.subscriptions.next();
    this.subscriptions.complete();
  }
}
