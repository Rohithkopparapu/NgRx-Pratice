import {async, ComponentFixture, TestBed} from '@angular/core/testing';

import {ChallengeFinalSubmissionComponent} from './challenge-final-submission.component';

describe('ChallengeFinalSubmissionComponent', () => {
  let component: ChallengeFinalSubmissionComponent;
  let fixture: ComponentFixture<ChallengeFinalSubmissionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ChallengeFinalSubmissionComponent]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ChallengeFinalSubmissionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
