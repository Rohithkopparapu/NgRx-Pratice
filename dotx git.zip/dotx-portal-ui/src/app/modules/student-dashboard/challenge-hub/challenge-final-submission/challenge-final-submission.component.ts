import {Component, OnInit} from '@angular/core';
import {FileUploadComponent} from '../../../../shared/component/file-upload/file-upload.component';
import {NgbActiveModal, NgbModal} from '@ng-bootstrap/ng-bootstrap';
import * as moment from 'moment';
import {ToastrService} from 'ngx-toastr';
import {StudentHelperService} from '../../student-helper.service';
import {ChallengeSuccessComponent} from '../challenge-success/challenge-success.component';
import {ImageVideoViewComponent} from '../../../../shared/component/image-video-view/image-video-view.component';

@Component({
  selector: 'app-challenge-final-submission',
  templateUrl: './challenge-final-submission.component.html',
  styleUrls: ['./challenge-final-submission.component.scss']
})
export class ChallengeFinalSubmissionComponent implements OnInit {
  challenge: any;
  isLoading = false;
  videoFiles = [];
  imageFiles = [];
  docFiles = [];
  file: any;
  fileType: string;
  mediaType: string;
  message = '';
  toggled = false;
  consentBox = false;

  constructor(private modalService: NgbModal, private activeModal: NgbActiveModal,
              private toastrService: ToastrService, private studentHelperService: StudentHelperService) {
  }

  ngOnInit() {
  }

  onUploadDoc(evt, catagory, type) {
    const modalData = {
      headerName: 'Media',
      fileType: type,
      fileCategory: catagory,
      isMultipleFile: true
    };

    const modalRef = this.modalService.open(FileUploadComponent, {
      keyboard: false,
      backdrop: 'static',
      scrollable: true,
      windowClass: 'modal-cover modal-cover-fluid modal-upload'
    });
    modalRef.componentInstance.data = modalData;
    modalRef.result.then((res) => {
      console.log(res);
    }, (reason) => {
      if (reason && reason.length) {
        reason.forEach(file => {
          const fileExtension = file.file.split('.').pop();
          if (fileExtension.match(/(jpg|jpeg|png|gif)$/i)) {
            this.imageFiles.push({...file, type: 'image'});
          } else if (fileExtension.match(/(mp4|mov|wmv|avi|avchd)$/i)) {
            this.videoFiles.push({...file, type: 'video'});
          } else {
            this.docFiles.push({...file, type: 'doc'});
          }
        });
      }
    });
  }

  openModalSpot(link, type) {
    const modalRef = this.modalService.open(ImageVideoViewComponent, {
      centered: true,
      size: 'lg'
    });
    modalRef.componentInstance.fileType = type;
    modalRef.componentInstance.fileUrl = link;
  }

  openDocument(event: any, fileUrl: string) {
    // event.stopPropagation();
    window.open(
      fileUrl,
      '_blank'
    );
  }

  deleteFiles(event: Event, file, type) {
    event.stopPropagation();
    if (type === 'video') {
      this.videoFiles = this.videoFiles.filter(item => item.file !== file.file);
    } else if (type === 'image') {
      this.imageFiles = this.imageFiles.filter(item => item.file !== file.file);
    } else if (type === 'doc') {
      this.docFiles = this.docFiles.filter(item => item.file !== file.file);
    }
  }

  cancelSubmit() {
    this.activeModal.close();
  }

  submitFinalComment() {
    const TodayDate = moment().format('YYYY-MM-DD hh:mm:ss');
    const attachment = [...this.videoFiles, ...this.imageFiles, ...this.docFiles];
    if (!this.message || attachment.length === 0) {
      this.toastrService.warning('Please upload a file or write a description.');
      return false;
    } else {
      this.isLoading = true;
      const payload = {
        response_description: this.message.trim(),
        date_of_response: TodayDate,
        topic_assign: this.challenge.topic_assign_id,
        is_final_submit: 1,
        attachments: attachment
      };
      this.studentHelperService.addComments(payload).subscribe(res => {
        this.message = '';
        this.isLoading = false;
        if (res) {
          this.toastrService.success('Challenge successfully submitted');
          this.videoFiles = this.imageFiles = this.docFiles = [];
          this.activeModal.close('close');
          this.modalService.open(ChallengeSuccessComponent, {centered: true, size: 'lg', keyboard: false, backdrop: 'static', windowClass: 'bd-example-modal-lg modalCcongratulations-outer'});
        }
      }, err => this.isLoading = false);
    }
  }

  handleSelection(event: any) {
    this.message += event.char;
  }

  agreeConsentBox(event: any): void {
    this.consentBox = event.target.checked;
  }
}
