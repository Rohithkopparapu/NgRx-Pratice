import {NgModule} from '@angular/core';
import {RouterModule, Routes} from '@angular/router';
import {ChallengeHubComponent} from './challenge-hub.component';
import {SearchChallengeComponent} from './search-challenge/search-challenge.component';
import {CreateChallengeComponent} from './create-challenge/create-challenge.component';


const routes: Routes = [
  {
    path: '',
    component: ChallengeHubComponent
  },
  {
    path: 'search',
    component: SearchChallengeComponent,
  },
  {
    path: 'create',
    component: CreateChallengeComponent,
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})

export class ChallengeHubRoutingModule {}
