import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ChallengeHubComponent } from './challenge-hub.component';

describe('ChallengeHubComponent', () => {
  let component: ChallengeHubComponent;
  let fixture: ComponentFixture<ChallengeHubComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ChallengeHubComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ChallengeHubComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
