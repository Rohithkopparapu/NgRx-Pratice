import { AfterViewChecked, Component, OnDestroy, OnInit } from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { StudentHelperService } from '../student-helper.service';
import { Store } from '@ngrx/store';
import { AuthState } from '../../../shared/store/auth.model';
import { HelperService } from '../../../shared/services/helper.service';
import { SoloChallengeModelComponent } from '../../../shared/component/solo-challenge-model/solo-challenge-model.component';
import { GroupChallengeModelComponent } from '../../../shared/component/group-challenge-model/group-challenge-model.component';
import { ViewResponsesComponent } from '../../../shared/component/view-responses/view-responses.component';
import { ActivatedRoute, Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { UserDetailsAction } from '../../../shared/store/auth.action';
import * as moment from 'moment';
import { takeUntil } from 'rxjs/operators';
import { userInfo } from 'src/app/shared/store/auth.selector';
import { Subject, Subscription } from 'rxjs';
import Swiper, { Navigation, Pagination } from 'swiper';
import { PostRefreshService } from '../../../shared/services/post-refresh.service';

declare const $: any;
@Component({
  selector: 'app-challenge-hub',
  templateUrl: './challenge-hub.component.html',
  styleUrls: ['./challenge-hub.component.scss']
})
export class ChallengeHubComponent implements OnInit, AfterViewChecked, OnDestroy {
  private subscription: Subscription;
  private subscriptions = new Subject<void>();
  isHubLoading: boolean;
  isLoading: boolean;
  userInfo: any;
  evergreenChallenges: any[];
  continueChallenges: any[];
  recentChallenges: any[];
  influencerChallenges: any[];
  trendingChallenges: any[];
  myChallenges: any[];
  top10Challenges: any[];
  top10ResponsesChallenges: any[];
  upcomingChallenges: any[];
  top10ResponseCards: any[];
  influencerResponseCards: any[];
  spotLightChallenges: any[];
  pendingInvitesChallenges: any[];
  dateRangeSelected = 'Last 6 Months';
  searchType = 'Topic';
  searchKeyword: string;
  toggleLeaderBoard = true;
  isEnableTop10Responses = false;
  isEnableInfluencerResponses = false;
  communitiesList: any[];
  myCommunityInfo: any;
  userCommunityPreference: any;
  subscribedCommunitiesList: any = [];
  is_competition: boolean = false;

  constructor(private modalService: NgbModal, private studentHelperService: StudentHelperService, private store$: Store<AuthState>,
    private _uhs: HelperService, private router: Router, private toastrService: ToastrService,
    private activatedRoute: ActivatedRoute, private postRefresh: PostRefreshService) {
    this.store$.select(userInfo)
      .pipe(takeUntil(this.subscriptions))
      .subscribe(res => {
        if (res) {
          this.userInfo = res;
          // this.userCommunityPreference = this.userInfo.preferences.find(s => s.entity_name === PREFERENCES.COMMUNITY.ENTITY_NAME && s.entity_type === PREFERENCES.COMMUNITY.ENTITY_TYPE);
        }
      });
    this.subscription = this.postRefresh.postrefreshComponent$.subscribe(() => {
      this.refreshPosts();
    });
  }

  ngOnInit() {
    this.activatedRoute.data.subscribe((response) => {
      this.userCommunityPreference = response && response.userPreferenceDetails;
    });
    this.getCommunities();
    this.getChallenges(Number(this.userCommunityPreference.value));
    this.studentHelperService.isRefreshHubPage
      .pipe(takeUntil(this.subscriptions))
      .subscribe(value => {
        if (value && value._page === 'challenge') {
          this.refreshData();
        }
      });
  }

  refreshPosts() {
    this.refreshData();
  }

  getCommunities(): void {
    this.isLoading = true;
    this.studentHelperService.getAllCommunitiesNew().subscribe(res => {
      this.isLoading = false;
      // if (res && res.length) {
      //   this.communitiesList = res.filter(s => !s.combo && moment(moment(s.community_start_date).format('YYYY-MM-DD')).isSameOrBefore(moment().format('YYYY-MM-DD')) && s.num_challenges > 0);
      // }

      if (res && res.my_communities.length !== 0) {
        sessionStorage.setItem('subsribedCommunities',JSON.stringify(res));
        this.subscribedCommunitiesList = res.my_communities.sort((a, b) => a.community_name.localeCompare(b.community_name));
        const data = this.subscribedCommunitiesList.find(x => x.community_id === Number(this.userCommunityPreference.value));
        if(data !== undefined && data.is_competition === 1){
          this.is_competition = true;
        }else{
          this.is_competition = false;
        }
      }

    }, () => this.isLoading = false);
  }

  getChallenges(communityId): void {
    this.isHubLoading = true;
    this.studentHelperService.getChallenges(communityId).subscribe(res => {
      this.myCommunityInfo = res['community'] ? res['community'] : {};
      this.spotLightChallenges = this.initSpotlightBanner(res['spotlight_challenges']);
      this.continueChallenges = this.initChallengesSlider(res['continue_challenges'], false);
      this.recentChallenges = this.initChallengesSlider(res['recent_challenges'], false);
      this.influencerChallenges = this.initChallengesSlider(res['influencer_challenges'], true);
      // this.trendingChallenges = this._uhs.getOnlyImageFromChallenges(res['trending_now']);
      this.evergreenChallenges = this.initChallengesSlider(res['evergreen_challenges'], false);
      // this.top10Challenges = this._uhs.getOnlyImageFromChallenges(res['top10_challenges']);
      this.top10ResponsesChallenges = this.initChallengesSlider(res['top10_responses'], true);
      this.myChallenges = this.initChallengesSlider(res['my_challenges'], false);
      this.upcomingChallenges = this.initChallengesSlider(res['upcoming_challenges'], false);
      this.pendingInvitesChallenges = this.initChallengesSlider(res['invited_challenges'], false);
      this.isHubLoading = false;
    }, () => this.isHubLoading = false);
  }

  initSpotlightBanner(spotLightChallenges: any[]) {
    spotLightChallenges = this._uhs.getImageOrVideoFromChallenges(spotLightChallenges);
    if (spotLightChallenges && spotLightChallenges.length > 1) {
      setTimeout(() => {
        const swiper = new Swiper('.swiper.swiper-banner-spotlight', {
          modules: [Navigation, Pagination],
          // Optional parameters
          // loop: true,

          // If we need pagination
          pagination: {
            clickable: true,
            el: '.swiper-pagination',
            type: 'bullets'
          },

          // autoplay: {
          //   delay: 5000,
          // },

          keyboard: {
            enabled: true,
            onlyInViewport: false,
          },

          // Navigation arrows
          navigation: {
            nextEl: '.swiper-button-next',
            prevEl: '.swiper-button-prev',
          },
        });
      });
    } else {
      setTimeout(() => {
        const swiper = new Swiper('.swiper.swiper-banner-spotlight', {
          // Optional parameters
          enabled: false,
          navigation: {
            nextEl: null,
            prevEl: null,
          },
        });
      });
    }
    return spotLightChallenges;
  }

  initChallengesSlider(challenges: any[], isStack: boolean) {
    challenges = this._uhs.getOnlyImageFromChallenges(challenges);
    if (!isStack) {
      setTimeout(() => {
        const swiperSlider = new Swiper('.swiper.swiper-slider', {
          modules: [Navigation, Pagination],
          // Optional parameters
          // loop: true,

          keyboard: {
            enabled: true,
            onlyInViewport: false,
          },

          // Navigation arrows
          navigation: {
            nextEl: '.swiper-button-next',
            prevEl: '.swiper-button-prev',
          },
          breakpoints: {
            0: {
              slidesPerView: 1,
              spaceBetween: 10,
              slidesPerGroup: 1
            },
            576: {
              slidesPerView: 2,
              spaceBetween: 20,
              slidesPerGroup: 2
            },
            992: {
              slidesPerView: 3,
              spaceBetween: 25,
              slidesPerGroup: 3
            },
            1200: {
              slidesPerView: 4,
              spaceBetween: 30,
              slidesPerGroup: 4
            }
          }
        });
      });
    } else {
      setTimeout(() => {
        const swiperSliderStack = new Swiper('.swiper.swiper-slider-stack', {
          modules: [Navigation, Pagination],
          // Optional parameters
          // loop: true,

          keyboard: {
            enabled: true,
            onlyInViewport: false,
          },

          // Navigation arrows
          navigation: {
            nextEl: '.swiper-button-next',
            prevEl: '.swiper-button-prev',
          },
          breakpoints: {
            0: {
              slidesPerView: 1,
              spaceBetween: 10,
              slidesPerGroup: 1
            },
            576: {
              slidesPerView: 2,
              spaceBetween: 30,
              slidesPerGroup: 2
            },
            992: {
              slidesPerView: 3,
              spaceBetween: 35,
              slidesPerGroup: 3
            },
            1200: {
              slidesPerView: 4,
              spaceBetween: 50,
              slidesPerGroup: 4
            }
          }
        });
      });
    }
    return challenges;
  }

  onDateRangeChanged(filterVal: any) {
    this.dateRangeSelected = filterVal.innerText;

    const payload = {
      time_filter: this.dateRangeSelected,
      community_id: this.userCommunityPreference.value
    };
    this.getTop10Challenges(payload);
    this.getContinueChallenges(payload);
    this.getTrendingNowChallenges(payload);
    this.getMyChallenges(payload);
    this.getUpcomingChallengesList(payload);
    // this.getRecentlyAddedChallenges();
  }

  getTop10Challenges(payload) {
    this.isLoading = true;
    this.top10Challenges = [];
    this.studentHelperService.getChallengesTop10(payload).subscribe(res => {
      this.isLoading = false;
      if (res) {
        this.top10Challenges = this._uhs.getOnlyImageFromChallenges(res);
        this.initChallengesSlider(this.top10Challenges, false);
      }
    }, err => this.isLoading = false);
  }

  getRecentlyAddedChallenges() {
    this.isLoading = true;
    this.recentChallenges = [];
    const payload = {
      time_filter: ''
    };
    this.studentHelperService.getChallengesRecent(payload).subscribe(res => {
      this.isLoading = false;
      if (res) {
        this.recentChallenges = this._uhs.getOnlyImageFromChallenges(res);
        this.initChallengesSlider(this.recentChallenges, false);
      }
    }, err => this.isLoading = false);
  }

  getContinueChallenges(payload) {
    this.isLoading = true;
    this.continueChallenges = [];
    this.studentHelperService.getChallengesContinue(payload).subscribe(res => {
      this.isLoading = false;
      if (res) {
        this.continueChallenges = this._uhs.getOnlyImageFromChallenges(res);
        this.initChallengesSlider(this.continueChallenges, false);
      }
    }, err => this.isLoading = false);
  }

  getTrendingNowChallenges(payload) {
    this.isLoading = true;
    this.trendingChallenges = [];
    this.studentHelperService.getChallengeTrend(payload).subscribe(res => {
      this.isLoading = false;
      if (res) {
        this.trendingChallenges = this._uhs.getOnlyImageFromChallenges(res);
        this.initChallengesSlider(this.trendingChallenges, false);
      }
    }, err => this.isLoading = false);
  }

  getMyChallenges(payload) {
    this.isLoading = true;
    this.myChallenges = [];
    this.studentHelperService.getMyChallenges(payload).subscribe(res => {
      this.isLoading = false;
      if (res) {
        this.myChallenges = this._uhs.getOnlyImageFromChallenges(res);
        this.initChallengesSlider(this.myChallenges, false);
      }
    }, err => this.isLoading = false);
  }

  getUpcomingChallengesList(payload): void {
    this.isLoading = true;
    this.upcomingChallenges = [];
    this.studentHelperService.getUpcomingChallenges(payload).subscribe(res => {
      this.isLoading = false;
      if (res) {
        this.upcomingChallenges = this._uhs.getOnlyImageFromChallenges(res);
        this.initChallengesSlider(this.upcomingChallenges, false);
      }
    }, err => this.isLoading = false);
  }

  ngAfterViewChecked() {
    $('.top-responses-slider').not('.slick-initialized').slick({
      slidesToShow: 4,
      infinite: 0,
      slidesToScroll: 4,
      responsive: [
        {
          breakpoint: 1200,
          settings: {
            arrows: false,
            slidesToScroll: 3,
            slidesToShow: 3
          }
        },
        {
          breakpoint: 993,
          settings: {
            arrows: false,
            slidesToScroll: 2,
            slidesToShow: 2
          }
        },
        {
          breakpoint: 631,
          settings: {
            arrows: false,
            slidesToScroll: 1,
            slidesToShow: 1
          }
        }
      ]
    });
    $('.recent-challenge-slider').not('.slick-initialized').slick({
      // centerMode: true,
      // centerPadding: '90px',
      // slidesToShow: 4,

      slidesToShow: 4,
      infinite: 0,
      slidesToScroll: 4,
      responsive: [
        {
          breakpoint: 1200,
          settings: {
            arrows: false,
            slidesToScroll: 3,
            slidesToShow: 3
          }
        },
        {
          breakpoint: 993,
          settings: {
            arrows: false,
            slidesToScroll: 2,
            slidesToShow: 2
          }
        },
        {
          breakpoint: 631,
          settings: {
            arrows: false,
            slidesToScroll: 1,
            slidesToShow: 1
          }
        }
      ]
    });
    $('.continue-slider').not('.slick-initialized').slick({
      slidesToShow: 4,
      infinite: 0,
      slidesToScroll: 4,
      responsive: [
        {
          breakpoint: 1200,
          settings: {
            arrows: false,
            slidesToScroll: 3,
            slidesToShow: 3
          }
        },
        {
          breakpoint: 993,
          settings: {
            arrows: false,
            slidesToScroll: 2,
            slidesToShow: 2
          }
        },
        {
          breakpoint: 631,
          settings: {
            arrows: false,
            slidesToScroll: 1,
            slidesToShow: 1
          }
        }
      ]
    });
    $('.top-challenges-slider').not('.slick-initialized').slick({
      // centerMode: true,
      // centerPadding: '90px',
      // slidesToShow: 4,

      slidesToShow: 4,
      infinite: 0,
      slidesToScroll: 4,
      responsive: [
        {
          breakpoint: 1200,
          settings: {
            arrows: false,

            slidesToShow: 3
          }
        },
        {
          breakpoint: 993,
          settings: {
            arrows: false,

            slidesToShow: 2
          }
        },
        {
          breakpoint: 631,
          settings: {
            arrows: false,

            slidesToShow: 1
          }
        }
      ]
    });
    $('.my-challenges-slider').not('.slick-initialized').slick({
      slidesToShow: 4,
      infinite: 0,
      slidesToScroll: 4,
      responsive: [
        {
          breakpoint: 1200,
          settings: {
            arrows: false,
            slidesToScroll: 3,
            slidesToShow: 3
          }
        },
        {
          breakpoint: 993,
          settings: {
            arrows: false,
            slidesToScroll: 2,
            slidesToShow: 2
          }
        },
        {
          breakpoint: 631,
          settings: {
            arrows: false,
            slidesToScroll: 1,
            slidesToShow: 1
          }
        }
      ]
    });
    $('.trending-now-slider').not('.slick-initialized').slick({
      slidesToShow: 4,
      infinite: 0,
      slidesToScroll: 4,
      responsive: [
        {
          breakpoint: 1200,
          settings: {
            arrows: false,

            slidesToShow: 3
          }
        },
        {
          breakpoint: 993,
          settings: {
            arrows: false,

            slidesToShow: 2
          }
        },
        {
          breakpoint: 631,
          settings: {
            arrows: false,

            slidesToShow: 1
          }
        }
      ]
    });
  }

  searchSpotlightChallenges(): void {
    this.isLoading = true;
    if (this.searchKeyword) {
      const data = {
        search_type: this.searchType,
        keyword: this.searchKeyword
      };
      // this._uhs.searchData = data;
      this.router.navigate(['/auth/student/challenge/search'], { state: { searchData: data } });
    } else {
      this.isLoading = false;
      this.toastrService.warning('Please enter valid input details', 'Search');
    }
  }

  openOrCloseLeaderBoardPopup() {
    this.toggleLeaderBoard = !this.toggleLeaderBoard;
  }

  onSearchFilter(value): void {
    this.searchType = value;
  }

  onChangeCommunity(community: any, item): void {
    if (community.community_id !== item.community_id) {
      if (community.is_community_user) {
        this.callCommunityService(community);
      } else {
        this.router.navigate(['/auth/student/community/join']);
      }
    }
  }

  callCommunityService(community): void {
    this.isLoading = true;
    const payload = {
      id: this.userCommunityPreference.id,
      user: this.userInfo.user_id,
      value: community.community_id.toString()
    };
    this.studentHelperService.updatePreference(payload).subscribe(res => {
      this.isLoading = false;
      if (res) {
        this.userCommunityPreference = res;
        this.store$.dispatch(new UserDetailsAction({ userId: this.userInfo.user_id, _page: 'challenge' }));
      }
    }, () => this.isLoading = false);
  }

  openChallenge(challenge: any): any {
    const data = {
      challenge
    };
    const component = challenge.topic_group_size === 1 ? SoloChallengeModelComponent : GroupChallengeModelComponent;
    const modelRef = this.modalService.open(component, {
      centered: true,
      scrollable: true,
      backdrop: 'static',
      keyboard: false,
      size: 'xl',
      windowClass: 'modal-challenge'
    });
    modelRef.componentInstance.data = data;
  }

  openViewResponses(challenge: any): void {
    const modelRef = this.modalService.open(ViewResponsesComponent, {
      centered: true,
      scrollable: true,
      backdrop: 'static',
      size: 'xl',
      windowClass: 'modal-challenge'
    });
    modelRef.componentInstance.challenge = challenge;
    modelRef.componentInstance.fromPage = 'hub';
    modelRef.componentInstance._page = 'MyChallenges';
    modelRef.componentInstance.isResponseSelect = true;
    modelRef.result.then(res => {
      if (res === 'hub') {
        this.refreshData();
      }
    });
  }

  getStackedResponseCards(topicId, type): void {
    this.isLoading = true;
    this.studentHelperService.getResponseCards(topicId).subscribe(res => {
      this.isLoading = false;
      if (res && res.length) {
        this.getResponseCardsByType(type, res);
      } else {
        this.toastrService.warning('No responses found...');
      }
    });
  }

  getResponseCardsByType(type, result): void {
    if (type === 'Top 10 Responses') {
      this.top10ResponseCards = [];
      result.forEach(chall => {
        if (chall.attachments && chall.attachments.length) {
          const imageObj = chall.attachments.find(attach => attach.type === 'image');
          chall['response_image'] = imageObj && imageObj.file ? imageObj.url : null;
        }
      });
      this.top10ResponseCards = result;
      this.initChallengesSlider([], false);
      this.isEnableTop10Responses = true;
    } else if (type === 'Influencer Challenges') {
      this.influencerResponseCards = [];
      result.forEach(chall => {
        if (chall.attachments && chall.attachments.length) {
          const imageObj = chall.attachments.find(attach => attach.type === 'image');
          chall['response_image'] = imageObj && imageObj.file ? imageObj.url : null;
        }
      });
      this.influencerResponseCards = result;
      this.initChallengesSlider([], false);
      this.isEnableInfluencerResponses = true;
    }
  }

  onCloseStackedResponses(type): void {
    if (type === 'Influencer Challenges') {
      this.influencerResponseCards = [];
      this.initChallengesSlider([], true);
      this.isEnableInfluencerResponses = !this.isEnableInfluencerResponses;
    } else if (type === 'Top 10 Responses') {
      this.top10ResponseCards = [];
      this.initChallengesSlider([], true);
      this.isEnableTop10Responses = !this.isEnableTop10Responses;
    }
  }

  refreshData(): void {
    this.myCommunityInfo = {};
    this.spotLightChallenges = [];
    this.pendingInvitesChallenges = [];
    this.continueChallenges = [];
    this.recentChallenges = [];
    this.influencerChallenges = [];
    this.trendingChallenges = [];
    this.evergreenChallenges = [];
    this.top10Challenges = [];
    this.top10ResponsesChallenges = [];
    this.myChallenges = [];
    this.upcomingChallenges = [];
    this.getCommunities();
    this.getChallenges(Number(this.userCommunityPreference.value));
    // this.cd.detectChanges();
  }

  navigateCreateChallenge(): void {
    this.router.navigate(['/auth/student/challenge/create'], { state: { page: 'challenge' } });
  }

  ngOnDestroy(): void {
    this.subscriptions.next();
    this.subscriptions.complete();
  }
}
