import {NgModule} from '@angular/core';
import {SharedModule} from '../../../shared/shared.module';
import {ChallengeHubRoutingModule} from './challenge-hub-routing.module';
import {ChallengeHubComponent} from './challenge-hub.component';
import {ChallengeWorkAreaComponent} from './challenge-work-area/challenge-work-area.component';
import {ChallengeFinalSubmissionComponent} from './challenge-final-submission/challenge-final-submission.component';
import {AssignRoleComponent} from './assign-role/assign-role.component';
import {CreateGroupComponent} from './create-group/create-group.component';
import {ChallengeSuccessComponent} from './challenge-success/challenge-success.component';
import {InviteBuddyPopupComponent} from './invite-buddy-popup/invite-buddy-popup.component';
import {CreateChallengeComponent} from './create-challenge/create-challenge.component';
import {SearchChallengeComponent} from './search-challenge/search-challenge.component';


@NgModule({
  declarations: [
    ChallengeHubComponent,
    ChallengeWorkAreaComponent,
    ChallengeFinalSubmissionComponent,
    AssignRoleComponent,
    CreateGroupComponent,
    InviteBuddyPopupComponent,
    ChallengeSuccessComponent,
    CreateChallengeComponent,
    SearchChallengeComponent
  ],
  imports: [
    ChallengeHubRoutingModule,
    SharedModule
  ],
  entryComponents: [
    ChallengeWorkAreaComponent,
    ChallengeFinalSubmissionComponent,
    AssignRoleComponent,
    CreateGroupComponent,
    InviteBuddyPopupComponent,
    ChallengeSuccessComponent
  ]
})
export class ChallengeHubModule {}
