import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ChallengeSuccessComponent } from './challenge-success.component';

describe('ChallengeSuccessComponent', () => {
  let component: ChallengeSuccessComponent;
  let fixture: ComponentFixture<ChallengeSuccessComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ChallengeSuccessComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ChallengeSuccessComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
