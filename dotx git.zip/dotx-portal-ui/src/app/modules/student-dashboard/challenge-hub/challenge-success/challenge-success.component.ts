import {Component, OnDestroy, OnInit} from '@angular/core';
import {Router} from '@angular/router';
import {StudentHelperService} from '../../student-helper.service';
import {takeUntil} from 'rxjs/operators';
import {userInfo} from '../../../../shared/store/auth.selector';
import {Subject} from 'rxjs';
import {Store} from '@ngrx/store';
import {AuthState} from '../../../../shared/store/auth.model';
import {NgbActiveModal} from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-challenge-success',
  templateUrl: './challenge-success.component.html',
  styleUrls: ['./challenge-success.component.scss']
})
export class ChallengeSuccessComponent implements OnInit, OnDestroy {

  private subscriptions = new Subject<void>();
  userInfo: any;

  constructor(private router: Router, private studentHelperService: StudentHelperService, private store$: Store<AuthState>,
              private activeModal: NgbActiveModal) {
    this.store$.select(userInfo)
      .pipe(takeUntil(this.subscriptions))
      .subscribe(res => this.userInfo = res);
  }

  ngOnInit() {
  }

  closeCongrats() {
    // this.studentService.setLoadHubPage(true);
    this.router.navigate(['/auth/student/home']);
    this.studentHelperService.getBadgesAndDotCoins(this.userInfo.user_id);
    this.activeModal.close();
  }

  ngOnDestroy(): void {
    this.subscriptions.next();
    this.subscriptions.complete();
  }
}
