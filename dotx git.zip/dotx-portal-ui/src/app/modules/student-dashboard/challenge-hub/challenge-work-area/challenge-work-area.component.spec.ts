import {async, ComponentFixture, TestBed} from '@angular/core/testing';

import {ChallengeWorkAreaComponent} from './challenge-work-area.component';

describe('ChallengeWorkareaComponent', () => {
  let component: ChallengeWorkAreaComponent;
  let fixture: ComponentFixture<ChallengeWorkAreaComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ChallengeWorkAreaComponent]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ChallengeWorkAreaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
