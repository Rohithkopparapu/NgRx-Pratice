import {Component, OnDestroy, OnInit} from '@angular/core';
import {NgbActiveModal, NgbModal} from '@ng-bootstrap/ng-bootstrap';
import * as moment from 'moment';
import {ToastrService} from 'ngx-toastr';
import {FileUploadComponent} from 'src/app/shared/component/file-upload/file-upload.component';
import {CommonApiService} from 'src/app/shared/services/common-api.service';
import {StudentHelperService} from '../../student-helper.service';
import {ChallengeFinalSubmissionComponent} from '../challenge-final-submission/challenge-final-submission.component';
import {CreateGroupComponent} from '../create-group/create-group.component';
import {ImageVideoViewComponent} from '../../../../shared/component/image-video-view/image-video-view.component';
import {takeUntil} from 'rxjs/operators';
import {Store} from '@ngrx/store';
import {AuthState} from '../../../../shared/store/auth.model';
import { userInfo } from 'src/app/shared/store/auth.selector';
import {Subject} from 'rxjs';

@Component({
  selector: 'app-challenge-work-area',
  templateUrl: './challenge-work-area.component.html',
  styleUrls: ['./challenge-work-area.component.scss']
})
export class ChallengeWorkAreaComponent implements OnInit, OnDestroy {
  private subscriptions = new Subject<void>();
  isLoading = false;
  groupListLoading = false;
  userInfo: any;
  challenge: any;
  comment = '';
  commentsList: any[];
  finalCommentSubmitted: any;
  file: any;
  fileType: string;
  mediaType: string;
  daysLeftForSubmission: any;
  groupList: any[];
  groupOwner: any;
  commentImageFiles = [];
  commentVideoFiles = [];
  commentFiles = [];
  pendingGroupMembers: any[];
  acceptedGroupMembers: any[];

  readonly pluralMapping: any = {
    response: {
      '=0': '0 Responses',
      '=1': '1 Response',
      other: '# Responses',
    },
    day: {
      '=0': '0 days',
      '=1': '1 day',
      other: '# days',
    }
  };
  toggled = false;

  constructor(private studentHelperService: StudentHelperService, private modalService: NgbModal, private commonService: CommonApiService,
              private toastrService: ToastrService, private activeModal: NgbActiveModal, private store$: Store<AuthState>) {
    this.store$.select(userInfo)
      .pipe(takeUntil(this.subscriptions))
      .subscribe(res => this.userInfo = res);
  }

  ngOnInit() {
    this.daysLeftForSubmission = this.commonService.getDateDifference(
      new Date(), this.challenge.topic_end_date, 'days'
    );
    if (this.challenge.group_id) {
      this.getGroupMembers();
    }
    this.getChallengeComments();
  }

  getChallengeComments(): void {
    this.isLoading = true;
    if (this.challenge.topic_group_size === 1) {
      this.studentHelperService
        .getSoloChallengeNotes(this.challenge.topic_assign_id).subscribe(res => {
        this.isLoading = false;
        this.commentsList = res;
        this.finalCommentSubmitted = this.commentsList.find(item => item.is_final_submit === '1');
        this.commentsList = this.commentsList.filter(item => item.is_final_submit === '0');
      }, () => this.isLoading = false);
    } else {
      this.studentHelperService
        .getCommentRetrieveGroup(this.challenge.group_id).subscribe(res => {
        this.isLoading = false;
        this.commentsList = res;
        this.finalCommentSubmitted = this.commentsList.find(item => item.is_final_submit === '1');
        this.commentsList = this.commentsList.filter(item => item.is_final_submit === '0');
      }, () => this.isLoading = false);
    }
  }

  getGroupMembers() {
    this.groupListLoading = true;
    this.studentHelperService.groupMembers({group_id: this.challenge.group_id}).subscribe(res => {
      this.groupListLoading = false;
      if (res) {
        this.groupList = res;
        this.groupOwner = this.groupList.find(item => item.is_group_owner);
        this.acceptedGroupMembers = this.groupList.filter(s => s.role_id);
        this.pendingGroupMembers = this.groupList.filter(s => !s.role_id);
      }
    }, err => this.groupListLoading = false);
  }

  viewGroup(): void {
    const data = {challenge: this.challenge, groupMembers: this.groupList, formName: 'Update', isPendingInvitesExist: this.pendingGroupMembers.length === 0};
    const modelRef = this.modalService.open(CreateGroupComponent, {
      centered: true,
      scrollable: true,
      backdrop: 'static',
      keyboard: false,
      size: 'xl',
      windowClass: 'modal-challenge modal-challenge-fluid'
    });
    modelRef.componentInstance.data = data;
    modelRef.result.then(res => {
      if (res) {
        this.getGroupMembers();
      }
    });
  }

  saveComment() {
    const TodayDate = moment().format('YYYY-MM-DD hh:mm:ss');
    const attachment = [...this.commentVideoFiles, ...this.commentImageFiles, ...this.commentFiles];
    if (!this.comment && attachment.length === 0) {
      this.toastrService.warning('Please write something or upload a file.');
      return false;
    } else {
      this.isLoading = true;
      const payload = {
        response_description: this.comment.trim(),
        date_of_response: TodayDate,
        topic_assign: this.challenge.topic_assign_id,
        attachments: attachment
      };
      this.studentHelperService.addComments(payload).subscribe(res => {
        this.isLoading = false;
        if (res) {
          this.comment = '';
          this.commentVideoFiles = this.commentImageFiles = this.commentFiles = [];
          this.getChallengeComments();
        }
      }, err => this.isLoading = false);
    }
  }

  openModal(link: any, type: any): void {
    const modalRef = this.modalService.open(ImageVideoViewComponent, {
      centered: true,
      size: 'lg'
    });
    modalRef.componentInstance.fileType = type;
    modalRef.componentInstance.fileUrl = link;
  }

  openDocument(event: any, fileUrl: string) {
    // event.stopPropagation();
    window.open(
      fileUrl,
      '_blank'
    );
  }

  commentDeleteFiles(event: Event, file, type) {
    event.stopPropagation();
    if (type === 'video') {
      this.commentVideoFiles = this.commentVideoFiles.filter(item => item.file !== file.file);
    } else if (type === 'image') {
      this.commentImageFiles = this.commentImageFiles.filter(item => item.file !== file.file);
    } else if (type === 'doc') {
      this.commentFiles = this.commentFiles.filter(item => item.file !== file.file);
    }
  }

  onUploadComment(evt, catagory, type) {
    const modalData = {
      headerName: 'Media',
      fileType: type,
      fileCategory: catagory,
      isMultipleFile: true
    };

    const modalRef = this.modalService.open(FileUploadComponent, {
      keyboard: false,
      backdrop: 'static',
      scrollable: true,
      windowClass: 'modal-cover modal-cover-fluid modal-upload'
    });
    modalRef.componentInstance.data = modalData;
    modalRef.result.then((res) => {
      console.log(res);
    }, (reason) => {
      if (reason && reason.length) {
        reason.forEach(file => {
          const fileExtension = file.file.split('.').pop();
          if (fileExtension.match(/(jpg|jpeg|png|gif)$/i)) {
            this.commentImageFiles.push({...file, type: 'image'});
          } else if (fileExtension.match(/(mp4|mov|wmv|avi|avchd)$/i)) {
            this.commentVideoFiles.push({...file, type: 'video'});
          } else {
            this.commentFiles.push({...file, type: 'doc'});
          }
        });
      }
    });
  }

  closeModal() {
    this.activeModal.close();
  }

  submitChallenge(): void {
    if (this.challenge.topic_group_size === 1) {
      this.gotoChallengeFinalSubmission();
    } else {
      if (this.challenge.topic_group_size === this.acceptedGroupMembers.length) {
        this.gotoChallengeFinalSubmission();
      } else {
        this.toastrService.warning('Waiting for the group members to accept the challenge...');
      }
    }
  }

  gotoChallengeFinalSubmission(): void {
    if (this.challenge.final_submitted !== 1) {
      const modelRef = this.modalService.open(ChallengeFinalSubmissionComponent, {
        centered: true,
        keyboard: false,
        backdrop: 'static',
        size: 'lg',
        windowClass: 'modal-cover'
      });
      modelRef.componentInstance.challenge = this.challenge;
      modelRef.result.then((res) => {
        if (res === 'close') {
          this.activeModal.close('close');
        }
      });
    }
  }

  handleSelection(event: any) {
    this.comment += event.char;
  }

  ngOnDestroy(): void {
    this.subscriptions.next();
    this.subscriptions.complete();
  }
}
