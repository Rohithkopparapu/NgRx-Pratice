import {Component, ElementRef, OnInit, ViewChild} from '@angular/core';
import {FormArray, FormBuilder, FormGroup, Validators} from '@angular/forms';
import {HelperService} from '../../../../shared/services/helper.service';
import {ToastrService} from 'ngx-toastr';
import {FileUploadComponent} from '../../../../shared/component/file-upload/file-upload.component';
import {NgbModal} from '@ng-bootstrap/ng-bootstrap';
import {ImageVideoViewComponent} from '../../../../shared/component/image-video-view/image-video-view.component';
import {ERROR_MESSAGE, SUCCESS_MESSAGE} from '../../../../shared/constants/constant';
import {ActivatedRoute, Router} from '@angular/router';
import * as moment from 'moment';
import {StudentHelperService} from '../../student-helper.service';
import { AdminHelperService } from 'src/app/modules/admin-dashboard/admin-helper.service';

@Component({
  selector: 'app-create-challenge',
  templateUrl: './create-challenge.component.html',
  styleUrls: ['./create-challenge.component.scss']
})
export class CreateChallengeComponent implements OnInit {
  isLoading = false;
  @ViewChild('searchTag', { static: false }) searchTag: ElementRef;
  defaultRoleImage = 'assets/img/role-img.png';
  roles: FormArray;
  challengeForm = this.fb.group({
    community_id: ['', [Validators.required]],
    level_id:[''],
    topic_name: ['', [Validators.required]],
    topic_description: ['', [Validators.required]],
    topic_short_description: ['', [Validators.required]],
    is_spotlight: [false],
    is_influencer_challenge: [false],
    influencer_name: [''],
    topic_group_size: ['', [Validators.required, Validators.min(1), Validators.max(4), Validators.pattern('^[0-9]*$')]],
    topic_level: ['', [Validators.required]],
    attachments: this.fb.array([]),
    topic_image: [''],
    topic_video: [''],
    topic_audio: [''],
    topic_document: [''],
    roles: this.fb.array([]),
    tags: this.fb.array([]),
    topic_status: ['Pending']
  });
  isEnable = false;
  tagsList: any[] = [];
  communitiesList: any;
  selectedType: string;
  isSaving: boolean;
  userCommunityPreference: any;
  videoList: any[] = [];
  audioList: any[] = [];
  imageList: any[] = [];
  docList: any[] = [];
  page: string;
  questData: any;
  levelsList: any = [];
  selectedCommunity: any;

  constructor(private fb: FormBuilder, public _uhs: HelperService, private toastrService: ToastrService,
              private modalService: NgbModal, private studentHelperService: StudentHelperService, private router: Router,
              private activatedRoute: ActivatedRoute,private adminHelperService: AdminHelperService) {
    const data = this.router.getCurrentNavigation().extras.state;
    if (data) {
      this.page = data.page;
      this.questData = data.questData;
      this.challengeForm.get('topic_name').setValue(data.challengeName);
    }
  }

  ngOnInit() {
    this.activatedRoute.data.subscribe((response) => {
      this.userCommunityPreference = response && response.userPreferenceDetails;
    });
    this.getCommunities();
  }

  getCommunities(): void {
    this.isLoading = true;
    this.studentHelperService.getAllCommunities().subscribe(res => {
      this.isLoading = false;
      if (res && res.length) {
        this.communitiesList = res.filter(s =>
          !s.combo && moment(moment(s.community_start_date).format('YYYY-MM-DD')).isSameOrBefore(moment().format('YYYY-MM-DD')) && s.num_challenges > 0);
        this.challengeForm.patchValue({
          community_id: Number(this.userCommunityPreference.value)
        });
        if(this.challengeForm.get('community_id').value !== ""){
          const payload = this.challengeForm.get('community_id').value;
          this.levelsList=[];
          this.adminHelperService.getQuestLevelsById(payload).subscribe(res => {          
                this.levelsList = res;
                this.challengeForm.patchValue({
                  level_id : this.levelsList[0]
                });
          });
        }
      }
    }, () => this.isLoading = false);
  }

  onChange(community:any){
    this.selectedCommunity = Number(community.target.value.slice(-2));
      if(this.selectedCommunity){
        // const payload = {community_id: this.selectedCommunity, user_id: this.userInfo.user_id  };
        const payload = this.selectedCommunity;
        this.levelsList=[];
        this.adminHelperService.getQuestLevelsById(payload).subscribe(res => {          
              this.levelsList = res;
              this.challengeForm.patchValue({
                level_id : this.levelsList[0]
              });
        });
      }
  }

  onChangeInfluencer(): void {
    this.challengeForm.get('is_influencer_challenge').value ?
      this.challengeForm.get('is_spotlight').setValue(true) :
      this.challengeForm.get('is_spotlight').setValue(false);
  }

  submitForm() {
    if (this.challengeForm.valid) {
      const challengeFormData = this.processPayload();
      this.isSaving = true;
      this.studentHelperService.saveChallengeData(challengeFormData).subscribe(result => {
        this.isSaving = false;
        if (result) {
          this.toastrService.success(SUCCESS_MESSAGE.RECORD_SENT);
          this.router.navigate(['/auth/student/challenge']);
        }
      }, err => this.isSaving = false);
    } else {
      this.toastrService.warning(ERROR_MESSAGE.FIELDS_REQUIRED);
      this._uhs.validateAllFormFields(this.challengeForm);
    }
  }

  uploadDocument(type: string, title: string, fileCategory: any) {
    this.selectedType = title;
    const modalData = {
      headerName: title,
      fileType: type,
      fileCategory,
      isMultipleFile: false
    };

    const modalRef = this.modalService.open(FileUploadComponent, {
      keyboard: false,
      backdrop: 'static',
      scrollable: true,
      windowClass: 'modal-cover modal-cover-fluid modal-upload'
    });
    modalRef.componentInstance.data = modalData;
    modalRef.result.then((res) => {
      console.log(res);
    }, (reason) => {
      if (reason) {
        console.log(reason);
        if (reason) {
          this.setFileName(reason, fileCategory);
          this.challengeForm.markAsTouched({ onlySelf: true });
        }
      }
    });
  }

  setFileName(res: any, title: string): void {
    if (res && res.length) {
      if (this.selectedType === 'Document') {
        this.addOrReplaceAttachment(this.docList, res, title);
      } else if (this.selectedType === 'Image') {
        this.addOrReplaceAttachment(this.imageList, res, title);
      } else if (this.selectedType === 'Audio') {
        this.addOrReplaceAttachment(this.audioList, res, title);
      } else if (this.selectedType === 'Video') {
        this.addOrReplaceAttachment(this.videoList, res, title);
      }
    }
  }

  addOrReplaceAttachment(attachmentList, res, title): void {
    while (attachmentList.length > 0) {
      attachmentList.pop();
    }
    attachmentList.push({attachment_title: title, file: res[0].file, name: res[0].display_name, url: res[0].fileUrl});
  }

  deleteFile(event: Event, item: any, type: string) {
    event.stopPropagation();
    this.challengeForm.markAsTouched({ onlySelf: true });
    if (type === 'challenge_document') {
      this.docList = this.docList.filter(doc => doc.file !== item.file);
    } else if (type === 'challenge_image') {
      this.imageList = this.imageList.filter(img => img.file !== item.file);
    } else if (type === 'challenge_audio') {
      this.audioList = this.audioList.filter(audio => audio.file !== item.file);
    } else if (type === 'challenge_video') {
      this.videoList = this.videoList.filter(video => video.file !== item.file);
    }
  }

  openViewerModel(type: string, url: string): void {
    const modalRef = this.modalService.open(ImageVideoViewComponent, {
      centered: true,
      size: 'lg'
    });
    modalRef.componentInstance.fileType = type;
    modalRef.componentInstance.fileUrl = url;
  }

  openAvatarModal(roleIndex) {
    const modalData = {
      headerName: 'Role Image',
      fileType: 'image',
      fileCategory: 'role',
      isMultipleFile: false
    };

    const modalRef = this.modalService.open(FileUploadComponent, {
      keyboard: false,
      backdrop: 'static',
      scrollable: true,
      windowClass: 'modal-cover modal-cover-fluid modal-upload'
    });
    modalRef.componentInstance.data = modalData;
    modalRef.result.then((res) => {
      console.log(res);
    }, (reason) => {
      if (reason && reason.length) {
        this.roles.at(roleIndex).patchValue({
          role_img: reason[0].file,
          role_img_url: reason[0].fileUrl
        });
      }
    });
  }

  addTag() {
    if ( this.tagsList.length < 5) {
      this.tagsList.push({ tag: this.searchTag.nativeElement.value });
      this.searchTag.nativeElement.value = '';
    } else {
      this.toastrService.warning('Please refine search tags upto 5');
    }
  }

  removeTag(tag) {
    this.tagsList = this.tagsList.filter(item => item['tag'] !== tag.tag);
  }

  createRole(roleImage: string = ''): FormGroup {
    return this.fb.group({
      role_name: ['', [Validators.required]],
      role_img: [roleImage],
      role_img_url: ['assets/img/' + roleImage],
      dummyTag: [''],
      tags: this.fb.array([]),
      role_id: ['']
    });
  }

  createSkillTag(value): FormGroup {
    return this.fb.group({
      tag: [value],
    });
  }

  addSkillTag(index: number) {
    const skillTags = this.challengeForm.get('roles')['controls'][index].get('tags') as FormArray;
    const roles = this.challengeForm.get('roles') as FormArray;
    const skillTag = roles.at(index).get('dummyTag').value;
    skillTag.split(/(?:, |,| #|#)+/).filter(s => s).forEach(tag => {
      skillTags.push(this.createSkillTag(tag));
    });
    roles.at(index).get('dummyTag').setValue('');
  }

  deleteSkillTag(mainIndex: number, subIndex: number) {
    const skillTags = this.challengeForm.get('roles')['controls'][mainIndex].get('tags') as FormArray;
    skillTags.removeAt(subIndex);
  }

  deleteRole(i: number): void {
    this.roles.removeAt(i);
  }

  addRole(roleImage: string = ''): void {
    this.roles = this.challengeForm.get('roles') as FormArray;
    this.roles.push(this.createRole(roleImage));
  }

  onChangeGroupSize(): void {
    this.roles = this.challengeForm.get('roles') as FormArray;
    const groupSize = this.challengeForm.get('topic_group_size').value;
    if (groupSize === '1') {
      this.isEnable = false;
      this.roles.clear();
    } else {
      this.isEnable = true;
      if (!this.roles || this.roles && Number(groupSize) >= this.roles.length) {
        for (let i = this.roles && this.roles.length || 0; i <= Number(groupSize) - 1; i++) {
          this.addRole('group-' + (i + 1) + '.png');
        }
      } else {
        for (let i = this.roles.length - 1; i >= Number(groupSize); i--) {
          this.roles.removeAt(i);
        }
      }
    }
  }

  processPayload() {
    this.challengeForm.value['level_id'] = this.challengeForm.get('level_id').value.id;
    const challengeForm = JSON.parse(JSON.stringify(this.challengeForm.value));
    challengeForm.topic_group_size = Number(challengeForm.topic_group_size);
    challengeForm.is_spotlight = challengeForm.is_spotlight ? 1 : 0;
    challengeForm.is_influencer_challenge = challengeForm.is_influencer_challenge ? 1 : 0;
    challengeForm.attachments = [...this.imageList, ...this.videoList, ...this.audioList, ...this.docList];
    challengeForm.tags = this.tagsList;
    challengeForm.roles = challengeForm.roles.map(({role_img, role_name, tags, role_id}) => ({role_img, role_name, tags, role_id}));
    return challengeForm;
  }

  onImgError(event) {
    event.target.src = this.defaultRoleImage;
  }

  navigateTo(): void {
    if (this.page === 'challenge') {
      this.router.navigate(['/auth/student/challenge']);
    } else if (this.page === 'quest') {
      this.router.navigate(['/auth/student/quest/details'], {state: {questData: this.questData}});
    }else{ 
      this.router.navigate(['/auth/student/home']);
    }
  }
}
