import {Component, ElementRef, OnDestroy, OnInit, TemplateRef, ViewChild} from '@angular/core';
import {StudentHelperService} from '../../student-helper.service';
import {NgbActiveModal, NgbModal, NgbModalRef} from '@ng-bootstrap/ng-bootstrap';
import {ToastrService} from 'ngx-toastr';
import {HelperService} from '../../../../shared/services/helper.service';
import {ChallengeWorkAreaComponent} from '../challenge-work-area/challenge-work-area.component';
import {InviteBuddyPopupComponent} from '../invite-buddy-popup/invite-buddy-popup.component';
import {EMAIL} from '../../../../shared/constants/validationConstants';
import {ERROR_MESSAGE} from '../../../../shared/constants/constant';
import {takeUntil} from 'rxjs/operators';
import {Store} from '@ngrx/store';
import {AuthState} from '../../../../shared/store/auth.model';
import { userInfo } from 'src/app/shared/store/auth.selector';
import {Subject} from 'rxjs';

@Component({
  selector: 'app-create-group',
  templateUrl: './create-group.component.html',
  styleUrls: ['./create-group.component.scss']
})
export class CreateGroupComponent implements OnInit, OnDestroy {

  private subscriptions = new Subject<void>();
  ngbModalRef: NgbModalRef;
  @ViewChild('email', {static: false}) emailId: ElementRef;
  @ViewChild('congratulationsModal', {static: false}) congrats: TemplateRef<any>;
  isLoading = false;
  isRolesLoading = false;
  userInfo: any;
  emailRegexPattern = EMAIL.REGEX_EMAIL;
  data: any;
  challenge: any;
  isPendingInvitesExist: boolean;
  rolesList: any[];
  groupMembers: any[] = [];
  groupOwner: any;
  formName: string;
  searchValue: any;
  inviteOption = 'inviteBuddies';
  createGroupForm = {
    group_name: '',
    roles: [],
    topic_id: '',
    assignments: []
  };
  defaultUserObject = {
    display_name: '',
    avatar_image_file: '',
    user_email: ''
  };
  isGroupAlreadyExist: boolean;
  checkGroupSize: any;
  isUpdate = false;

  constructor(private studentHelperService: StudentHelperService, private activeModal: NgbActiveModal, private toastrService: ToastrService,
              public _uhs: HelperService, private modalService: NgbModal,
              private store$: Store<AuthState>) {
    this.store$.select(userInfo)
      .pipe(takeUntil(this.subscriptions))
      .subscribe(res => this.userInfo = res);
  }

  ngOnInit() {
    this.formName = this.data.formName;
    this.challenge = this.data.challenge;
    this.groupMembers = this.data.groupMembers;
    this.isPendingInvitesExist = this.data.isPendingInvitesExist;
    this.getRolesForChallenge();
    if (this.formName === 'Update') {
      this.viewGroup();
    }
  }

  getRolesForChallenge(): void {
    this.isRolesLoading = true;
    const payload = {
      topic_id: this.challenge.topic_id,
      group_id: this.challenge.group_id
    };
    this.studentHelperService.roles(payload).subscribe(res => {
      this.isRolesLoading = false;
      if (res) {
        if (this.formName === 'Update') {
          this.rolesList = res;
          this.groupOwner = this.groupMembers.find(s => s.is_group_owner);
          this.createGroupForm.roles = this.rolesList.filter(s => s.group_role_id);
        } else {
          this.rolesList = res.flatMap(s => s ? {...s, avatar_image_file: null, display_name: null, group_id: null, group_role_id: null, role_assigned_to: null, user_id: null} : []);
        }
      }
    }, () => this.isRolesLoading = false);
  }

  backTo(): void {
  }

  onSelectRole(role): void {
    this.createGroupForm.roles = [];
    role['role_avatar'] = role.role_img;
    role.role_assigned_to = this.userInfo.user_email;
    this.createGroupForm.roles.push(role);
    // this.isUpdate = true;
  }

  addBuddie(email) {
    if (email.value === this.userInfo.user_email) {
      this.toastrService.warning('Please provide buddy name other than yourself');
      return false;
    }
    if (email.value && email.valid && this.createGroupForm.assignments.findIndex(s => s.user_email === email.value) === -1) {
      this.searchBuddyByEmail(email);
    }
  }

  deleteBuddie(index) {
    this.createGroupForm.assignments.splice(index, 1);
  }

  createGroup(payload): void {
    if (this.validateCreateGroup()) {
      this.isLoading = true;
      this.studentHelperService.saveGroup(payload).subscribe(res => {
        this.isLoading = false;
        if (res) {
          this.challenge.group_id = res.group_id;
          this.challenge.topic_assign_id = res.topic_assign_id;
          this.toastrService.success('Group created successfully');
          this.activeModal.close('Create');
          this.openCongratulationModal();
        }
      }, () => this.isLoading = false);
    }
  }

  updateGroup(payload): void {
    if (this.validateCreateGroup()) {
      this.isLoading = true;
      this.studentHelperService.updateGroup(payload).subscribe(res => {
        this.isLoading = false;
        if (res) {
          this.toastrService.success('Group updated successfully');
          this.activeModal.close(true);
        }
      }, () => this.isLoading = false);
    }
  }

  callGroupService(): void {
    const payload = this.processPayload(JSON.parse(JSON.stringify(this.createGroupForm)));
    if (this.challenge.group_id) {
      payload['group_id'] = this.challenge.group_id;
      this.updateGroup(payload);
    } else {
      this.createGroup(payload);
    }
  }

  onChangeInviteOption(action: string) {
    if (action === 'inviteBuddies') {
      this.inviteOption = action;
    } else if (action === 'autoAssign') {
      this.isLoading = true;
      this.inviteOption = action;
      const payload = {
        topic_id: this.challenge.topic_id,
        topic_group_size: this.challenge.topic_group_size
      };
      this.studentHelperService.autoAssignChallenge(payload).subscribe(res => {
        this.isLoading = false;
        if (res) {
          this.toastrService.success('Buddies have been auto assigned!');
          this.createGroupForm.assignments = res;
        }
      }, err => this.isLoading = false);
    }
  }

  checkGroupNameExists() {
    if (this.createGroupForm.group_name !== '') {
      const payload = {
        topic_id: this.challenge.topic_id,
        group_name: this.createGroupForm.group_name
      };
      this.studentHelperService.checkGroup(payload).subscribe(res => {
        this.isGroupAlreadyExist = !res.success;
      });
    }
  }

  searchBuddyByEmail(email): any {
    const payload =  {
      user_email: email.value,
      user_type: 'student'
    };
    this.studentHelperService.searchStudentByEmail(payload).subscribe(res => {
      if (res) {
        this.defaultUserObject['user_email'] = this.defaultUserObject['display_name'] = email.value;
        this.createGroupForm.assignments.push(res.status === 'success' ? res.data : JSON.parse(JSON.stringify(this.defaultUserObject)));
        email.reset('');
      }
    });
  }

  searchBy(school: string) {
    const data = {searchType: school, topic_id: this.challenge.topic_id, buddiesList: this.createGroupForm.assignments};
    const modelRef = this.modalService.open(InviteBuddyPopupComponent, {
      scrollable: true,
      centered: true,
      backdrop: 'static',
      size: 'xl',
      windowClass: 'modal-challenge'
    });
    modelRef.componentInstance.data = data;
    modelRef.result.then((res) => {
      if (res && res.length) {
        res.forEach(s => {
          if (this.createGroupForm.assignments.findIndex(i => i.user_id === s.user_id) === -1) {
            this.createGroupForm.assignments.push(s);
          }
        });
      }
    });
  }

  validateCreateGroup(): boolean {
    if (this.createGroupForm.group_name === '' || this.createGroupForm.roles.length === 0) {
      this.toastrService.warning(ERROR_MESSAGE.FIELDS_REQUIRED);
      return false;
    } else if (this.isGroupAlreadyExist) {
      this.toastrService.warning('Group Name is already exists');
      return false;
    } else if (this.challenge.topic_group_size !== this.checkGroupSize.length) {
      this.toastrService.warning('No. of buddies should be same as no of roles defined');
      return false;
    }
    return true;
  }

  processPayload(payload) {
    payload.topic_id = this.challenge.topic_id;
    payload.assignments = payload.assignments.map(({user_email}) => ({user_email}));
    if (payload.assignments.findIndex(s => s.user_email === this.userInfo.user_email) === -1) {
      payload.assignments.push({user_email: this.userInfo.user_email});
    }
    this.checkGroupSize = payload.assignments;
    return payload;
  }

  closeModal(): void {
    this.activeModal.close();
  }

  viewGroup(): void {
    console.log(this.groupMembers);
    this.createGroupForm.assignments = this.groupMembers;
    this.createGroupForm.group_name = this.groupMembers[0].group_name;
  }

  openCongratulationModal(): void {
    this.ngbModalRef = this.modalService.open(this.congrats, {
      centered: true,
      backdrop: 'static',
      windowClass: 'congratulationsModal'
    });
  }

  goHome(): void {
    this.ngbModalRef.close();
  }

  participateChallenge(): void {
    this.ngbModalRef.close();
    const modelRef = this.modalService.open(ChallengeWorkAreaComponent, {
      centered: true,
      backdrop: 'static',
      scrollable: true,
      size: 'xl',
      // windowClass: 'modalChallengeStoryTelling'
      windowClass: 'modal-challenge'
    });
    modelRef.componentInstance.challenge = this.challenge;
  }

  onImgError(event, index) {
    event.target.src = 'assets/img/group-' + (index + 1) + '.png';
  }

  ngOnDestroy(): void {
    this.subscriptions.next();
    this.subscriptions.complete();
  }
}
