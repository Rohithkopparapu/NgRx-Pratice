import {async, ComponentFixture, TestBed} from '@angular/core/testing';

import {InviteBuddyPopupComponent} from './invite-buddy-popup.component';

describe('InviteBuddyPopupComponent', () => {
  let component: InviteBuddyPopupComponent;
  let fixture: ComponentFixture<InviteBuddyPopupComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [InviteBuddyPopupComponent]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InviteBuddyPopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
