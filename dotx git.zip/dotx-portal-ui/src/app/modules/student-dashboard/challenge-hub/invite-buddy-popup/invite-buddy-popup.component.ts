import {AfterViewInit, Component, ElementRef, OnInit, ViewChild} from '@angular/core';
import {StudentHelperService} from '../../student-helper.service';
import {NgbActiveModal} from '@ng-bootstrap/ng-bootstrap';
import {ToastrService} from 'ngx-toastr';
import {SEARCH_TYPE} from '../../../../shared/constants/constant';
import {fromEvent} from 'rxjs';
import {debounceTime, distinctUntilChanged, map} from 'rxjs/operators';

@Component({
  selector: 'app-invite-buddy-popup',
  templateUrl: './invite-buddy-popup.component.html',
  styleUrls: ['./invite-buddy-popup.component.scss']
})
export class InviteBuddyPopupComponent implements OnInit, AfterViewInit {
  @ViewChild('searchValue', {static: false}) searchValue: ElementRef;
  data: any;
  isLoading = false;
  isCheck: string;
  searchResult: any[] = [];
  selectedUserStore: any[] = [];
  searchKey: string;
  buddiesList: any[];

  constructor(private studentHelperService: StudentHelperService, private activeModal: NgbActiveModal,
              private toastrService: ToastrService) {
  }

  ngOnInit() {
    this.buddiesList = this.data.buddiesList;
    this.searchBy(this.data.searchType);
  }

  saveInvites(): void {
    this.activeModal.close(this.selectedUserStore);
  }

  searchByCategory() {
    if (this.searchValue.nativeElement.value === '' || this.searchKey === undefined) {
      this.toastrService.warning('Please provide search criteria');
      return false;
    }
    this.isLoading = true;
    const payload = {topic_id: this.data.topic_id};
    payload[this.searchKey] = this.searchValue.nativeElement.value;
    this.studentHelperService.searchByValue(payload).subscribe(res => {
      this.isLoading = false;
      const response = res.map(s => s ? {...s, selected: false} : []);
      response.forEach(i => {
        if (this.buddiesList.findIndex(s => s.user_id === i.user_id) !== -1) {
          i['selected'] = true;
        }
      });
      this.searchResult = response;
    }, () => this.isLoading = false);
  }

  searchBy(type: string) {
    this.isCheck = type;
    this.searchKey = SEARCH_TYPE[this.isCheck];
  }

  onCheckUser(user) {
    user.selected = !user.selected;
    if (user.selected) {
      this.selectedUserStore.push(user);
    } else {
      this.selectedUserStore = this.selectedUserStore.filter(s => s.user_id !== user.user_id);
    }
  }

  ngAfterViewInit(): void {
    fromEvent(this.searchValue.nativeElement, 'keyup')
      .pipe(
        map((event: Event) => (event.target as HTMLInputElement).value),
        debounceTime(500),
        distinctUntilChanged()).subscribe(search => {
          if (search && search.trim()) {
            this.searchByCategory();
          }
    });
  }

  closeModal(): void {
    this.activeModal.close();
  }
}
