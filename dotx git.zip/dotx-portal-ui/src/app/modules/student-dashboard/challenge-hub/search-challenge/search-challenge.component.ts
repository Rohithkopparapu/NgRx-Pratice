import { Component, OnInit } from '@angular/core';
import {StudentHelperService} from '../../student-helper.service';
import {ActivatedRoute, Router} from '@angular/router';
import {NgbModal} from '@ng-bootstrap/ng-bootstrap';
import {SoloChallengeModelComponent} from '../../../../shared/component/solo-challenge-model/solo-challenge-model.component';
import {GroupChallengeModelComponent} from '../../../../shared/component/group-challenge-model/group-challenge-model.component';

@Component({
  selector: 'app-search-challenge',
  templateUrl: './search-challenge.component.html',
  styleUrls: ['./search-challenge.component.scss']
})
export class SearchChallengeComponent implements OnInit {

  searchResult: any[];
  searchKeyword = '';
  searchType = 'topic_name';
  searchTypeView = 'Topic';
  searchData: any;
  keyword: string;
  userCommunityPreference: any;

  constructor(private studentHelperService: StudentHelperService, private router: Router, private modalService: NgbModal,
              private activatedRoute: ActivatedRoute) {
    const data = this.router.getCurrentNavigation().extras.state;
    if (data) {
      this.searchData = data.searchData;
    }
  }

  ngOnInit() {
    this.activatedRoute.data.subscribe((response) => {
      this.userCommunityPreference = response && response.userPreferenceDetails;
    });
    if (this.searchData) {
      this.searchKeyword = this.searchData.keyword;
      this.onSearchFilter(this.searchData.search_type);
      this.doSearch();
    }
  }

  doSearch() {
    const data = {
      search_type: this.searchType,
      keyword: this.searchKeyword,
      community_id: Number(this.userCommunityPreference.value)
    };
    this.callSearchService(data);
  }

  callSearchService(payload) {
    this.keyword = payload.keyword;
    this.studentHelperService.searchChallenges(payload).subscribe(res => {
        this.searchResult = res;
      }
    );
  }

  clearFilters() {
    this.searchKeyword = '';
  }

  gotoChallenge(challenge: any) {
    const data = {
      challenge
    };
    const component = challenge.topic_group_size === 1 ? SoloChallengeModelComponent : GroupChallengeModelComponent;
    const modelRef = this.modalService.open(component, {
      centered: true,
      scrollable: true,
      backdrop: 'static',
      keyboard: false,
      size: 'xl',
      windowClass: 'modal-challenge'
    });
    modelRef.componentInstance.data = data;
  }

  onSearchFilter(value) {
    this.searchTypeView = value;
    this.searchType = this.searchTypeView === 'Topic' ? 'topic_name' :
      this.searchTypeView === 'Group' ? 'group' : this.searchTypeView === 'Buddy Name' ?
        'buddy_name' : '';
  }
}
