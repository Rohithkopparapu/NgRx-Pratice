import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DotstorepopupComponent } from './dotstorepopup.component';

describe('DotstorepopupComponent', () => {
  let component: DotstorepopupComponent;
  let fixture: ComponentFixture<DotstorepopupComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DotstorepopupComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DotstorepopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
