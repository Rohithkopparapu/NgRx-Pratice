import { Component, Input, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { NgbActiveModal, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { Router } from '@angular/router'
import { Location } from '@angular/common'
import { AuthState, Portfolio } from 'src/app/shared/store/auth.model';
import { Store } from '@ngrx/store';
import { myPortfolio, userInfo } from 'src/app/shared/store/auth.selector';
import { takeUntil } from 'rxjs/operators';
import { Subject } from 'rxjs';
import { PREFERENCES } from '../../../../../shared/constants/constant';
import { StudentHelperService } from '../../../student-helper.service';
import { ToastrService } from 'ngx-toastr';
import { DeleteComponent } from 'src/app/shared/component/delete/delete.component';
@Component({
  selector: 'app-dotstorepopup',
  templateUrl: './dotstorepopup.component.html',
  styleUrls: ['./dotstorepopup.component.scss']
})
export class DotstorepopupComponent implements OnInit {
  // @Input() communitydata;
  private subscriptions = new Subject<void>();
  communitiesList: any;
  leveldetails: any;
  headerName: string = "Avatar";
  levelInfo: boolean = false;
  edit: boolean = false;
  dotStoreCat: any;
  storeData: any;
  userInfo: any;
  userCommunityPreference: any;
  myPortfolio: Portfolio;
  dotCoins: number;
  redeemedItems: any;
  redeemflag: boolean = false;
  redeemId: any = undefined;
  isLoading: boolean;
  errorMessage: boolean;
  selectedId: any;
  categoryCard: any;
  redCond: any;
  isfree: any=false;
  selectedDotstoreView: string = "Catetories";
  activatedFlag: string;
  // modalService: any;
  // router: any;
  //  @Input() data: any;
  constructor(private router: Router,
    private location: Location,
    private store$: Store<AuthState>,
    private studentHelperService: StudentHelperService,
    private toastrService: ToastrService,
    private modalService: NgbModal,
  ) {
      this.dotStoreCat = this.router.getCurrentNavigation().extras.state;
      if(this.dotStoreCat === undefined){
        this.router.navigate(['/auth/student/dot-store']);
      }
      
      this.store$.select(userInfo)
      .pipe(takeUntil(this.subscriptions))
      .subscribe(res => {
        if (res) {
          this.userInfo = res;
          this.userCommunityPreference = res.preferences ? res.preferences.find(s => s.entity_name === PREFERENCES.COMMUNITY.ENTITY_NAME && s.entity_type === PREFERENCES.COMMUNITY.ENTITY_TYPE) : null;
          
        }
      });
      this.store$.select(myPortfolio)
      .pipe(takeUntil(this.subscriptions))
      .subscribe(res => {
        this.myPortfolio = res;
        this.displayBadgesAndDotCoins();
      });
  }
   // getting dotcoins available to users
  displayBadgesAndDotCoins(): void {
    this.dotCoins = this.myPortfolio.achievements && this.myPortfolio.achievements.total_dot_coins ? Number(this.myPortfolio.achievements.total_dot_coins) : 0;
    
  }

  ngOnInit() {
    if(this.dotStoreCat !== undefined){
    this.storeData = this.dotStoreCat.data;
    this.selectedId = this.storeData.selectedId,
      
    this.headerName = this.storeData.headerName;
    this.redeemedItems =this.storeData.redeemedItems
    }
    this.redCond=this.redeemedItems.items
    this.redCond.forEach(element => { if(element.unit_rate >0){ this.isfree=true}})
    this.getItemsListBasedonCatgories();
  }
  getItemsListBasedonCatgories(){
    this.isLoading = true;
    const payload ={"category_id ": this.selectedId, "redeemed" : false}
    let isCount=0
    this.studentHelperService.getItemsListBasedonCatgories(payload).subscribe(res => {
      this.isLoading = false;
      if (res) {
        this.categoryCard = res.items;
        this.categoryCard.forEach(x =>{isCount= isCount + x.itemitems_count_c})

      }
      else {
      };
    }, () => {
      this.isLoading = false;
      this.errorMessage = true;
    });;
  }
 // redeems the selected items
  redeemCoin(itemId) {
    const payload = {
      "user_id": this.userInfo.user_id,
      "item_id": itemId
    }
    
    this.studentHelperService.getDotStoreRedeem(payload).subscribe(res => {
      if (res.success) {
        this.studentHelperService.getAchievements(this.userInfo.user_id).subscribe(result => {
          this.dotCoins = result[0].total_dot_coins;
          
          
      })
      this.toastrService.success(this.headerName+" successfully redeemed");
        this.refreshData()
        this.redeemflag = true;
        this.redeemId=res.item_id
      }
      else {
        this.toastrService.warning("You don't have sufficient Dotcoins");
        this.refreshData();
      };
    });
  }
   // refreshing dots-coins after redeem
  refreshData(): void {
    this.studentHelperService.getBadgesAndDotCoins(this.userInfo.user_id);
    this.studentHelperService.getDotStoreCategory(false)
    const payload = {"redeemed" : true}
    this.studentHelperService.getItemsListBasedonCatgories(payload).subscribe(res => {
      this.isLoading = false;
      if (res) {
          this.redeemedItems = res
        }else{
          this.redeemedItems = res
        }
    })
    
    
    this.getItemsListBasedonCatgories()
  }

  // checkdisabled(abc){
  //   if(this.redeemflag === true){
  //     if(abc = this.redeemId){
  //       return true
  //     }else{
  //       return false
  //     }
  //   }else{
  //     return false
  //   }
  // }


  onChangeDotstore(value): void {
    this.selectedDotstoreView = value;
    if (this.selectedDotstoreView === 'Categories') {
      this.activatedFlag = "AvatarActivated";
    }
    if(this.selectedDotstoreView === 'Items'){
      this.activatedFlag = "FlashCardActivated";
    }
}

  onRedeem(itemId: any) {
    const deleteModelRef = this.modalService.open(DeleteComponent, { centered: true, backdrop: 'static' });
    deleteModelRef.componentInstance.message = 'Are you sure you want to redeem ?';
    deleteModelRef.result.then((res) => {
      if (res) {
        // this.deleteRecord(userID);
        this.redeemCoin(itemId) 
        
      }
    }, (reason) => {
      if (reason) {
        // this.deleteRecord(userID); 
        
      }
    });
  }
  back(): void {
    this.router.navigate(['/auth/student/dot-store']);
  }
}
