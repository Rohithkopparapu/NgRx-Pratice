import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DotcoinStoreComponent } from './dotcoin-store.component';

describe('DotcoinStoreComponent', () => {
  let component: DotcoinStoreComponent;
  let fixture: ComponentFixture<DotcoinStoreComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DotcoinStoreComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DotcoinStoreComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
