import { AfterViewInit, Component, Input, OnInit } from '@angular/core';
import { SafeResourceUrl } from '@angular/platform-browser';
import { NgbActiveModal, NgbModalOptions } from '@ng-bootstrap/ng-bootstrap';
import Swiper, { Navigation, Pagination } from 'swiper';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { StudentHelperService } from '../student-helper.service';
import { AuthState, Portfolio } from '../../../shared/store/auth.model';
import { Store } from '@ngrx/store';
import { myPortfolio, userInfo } from '../../../shared/store/auth.selector';
import { takeUntil } from 'rxjs/operators';
import { Subject } from 'rxjs';
import { ToastrService } from 'ngx-toastr';
// import { DotstorepopupComponent } from './dot-store/dotstorepopup/dotstorepopup.component';
import { FormArray, FormGroup } from '@angular/forms';
import { NavigationStart, Router } from '@angular/router'
import { DeleteComponent } from 'src/app/shared/component/delete/delete.component';

@Component({
  selector: 'app-dotcoin-store',
  templateUrl: './dotcoin-store.component.html',
  styleUrls: ['./dotcoin-store.component.scss']
})
export class DotcoinStoreComponent implements OnInit {
  private subscriptions = new Subject<void>();
  userInfo: any;
  cardCategory: any
  levelsform: FormGroup;
  formcommunitydata: FormGroup;
  ngbModalOptions: NgbModalOptions = {
    centered: true,
    scrollable: true,
    backdrop: 'static',
    keyboard: false,
    size: 'lg',
    windowClass: 'modal-challenge'
  }
  isLoading: boolean = false;
  fb: any;
  errorMessage = false;
  dotCoins: number;
  myPortfolio: Portfolio;
  categoryCard: any;
  redeemedItems: any;
  isfree: any=false;
  redCond: any;
  selectedDotstoreView: string = "Catetories";
  // activatedFlag: boolean = true;
  activatedTab: string = 'AVATARS'
  categoriesWithItemCount: any;
  data: { headerName: any; levelInfo: string; catType: any; selectedId: any; redeemedItems: any; };
  selectedId: any;
  tabs: any;
  redeemflag: boolean = false;
  redeemId: any = undefined;
  currentTab: any;
  // showRedeemedFlag: boolean = false;

  constructor(private store$: Store<AuthState>,
    private modalService: NgbModal,
    private studentHelperService: StudentHelperService,
    private toastrService: ToastrService,
    private router: Router) {
    this.store$.select(userInfo)
      .pipe(takeUntil(this.subscriptions))
      .subscribe(res => {
        if (res) {
          this.userInfo = res;
          
        }
      });
    this.store$.select(myPortfolio)
      .pipe(takeUntil(this.subscriptions))
      .subscribe(res => {
        this.myPortfolio = res;
        this.displayBadgesAndDotCoins();
      });
  }
  // getting dotcoins available to users
  displayBadgesAndDotCoins(): void {
    this.dotCoins = this.myPortfolio.achievements && this.myPortfolio.achievements.total_dot_coins ? Number(this.myPortfolio.achievements.total_dot_coins) : 0;

  }
  ngOnInit() {
    // this.getDotStoreItems()
    this.refreshData();
    this.getDotStoreCatDetails();
    this.getRedeemsItems();
    this.router.events.subscribe((event) => {
      if (event instanceof NavigationStart) {
        if (event.navigationTrigger === 'popstate') {
          this.modalService.dismissAll();
        }
      }
    });
  }
  // category card
  getDotStoreCatDetails() {
    this.isLoading = true;
    const payload = {}
    let isCount=0
    this.studentHelperService.getDotStoreCatDetails(payload).subscribe(res => {
      this.isLoading = false;
      if (res) {
        this.tabs = res;
        this.categoryCard = res
        
        this.categoryCard.forEach(x =>{isCount= isCount + x.itemitems_count_c});
        this.categoriesWithItemCount = this.categoryCard.filter(element => element.items_count !== 0);
        this.selectedId = this.categoriesWithItemCount[0].category_id;
        if(this.categoriesWithItemCount.length !== 0){
        this.viewCardDetail(this.categoriesWithItemCount[0].category_name,this.categoriesWithItemCount[0].category_type,this.categoriesWithItemCount[0].category_id)
        }
      }
      else {
      };
    }, () => {
      this.isLoading = false;
      this.errorMessage = true;
    });
    
  }

  getItemsListBasedonCatgories(){
    this.isLoading = true;
    const payload ={"category_id ": this.selectedId, "redeemed" : false}
    let isCount=0
    this.studentHelperService.getItemsListBasedonCatgories(payload).subscribe(res => {
      this.isLoading = false;
      if (res) {
        console.log('qewe');
        this.categoryCard = res.items;
        this.categoryCard.forEach(x =>{isCount= isCount + x.itemitems_count_c})

      }
      else {
      };
    }, () => {
      this.isLoading = false;
      this.errorMessage = true;
    });;
  }

  redeemCoin(itemId) {
    const payload = {
      "user_id": this.userInfo.user_id,
      "item_id": itemId
    }
    
    this.studentHelperService.getDotStoreRedeem(payload).subscribe(res => {
      if (res.success) {
        this.studentHelperService.getAchievements(this.userInfo.user_id).subscribe(result => {
          this.dotCoins = result[0].total_dot_coins;
          
          
      })
      this.toastrService.success(this.categoriesWithItemCount[0].category_name+" successfully redeemed");
        this.refreshData()
        this.redeemflag = true;
        this.redeemId=res.item_id
      }
      else {
        this.toastrService.warning("You don't have sufficient Dotcoins");
        this.refreshData();
      };
    });
  }

  onRedeem(itemId: any) {
    const deleteModelRef = this.modalService.open(DeleteComponent, { centered: true, backdrop: 'static' });
    deleteModelRef.componentInstance.message = 'Are you sure you want to redeem ?';
    deleteModelRef.result.then((res) => {
      if (res) {
        // this.deleteRecord(userID);
        this.redeemCoin(itemId) 
        
      }
    }, (reason) => {
      if (reason) {
        // this.deleteRecord(userID); 
        
      }
    });
  }

  toggleTabs(tab:any){
    this.currentTab = tab.category_name
    if(tab.category_name === "AVATARS"){
    this.activatedTab = 'AVATARS'
    this.selectedId = tab.category_id;
    this.getItemsListBasedonCatgories();
    }else if(tab.category_name === "FLASH CARDS"){
      this.selectedId = tab.category_id;
      this.getItemsListBasedonCatgories();
      this.activatedTab = 'FLASH CARDS' 
    }else if(tab.category_name === 'GIFS'){
      this.selectedId = tab.category_id;
      this.getItemsListBasedonCatgories();
      this.activatedTab = 'GIFS' 
    }else if(tab.category_name === 'STICKERS'){
      this.selectedId = tab.category_id;
      this.getItemsListBasedonCatgories();
      this.activatedTab = 'STICKERS' 
    }
    // this.getDotStoreCatDetails();
  }

  // toggleRedeemedPopUp(){
  //   this.showRedeemedFlag = true;
  // }

  getRedeemsItems() {
    this.isLoading = true;
    const payload = {"redeemed" : true}
    this.studentHelperService.getItemsListBasedonCatgories(payload).subscribe(res => {
      this.isLoading = false;
      if (res) {
        
          this.redeemedItems = res
          this.redCond=this.redeemedItems.items
          this.redCond.forEach(element => { if(element.unit_rate >0){ this.isfree=true}})
          
        }else{
          this.redeemedItems = res
          this.redCond=this.redeemedItems.items
          this.redCond.forEach(element => {if(element.unit_rate >0){ this.isfree=true}})
          
        }
      
    }, () => {
      this.isLoading = false;
      this.errorMessage = true;
    });;
  }

//   onChangeDotstore(value): void {
//     this.selectedDotstoreView = value;
//     if (this.selectedDotstoreView === 'Categories') {
//       this.activatedFlag = "AvatarActivated";
//     }
//     if(this.selectedDotstoreView === 'Items'){
//       this.activatedFlag = "FlashCardActivated";
//     }
// }

  // refreshing dots-coins after redeem
  refreshData(): void {
    this.studentHelperService.getBadgesAndDotCoins(this.userInfo.user_id);
  }
  // getting details about selected categories of cards
  viewCardDetail(itemsname, cat,category_id) {
    let itmList: any
    
    this.data = {
      headerName: itemsname,
      levelInfo: 'Update',
      catType: cat,
      selectedId: category_id,
      redeemedItems:this.redeemedItems
    }

    this.getItemsListBasedonCatgories();
    // if (itemsname) {
    //   this.router.navigate(['/auth/student/dot-store-reddem'], {
    //     state: {
    //       data: this.data
    //     }
    //   });
    // } else {
    //   this.toastrService.warning("There is no " + itemsname + " available to redeem will add soon.");
    // }
    
  }

}
