import { Component, Input, OnInit } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-dotstore-pop',
  templateUrl: './dotstore-pop.component.html',
  styleUrls: ['./dotstore-pop.component.scss']
})
export class DotstorePopComponent implements OnInit {
  @Input() dotStoreInfo;
  constructor(private ngbActiveModal:NgbActiveModal,) { }

  ngOnInit() {
    console.log(this.dotStoreInfo);
    
  }
  closeModal(){
    this.ngbActiveModal.close();
  }
  

}
