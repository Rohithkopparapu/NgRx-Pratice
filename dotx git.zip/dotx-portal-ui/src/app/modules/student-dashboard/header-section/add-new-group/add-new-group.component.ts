import { AfterViewInit, Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { NgbActiveModal, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { Store } from '@ngrx/store';
import { ToastrService } from 'ngx-toastr';
import { fromEvent, Subject } from 'rxjs';
import { debounceTime, distinctUntilChanged, map, takeUntil } from 'rxjs/operators';
import { ERROR_MESSAGE, SEARCH_TYPE } from 'src/app/shared/constants/constant';
import { HelperService } from 'src/app/shared/services/helper.service';
import { AuthState } from 'src/app/shared/store/auth.model';
import { myPortfolio, userInfo } from 'src/app/shared/store/auth.selector';
import { StudentHelperService } from '../../student-helper.service';
import { NavigationStart, Router } from '@angular/router';

@Component({
  selector: 'app-add-new-group',
  templateUrl: './add-new-group.component.html',
  styleUrls: ['./add-new-group.component.scss']
})
export class AddNewGroupComponent implements OnInit, AfterViewInit {
  private subscriptions = new Subject<void>();
  @ViewChild('searchValue', { static: false }) searchValue: ElementRef;
  data: any;

  createGroupForm = this.fb.group({
    group_name: ['', [Validators.required]],
    description: [''],
    is_active: [true],

  });
  isAll:boolean=false
  userDetails: any;
  isLoading: boolean;
  buddiesList: any[];
  searchResult: any;
  searchKey: string;
  isCheck: string;
  selectedUserStore: any[] = [];
  editmode: boolean = false;
  addmenber: any[]=[];
  idupdate: boolean=true;
  constructor(public _uhs: HelperService, public activeModal: NgbActiveModal, private router: Router, private modalService: NgbModal,
    private fb: FormBuilder, private store$: Store<AuthState>,
    private toasterService: ToastrService, private studentHelperService: StudentHelperService) {
    this.store$.select(userInfo)
      .pipe(takeUntil(this.subscriptions))
      .subscribe(res => {
        this.userDetails = res;
      });
  }

  ngOnInit() {
    // this.searchKey="Name"
    // this.isCheck="Name"
    this.buddiesList ? this.buddiesList = this.data.buddiesList.map(s => s ? { ...s, selected: true } : []) : [];
    if (this.data.mode) { this.editmode = true; this.updateForm() } else { this.editmode = false }
    this.searchBy("Name");
    this.router.events.subscribe((event) => {
      if (event instanceof NavigationStart) {
        if (event.navigationTrigger === 'popstate') {
          this.modalService.dismissAll();
        }
      }
    });
  }
  updateForm(): void {
    this.createGroupForm.patchValue({
      group_name: this.data.group_name,
      description: this.data.group_description.length? this.data.group_description:'',
    });
  }
  ngAfterViewInit(): void {
    fromEvent(this.searchValue.nativeElement, 'keyup')
      .pipe(
        map((event: Event) => (event.target as HTMLInputElement).value),
        debounceTime(500),
        distinctUntilChanged()).subscribe(search => {
          if (search && search.trim()) {
            this.searchByCategory();
          }
        });
  }
  searchBy(type: string) {
    console.log(type)
    this.isCheck = type;
    this.searchKey = SEARCH_TYPE[this.isCheck];
  }
  searchByCategory() {
    if (this.searchValue.nativeElement.value === '' || this.searchKey === undefined) {
      this.toasterService.warning('Please provide search criteria');
      return false;
    }
    this.isLoading = true;
    const payload = {};
    payload[this.searchKey] = this.searchValue.nativeElement.value;
    this.studentHelperService.getMyBuddiesBasedSchool(payload).subscribe(res => {
      this.isLoading = false;
      const response = res.map(s => s ? { ...s, selected: false } : []);
      response.forEach(i => {
        if (this.buddiesList && (this.buddiesList.findIndex(s => s.user_id === i.user_id) !== -1)) {
          i['selected'] = true;
        }
      });
      this.searchResult = response;
    }, () => this.isLoading = false);
  }
  checkAllUser(){
    if(this.isAll){
      this.isAll=false
      this.searchResult.forEach(i=> i['selected'] = false)
      this.addmenber=[]
      this.selectedUserStore=[]
    }else{
      this.isAll=true
      let adduser = []
      this.searchResult.forEach(i=> i['selected'] = true)
      this.searchResult.forEach(i => adduser.push(i.user_id))
      this.selectedUserStore=this.searchResult
      this.addmenber = adduser
    }
    
  }
  onCheckUser(user) {
    
    user.selected = !user.selected;
    if (user.selected) {
      this.selectedUserStore.push(user);
    } else {
      this.selectedUserStore = this.selectedUserStore.filter(s => s.user_id !== user.user_id);
    }
    this.selectedUserStore.forEach(i => {
      if (this.buddiesList && (this.buddiesList.findIndex(s => s.user_id === i.user_id) !== -1)) {
        this.buddiesList.push(i);
      }
    });
    let adduser = []
    this.selectedUserStore.forEach(i => adduser.push(i.user_id))
    this.addmenber = adduser
    if(this.selectedUserStore.length==this.searchResult.length){
      this.isAll=true
    }else{
      this.isAll=false
    }
  }
  saveInvites(): void {
    if(!this.addmenber.length || !this.data.groupId){
        this.toasterService.warning('Please select member');
        return;
    }
    const payload = {
      "dot_user_group_id": this.data.groupId,
      "member_id": this.addmenber
    }
   
    this.studentHelperService.addGroupMembers(payload).subscribe(res => {
      if (res.msg == 'success') {
        this.selectedUserStore=[]
        this.addmenber=[]
        this.toasterService.success('Successfully added members');
        
      } else {
        this.toasterService.warning('Something went wrong!');
        return false;
      }

    }, () => this.isLoading = false);
  }
  submitUpdateGroupForm(){
    // if (!this.createGroupForm.valid) {
    //   this.toasterService.warning('Please fill all required fields');
    //   return false;
    // }
    
    const { group_name, description, is_active } = this.createGroupForm.value;
    const payload = {
      group_name,
      description,
      is_active:1,
      user_id: this.userDetails.user_id,
      id:this.data.groupId
    };
    if (this.createGroupForm.valid) {
      // this.isLoading = true;
        this.studentHelperService.updateGroupBy(payload).subscribe(result => {
          if (result) {
            this.idupdate=true
            // this.isLoading = true;
            this.toasterService.success("Group updated successfully...");
            return false;
          }
        }, err => this.isLoading = false);
    } else {
      this.toasterService.warning(ERROR_MESSAGE.FIELDS_REQUIRED);
      return false;
    }
  }
  onchangetext(){
    this.idupdate=false
  }
  submitcreateGroupForm(groupId = '') {
    console.log("jhdgfh")
    if (!this.createGroupForm.valid) {
      this.toasterService.warning('Please fill all required fields');
      return false;
    }
    if(this.addmenber.length==0){
      this.toasterService.warning('Please select atleast one member');
      return false;
    }
    const { group_name, description, is_active } = this.createGroupForm.value;
    const payload = {
      group_name,
      description,
      is_active:1,
      user_id: this.userDetails.user_id,
      member_ids:this.addmenber
    };
    if (this.createGroupForm.valid) {
      this.isLoading = true;
        this.studentHelperService.createGroupBy(payload).subscribe(result => {
          if (result) {
            this.showSuccessMessage('SAVE', result);
          }
        }, err => this.isLoading = false);
    } else {
      this.toasterService.warning(ERROR_MESSAGE.FIELDS_REQUIRED);
      return false;
    }
  }
  showSuccessMessage(type: string, result): void {
    if (type === 'UPDATE') {
      this.toasterService.success("Group updated successfully...");
    } else {
      this.toasterService.success("Group created successfully...");
    }
    this.closeModal()
    // this.activeModal.dismiss('center_panel');
  }

  closeModal(): void {
    this.activeModal.close('center_panel');
    
  }
}
