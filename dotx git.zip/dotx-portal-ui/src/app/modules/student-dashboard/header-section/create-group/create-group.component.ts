import {AfterViewInit, Component, ElementRef, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { NgbActiveModal,NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { Store } from '@ngrx/store';
import { ToastrService } from 'ngx-toastr';
import { fromEvent, Subject } from 'rxjs';
import { debounceTime, distinctUntilChanged, map, takeUntil } from 'rxjs/operators';
import { DeleteComponent } from 'src/app/shared/component/delete/delete.component';
import { ERROR_MESSAGE, SEARCH_TYPE } from 'src/app/shared/constants/constant';
import { HelperService } from 'src/app/shared/services/helper.service';
import { AuthState } from 'src/app/shared/store/auth.model';
import { userInfo } from 'src/app/shared/store/auth.selector';
import { StudentHelperService } from '../../student-helper.service';
import { AddNewGroupComponent } from '../add-new-group/add-new-group.component';
import { NavigationStart, Router } from '@angular/router';

@Component({
  selector: 'app-create-group',
  templateUrl: './create-group.component.html',
  styleUrls: ['./create-group.component.scss']
})
export class CreateGroupComponent implements OnInit {
  private subscriptions = new Subject<void>();
  @ViewChild('searchValue', {static: false}) searchValue: ElementRef;
  data: any;
  isLoading = false;
  isCheck: boolean=true;
  searchResult: any[] = [];
  selectedUserStore: any[] = [];
  searchKey: string;
  buddiesList: any[];
  addg: boolean=false;
  createGroupForm = this.fb.group({
    // object_type: [''],
    // object_id: [null],
    group_name: ['', [Validators.required]],
    description: ['', [Validators.required]],
    // is_active: [true],
    
  });
  userDetails: any;
  groupListData: any;
  searchGrpResult: any[] = [];
  searchChallenge = '';
  selectedUser: any;
  groupId: any='';
  gName: any;
  gDescription: any;
  cate: boolean;
  isAll:boolean=false;
  addmenber: any[]=[];
  constructor(private studentHelperService: StudentHelperService,  private router: Router,
    private activeModal: NgbActiveModal,
    private toastrService: ToastrService,private modalService: NgbModal,public _uhs: HelperService,
    private fb: FormBuilder, private store$: Store<AuthState>,
    ) { 
      this.store$.select(userInfo)
      .pipe(takeUntil(this.subscriptions))
      .subscribe(res => {
        this.userDetails = res;
      });
    }
 

  ngOnInit() {
    this.groupDetailList();
    this.router.events.subscribe((event) => {
      if (event instanceof NavigationStart) {
        if (event.navigationTrigger === 'popstate') {
          this.modalService.dismissAll();
        }
      }
    });
  }
  groupDetailList(){
    const payload={
      id: this.userDetails.user_id
      // id: 1416
    }
    
    this.cate=true
    this.studentHelperService.getGroupDetails(payload).subscribe(res => {
      
      this.cate=false
      this.groupListData = res.sort((a,b) => a.group_name.localeCompare(b.group_name));
      // console.log("gg",res);
      // this.groupListData = orderBy(this.groupListData, ['group_name'], ['asc']);
    });
  }
  setSearchValue($event: any): void {
    this.searchChallenge = $event;
  }
  // ngAfterViewInit(): void {
  //   fromEvent(this.searchValue.nativeElement, 'keyup')
  //     .pipe(
  //       map((event: Event) => (event.target as HTMLInputElement).value),
  //       debounceTime(500),
  //       distinctUntilChanged()).subscribe(search => {
  //         if (search && search.trim()) {
  //           this.searchByCategory();
  //         }
  //   });
  // }
  searchByCategory() {
    this.cate=true
    const payload = {
      groupname:this.searchValue.nativeElement.value
    };
     
    this.studentHelperService.getGroupDetails(payload).subscribe(res => {
      
      this.cate=false
      this.groupListData = res;
      console.log("dads",this.groupListData)
    }, () => this.isLoading = false);
  }
  checkAllUser(){
    if(this.isAll){
      this.isAll=false
      this.searchGrpResult.forEach(i=> i['selected'] = false)
      this.addmenber=[]
      this.selectedUserStore=[]
    }else{
      this.isAll=true
      let adduser = []
      this.searchGrpResult.forEach(i=> i['selected'] = true)
      this.searchGrpResult.forEach(i => adduser.push(i.user_id))
      this.selectedUserStore=this.searchGrpResult
      this.addmenber = adduser
      // selectedUserStore
    }
    
  }
  onCheckUser(user) {
    this.selectedUser=[]
    user.selected = !user.selected;
    if (user.selected) {
      this.selectedUserStore.push(user);
    } else {
      this.selectedUserStore = this.selectedUserStore.filter(s => s.user_id !== user.user_id);
    }
    this.selectedUserStore.forEach(i=>{ this.selectedUser.push(i.user_id)})
    this.buddiesList = this.selectedUserStore
    if(this.selectedUserStore.length==this.searchGrpResult.length){
      this.isAll=true
    }else{
      this.isAll=false
    }
  }
  addMemberToGroup(value){
    if (!value) {
      this.toastrService.warning('Please select group.');
      return false;
    }
    const data = {
      groupId: value,
      topic_id: '',
      buddiesList: this.searchGrpResult,
      group_name: this.gName,
      group_description: this.gDescription?this.gDescription:'',
      mode:"addmember",
      searchType: "Name"
     };
    const modelRef = this.modalService.open(AddNewGroupComponent, {
      scrollable: true,
      centered: true,
      backdrop: 'static',
      size: 'xl',
      windowClass: 'modal-challenge'
    });
    modelRef.componentInstance.data = data;
    modelRef.componentInstance.fromPage = 'center_panel';
    
    modelRef.componentInstance.isResponseSelect = true;
    modelRef.result.then((res) => {
      if (res==='center_panel') {
        this.searchGrpResult=[]
        this.groupId=''
        this.selectedUserStore=[]
        this.groupDetailList()

      }
    });
  }
  deleteGroupMember(id){
    if (!this.selectedUser) {
      this.toastrService.warning('Please select members.');
      return false;
    }
    const payload = {
      "dot_user_group_id": id,
      "member_id": this.selectedUser
    }
    const deleteModelRef = this.modalService.open(DeleteComponent, { centered: true, backdrop: 'static' });
    deleteModelRef.componentInstance.message = 'Are you sure want to remove from group ?';
    deleteModelRef.result.then((res) => {
      if (res) {
        this.studentHelperService.deleteGroupMembers(payload).subscribe(result => {
          this.isLoading = false;
          if (result.success) {
            this.toastrService.success("Member/s deleted successfully");
            this.selectedUser=[]
            this.groupId=''
            this.searchBy(id)
            
          }
        }, () => this.isLoading = false);
      }
    }, (reason) => {
      if (reason) {
      }
    });
  }
  deleteGroupBy(id){
    if (!id) {
      this.toastrService.warning('Please select group.');
      return false;
    }
    const payload = {
      id: id
    }
    const deleteModelRef = this.modalService.open(DeleteComponent, { centered: true, backdrop: 'static' });
    deleteModelRef.componentInstance.message = 'Are you sure want to delete group ?';
    deleteModelRef.result.then((res) => {
      if (res) {
        this.studentHelperService.deleteGroupBy(payload).subscribe(result => {
          this.isLoading = false;
          if (result.success) {
            this.toastrService.success("Group deleted successfully");
            this.searchGrpResult=[]
            this.groupId=''
            this.groupDetailList()

          }
        }, () => this.isLoading = false);
      }
    }, (reason) => {
      if (reason) {
      }
    });
  }
  closeModal(): void {
    this.activeModal.close();
  }
 
  submitcreateGroupForm(groupId=''){
    const {group_name, description, is_active} = this.createGroupForm.value;
    const payload = {
      group_name,
      description,
      // is_active,
      user_id: this.userDetails.user_id,
    };
    
    if (this.createGroupForm.valid) {
      this.isLoading = true;
    //   console.log("admin",payload);
    // return
      if (groupId) {
        // update records
        this.studentHelperService.updateGroupBy(payload).subscribe(result => {
          if (result) {
            this.showSuccessMessage('UPDATE', result);
          }
        }, err => this.isLoading = false);

      } else {
        // save records
        this.studentHelperService.createGroupBy(payload).subscribe(result => {
          if (result) {
            this.showSuccessMessage('SAVE', result);
          }
        }, err => this.isLoading = false);
      }
    } else {
      this.toastrService.warning(ERROR_MESSAGE.FIELDS_REQUIRED);
      return false;
    }
  }
  showSuccessMessage(type: string, result): void {
    if (type === 'UPDATE') {
      this.toastrService.success(ERROR_MESSAGE.RECORD_UPDATED);
    } else {
      this.toastrService.success(ERROR_MESSAGE.USER_CREATED);
    }
    this.activeModal.dismiss(result);
  }
  addNewGroup(value='add'){
    const data = {
      groupId: '',
      topic_id: '',
      buddiesList: '',
      group_name: '',
      group_description: '',
      mode:""
     };
    const modelRef = this.modalService.open(AddNewGroupComponent, {
      scrollable: true,
      centered: true,
      backdrop: 'static',
      size: 'xl',
      windowClass: 'modal-challenge'
    });
    modelRef.componentInstance.data = data;
    modelRef.componentInstance.fromPage = 'center_panel';
    
    modelRef.componentInstance.isResponseSelect = true;
    modelRef.result.then((res) => {
      if (res==='center_panel') {
        this.searchGrpResult=[]
        this.groupId=''
        this.groupDetailList()

      }
    });
  }
  searchBy(group) {
    // this.isCheck=false
    this.groupId = group.id?group.id:group
    this.gName = group.group_name? group.group_name:group
    this.gDescription = group.description ? group.description:group
    this.selectedUserStore=[]
    this.searchGrpResult=[]
    const payload={
      id:group.id ? group.id:group
    }
    this.isLoading = true;
    
    this.studentHelperService.getGroupMembers(payload).subscribe(res => {
      this.isLoading = false;
      this.searchGrpResult = res.sort((a,b) => a.display_name.localeCompare(b.display_name));
    }, () => this.isLoading = false);
  }
  
}
