import { NgbActiveModal, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ChangeDetectorRef, Component, EventEmitter, Input, OnInit, Output, OnDestroy, TestabilityRegistry } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { FileUploadComponent } from 'src/app/shared/component/file-upload/file-upload.component';
import { ToastrService } from 'ngx-toastr';
import { StudentHelperService } from '../../../student-helper.service';
import {AVATAR_RELATIVE_PATH, ICON_AVATAR} from 'src/app/shared/constants/constant';
import { AuthState } from 'src/app/shared/store/auth.model';
import { Store } from '@ngrx/store';
import {SetUserDetail} from '../../../../../shared/store/auth.action';
import {takeUntil} from 'rxjs/operators';
import {Subject} from 'rxjs';
import { userInfo } from 'src/app/shared/store/auth.selector';
import { Router } from '@angular/router';

@Component({
  selector: 'app-avatar',
  templateUrl: './avatar.component.html'
})
export class AvatarComponent implements OnInit, OnDestroy {
  private subscriptions = new Subject<void>();
  isShowing:boolean = true;
  userInfo: any;
  @Input() userAvatar;
  @Input() userData;
  @Output() avatarUpdate = new EventEmitter<any>();

  defaultImage = 'assets/img/upload-avatar.png';
  userProfilePic: string;
  ctrlName1 = 'radioCtrl1';
  ctrlName2 = 'radioCtrl2';
  ctrlName3 = 'radioCtrl3';
  femaleAvatars = ICON_AVATAR.femaleAvatars;
  maleAvatars = ICON_AVATAR.maleAvatars;
  otherAvatars = ICON_AVATAR.otherAvatars;

  createAvatarForm = this.fb.group({
    gender: ['', [Validators.required]],
    avatar_image_file: [null, [Validators.required]],
  });
  selectedAvatar: string;
  userId;
  isFormSubmitted = false;
  myOwnAvatars: any;
  categories: any[];
  isDidable: boolean = true;
  tests: boolean;

  constructor(
    private fb: FormBuilder,
    private activeModal: NgbActiveModal,
    private toastrService: ToastrService,
    private cd: ChangeDetectorRef,
    private studentHelperService: StudentHelperService,
    private modalService: NgbModal,
    private store$: Store<AuthState>,
    private router: Router
  ) {
    this.store$.select(userInfo)
      .pipe(takeUntil(this.subscriptions))
      .subscribe(res => this.userInfo = res);
    this.userId = this.userInfo.user_id;
  }

  ngOnInit() {
    this.userProfilePic = this.userAvatar;
    if (this.userData) {
      this.updateProfileForm(this.userData);
    }
    this.getMyOwnAvatars();
  }

  updateProfileForm(user: any) {
    this.createAvatarForm.patchValue({
      gender: user.gender,
      avatar_image_file: user.avatar_image_file,
    });
  }

  // getMyOwnAvatars():void{
  //   const payload ={
  //     category_id : 1,
  //     redeemed : true,
  //   };
  //   this.studentHelperService.getAllItemsList(payload).subscribe(res =>{
  //     this.myOwnAvatars =res;
  //     if(res){
  //         this.myOwnAvatars =res.items;
  //         this.isShowing = false; 
  //         console.log( "items list ", this.myOwnAvatars);
  //       }else{
  //         console.log(res);
  //       }
  //   })  
  // }
  getMyOwnAvatars():void{

    const payload ={

      category_id : 1,

      redeemed : true,

    };

    this.studentHelperService.getAllItemsList(payload).subscribe(res =>{

      if(res.items[0]){

          this.myOwnAvatars =res.items;

          this.isShowing = false;

          // console.log( "items list ", this.myOwnAvatars);

        }

    })  

  }

  selectAvatar(avatar: string): void {
    if(avatar.includes('http')){
      this.selectedAvatar = avatar;
      this.userProfilePic = avatar;
      this.createAvatarForm.controls.avatar_image_file.setValue(avatar.split('uploads/')[1]);
    }else{
      this.selectedAvatar = avatar;
      this.userProfilePic = 'assets/img/avatars/SVG/' + avatar;
      this.createAvatarForm.controls.avatar_image_file.setValue(AVATAR_RELATIVE_PATH + avatar);
    }
    
  }

  onImgError(event) {
    event.target.src = this.defaultImage;
  }

  openAvatarModal() {
    const modalData = {
      headerName: 'Profile Pic',
      fileType: 'image',
      fileCategory: 'avatar',
      isMultipleFile: false
    };

    const modalRef = this.modalService.open(FileUploadComponent, {
      keyboard: false,
      backdrop: 'static',
      scrollable: true,
      windowClass: 'modal-cover modal-cover-fluid modal-upload'
    });
    modalRef.componentInstance.data = modalData;
    modalRef.result.then((res) => {
      // console.log(res);
    }, (reason) => {
      if (reason && reason.length) {
        const fileName = reason[0].file;
        this.userProfilePic = reason[0].fileUrl;
        this.createAvatarForm.patchValue({
          avatar_image_file: fileName
        });
        this.cd.detectChanges();
      }
    });
  }

  closeModal(value?: string): void {
    if (value === 'closeAll') {
      this.activeModal.close(value);
    } else {
      this.activeModal.close();
    }
  }
  gotoDotStore(){
    this.closeModal('closeAll');
    this.router.navigateByUrl('/auth/student/dot-store');
  }
  tabChange(event:any){
    if(event.activeId=="ngb-tab-0"){
      this.tests=true
    }else{
      this.tests=false
    }
  }
  saveAvatar() {
    this.cd.detectChanges();
    if (!this.createAvatarForm.valid) {
      this.toastrService.warning('Please select gender and avatar');
      return false;
    }
    const userData = this.createAvatarForm.value;
    userData.user_id = this.userId;
    this.isFormSubmitted = true;
    this.studentHelperService.updateUserProfile(userData).subscribe(res => {
      this.isFormSubmitted = false;
      this.cd.detectChanges();
      this.store$.dispatch(new SetUserDetail(res));
      this.toastrService.success('Your information updated successfully');
      if (res && res.avatar_image_file) {
        this.avatarUpdate.emit(res);
      }
    }, err => {
      this.cd.detectChanges();
      this.isFormSubmitted = false;
      this.toastrService.error('Something went wrong');
    });
  }

  ngOnDestroy() {
    this.subscriptions.next();
    this.subscriptions.complete();
    this.cd.detach();
  }
  
}
