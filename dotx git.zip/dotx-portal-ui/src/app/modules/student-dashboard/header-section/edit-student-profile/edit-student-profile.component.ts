import {Component, Input, OnDestroy, OnInit} from '@angular/core';
import {NgbActiveModal, NgbModal} from '@ng-bootstrap/ng-bootstrap';
import {UploadService} from '../../../../shared/services/upload.service';
import {FileUploadComponent} from '../../../../shared/component/file-upload/file-upload.component';
import {StudentHelperService} from '../../student-helper.service';
import {ImageVideoViewComponent} from '../../../../shared/component/image-video-view/image-video-view.component';
import {SetUserDetail} from '../../../../shared/store/auth.action';
import {Store} from '@ngrx/store';
import {AuthState} from '../../../../shared/store/auth.model';
import {HelperService} from '../../../../shared/services/helper.service';
import {userInfo} from '../../../../shared/store/auth.selector';
import {takeUntil} from 'rxjs/operators';
import {Subject} from 'rxjs';
import { NavigationStart, Router } from '@angular/router';

@Component({
  selector: 'app-edit-student-profile',
  templateUrl: './edit-student-profile.component.html',
  styleUrls: ['./edit-student-profile.component.scss']
})
export class EditStudentProfileComponent implements OnInit, OnDestroy {

  @Input() data;
  private subscriptions = new Subject<void>();
  isLoading: boolean;
  currentPage = 'personalInfo';
  userDetails: any;
  age: number;
  view: any = 'personalInfo';

  constructor(private activeModal: NgbActiveModal, private uploadService: UploadService, private store$: Store<AuthState>,private router: Router,
              private modalService: NgbModal, private studentHelperService: StudentHelperService, private helperService: HelperService) {
    this.store$.select(userInfo)
      .pipe(takeUntil(this.subscriptions))
      .subscribe(res => {
        this.userDetails = res;
        this.age = this.helperService.getAge(this.userDetails.user_dob);
      });
      console.log(this.userDetails);
      
  }

  ngOnInit() {
    this.router.events.subscribe((event) => {
      if (event instanceof NavigationStart) {
        if (event.navigationTrigger === 'popstate') {
          this.modalService.dismissAll();
        }
      }
    });
  }

  closeModal(): void {
    this.activeModal.close();
  }

  userInfoUpdate(userinfo: any): void {
  }

  avatarUpdate(userinfo: any): void {
  }

  openViewerModel(type: string, url: string): void {
    const modalRef = this.modalService.open(ImageVideoViewComponent, {
      centered: true,
      size: 'lg'
    });
    modalRef.componentInstance.fileType = type;
    modalRef.componentInstance.fileUrl = url;
  }

  uploadBioVideo() {
    const modalData = {
      headerName: 'Bio',
      fileType: 'video',
      fileCategory: 'bio_video',
      isMultipleFile: false
    };
    const modalRef = this.modalService.open(FileUploadComponent, {
      keyboard: false,
      backdrop: 'static',
      scrollable: true,
      windowClass: 'modal-cover modal-cover-fluid modal-upload'
    });
    modalRef.componentInstance.data = modalData;
    modalRef.result.then((reason) => {
      if (reason) {
      }
    }, (reason) => {
      if (reason) {
        if (reason && reason.length) {
          const payload = {
            user_bio_video_file: reason[0].file,
            user_id: this.userDetails.user_id
          };
          this.studentHelperService.updateUserProfile(payload).subscribe(res => {
            this.userDetails = res;
            this.store$.dispatch(new SetUserDetail(res));
          });
        }
      }
    });
  }

  ngOnDestroy(): void {
    this.subscriptions.next();
    this.subscriptions.complete();
  }
}
