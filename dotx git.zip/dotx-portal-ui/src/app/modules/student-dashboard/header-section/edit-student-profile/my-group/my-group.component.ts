import {Component, OnInit, TemplateRef} from '@angular/core';
import {NgbModal} from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-my-group',
  templateUrl: './my-group.component.html',
  styleUrls: ['./my-group.component.scss']
})
export class MyGroupComponent implements OnInit {

  constructor(private modalService: NgbModal) { }

  ngOnInit() {
  }

  openRemoveBuddyPopup(content: TemplateRef<any>): void {
    const modelRef = this.modalService.open(content, {
      backdrop: 'static',
      keyboard: false,
      size: 'md',
      windowClass: 'modal-challenge',
      centered: true
    });
  }

}
