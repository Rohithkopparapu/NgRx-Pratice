import { Component, EventEmitter, Input, OnInit, Output, OnDestroy } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { HelperService } from 'src/app/shared/services/helper.service';
import { CustomValidator } from 'src/app/shared/services/validators/customValidator';
import { StudentHelperService } from '../../../student-helper.service';
import { AuthState } from 'src/app/shared/store/auth.model';
import { Store } from '@ngrx/store';
import {SetUserDetail} from '../../../../../shared/store/auth.action';
import {Subject} from 'rxjs';
import {takeUntil} from 'rxjs/operators';
import { userInfo } from 'src/app/shared/store/auth.selector';

@Component({
  selector: 'app-personal-info',
  templateUrl: './personal-info.component.html'
})
export class PersonalInfoComponent implements OnInit, OnDestroy {
  private subscriptions = new Subject<void>();
  userInfo: any;
  @Input() userData;
  @Output() profileUpdated = new EventEmitter<any>();

  userId: string | number;
  dobMaxDate: any;
  isFormSubmitted = false;
  minYear: number;

  createProfileForm = this.fb.group({
    display_name: [{value: '', disabled: true}],
    user_phone_num: ['', [CustomValidator.AllowNumericOnly]],
    user_email: [{value: '', disabled: true}],
    user_dob: ['', [Validators.required]],
    gender: ['', [Validators.required]],
    school_name: ['', [Validators.required]],
    class_details: ['', [Validators.required]],
    user_about_me: ['', [Validators.required]],
    parent_name: ['', [Validators.required]],
    parent_email: ['', [CustomValidator.ValidateEmail]],
    parent_contact_no: ['', [Validators.required, CustomValidator.AllowNumericOnly]],
  });

  constructor(
    private toastrService: ToastrService,
    public _uhs: HelperService,
    private fb: FormBuilder,
    private studentHelperService: StudentHelperService,
    private store$: Store<AuthState>
  ) {
    this.store$.select(userInfo)
      .pipe(takeUntil(this.subscriptions))
      .subscribe(res => this.userInfo = res);
    this.userId = this.userInfo.user_id;
  }

  ngOnInit() {
    this.dobMaxDate = this._uhs.getTodaysFormattedDate();
    this.minYear = this.dobMaxDate.year - 8;
    if (this.userData) {
      this.updateForm(this.userData);
    }
  }

  updateForm(dotUserDetails: any): void {
    this.createProfileForm.patchValue({
      display_name: dotUserDetails.display_name,
      user_phone_num: dotUserDetails.user_phone_num,
      user_email: dotUserDetails.user_email,
      user_dob: dotUserDetails.user_dob ? this._uhs.getFormattedDateForAdminChall(this.userData.user_dob) : null,
      gender: dotUserDetails.gender,
      class_details: dotUserDetails.class_details,
      school_name: dotUserDetails.school_name,
      user_about_me: dotUserDetails.user_about_me,
      parent_name: this.userInfo.parent_name,
      parent_email: this.userInfo.parent_email,
      parent_contact_no: this.userInfo.parent_contact_no
    });
  }

  profileMarkAsTouched() {
    Object.values(this.createProfileForm.controls).forEach((control: any) => {
      control.markAsTouched();
    });
  }

  saveProfile() {
    if (!this.createProfileForm.valid) {
      this.profileMarkAsTouched();
      this.toastrService.warning('Please enter all required fields');
      return false;
    }
    const {display_name, user_phone_num, user_email, user_dob, gender,
      class_details, school_name, user_about_me, parent_name, parent_email, parent_contact_no} = this.createProfileForm.value;
    const payload = {
      user_id: this.userId,
      display_name,
      user_phone_num,
      user_email,
      user_dob,
      gender,
      class_details,
      school_name,
      user_about_me,
      parent_name,
      parent_email,
      parent_contact_no
    };
    payload.user_dob = this._uhs.getFormattedDateToBind(user_dob) + 'T00:00';
    this.isFormSubmitted = true;
    this.studentHelperService.updateUserProfile(payload).subscribe(res => {
      this.isFormSubmitted = false;
      this.store$.dispatch(new SetUserDetail(res));
      this.toastrService.success('Profile updated successfully');
      this.profileUpdated.emit(res);
    }, err => {
      this.isFormSubmitted = false;
      this.toastrService.error('Something went wrong');
    });
  }

  ngOnDestroy() {
    this.subscriptions.next();
    this.subscriptions.complete();
  }
}
