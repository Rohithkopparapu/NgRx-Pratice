import { Component, Input, OnInit } from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ToastrService } from 'ngx-toastr';
import { FileUploadComponent } from 'src/app/shared/component/file-upload/file-upload.component';
import { ImageVideoViewComponent } from 'src/app/shared/component/image-video-view/image-video-view.component';
import { StudentHelperService } from '../../../student-helper.service';

@Component({
  selector: 'app-talents-favourites',
  templateUrl: './talents-favourites.component.html',
  styleUrls: ['./talents-favourites.component.scss']
})
export class TalentsFavouritesComponent implements OnInit {
  @Input() data;
  page: any;
  userDetails: any;
  talents: any = [];
  isLoading = true;
  options: any[] = [];

  constructor(private studentHelperService: StudentHelperService,
              private toastrService: ToastrService,
              private modalService: NgbModal) { }

  ngOnInit() {
    this.page = this.data.page;
    this.userDetails = this.data.userDetails;
    this.getTalents();
  }

  getTalents(): void {
    this.isLoading = true;
    this.studentHelperService.getUserSkills(this.page).subscribe(res => {
      this.isLoading = false;
      if (res && res.length) {
         this.talents = res;
         this.talents.forEach(element => {
           element['selected'] = !!element.is_selected;
           if (element.attachments && element.attachments.length) {
            element['skill_files'] = element.attachments;
            element.skill_files.forEach(ele => {
              let fileExtension = ele.file.split('.').pop();
              if (fileExtension.match(/(jpg|jpeg|png|gif)$/i)) {
                fileExtension = 'image';
              } else {
                fileExtension = 'video';
                ele['streamUrl'] = ele.stream_url;
              }
              ele['filePath'] = ele.url;
              ele['fileType'] = fileExtension;
            });
           } else {
            element['skill_files'] = [];
           }
         });
      }
    }, () => this.isLoading = false);
  }

  save(): void {
   const requestPayload = {
    user_id: this.userDetails.user_id,
    skill_category: this.page,
    skills: this.buildRequestPayload()
   }
   this.isLoading = true;
   this.studentHelperService.updateSkills(requestPayload).subscribe(() => {
      this.isLoading = false;
      this.getTalents();
      this.toastrService.success(this.page + ' Updated Successfully!')
   },() => {
     this.isLoading = false;
     this.toastrService.error('Unable to Update ' +this.page)
   });

  }
  buildRequestPayload(): any {
    const skills = [];
    this.talents.forEach(talent => {
      if (talent.selected) {
        const requestObj = {
          user: this.userDetails.user_id,
          skill: talent.skill_id,
          is_primary: 1,
          skill_files: talent.skill_files
        };
        skills.push(requestObj);
      }
    });
    return skills;
  }

  openUploadModel(skillId: number): void {
    const modalData = {
      headerName: 'Skill',
      fileType: 'image&video',
      fileCategory: 'skill',
      isMultipleFile: true
    };
    const modalRef = this.modalService.open(FileUploadComponent, {
      keyboard: false,
      backdrop: 'static',
      scrollable: true,
      windowClass: 'modal-cover modal-cover-fluid modal-upload'
    });
    modalRef.componentInstance.data = modalData;
    modalRef.result.then((reason) => {
      if (reason) {
      }
    }, (reason) => {
      if (reason) {
        if (reason && reason.length) {
          reason.forEach(res => {
            const fileObj = {};
            let fileExtension = res.file.split('.').pop();
            if (fileExtension.match(/(jpg|jpeg|png|gif)$/i)) {
              fileExtension = 'image';
            }
            fileObj['filePath'] = res.fileUrl;
            fileObj['fileType'] = fileExtension;
            fileObj['file'] = res.file;
            fileObj['display_name'] = res.display_name;
            this.talents.find(talent => talent.skill_id === skillId).skill_files.push(fileObj);
          });
        }
      }
    });
  }
  openViewerModel(type: string, url: string): void {
    const modalRef = this.modalService.open(ImageVideoViewComponent, {
      centered: true,
      size: 'lg'
    });
    modalRef.componentInstance.fileType = type;
    modalRef.componentInstance.fileUrl = url;
  }

  removeFile(parentIndex, subIndex) {
    this.talents[parentIndex].skill_files = this.talents[parentIndex].skill_files.filter((s, index) => index !== subIndex);
  }
}
