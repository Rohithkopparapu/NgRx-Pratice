import {Component, Input, OnDestroy, OnInit} from '@angular/core';
import {NgbActiveModal, NgbModal, NgbModalOptions} from '@ng-bootstrap/ng-bootstrap';
import {StudentHelperService} from '../../student-helper.service';
import {HelperService} from '../../../../shared/services/helper.service';
import {Store} from '@ngrx/store';
import {AuthState} from '../../../../shared/store/auth.model';
import {EditStudentProfileComponent} from '../edit-student-profile/edit-student-profile.component';
import {NOTIFICATION_TYPES, SEARCH_TYPE} from '../../../../shared/constants/constant';
import {MyChallengesPopupComponent} from '../../../../shared/component/my-challenges-popup/my-challenges-popup.component';
import {MyQuestPopupComponent} from '../../../../shared/component/my-quest-popup/my-quest-popup.component';
import {FileUploadComponent} from '../../../../shared/component/file-upload/file-upload.component';
import {ImageVideoViewComponent} from '../../../../shared/component/image-video-view/image-video-view.component';
import {ViewOtherProfileComponent} from '../../../../shared/component/view-other-profile/view-other-profile.component';
import {InviteBuddyByEmailComponent} from '../../../../shared/component/invite-buddy-by-email/invite-buddy-by-email.component';
import {SetUserDetail} from '../../../../shared/store/auth.action';
import {SendMessagePopupComponent} from '../../../../shared/component/send-message-popup/send-message-popup.component';
import {BadgesDotcoinsPopupComponent} from '../../../../shared/component/badges-dotcoins-popup/badges-dotcoins-popup.component';
import {debounceTime, distinctUntilChanged, takeUntil} from 'rxjs/operators';
import {myPortfolio, onlineSocketUsers, userInfo} from 'src/app/shared/store/auth.selector';
import {Subject} from 'rxjs';
import {FormControl, FormGroup, Validators} from '@angular/forms';
import { CertificationsPopupComponent } from 'src/app/shared/component/certifications-popup/certifications-popup.component';
import { InviteBuddyPopupComponent } from '../../challenge-hub/invite-buddy-popup/invite-buddy-popup.component';
import { CreateGroupComponent } from '../create-group/create-group.component';
import { NavigationStart, Router } from '@angular/router';
@Component({
  selector: 'app-my-space',
  templateUrl: './my-space.component.html',
  styleUrls: ['./my-space.component.scss']
})
export class MySpaceComponent implements OnInit, OnDestroy {
  private subscriptions = new Subject<void>();
  @Input() data;
  isLoading: boolean;
  userDetails: any;
  myTalentsList: any[] = [];
  alluserDetails: any[];
  age: number;
  buddySearchForm = new FormGroup({
    buddyName: new FormControl('', [Validators.required])
  });
  userId: any;
  isMySkillsLoaded: boolean;
  isUsersLoading = false;
  badges: number;
  dotCoins: number;
  totalCertificates: number;
  totalChallengesCount: number;
  myNotificationList: any[] = [];
  myBuddiesFlag = true;
  myNotificationsFlag = false;
  selectedSkillTab = 'My Talents';
  myFavouritesList: any[] = [];
  searchType = 'Name';
  switchNotifications = 'Notifications';
  notificationListLoaded = false;

  ngbModalOptions: NgbModalOptions = {
    centered: true,
    backdrop: 'static',
    keyboard: false,
    size: 'xl',
    windowClass: 'custom-modal edit-student-dashboard'
  };

  mySkills: any;
  onlineUsersList: any;
  myPortfolio: any;
  challenge: any;
  createGroupForm: any;
  dotRegistrationId: any;
  userInfo: any;

  constructor(
    private studentHelperService: StudentHelperService,
    public activeModal: NgbActiveModal,
    public _uhs: HelperService,
    private modalService: NgbModal,
    private router: Router,
    private store$: Store<AuthState>
  ) {
    this.store$.select(userInfo)
      .pipe(takeUntil(this.subscriptions))
      .subscribe(res => {
        this.userDetails = res;
        this.age = this._uhs.getAge(this.userDetails.user_dob);
      });
    this.store$.select(onlineSocketUsers)
      .pipe(takeUntil(this.subscriptions))
      .subscribe(res => this.onlineUsersList = res);
      this.store$.select(userInfo)
      .pipe(takeUntil(this.subscriptions))
      .subscribe(res => this.userInfo = res);
    this.store$.select(myPortfolio)
      .pipe(takeUntil(this.subscriptions))
      .subscribe(res => this.myPortfolio = res);
    this.userId = this.userDetails.user_id;
  }

  ngOnInit() {
    this.dotRegistrationId = this.userInfo.dot_registration_id;
    this.getUserSkillsInfo();
    this.getMyBuddies({});
    this.getNotifications();
    this.getAchievements();

    this.buddySearchForm.get('buddyName').valueChanges.pipe(
      debounceTime(500),
      distinctUntilChanged()).subscribe(search => {
        this.onChangeValue(search);
    });
    this.router.events.subscribe((event) => {
      if (event instanceof NavigationStart) {
        if (event.navigationTrigger === 'popstate') {
          this.modalService.dismissAll();
        }
      }
    });
  }

  openEditStudentDashboard(currentPage?: string): void {
    const modalRef = this.modalService.open(EditStudentProfileComponent, this.ngbModalOptions);
    modalRef.componentInstance.data = {};
    modalRef.componentInstance.currentPage = currentPage ? currentPage : 'personalInfo';
    modalRef.result.then((res) => {
      this.updateRecords();
      this.activeModal.close();
    }, (reason) => {
      if (reason) {
        this.updateRecords();
       }
    });
  }

  updateRecords(): void {
    this.getUserSkillsInfo();
  }

  closeModal(): void {
    this.activeModal.close();
  }

  getMyBuddies(payload: any) {
    this.isUsersLoading = true;
    this.studentHelperService.getMyBuddies(payload).subscribe((resp) => {
      this.alluserDetails = resp;
      this.isUsersLoading = false;
    }, () => this.isUsersLoading = false);
  }

  getUserSkillsInfo() {
    this.isMySkillsLoaded = true;
    this.myTalentsList = [];
    this.myFavouritesList = [];
    this.studentHelperService.getUserSkills().subscribe((resp) => {
      this.isMySkillsLoaded = false;
      if (resp && resp.length) {
        this.myTalentsList = resp.filter(res => res.skill_category === 'Talents' && res.is_selected);
        this.myFavouritesList = resp.filter(res => res.skill_category === 'Favourites' && res.is_selected);
        this.myTalentsList.forEach(element => {
          if (element.attachments && element.attachments.length) {
            element['attachmentsList'] = this.processAttachments(element);
          }
        });
        this.myFavouritesList.forEach(element => {
          if (element.attachments && element.attachments.length) {
            element['attachmentsList'] = this.processAttachments(element);
          }
        });
        this.selectSkillTab(this.selectedSkillTab);
      }
    }, () => this.isMySkillsLoaded = false);
  }

  getAchievements() {
    if (this.myPortfolio.achievements) {
      this.badges = this.myPortfolio.achievements && this.myPortfolio.achievements.winning_badges_count ? this.myPortfolio.achievements.winning_badges_count : 0;
      this.dotCoins = this.myPortfolio.achievements && this.myPortfolio.achievements.total_dot_coins ? Number(this.myPortfolio.achievements.total_dot_coins) : 0;
      this.totalChallengesCount = this.myPortfolio.achievements.total_challenges_count;
      this.totalCertificates = this.myPortfolio.achievements && this.myPortfolio.achievements.total_certificates ? this.myPortfolio.achievements.total_certificates : 0;
    }
  }

  onChangeValue(value: any): void {
    
    if (value && value.trim()) {
      const property = SEARCH_TYPE[this.searchType];
      // console.log("fh",value,property)
      this.getMyBuddies({[property] : value});
    } else {
      this.getMyBuddies({});
    }
  }

  openMyBuddies() {
    this.myNotificationsFlag = false;
    this.myBuddiesFlag = true;
  }

  openMyNotifications() {
    this.myBuddiesFlag = false;
    this.myNotificationsFlag = true;
  }

  selectSkillTab(value) {
    let data = {
      partialAccess: true,
      skillsListWithAttachments: [],
      skillsListWithOutAttachments: [],
      skillCategory: ''
    };
    if (value === 'My Talents') {
      this.selectedSkillTab = value;
      data.skillCategory = 'talents';
      data.skillsListWithAttachments = this.myTalentsList.filter(talent => talent.attachmentsList);
      data.skillsListWithOutAttachments = this.myTalentsList.filter(talent => !talent.attachmentsList);
      this.mySkills = data;
    } else if (value === 'My Favourites') {
      this.selectedSkillTab = value;
      data.skillCategory = 'favourites';
      data.skillsListWithAttachments = this.myFavouritesList.filter(favourite => favourite.attachmentsList);
      data.skillsListWithOutAttachments = this.myFavouritesList.filter(favourite => !favourite.attachmentsList);
      this.mySkills = data;
    }
  }
openGroupPopup(value ){
  if (value === 'My Groups') {
    this.selectedSkillTab = value;
  }
  const data = {
     searchType: value,
     topic_id: this.challenge,
     buddiesList: this.createGroupForm
    };
    // InviteBuddyPopupComponent
  const modelRef = this.modalService.open(CreateGroupComponent, {
    scrollable: true,
    centered: true,
    backdrop: 'static',
    size: 'xl',
    windowClass: 'modal-challenge'
  });
  modelRef.componentInstance.data = data;
  // modelRef.result.then((res) => {
  //   if (res && res.length) {
  //     res.forEach(s => {
  //       if (this.createGroupForm.assignments.findIndex(i => i.user_id === s.user_id) === -1) {
  //         this.createGroupForm.assignments.push(s);
  //       }
  //     });
  //   }
  // });
}
  openMyChallengesPopup(value) {
    const myChallengeDetails = {
      badges: this.badges,
      dotcoins: this.dotCoins,
      accessViewType: 'All',
      buddyDetails: this.userDetails,
    };
    const modalRef = this.modalService.open(value === 'challenge' ? MyChallengesPopupComponent : MyQuestPopupComponent, {
      centered: true,
      scrollable: true,
      backdrop: 'static',
      keyboard: false,
      size: 'xl',
      windowClass: 'modal-challenge'
    });
    modalRef.componentInstance.data = myChallengeDetails;
    modalRef.result.then((res) => {
      if (res === 'closeAll') {
        this.closeModal();
      }
    });
  }

  uploadBioVideo() {
    const modalData = {
      headerName: 'Bio',
      fileType: 'video',
      fileCategory: 'bio_video',
      isMultipleFile: false
    };
    const modalRef = this.modalService.open(FileUploadComponent, {
      keyboard: false,
      backdrop: 'static',
      scrollable: true,
      windowClass: 'modal-cover modal-cover-fluid modal-upload'
    });
    modalRef.componentInstance.data = modalData;
    modalRef.result.then((reason) => {
      if (reason) {
      }
    }, (reason) => {
      if (reason) {
        if (reason && reason.length) {
          const payload = {
            user_bio_video_file: reason[0].file,
            user_id: this.userId
          };
          this.studentHelperService.updateUserProfile(payload).subscribe(res => {
            this.userDetails = res;
            this.store$.dispatch(new SetUserDetail(res));
          });
        }
      }
    });
  }

  openViewerModel(type: string, url: string): void {
    const modalRef = this.modalService.open(ImageVideoViewComponent, {
      centered: true,
      size: 'lg'
    });
    modalRef.componentInstance.fileType = type;
    modalRef.componentInstance.fileUrl = url;
  }

  onSearchByType(type, value) {
    if (value === 'buddies') {
      this.searchType = type;
    } else if (value === 'notifications') {
      this.switchNotifications = type;
      this.getNotifications();
    }
  }

  getNotifications(): void {
    const payload = {
      user_id: this.userId,
      notification_type: NOTIFICATION_TYPES[this.switchNotifications]
    };
    this.notificationListLoaded = true;
    this.studentHelperService.getNotifications(payload).subscribe(res => {
      this.notificationListLoaded = false;
      res.forEach(notification => {
        if (notification.info) {
          notification['challenge'] = notification.info;
        }
      });
      this.myNotificationList = res;
    }, () => this.notificationListLoaded = false);
  }

  openChallenge(notification: any): void {
    if (notification.challenge && notification.challenge.topic_id) {

    }
  }

  openBuddyProfile(buddie): void {
    const modalRef = this.modalService.open(ViewOtherProfileComponent, {
      centered: true,
      size: 'xl',
      windowClass: 'custom-modal'
    });
    modalRef.componentInstance.data = { userId: buddie.user_id };
  }

  processAttachments(skillsList) {
    const attachmentsList = [];
    skillsList.attachments.forEach(ele => {
      let file = {};
      let fileExtension = ele.file.split('.').pop();
      if (fileExtension.match(/(jpg|jpeg|png|gif)$/i)) {
        fileExtension = 'image';
      } else {
        fileExtension = 'video';
        file['streamUrl'] = ele.stream_url;
      }
      file = { ...file, fileName: ele.display_name, filePath: ele.url, fileType: fileExtension };
      attachmentsList.push(file);
    });
    return attachmentsList;
  }

  openInviteBuddyPopup(): void {
    const modalRef = this.modalService.open(InviteBuddyByEmailComponent, {
      centered: true,
      backdrop: 'static',
      keyboard: false,
      windowClass: 'modal-cover modal-cover-fluid'
    });
  }

  openMessagePopup(userDetails): void {
    const data = {
      userDetails,
      popupType: 'Send Message'
    };
    const modalRef = this.modalService.open(SendMessagePopupComponent, {
      centered: true,
      keyboard: false,
      backdrop: 'static',
      windowClass: 'modal-cover modal-cover-fluid'
    });
    modalRef.componentInstance.data = data;
    // modalRef.result.then((res) => {
    // });
  }

  openBadgesOrDotCoinsPopup(value: string): void {
    const data = {
      viewPopup: value,
      accessViewType: 'All',
      buddyDetails: this.userDetails
    };
    const modalRef = this.modalService.open(BadgesDotcoinsPopupComponent, {
      // centered: true,
      size: 'xl',
      windowClass: 'modal-cover modal-cover-graphical',
      scrollable: true
    });
    modalRef.componentInstance.data = data;
    modalRef.result.then((res) => {
      if (res === 'closeAll') {
        this.closeModal();
      }
    });
  }

  openCertificationsPopup(): void {
    if (this.totalCertificates > 0) {
      const data = {
        accessViewType: 'All',
        buddyDetails: this.userDetails
      };
      const modalRef = this.modalService.open(CertificationsPopupComponent, {
        // centered: true,
        size: 'xl',
        windowClass: 'modal-cover modal-cover-graphical',
        scrollable: true
      });
      modalRef.componentInstance.data = data;
    }
  }

  ngOnDestroy(): void {
    this.subscriptions.next();
    this.subscriptions.complete();
  }
}
