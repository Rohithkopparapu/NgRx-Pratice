import { StudentHelperService } from 'src/app/modules/student-dashboard/student-helper.service';
import { Component, OnDestroy, OnInit } from '@angular/core';
import { NgbModal, NgbModalOptions } from '@ng-bootstrap/ng-bootstrap';
import { Subject } from 'rxjs';
import { AuthState, Portfolio } from 'src/app/shared/store/auth.model';
import { Store } from '@ngrx/store';
import { AuthLogout, SetUserDetail } from 'src/app/shared/store/auth.action';
import { MySpaceComponent } from '../my-space/my-space.component';
import { BadgesDotcoinsPopupComponent } from '../../../../shared/component/badges-dotcoins-popup/badges-dotcoins-popup.component';
import { takeUntil } from 'rxjs/operators';
import { myPortfolio, userInfo } from 'src/app/shared/store/auth.selector';
import { SocketUtilService } from '../../socket-util.service';
import { ModalUtilService } from '../../../../shared/services/modal-util.service';
import { NavigationStart, Router } from '@angular/router';
import { environment } from 'src/environments/environment';
import { DataService } from '../../../../shared/services/data.service';
import { CommunitySwitchService } from 'src/app/shared/services/community-switch.service';

@Component({
  selector: 'app-student-header',
  templateUrl: './student-header.component.html',
  styleUrls: ['./student-header.component.css']
})
export class StudentHeaderComponent implements OnInit, OnDestroy {
  private subscriptions = new Subject<void>();
  userInfo: any;
  userId: any;
  isLoading: boolean = false;
  badges = 0;
  dotCoins = 0;
  badgesList: any;
  achievementsList: any;
  openOrHideMobileMenu = false;
  ngbModalOptions: NgbModalOptions = {
    centered: true,
    backdrop: 'static',
    size: 'xl',
    windowClass: 'custom-modal'
  };
  myPortfolio: Portfolio;
  cmsLandingUrl: any;
  homepageUrl: string;
  toggleSchoolList: boolean = false;
  schoolList = [];
  searchSchool: any = "";
  dateFormatKeys = [];

  constructor(
    private modalService: NgbModal,
    private studentHelperService: StudentHelperService,
    private store$: Store<AuthState>,
    private socketUtilService: SocketUtilService,
    private route: Router,
    private modalUtilService: ModalUtilService,
    private router: Router,
    private commService : CommunitySwitchService,
    private dataService: DataService) {
    this.store$.select(userInfo)
      .pipe(takeUntil(this.subscriptions))
      .subscribe(res => {
        this.userInfo = res;
        console.log(this.userInfo);

        this.userId = this.userInfo.user_id;
      });
    this.store$.select(myPortfolio)
      .pipe(takeUntil(this.subscriptions))
      .subscribe(res => {
        this.myPortfolio = res;
        this.displayBadgesAndDotCoins();
      });
      if(this.userInfo.details !== null){
        if(this.userInfo.details.school_ids !== undefined){
        this.schoolList = this.userInfo.details.school_ids;
        }
      }
  }

  ngOnInit() {
    // checking
    this.studentHelperService.getBadgesAndDotCoins(this.userId);
    this.cmsLandingUrl = environment.cmsUrl;
    this.homepageUrl = environment.homePageUrl;
    this.router.events.subscribe((event) => {
      if (event instanceof NavigationStart) {
        if (event.navigationTrigger === 'popstate') {
          this.modalService.dismissAll();
        }
      }
    });
  }

  // getBadgesList(userId): void {
  //   this.studentHelperService.getBadges(userId).subscribe(res => {
  //     this.badgesList = res;
  //     this.getAchievements(this.userId);
  //   });
  // }

  // getAchievements(userId): void {
  //   this.studentHelperService.getAchievements(userId).subscribe(result => {
  //     if (result && result.length) {
  //       this.badges = result[0].winning_badges_count;
  //       this.dotCoins = result[0].total_dot_coins;
  //       this.achievementsList = result[0];
  //     }
  //   });
  // }

  displayBadgesAndDotCoins(): void {
    this.badgesList = this.myPortfolio.badges;
    this.badges = this.myPortfolio.achievements && this.myPortfolio.achievements.winning_badges_count ? this.myPortfolio.achievements.winning_badges_count : 0;
    this.dotCoins = this.myPortfolio.achievements && this.myPortfolio.achievements.total_dot_coins ? Number(this.myPortfolio.achievements.total_dot_coins) : 0;
    this.achievementsList = this.myPortfolio.achievements;
  }

  openDashboard(notification?: boolean) {
    this.openOrHideMobileMenu = false;
    const modalRef = this.modalService.open(MySpaceComponent, this.ngbModalOptions);
    if (notification) {
      modalRef.componentInstance.myBuddiesFlag = false;
      modalRef.componentInstance.myNotificationsFlag = true;
    }
  }

  logout(): void {
    this.openOrHideMobileMenu = false;
    this.ngOnDestroy();
    this.socketUtilService.disconnectConnection();
    this.store$.dispatch(new AuthLogout());
    window.location.replace(this.homepageUrl);
  }

  openBadgesOrDotCoinsPopup(value: string): void {
    const data = {
      viewPopup: value,
      accessViewType: 'All',
      buddyDetails: this.userInfo
    };
    this.openOrHideMobileMenu = false;
    const modalRef = this.modalService.open(BadgesDotcoinsPopupComponent, {
      // centered: true,
      size: 'xl',
      windowClass: 'modal-cover modal-cover-graphical',
      scrollable: true
    });
    modalRef.componentInstance.data = data;
  }

  // Create Humber Menu View
  enableOrDisableMobileMenu(): void {
    this.openOrHideMobileMenu = !this.openOrHideMobileMenu;
  }

  openContactUsForm(): void {
    this.openOrHideMobileMenu = false;
    this.modalUtilService.openContactUsPopup();
  }

  openChallegesForm(): void {
    this.route.navigate(['/auth/student/challenge']);

  }

  showDiv() {
    this.toggleSchoolList = true;
  }

  hideDiv() {
    this.toggleSchoolList = false;
    this.searchSchool ="";
  }

  switchSchool(data: any) {
    const payload = {
      "user_id": this.userInfo.user_id,
      "registration_id": data.id,
      "school_name": data.name
    }
    this.studentHelperService.SwitchSchool(payload).subscribe(res => {
      if (res) {
        sessionStorage.setItem("school_name", data.name);
        console.log(res);
        this.getuserDetails();
      }
    })
  }

  checkPrefComm(res: any): any {
    const comm = JSON.parse(sessionStorage.getItem('subsribedCommunities')).my_communities.find(x => Number(x.community_id) === Number(res.value))
    if (comm !== undefined && comm.is_competition !== undefined && comm.is_competition === 1) {
      return 1;
    } else {
      return 0;
    }
  }

  verifyNavigation(){
    // routerLink="/auth/student/home"
    // if (this.userInfo.preferences[0] !== undefined ? this.checkPrefComm(this.userInfo.preferences[0]) : false) {
    //   this.router.navigate(['/auth/student/challenge']);
    // } else if (this.userInfo.preferences[0] === undefined) {
    //   this.router.navigate(['/auth/student/community/join']);
    // }else{
    this.router.navigate(['/auth/student/home']);
    // }
  }

  navigateToComm(){
    this.router.navigate(['/auth/student/community/join']);
    this.commService.triggerRefresh();
  }

  getuserDetails() {
    this.isLoading = true;
    this.studentHelperService.getUserInfo(this.userId).subscribe((res) => {
      this.isLoading = false;
      this.store$.dispatch(new SetUserDetail(res));
      sessionStorage.setItem("school_name", res.school_name !== null ? res.school_name : "");
      setTimeout(() => {
        this.dataService.triggerRefresh();
      }, 500);
    },(err)=>{
      this.dataService.triggerRefresh();
    })
    this.isLoading = false;
  }

  setSearchValue($event: any): void {
    this.searchSchool = $event;
  }

  goToLink(url: string) {
    window.open(url, "_blank");
  }

  ngOnDestroy(): void {
    this.subscriptions.next();
    this.subscriptions.complete();
  }
}
