import { Component, EventEmitter, OnDestroy, OnInit, Output, QueryList, ViewChildren, TemplateRef } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { StudentHelperService } from '../../student-helper.service';
import { ActivatedRoute, Router } from '@angular/router';
import { NEWS_FEED_FILTER } from '../../../../shared/constants/input.constants';
import { ITEMS_PER_PAGE } from '../../../../shared/constants/pagination.constants';
import { ViewResponsesComponent } from '../../../../shared/component/view-responses/view-responses.component';
import { NgbModal, NgbModalRef } from '@ng-bootstrap/ng-bootstrap';
import { EVENT_TYPE, PREFERENCES, SEARCH_TYPE } from '../../../../shared/constants/constant';
import { debounceTime, distinctUntilChanged, takeUntil } from 'rxjs/operators';
import { Store } from '@ngrx/store';
import { AuthState } from '../../../../shared/store/auth.model';
import { onlineSocketUsers, userInfo } from 'src/app/shared/store/auth.selector';
import { HelperService } from '../../../../shared/services/helper.service';
import * as moment from 'moment';
import { IDropdownSettings } from 'ng-multiselect-dropdown/multiselect.model';
import { ToastrService } from 'ngx-toastr';
import { AnnouncementResponsesComponent } from '../../../../shared/component/announcement-responses/announcement-responses.component';
import { UserDetailsAction } from '../../../../shared/store/auth.action';
import { isEmpty, orderBy } from 'lodash';
import { MySpaceComponent } from '../../header-section/my-space/my-space.component';
import { ViewOtherProfileComponent } from 'src/app/shared/component/view-other-profile/view-other-profile.component';
import { Subject, Subscription } from 'rxjs';
import { DataService } from '../../../../shared/services/data.service';
import { PostRefreshService } from '../../../../shared/services/post-refresh.service';

@Component({
  selector: 'app-center-panel',
  templateUrl: './center-panel.component.html',
  styleUrls: ['./center-panel.component.scss']
})
export class CenterPanelComponent implements OnInit, OnDestroy {
  private subscription: Subscription;
  private subscriptions = new Subject<void>();
  @Output() modalPopupEmitter = new EventEmitter<any>();
  @ViewChildren('newsFeedPosts') newsFeedPostsElement: QueryList<any>;
  userCommunityPreference: any;
  isFilterLoading = false;
  isFilterApplied = false;
  isLoading = false;
  page = 1;
  pageSize = ITEMS_PER_PAGE;
  isLastPage: boolean;
  totalRecords = 0;

  filterPopup: NgbModalRef;
  filterForm: FormGroup;
  SINGLE_DROPDOWN_SETTINGS: IDropdownSettings = {
    singleSelection: true,
    idField: 'community_id',
    textField: 'community_name',
    allowSearchFilter: true,
    closeDropDownOnSelection: true
  };
  SINGLE_DROPDOWN_SETTINGS_GROUP: IDropdownSettings = {
    singleSelection: true,
    idField: 'id',
    textField: 'group_name',
    allowSearchFilter: true,
    closeDropDownOnSelection: true
  };
  MULTI_DROPDOWN_SETTINGS_CLASS: IDropdownSettings = {
    singleSelection: false,
    idField: 'topic_id',
    textField: 'topic_name',
    selectAllText: 'Select All',
    unSelectAllText: 'UnSelect All',
    enableCheckAll: true,
    itemsShowLimit: 3,
    allowSearchFilter: true
  };
  MULTI_DROPDOWN_SETTINGS: IDropdownSettings = {
    singleSelection: false,
    idField: 'topic_id',
    textField: 'topic_name',
    selectAllText: 'Select All',
    unSelectAllText: 'UnSelect All',
    enableCheckAll: true,
    itemsShowLimit: 3,
    allowSearchFilter: true
  };
  minDate = { month: 12, year: 2021, day: 5 };
  maxDate = this.helperService.getSpotlightFormattedStartMinDate();
  startDate: { month: number; year: number; day: number };
  setStartDate: { month: number; year: number; day: number };
  setEndDate: { month: number; year: number; day: number };
  communitiesList: any[];
  groupListData: any[];
  classListData: any[];
  challengesList: any[];
  toggleChallenge = false;
  newsFeedData: any[] = [];
  filterList = JSON.parse(JSON.stringify(NEWS_FEED_FILTER));
  isBlockScroll: boolean;
  userInfo: any;
  newsFeedFilterPayload = {};
  onlineUsersList: any;
  latestBulletinBoard: any;
  bulletinBoardPreference: any;
  minimizeOrMaximizeView = false;
  toggleLeaderBoard = true;
  angle = [0, 90, 180, 270];
  current = 0;
  commentsList: any = [];
  resCommentsList: any = [];
  userType: any;
  latestComments: any;
  alluserDetails: any[];
  isUsersLoading: boolean = false;
  searchType = "Name";
  userId: any;
  budyId: any;
  maxImages = 10;
  public breakLoopFlag = false;
  isQuestLoader: boolean = false;
  dataQuest: any = [];
  datainfo: any;
  address: any;
  schoolName: any = "";

  public breakLoop() {
    this.breakLoopFlag = true;
  }
  constructor(private studentHelperService: StudentHelperService, private router: Router, private modalService: NgbModal,
    private store$: Store<AuthState>, private helperService: HelperService, private fb: FormBuilder,
    private activatedRoute: ActivatedRoute, private toastrService: ToastrService, private dataService: DataService, private postRefresh :PostRefreshService) {
    this.store$.select(userInfo)
      .pipe(takeUntil(this.subscriptions))
      .subscribe(res => {
        this.userInfo = res;
        const bulletinBoardPreference = res.preferences.find(s => s.entity_name === PREFERENCES.BULLETIN_BOARD.ENTITY_NAME && s.entity_type === PREFERENCES.BULLETIN_BOARD.ENTITY_TYPE);
        this.bulletinBoardPreference = bulletinBoardPreference ? bulletinBoardPreference : null;
      });
    this.userId = this.userInfo.user_id;
    this.store$.select(onlineSocketUsers)
      .pipe(takeUntil(this.subscriptions))
      .subscribe(res => this.onlineUsersList = res);
    this.subscription = this.dataService.refreshComponent$.subscribe(() => {
      this.refreshComponentLogic();
    });
    this.subscription = this.postRefresh.postrefreshComponent$.subscribe(() => {
      this.refreshPosts();
    });

  }

  ngOnInit() {
    this.newsFeedData = [];
    this.resCommentsList = [];
    this.newsFeedFilterPayload = {};
    this.activatedRoute.data.subscribe((response) => {
      this.userCommunityPreference = response && response.userPreferenceDetails;
    });
    this.minimizeOrMaximizeView = this.bulletinBoardPreference ? this.bulletinBoardPreference.value === '1' : true;
    this.setStartDate = this.helperService.getLastDateByDays(1);
    this.setEndDate = this.minDate;
    this.initFilterForm();
    this.getCommunities();
    this.getLatestBulletinBoard();
    this.callNewsFeedDataService();
    this.getMyBuddies({});
    this.filterForm.get('buddy_id').valueChanges.pipe(
      debounceTime(500),
      distinctUntilChanged()).subscribe(search => {
        this.onChangeValue(search);
      });
    // this.studentCommunityInfo();
    this.schoolName = this.userInfo.school_name;
  }

  // getCommunities(): void {
  //   this.isLoading = true;
  //   this.studentHelperService.getAllCommunitiesNew().subscribe(res => {
  //     this.isLoading = false;
  //     if (res && res.my_communities.length) {
  //       this.communitiesList = res.my_communities.filter(s =>!s.combo && moment(moment(s.community_start_date).format('YYYY-MM-DD')).isSameOrBefore(moment().format('YYYY-MM-DD'))).sort((a,b)=> a.community_name.localeCompare(b.community_name));
  //     }
  //   }, () => this.isLoading = false);
  // }

  refreshComponentLogic() {
    // this.getLatestChallengeComments(this.newsFeedData);
    this.page = 1;
    this.newsFeedData = [];
    this.callNewsFeedDataService();
    this.latestBulletinBoard = [];
    this.getLatestBulletinBoard();
    this.schoolName = sessionStorage.getItem("school_name");

  }

  refreshPosts(){
    this.refreshComponentLogic();
  }

  getCommunities(): void {
    this.isLoading = true;
    // this.studentHelperService.getAllCommunitiesNew().subscribe(res => {
      this.isLoading = false;
      const res = JSON.parse(sessionStorage.getItem('subsribedCommunities'));
      if (res && res.my_communities.length) {
        let arr1 = res.my_communities.filter(s =>
          !s.combo && moment(moment(s.community_start_date).format('YYYY-MM-DD')).isSameOrBefore(moment().format('YYYY-MM-DD'))).sort((a, b) => a.community_name.localeCompare(b.community_name));
        // this.getquestLevelCertificate();
        // this.communitiesList = arr1.filter(community => (community.community_id && community.is_grade_wise === 1) )
        if (this.userInfo.dot_registration_id !== null) {
          if (this.userInfo.user_type === "student") {
            this.communitiesList = arr1.filter(community => (community.community_id && community.is_grade_wise === 1));
          } else {
            this.communitiesList = arr1.filter(community => (community.community_id));
          }
        } else if (this.userInfo.dot_registration_id === null) {
          this.communitiesList = arr1.filter(community => (community.is_certified === 0));
        }
        this.studentCommunityInfo();
      }

    // }, err => {
    //   this.isLoading = false;
    // });
  }

  navigateToComm(){
    // const res = JSON.parse(sessionStorage.getItem('subsribedCommunities'));
    // if(res && res.my_communities.length){
    //   res.my_communities.forEach(element => {
    //     if(element.is_competition === 1){
    //       this.router.navigate(['/auth/student/community/join'],{state: {data: element}});
    //     }else{
    //       this.router.navigate(['/auth/student/community/join'],{state: {data: element}});
    //     }
    //   });
    // }
    this.router.navigate(['/auth/student/community/join'],{state: {data: "41"}});
  }

  onScroll(event: any) {
    const videos = document.querySelectorAll('video');
    videos.forEach(video => {
      if (video && video.id) {
        const videoObserver = this.videoObserver(video);
        videoObserver.observe(video);
      }
    });
    // visible height + pixel scrolled >= total height
    if ((event.target.offsetHeight + event.target.scrollTop + 400 >= event.target.scrollHeight) && !this.isBlockScroll && !this.isLastPage) {
      this.isBlockScroll = true;
      this.page += 1;
      this.callNewsFeedDataService();
    }
  }

  callNewsFeedDataService(): void {
    // console.log("this.newsFeedFilterPayload",this.newsFeedFilterPayload);

    this.isLoading = true;
    const payload = { filter: this.newsFeedFilterPayload, pageNumber: this.page, pageSize: this.pageSize };
    this.studentHelperService.getNewsFeed(payload).subscribe(res => {
      this.isLoading = false;
      if (res) {
        this.processNewsFeedData(res);
        this.insertOfflineNewsFeedData(res.content);
        this.isBlockScroll = false;
      }
    }, () => this.isLoading = false);
  }

  insertOfflineNewsFeedData(data: any[]): void {
    if (data.length) {
      this.newsFeedData = this.newsFeedData.concat(data);
      this.getLatestChallengeComments(this.newsFeedData);
    } else {
      this.toastrService.success('No responses found...!');
    }

  }

  openOrCloseChallenge(): void {
    this.toggleChallenge = !this.toggleChallenge;
  }

  navigateToCreateChallenge(value: string): void {
    this.router.navigate(['/auth/student/challenge/create'], { state: { challengeName: value } });
  }

  loadMore(): void {
    this.page += 1;
    this.newsFeedPostsElement.last.nativeElement.scrollIntoView({ behavior: 'smooth' });
    this.callNewsFeedDataService();
  }

  getLatestBulletinBoard(): void {
    this.isLoading = true;
    this.studentHelperService.getBulletinDetailsByLatest().subscribe(res => {
      this.isLoading = false;
      if (res && res.length) {
        this.latestBulletinBoard = res[0];
        this.getLatestAnnouncementComments()
      }
    }, () => this.isLoading = false);
  }

  // refreshNewsFeedData(): void {
  //   this.subscriptions.push(
  //     interval(5000).subscribe((refresh) => {
  //       this.studentHelperService.getNewsFeed(1, this.pageSize, this.newsFeedFilterPayload).subscribe(res => {
  //         if (res && res.length && res[0].event_id !== this.newsFeedData[0].event_id) {
  //           this.isAutoRefresh = true;
  //         }
  //       });
  //     })
  //   );
  // }

  openViewResponse(post: any): void {
    const modelRef = this.modalService.open(ViewResponsesComponent, {
      centered: true,
      scrollable: true,
      backdrop: 'static',
      size: 'xl',
      windowClass: 'modal-challenge'
    });
    modelRef.componentInstance.challenge = { ...post, topic_response_id: post.event_id };
    modelRef.componentInstance.fromPage = 'center_panel';
    modelRef.componentInstance._page = 'MyChallenges';
    modelRef.componentInstance.isResponseSelect = true;
    const communities = JSON.parse(sessionStorage.getItem('subsribedCommunities'));
    if(communities.my_communities !== undefined && communities.my_communities.length !== 0){
      modelRef.componentInstance.community = communities.my_communities.find(x => x.community_id === post.community_id);
    }
    modelRef.result.then(res => {
      if (res === 'center_panel') {
        this.newsFeedData.forEach(res => {
          res.comments = {};
        })
        // this.page = 1;
        // this.newsFeedData = [];
        this.resCommentsList = [];
        // this.callNewsFeedDataService();
        this.getLatestChallengeComments(this.newsFeedData);
      }
    });
  }

  angles = -90;
  rotation = 0;
  oldPosition: any;
  rotate(post: any) {
    // Access DOM element object
    const rotated = document.getElementById(post);
    if (this.oldPosition !== rotated) {
      this.oldPosition = rotated;
      this.rotation = 0
      this.angles = -90
    }
    this.rotation = (this.rotation + this.angles) % 360;
    rotated.style.transform = `rotate(${this.rotation}deg)`;
  }
  // }
  videoObserver(video): IntersectionObserver {
    return new IntersectionObserver(entries => {
      entries.forEach(entry => {
        if (!entry.isIntersecting) {
          video.pause();
          return;
        }
      });
    }, { threshold: 0.3 });
  }

  initFilterForm(): void {
    this.filterForm = this.fb.group({
      checkCommunity: [false],
      checkChallenge: [false],
      checkDate: [false],
      byCommunity: [[]],
      byChallenges: [[]],
      isWinner: [false],
      startDate: [null],
      endDate: [this.helperService.getSpotlightFormattedStartMinDate()],
      checkgroup: [false],
      is_group_selected: [[]],
      checkBuddies: [''],
      checkclass: [''],
      my_class: [[]],
      buddy_id: [],
    });
  }

  openFilterPopup(content: TemplateRef<any>): void {
    this.filterPopup = this.modalService.open(content, {
      backdrop: 'static',
      size: 'sm',
      windowClass: 'modal-filter',
    });
  }

  formatSchool() {
    let schoolAddr;
    let school = sessionStorage.getItem("school_name");
    if (school !== null) {
      const words = school.split(' ');
      const formattedWords = words.map(word => word.charAt(0).toUpperCase() + word.slice(1));
      if (this.userInfo.details !== null) {
        if(this.userInfo.details.school_ids !== undefined){
          schoolAddr = this.userInfo.details.school_ids.find(x => x.name === school);
        }else{
          schoolAddr = {
            "address": "",
            "id": null,
            "name": ""
        }
        }    
      }
      if(schoolAddr !== undefined){
        this.address = schoolAddr.address;
      }else{
        this.address = ""
      }
      // this.address = schoolAddr.address;
      if(this.userInfo.details !==  null && this.userInfo.details.school_ids !== undefined){
        return formattedWords.join(' ') + ',';
      }else{
        return school;
      }
     } else {
      return "";
    }

  }

  processNewsFeedData(data: any): void {
    this.isLastPage = data.last;
    this.totalRecords = data.total_records;
    data.content.forEach(post => {
      post['filtered_attachments'] = [];
      const imageList = post.attachments.flatMap(s => s.type === 'image' ? s : []);
      const videoList = post.attachments.flatMap(s => s.type === 'video' ? s : []);
      const audioList = post.attachments.flatMap(s => s.type === 'audio' ? s : []);
      const docList = post.attachments.flatMap(s => s.type === 'doc' ? s : []);
      post['filtered_attachments'] = imageList && imageList.length ?
        [...imageList[0]] : videoList && videoList.length ? [...videoList[0]] : audioList && audioList.length ? [...audioList[0]] :
          docList && docList.length ? [...docList[0]] : [];
      if (EVENT_TYPE[post.event_type.toUpperCase()] === 'response') {
        // post.event_tagline = post.topic_group_size === 1 ? 'and Team ' : '';
        post.event_tagline = post.user_id === this.userInfo.user_id ? 'have participated in' : 'participated in';
      }
      post['winner_notes'] = this.helperService.getWinnerNotes(post);
    });
  }

  openAnnouncementResponses(): void {
    const modelRef = this.modalService.open(AnnouncementResponsesComponent, {
      centered: true,
      scrollable: true,
      backdrop: 'static',
      size: 'xl',
      windowClass: 'modal-challenge'
    });
    modelRef.componentInstance.data = this.latestBulletinBoard;
    modelRef.componentInstance.fromPage = 'center_panel';
    // modelRef.componentInstance._page = 'MyChallenges';
    modelRef.componentInstance.isResponseSelect = true;
    modelRef.result.then(res => {
      if (res === 'center_panel') {
        this.page = 1;
        // this.newsFeedData = [];
        this.getLatestAnnouncementComments();
      }

    });

  }
  getLatestAnnouncementComments(): void {
    this.commentsList = [];
    this.isLoading = true;
    const payload = {
      announcement_id: this.latestBulletinBoard.id,
      noofcomments: 2
    };
    this.studentHelperService.getAnnouncementComments(payload).subscribe(res => {
      this.isLoading = false;

      if (this.userType === 'admin') {
        this.commentsList = res;
        // console.log("admin", this.commentsList);

      } else {
        this.commentsList = res;
        // console.log("student", this.commentsList);
      }
    }, () => this.isLoading = false);
  }
  getLatestChallengeComments(event_id: any): void {
    this.isLoading = true;
    this.resCommentsList = [];
    const uniqueArrayOfObjects = event_id.filter(
      (object, index, self) => index === self.findIndex((obj) => obj.event_id === object.event_id)
    );
    uniqueArrayOfObjects.forEach((element, index) => {
      const payload = {
        topic_response_id: element.event_id,
        noofcomments: 2
      };
      this.studentHelperService.getResponses(payload).subscribe(res => {
        this.isLoading = false;
        // || this.userInfo.user_id === this.currentChallenge.buddy_id
        if (this.userType === 'admin') {
          // this.resCommentsList.push(res);
          this.resCommentsList.push(res);
          // console.log(this.resCommentsList, "this is the admin list");

        } else {
          // .filter(comment => !comment.is_reported)
          res['topic_id'] = element.event_id;
          this.addObjectIfNotExists(this.resCommentsList, res);
        }
      }, () => this.isLoading = false);
    });

  }

  checkBadgeType(comment:any){
    if(comment.attachments[0].item_name === "Bronze" ){
      return 'badging-less-bronze'
    }else if(comment.attachments[0].item_name === "Silver" ){
      return 'badging-less-silver'
    }else if(comment.attachments[0].item_name === "Gold" ){
      return 'badging-less-gold'
    }else if(comment.attachments[0].item_name === "Platinum" ){
      return 'badging-less-platinum'
    }else if(comment.attachments[0].item_name === "Grandmaster" ){
      return 'badging-less-grand-master'
    }
  }

  addObjectIfNotExists(array, newObj) {
    const topicIdExists = array.some((obj) => obj.topic_id === newObj.topic_id);

    if (!topicIdExists) {
      this.resCommentsList.push(newObj);
    }
  }

  openBuddyProfile(buddie: any, userId: number): void {
    const modalRef = this.modalService.open(userId == this.userInfo.user_id ? MySpaceComponent : ViewOtherProfileComponent, {
      centered: true,
      backdrop: 'static',
      size: 'xl',
      windowClass: 'custom-modal'
    });
    if (userId != this.userInfo.user_id) {
      modalRef.componentInstance.data = { userId };
    }
  }

  checkBadgeComment(com: any) {
    if (com !== undefined) {
      if (com.attachments !== null) {
        const abc = com.attachments.some(att => att.is_teacher === 1);
        if (abc === true) {
          return true;
        } else {
          return false;
        }
      } else {
        return false;
      }
    } else false;
  }

  onChangeCommunity(): void {
    this.isFilterLoading = true;
    const payload = {
      community_id: this.filterForm.get('byCommunity').value[0].community_id,
      topic_status: 'Open'
    };
    this.studentHelperService.getChallengesByCommunityId(payload).subscribe(res => {
      this.isFilterLoading = false;
      this.challengesList = res[0];
      this.challengesList = orderBy(this.challengesList, ['topic_name'], ['asc']);
    });
  }
  onChangeValue(value: any): void {
    // this.filterForm.get('buddy_id').setValue(null);
    if (value && value.trim()) {
      const property = SEARCH_TYPE[this.searchType];
      this.getMyBuddies({ [property]: value });
    } else {
      this.getMyBuddies({});
    }
  }
  getBuddyProfileId(buddie) {
    this.budyId = buddie.user_id
    // this.filterForm.buddy_id=
    this.filterForm.get('buddy_id').setValue(buddie.display_name);
  }
  getMyBuddies(payload: any) {
    this.isUsersLoading = true;
    this.studentHelperService.getMyBuddies(payload).subscribe((resp) => {
      this.alluserDetails = resp;
      this.isUsersLoading = false;
    }, () => this.isUsersLoading = false);
  }
  onCheck(control: string, subControl: string): void {
    // subControl.substr(0, subControl.indexOf('&'))
    // subControl.substr(subControl.indexOf('&') + 1, subControl.length)
    const payload = {
      id: this.userInfo.user_id
      // id: 1416
    }
    // console.log("com",this.communitiesList);
    if (control !== 'checkDate') {
      if (this.filterForm.get(control).value) {
        this.filterForm.get(subControl).enable();
        if (control === 'checkChallenge' && this.filterForm.get(control).value && (!this.filterForm.get('byCommunity').value || this.filterForm.get('byCommunity').value.length === 0)) {
          this.filterForm.get('checkCommunity').setValue(true);
          this.filterForm.get('byCommunity').setValue(
            this.communitiesList.filter(community => community.community_id === Number(this.userCommunityPreference.value)).map(({ community_id, community_name }) => ({ community_id, community_name }))
          );
          this.onChangeCommunity();
        }
        if (control === 'checkgroup') {
          this.studentHelperService.getGroupDetails(payload).subscribe(res => {
            this.isFilterLoading = false;
            this.groupListData = res;
            // console.log(res);
            // this.groupListData = orderBy(this.groupListData, ['group_name'], ['asc']);
          });
          this.filterForm.get('checkgroup').setValue(true);
        }
        if (control === 'checkBuddies') {
          this.filterForm.get('checkBuddies').setValue(true);
        }
        if (control == "checkclass") {
          this.classListData = this.userInfo.details.responsibilities
          this.filterForm.get('checkclass').setValue(true);

        }
      }
      else {
        this.filterForm.get(subControl).disable();
      }
    } else {
      if (this.filterForm.get(control).value) {
        this.filterForm.get('startDate').enable();
        this.filterForm.get('endDate').enable();
      } else {
        this.filterForm.get('startDate').disable();
        this.filterForm.get('endDate').disable();
      }
    }
  }

  onChangeStartDate(event: any): void {
    if (event) {
      this.setEndDate = this.helperService.getSpotlightFormattedEndMinDate(event, 1);
    }
  }

  onChangeEndDate(event: any) {
    if (event) {
      this.setStartDate = this.helperService.getSpotlightFormattedEndMinDate(event, -1);
    }
  }

  applyFilter(): void {
    const filterFormData = this.filterForm.getRawValue();
    this.filterList.forEach(_filter => {
      if (filterFormData[_filter.checkName]) {
        // console.log("_filter.checkName",_filter.checkName);

        if (_filter.checkName === 'checkCommunity' && filterFormData[_filter.searchKeyword] && filterFormData[_filter.searchKeyword].length > 0) {
          this.newsFeedFilterPayload[_filter.searchKeyword] = filterFormData[_filter.searchKeyword][0].community_id;
          _filter.checked = true;
        } else if (_filter.checkName === 'checkChallenge' && filterFormData[_filter.searchKeyword] && filterFormData[_filter.searchKeyword].length > 0) {
          this.newsFeedFilterPayload[_filter.searchKeyword] = filterFormData[_filter.searchKeyword].map(_chall => _chall.topic_id);
          _filter.checked = true;
        } else if (_filter.checkName === 'checkDate' && filterFormData['startDate']) {
          this.newsFeedFilterPayload['startDate'] = this.helperService.getFormattedDateToBind(filterFormData['startDate']);
          this.newsFeedFilterPayload['endDate'] = this.helperService.getFormattedDateToBind(filterFormData['endDate']);
          _filter.checked = true;
        } else if (_filter.checkName === 'isWinner' && filterFormData[_filter.searchKeyword]) {
          this.newsFeedFilterPayload[_filter.searchKeyword] = filterFormData[_filter.searchKeyword];
          _filter.checked = true;
        }
        else if (_filter.checkName === 'checkgroup' && filterFormData[_filter.searchKeyword] && filterFormData[_filter.searchKeyword].length > 0) {
          this.newsFeedFilterPayload[_filter.searchKeyword] = filterFormData[_filter.searchKeyword][0].id;
          _filter.checked = true;
        } else if (_filter.checkName === 'buddy_id' && filterFormData[_filter.searchKeyword] && filterFormData[_filter.searchKeyword].length > 0) {
          this.newsFeedFilterPayload[_filter.searchKeyword] = this.budyId;
          _filter.checked = true;
        } else if (_filter.checkName === 'checkclass' && filterFormData[_filter.searchKeyword] && filterFormData[_filter.searchKeyword].length > 0) {
          this.newsFeedFilterPayload[_filter.searchKeyword] = filterFormData[_filter.searchKeyword];
          _filter.checked = true;
        }
      }
    });
    if (!isEmpty(this.newsFeedFilterPayload)) {
      this.isFilterApplied = true;
      this.page = 1;
      this.newsFeedData = [];
      this.callNewsFeedDataService();
    }
    this.filterPopup.close();
  }

  commonFilterLogic(_filter: any): void {
    if (_filter.checkName !== 'checkDate') {
      this.filterForm.get(_filter['searchKeyword']).reset();
      delete this.newsFeedFilterPayload[_filter['searchKeyword']];
    } else {
      this.filterForm.get('startDate').reset();
      this.filterForm.get('endDate').reset();
      delete this.newsFeedFilterPayload['startDate'];
      delete this.newsFeedFilterPayload['endDate'];
      this.setStartDate = this.helperService.getLastDateByDays(1);
      this.setEndDate = this.minDate;
      this.filterForm.get('endDate').setValue(this.helperService.getSpotlightFormattedStartMinDate());
    }
    _filter.checked = false;
    this.filterForm.get(_filter['checkName']).setValue(false);
  }

  removeFilter(_filter: any) {
    this.page = 1;
    this.newsFeedData = [];
    this.commonFilterLogic(_filter);
    this.callNewsFeedDataService();
  }

  resetFilter(): void {
    this.challengesList = [];
    this.filterList.forEach(_filter => {
      // if (_filter.checked) {
      this.commonFilterLogic(_filter);
      // }
    });
    this.startDate = this.helperService.getLastDateByDays(7);
    if (this.isFilterApplied) {
      this.page = 1;
      this.newsFeedData = [];
      this.callNewsFeedDataService();
    }
  }

  closeOrCancelFilter(): void {
    this.filterPopup.close();
  }

  onChangeMinimizeOrMaximizeView(): void {
    this.minimizeOrMaximizeView = !this.minimizeOrMaximizeView;
    if (this.bulletinBoardPreference) {
      const payload = {
        id: this.bulletinBoardPreference.id,
        user: this.userInfo.user_id,
        value: this.minimizeOrMaximizeView ? '1' : '0'
      };
      this.isLoading = true;
      this.studentHelperService.updatePreference(payload).subscribe(res => {
        this.isLoading = false;
        if (res) {
          this.bulletinBoardPreference = res;
          this.store$.dispatch(new UserDetailsAction({ userId: this.userInfo.user_id, _page: '' }));
        }
      }, () => this.isLoading = false);
    } else {
      this.isLoading = true;
      const payload = {
        ...PREFERENCES.BULLETIN_BOARD,
        user: this.userInfo.user_id,
        value: this.minimizeOrMaximizeView ? '1' : '0',
        is_active: 1
      };
      this.studentHelperService.createPreference(payload).subscribe(res => {
        this.isLoading = false;
        if (res) {
          this.bulletinBoardPreference = res;
          this.store$.dispatch(new UserDetailsAction({ userId: this.userInfo.user_id, _page: '' }));
        }
      }, () => this.isLoading = false);
    }
  }

  studentCommunityInfo() {
    const payload = {
      "user_id": this.userId
    }
    this.isQuestLoader = true;
    this.studentHelperService.getTeacherDashboardStudentData(payload).subscribe(res => {
      this.datainfo = res.data;
      this.dataQuest = this.datainfo.reduce((result, obj1) => {
        if (this.communitiesList.some(obj2 => obj2.community_id === obj1.community_id)) {
          result.push(obj1);
        }
        return result;
      }, []);
      this.isQuestLoader = false;

    }, err => {
      this.isQuestLoader = false;
    })

  }
  navigatetoQuest(userList) {
    console.log(userList);
    const community = userList
    this.router.navigate(['/auth/student/quest'], { state: { data: community } });
  }

  openOrCloseLeaderBoardPopup(): void {
    this.toggleLeaderBoard = !this.toggleLeaderBoard;
  }
  // check the selected votes from the list
  checkForReal(data) {
    if (data !== undefined && data.attachments.length !== 0) {
      if (data.attachments[0].rating_reaction.length !== 0) {
        if (data.attachments[0].rating_reaction.includes('For Real')) {
          return "For Real";
        }
      }
    }
  }

  checkRad(data) {
    if (data !== undefined && data.attachments.length !== 0) {
      if (data.attachments[0].rating_reaction.length !== 0) {
        if (data.attachments[0].rating_reaction.includes('Rad')) {
          return "Rad";
        }
      }
    }
  }

  checkOriginal(data) {
    if (data !== undefined && data.attachments.length !== 0) {
      if (data.attachments[0].rating_reaction.length !== 0) {
        if (data.attachments[0].rating_reaction.includes('OG')) {
          return "OG";
        }
      }
    }
  }



  ngOnDestroy(): void {
    this.subscriptions.next();
    this.subscriptions.complete();
    this.subscription.unsubscribe();
  }
}
