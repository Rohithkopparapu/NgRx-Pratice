import {Component, ElementRef, EventEmitter, Input, OnChanges, OnDestroy, Output, SimpleChanges, ViewChild} from '@angular/core';
import {SocketUtilService} from '../../socket-util.service';
import {Message} from '../../../../shared/model/message.model';
import * as moment from 'moment/moment';
import {Store} from '@ngrx/store';
import {AuthState} from '../../../../shared/store/auth.model';
import {onlineSocketUsers, userInfo} from 'src/app/shared/store/auth.selector';
import {Subject} from 'rxjs';
import {takeUntil} from 'rxjs/operators';
import {StudentHelperService} from '../../student-helper.service';
import {ITEMS_PER_PAGE} from '../../../../shared/constants/pagination.constants';
import {CHAT_TYPE} from '../../../../shared/constants/constant';

@Component({
  selector: 'app-chat',
  templateUrl: './chat.component.html',
  styleUrls: ['./chat.component.scss']
})
export class ChatComponent implements OnChanges, OnDestroy {

  isLoading = false;
  page = 1;
  pageSize = ITEMS_PER_PAGE + 10;
  isLastPage: boolean;
  totalRecords = 0;
  isBlockScroll: boolean;
  subscriptions = new Subject<void>();
  @ViewChild('textMessage', {static: false}) textMessage: ElementRef;
  @ViewChild('scrollContainer', {static: false}) scrollContainer: ElementRef;
  @Input() data;
  @Output() modalPopupEmitter = new EventEmitter<any>();
  @Output() closeEmitter = new EventEmitter<boolean>();
  userInfo: any;
  buddyDetails: any;
  messagesList: Message[];
  message: Message;
  minimizeOrMaximize = true;
  onlineUsersList: any;
  toggled = false;

  constructor(private socketUtilService: SocketUtilService, private store$: Store<AuthState>, private studentHelperService: StudentHelperService) {
    this.store$.select(userInfo)
      .pipe(takeUntil(this.subscriptions))
      .subscribe(res => this.userInfo = res);
    this.store$.select(onlineSocketUsers)
      .pipe(takeUntil(this.subscriptions))
      .subscribe(res => this.onlineUsersList = res);
    this.insertOnlineChatData();
    // this.getChatHistoryByUser()
  }

  onScroll(event: any) { // temporary
    if (event.target.scrollTop <= 35 && !this.isBlockScroll && !this.isLastPage) {
      // console.log(event.target.offsetHeight, event.target.scrollTop, event.target.scrollHeight);
      this.isBlockScroll = true;
      this.page += 1;
      this.getChatHistoryByUser();
    }
  }

  onSendMessage(): void {
    let messageValue = this.textMessage.nativeElement.value.trim();
    messageValue = messageValue.lastIndexOf('/n') !== -1 ? messageValue.substr(0, messageValue.length - 2) : messageValue;
    if (messageValue === '') {
      return;
    }
    this.message = new Message(null, this.userInfo.user_id, this.buddyDetails.user_id, messageValue, moment(),
      this.userInfo.display_name, this.userInfo.avatar_image_url, CHAT_TYPE.ONE_TO_ONE);
    this.messagesList.push(this.message);
    this.socketUtilService.sendMessage(this.message);
    this.textMessage.nativeElement.value = '';
    const payload = {
                      from_user_id: this.userInfo.user_id, 
                      to_user_id: this.buddyDetails.user_id,
                      message: messageValue,
                      status: "delivered",
                      // read_status:0
                      // created_at: moment().format('YYYY-MM-DD HH:MM:SS')
                    };
    this.isLoading = true;
    this.studentHelperService.getSaveChat(payload).subscribe(res => {
      this.isLoading = false;
      if (res && res.status === 'success') {
        this.isLastPage = res.last;
        this.totalRecords = res.total;
        this.isBlockScroll = false;
      }
    }, () => this.isLoading = false);
  }

  closeChat(): void {
    this.socketUtilService.buddyDetails.next();
    this.closeEmitter.emit(false);
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes.data) {
      const data = changes.data.currentValue;
      this.messagesList = [];
      // this.messagesList = this.buddyDetails && this.buddyDetails.user_id !== data.buddyDetails.user_id ? [] : this.messagesList;
      this.buddyDetails = data.buddyDetails;
      this.getChatHistoryByUser(); // temporary
      this.minimizeOrMaximize = true;
      this.socketUtilService.buddyDetails.next(this.buddyDetails);
      // console.log("fgjhdfg",this.buddyDetails);
    }
  }

  getChatHistoryByUser(): void {
    // const payload = {userId: this.buddyDetails.user_id, pageNumber: this.page, pageSize: this.pageSize};
    const payload = {userId: this.buddyDetails.user_id};
    this.isLoading = true;
    this.studentHelperService.getChatHistory(payload).subscribe(res => {
      this.isLoading = false;
      if (res && res.status === 'success') {
        this.isLastPage = res.last;
        this.totalRecords = res.total;
        this.insertOfflineChatData(res.data);
        this.isBlockScroll = false;
      }
      
    }, () => this.isLoading = false);
  }

  insertOnlineChatData(): void {
    this.socketUtilService.getMessage().subscribe((message: Message) => {
      if (this.buddyDetails.user_id === message.from_user_id) {
        this.messagesList.push(message);
      }
    });
  }

  insertOfflineChatData(data: any[]): void {
    if (data.length) {
      this.messagesList.unshift(...data);
    }
  }

  openProfilePopup(): void {
    if (this.minimizeOrMaximize) {
      this.modalPopupEmitter.emit({modalName: 'profile', modalData: this.buddyDetails});
    } else {
      this.minimizeOrMaximizeChatBox();
    }
  }

  minimizeOrMaximizeChatBox(): void {
    this.minimizeOrMaximize = !this.minimizeOrMaximize;
  }

  addEmoji($event: any) {
    this.textMessage.nativeElement.value += $event.char;
  }

  ngOnDestroy(): void {
    this.subscriptions.next();
    this.subscriptions.complete();
    // this.socketUtilService.buddyDetails.next();
    // this.socketUtilService.buddyDetails.complete();
  }

  scrollToBottom(): void {
    if (this.scrollContainer && this.scrollContainer.nativeElement) {
      this.scrollContainer.nativeElement.scrollTop = this.scrollContainer.nativeElement.scrollHeight;
    }
  }

  isMessageThead(index: number): boolean {
    if (index !== 0 && this.messagesList && this.messagesList.length) {
      return (this.messagesList[index - 1].from_user_id === this.messagesList[index].from_user_id || this.messagesList[index - 1].to_user_id === this.messagesList[index].to_user_id);
    }
  }
}
