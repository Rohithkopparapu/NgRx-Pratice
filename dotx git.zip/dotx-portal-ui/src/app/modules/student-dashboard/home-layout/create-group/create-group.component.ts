import { Component, OnInit } from '@angular/core';
import {NgbActiveModal, NgbModal, NgbModalOptions} from '@ng-bootstrap/ng-bootstrap';
import {StudentHelperService} from '../../student-helper.service';
import {HelperService} from '../../../../shared/services/helper.service';
import {Store} from '@ngrx/store';
import {AuthState} from '../../../../shared/store/auth.model';
// import {EditStudentProfileComponent} from '../edit-student-profile/edit-student-profile.component';
import {NOTIFICATION_TYPES, SEARCH_TYPE} from '../../../../shared/constants/constant';
import {MyChallengesPopupComponent} from '../../../../shared/component/my-challenges-popup/my-challenges-popup.component';
import {MyQuestPopupComponent} from '../../../../shared/component/my-quest-popup/my-quest-popup.component';
import {FileUploadComponent} from '../../../../shared/component/file-upload/file-upload.component';
import {ImageVideoViewComponent} from '../../../../shared/component/image-video-view/image-video-view.component';
import {ViewOtherProfileComponent} from '../../../../shared/component/view-other-profile/view-other-profile.component';
import {InviteBuddyByEmailComponent} from '../../../../shared/component/invite-buddy-by-email/invite-buddy-by-email.component';
import {SetUserDetail} from '../../../../shared/store/auth.action';
import {SendMessagePopupComponent} from '../../../../shared/component/send-message-popup/send-message-popup.component';
import {BadgesDotcoinsPopupComponent} from '../../../../shared/component/badges-dotcoins-popup/badges-dotcoins-popup.component';
import {debounceTime, distinctUntilChanged, takeUntil} from 'rxjs/operators';
import {myPortfolio, onlineSocketUsers, userInfo} from 'src/app/shared/store/auth.selector';
import {Subject} from 'rxjs';
import {FormControl, FormGroup, Validators} from '@angular/forms';
import { CertificationsPopupComponent } from 'src/app/shared/component/certifications-popup/certifications-popup.component';

@Component({
  selector: 'app-create-group',
  templateUrl: './create-group.component.html',
  styleUrls: ['./create-group.component.scss']
})
export class CreateGroupComponent implements OnInit {

  constructor(private studentHelperService: StudentHelperService,
    public activeModal: NgbActiveModal,
    public _uhs: HelperService,
    private modalService: NgbModal,
    private store$: Store<AuthState>) { 
      
    }

  ngOnInit() {
  }

}
