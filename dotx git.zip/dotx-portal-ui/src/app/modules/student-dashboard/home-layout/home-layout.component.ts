import {Component, OnDestroy, OnInit} from '@angular/core';
import {StudentHelperService} from '../student-helper.service';
import {MySpaceComponent} from '../header-section/my-space/my-space.component';
import {ViewOtherProfileComponent} from '../../../shared/component/view-other-profile/view-other-profile.component';
import {NgbModal} from '@ng-bootstrap/ng-bootstrap';
import {Store} from '@ngrx/store';
import {AuthState} from '../../../shared/store/auth.model';
import {takeUntil} from 'rxjs/operators';
import { userInfo } from 'src/app/shared/store/auth.selector';
import {Subject} from 'rxjs';
import {SoloChallengeModelComponent} from '../../../shared/component/solo-challenge-model/solo-challenge-model.component';
import {GroupChallengeModelComponent} from '../../../shared/component/group-challenge-model/group-challenge-model.component';

@Component({
  selector: 'app-home-layout',
  templateUrl: './home-layout.component.html',
  styleUrls: ['./home-layout.component.scss']
})
export class HomeLayoutComponent implements OnInit, OnDestroy {
  private subscriptions = new Subject<void>();
  toggleLeaderBoard = true;
  userInfo: any;
  isEnableChat: boolean;
  chatInputData: any;
  selectedBuddy: any;

  constructor(private studentHelperService: StudentHelperService, private modalService: NgbModal, private store$: Store<AuthState>) {
    this.store$.select(userInfo)
      .pipe(takeUntil(this.subscriptions))
      .subscribe(res => this.userInfo = res);
  }

  ngOnInit() {
    // this.socketUtilService.notificationMessage
    //   .subscribe(notif => {
    //     if (notif) {
    //       this.rightPanel.getBuddiesList()
    //         .pipe(takeUntil(this.subscriptions))
    //         .subscribe(usersList => {
    //         const user = usersList.find(u => u.user_id === notif.from);
    //         this.openChatWindow(user);
    //       });
    //     }
    //   });
  }

  openBuddyProfile(buddie): void {
    const modalRef = this.modalService.open(buddie.user_id == this.userInfo.user_id ? MySpaceComponent : ViewOtherProfileComponent, {
      centered: true,
      backdrop: 'static',
      size: 'xl',
      windowClass: 'custom-modal'
    });
    if (buddie.user_id != this.userInfo.user_id) {
      modalRef.componentInstance.data = { userId: buddie.user_id };
    }
  }

  openOrCloseLeaderBoardPopup(): void {
    this.toggleLeaderBoard = !this.toggleLeaderBoard;
  }

  openChatWindow($event: any) {
    if (!this.selectedBuddy || $event.user_id !== this.selectedBuddy.user_id) {
      this.isEnableChat = true;
      this.selectedBuddy = $event;
      this.chatInputData = {buddyDetails: $event};
      console.log("nn",this.selectedBuddy);
      
    }
    console.log("bvbv",$event);
  }

  openChallenge(challenge: any): any {
    const data = {
      challenge
    };
    const component = challenge.topic_group_size === 1 ? SoloChallengeModelComponent : GroupChallengeModelComponent;
    const modelRef = this.modalService.open(component, {
      centered: true,
      scrollable: true,
      backdrop: 'static',
      keyboard: false,
      size: 'xl',
      windowClass: 'modal-challenge'
    });
    modelRef.componentInstance.data = data;
  }

  openModalPopup($event: any): void {
    if ($event.modalName === 'profile') {
      this.openBuddyProfile($event.modalData);
    } else if ($event.modalName === 'challengeView') {
      this.openChallenge($event.modalData);
    }
  }

  ngOnDestroy(): void {
    this.subscriptions.next();
    this.subscriptions.complete();
  }

  resetChatWindow(): void {
    this.selectedBuddy = null;
    this.isEnableChat = false;
  }
}
