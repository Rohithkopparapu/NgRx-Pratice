import {NgModule} from '@angular/core';
import {SharedModule} from '../../../shared/shared.module';
import {NgMultiSelectDropDownModule} from 'ng-multiselect-dropdown';
import {HomeLayoutRoutingModule} from './home-layout-routing.module';
import {HomeLayoutComponent} from './home-layout.component';
import {LeftPanelComponent} from './left-panel/left-panel.component';
import {CenterPanelComponent} from './center-panel/center-panel.component';
import {RightPanelComponent} from './right-panel/right-panel.component';
import {ChatComponent} from './chat/chat.component';
import { CreateGroupComponent } from './create-group/create-group.component';

@NgModule({
  declarations: [
    HomeLayoutComponent,
    LeftPanelComponent,
    CenterPanelComponent,
    RightPanelComponent,
    ChatComponent,
    CreateGroupComponent
  ],
  imports: [
    HomeLayoutRoutingModule,
    SharedModule,
    NgMultiSelectDropDownModule
  ]
})
export class HomeLayoutModule {
}
