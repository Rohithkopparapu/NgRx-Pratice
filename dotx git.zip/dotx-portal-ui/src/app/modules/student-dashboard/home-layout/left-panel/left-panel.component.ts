import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { StudentHelperService } from '../../student-helper.service';
import { HelperService } from '../../../../shared/services/helper.service';
import { Router } from '@angular/router';
import { Subject, Subscription } from 'rxjs';
import { AuthState } from 'src/app/shared/store/auth.model';
import { Store } from '@ngrx/store';
import { myPortfolio, userInfo } from 'src/app/shared/store/auth.selector';
import { takeUntil } from 'rxjs/operators';
import * as moment from 'moment';
import { DataService } from '../../../../shared/services/data.service';
@Component({
  selector: 'app-left-panel',
  templateUrl: './left-panel.component.html',
  styleUrls: ['./left-panel.component.scss']
})
export class LeftPanelComponent implements OnInit {

  @Output() modalPopupEmitter = new EventEmitter<any>();
  private subscription: Subscription;
  latestChallengesList: any[];
  isChallengeLoader = false;
  private subscriptions = new Subject<void>();
  userInfo: any;
  userId: any;
  data: any = [];
  isQuestLoader: boolean = false;
  communitiesList: any = [];
  datainfo: any;
  schoolName: string ="";
  address: string = "";
  getLatestCommunityData: any;
  constructor(private studentHelperService: StudentHelperService, private _uhs: HelperService, private router: Router, private dataService: DataService,
    private store$: Store<AuthState>) {
    this.store$.select(userInfo)
      .pipe(takeUntil(this.subscriptions))
      .subscribe(res => {
        this.userInfo = res;
        console.log(this.userInfo);

        this.userId = this.userInfo.user_id;
      });
    this.subscription = this.dataService.refreshComponent$.subscribe(() => {
      this.refreshComponentLogic();
    });
  }


  ngOnInit() {
    this.getCommunities();
    this.getLatestChallenges();
    // this.getLatestCommunity();
    this.schoolName = this.userInfo.school_name;
  }

  refreshComponentLogic() {
    this.schoolName = sessionStorage.getItem("school_name");
  }

  ngOnDestroy() {
    this.subscription.unsubscribe();
  }

  getLatestCommunity(){
    this.studentHelperService.getLastestCommunity().subscribe(res => {
      this.getLatestCommunityData = res;
      console.log(res);
    })
  }

  navigateToComm(){
    // const res = JSON.parse(sessionStorage.getItem('subsribedCommunities'));
    // if(res && res.my_communities.length){
    //   res.my_communities.forEach(element => {
    //     if(element.is_competition === 1){
    //       this.router.navigate(['/auth/student/community/join'],{state: {data: element}});
    //     }else{
    //       this.router.navigate(['/auth/student/community/join'],{state: {data: element}});
    //     }
    //   });
    // }
              this.router.navigate(['/auth/student/community/join'],{state: {data: "41"}});
  }

  getLatestChallenges(): void {
    this.isChallengeLoader = true;
    this.studentHelperService.getLatestChallenges().subscribe((res: any[]) => {
      this.isChallengeLoader = false;
      this.latestChallengesList = this._uhs.getOnlyImageFromChallenges(res);
    }, () => this.isChallengeLoader = false);
  }

  navigateToCommunity(): void {
    this.router.navigate(['/auth/student/challenge']);
  }

  getCommunities(): void {
    // this.studentHelperService.getAllCommunitiesNew().subscribe(res => {
      const res = JSON.parse(sessionStorage.getItem('subsribedCommunities'));
      if (res && res.my_communities.length) {
        let arr1 = res.my_communities.filter(s =>
          !s.combo && moment(moment(s.community_start_date).format('YYYY-MM-DD')).isSameOrBefore(moment().format('YYYY-MM-DD'))).sort((a, b) => a.community_name.localeCompare(b.community_name));
        // this.getquestLevelCertificate();
        if (this.userInfo.dot_registration_id !== null) {
          this.communitiesList = arr1.filter(community => (community.community_id && community.is_grade_wise === 1));
          setTimeout(() => {
            this.studentCommunityInfo();
          }, 2000);
        } else if (this.userInfo.dot_registration_id === null) {
          this.communitiesList = arr1.filter(community => (community.is_certified === 0));
          setTimeout(() => {
            this.studentCommunityInfo();
          }, 2000);
        }
      }

    // });
  }

  formatSchool() {
    let schoolAddr;
    let school = sessionStorage.getItem("school_name");
    if (school !== null) {
      const words = school.split(' ');
      const formattedWords = words.map(word => word.charAt(0).toUpperCase() + word.slice(1));
      if (this.userInfo.details !== null) {
        if(this.userInfo.details.school_ids !== undefined){
          schoolAddr = this.userInfo.details.school_ids.find(x => x.name === school);
        }else{
          schoolAddr = {
            "address": "",
            "id": null,
            "name": ""
        }
        }    
      }
      if(schoolAddr !== undefined){
        this.address = schoolAddr.address;
      }else{
        this.address = ""
      }
      // this.address = schoolAddr.address;
      if(this.userInfo.details !== null && this.userInfo.details.school_ids !== undefined){
        return formattedWords.join(' ') + ',';
      }else{
        return school;
      }
    } else {
      return "";
    }

  }

  studentCommunityInfo() {
    const payload = {
      "user_id": this.userId
    }
    this.isQuestLoader = true;
    this.studentHelperService.getTeacherDashboardStudentData(payload).subscribe(res => {
      if(res){
      this.datainfo = res.data;
      this.data = this.datainfo.filter(obj1 =>
        this.communitiesList.some(obj2 => obj2.community_id === obj1.community_id)
      );
      this.isQuestLoader = false;
      }
    }, (err) => {
      this.isQuestLoader = false;
    })

  }
  getProgressPercentage(compLevels: any, totalLevels: any) {
    const percentage = (compLevels / totalLevels) * 100;
    return Math.round(percentage);
  }
  navigatetoQuest(userList) {
    console.log(userList);
    const community = userList
    this.router.navigate(['/auth/student/quest'], { state: { data: community } });
  }

}
