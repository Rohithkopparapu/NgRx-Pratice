import {
  AfterViewInit,
  Component,
  ElementRef,
  EventEmitter,
  Input,
  OnDestroy,
  OnInit,
  Output,
  ViewChild
} from '@angular/core';
import {StudentHelperService} from '../../student-helper.service';
import {MySpaceComponent} from '../../header-section/my-space/my-space.component';
import {NgbModal} from '@ng-bootstrap/ng-bootstrap';
import {SEARCH_TYPE} from '../../../../shared/constants/constant';
import {AuthState} from '../../../../shared/store/auth.model';
import {Store} from '@ngrx/store';
import {fromEvent, Subject} from 'rxjs';
import {isLoggedIn, onlineSocketUsers, userInfo} from '../../../../shared/store/auth.selector';
import {debounceTime, distinctUntilChanged, map, takeUntil} from 'rxjs/operators';
import { CreateGroupComponent } from '../create-group/create-group.component';

@Component({
  selector: 'app-right-panel',
  templateUrl: './right-panel.component.html',
  styleUrls: ['./right-panel.component.scss']
})
export class RightPanelComponent implements OnInit, AfterViewInit, OnDestroy {

  private subscriptions = new Subject<void>();
  @ViewChild('searchName', {static: false}) searchBuddie: ElementRef;
  @Input() inputData: any;
  @Output() leaderboardEmitter = new EventEmitter<boolean>();
  @Output() buddieDetailsEmitter = new EventEmitter<boolean>();
  

  userInfo: any;
  isBroadCastLoader = false;
  isBuddyLoader = false;
  broadcastInfoList: any[];
  buddiesList: any[];
  onlineUsersList: any;
  onlineUsersCount: any[];
  isLoggedIn: boolean;
  dotRegistrationId: any;

  constructor(private studentHelperService: StudentHelperService, private modalService: NgbModal, private store$: Store<AuthState>) {
    this.store$.select(isLoggedIn)
      .pipe(takeUntil(this.subscriptions))
      .subscribe(res => this.isLoggedIn = res);
    this.store$.select(userInfo)
      .pipe(takeUntil(this.subscriptions))
      .subscribe(res => this.userInfo = res);
    this.store$.select(onlineSocketUsers)
      .pipe(takeUntil(this.subscriptions))
      .subscribe(res => {
        this.onlineUsersList = res;
        this.onlineUsersCount = Object.keys(this.onlineUsersList).filter(user => Number(user) !== this.userInfo.user_id);
        if (this.isLoggedIn) {
          this.getOnlineUsersData();
        }
      });
  }

  ngOnInit() {
    this.getBroadcastInfo();
    this.dotRegistrationId = this.userInfo.dot_registration_id;
  }

  openOrCloseLeaderBoardPopup(): void {
    this.leaderboardEmitter.emit(true);
  }

  openChatWindow(buddy: any): void {
    this.buddieDetailsEmitter.emit(buddy);

  }

  getBroadcastInfo(): void {
    this.isBroadCastLoader = true;
    this.studentHelperService.retrieveBroadcastData().subscribe(res => {
      this.isBroadCastLoader = false;
      this.broadcastInfoList = res;
    }, () => this.isBroadCastLoader = false);
  }

  openDashboard(): void {
    const modalRef = this.modalService.open(MySpaceComponent, {
      centered: true,
      backdrop: 'static',
      size: 'xl',
      windowClass: 'custom-modal edit-student-dashboard'
    });
    modalRef.componentInstance.myBuddiesFlag = false;
    modalRef.componentInstance.myNotificationsFlag = true;
    modalRef.componentInstance.switchNotifications = 'Broadcast';
  }

  // createGroup(): void {
  //   const modalRef = this.modalService.open(CreateGroupComponent, {
  //     centered: true,
  //     backdrop: 'static',
  //     size: 'xl',
  //     windowClass: 'custom-modal edit-student-dashboard'
  //   });
  //   // modalRef.componentInstance.myBuddiesFlag = false;
  //   // modalRef.componentInstance.myNotificationsFlag = true;
  //   // modalRef.componentInstance.switchNotifications = 'Broadcast';
  // }

  onSearchBuddy(searchName: string) {
    if (searchName && searchName.trim()) {
      const property = SEARCH_TYPE['Name'];
      this.searchBuddies({[property] : searchName});
    } else {
      this.getOnlineUsersData();
    }
  }

  searchBuddies(payload: any) {
    this.isBuddyLoader = true;
    this.studentHelperService.getMyBuddies(payload).subscribe((resp) => {
      this.isBuddyLoader = false;
      this.buddiesList = resp;
    }, () => this.isBuddyLoader = false);
  }

  getOnlineUsersData(): void {
    // if (this.onlineUsersCount && this.onlineUsersCount.length) {
      const payload = {userIds: this.onlineUsersCount};
      this.isBuddyLoader = true;
      this.studentHelperService.getUserList(payload).subscribe(res => {
        this.isBuddyLoader = false;
        this.buddiesList = res.data;
      }, () => this.isBuddyLoader = false);
    // }
  }

  ngAfterViewInit(): void {
    fromEvent(this.searchBuddie.nativeElement, 'keyup')
      .pipe(
        map((event: Event) => (event.target as HTMLInputElement).value),
        debounceTime(500),
        distinctUntilChanged()).subscribe(search => {
      this.onSearchBuddy(search);
    });
  }

  ngOnDestroy(): void {
    this.subscriptions.next();
    this.subscriptions.complete();
  }
}
