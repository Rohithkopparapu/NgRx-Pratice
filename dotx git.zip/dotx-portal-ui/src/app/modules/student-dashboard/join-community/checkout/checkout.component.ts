import {Component, ElementRef, OnDestroy, OnInit, ViewChild} from '@angular/core';
import {StudentHelperService} from '../../student-helper.service';
import {HelperService} from '../../../../shared/services/helper.service';
import {takeUntil} from 'rxjs/operators';
import {Store} from '@ngrx/store';
import {AuthState} from '../../../../shared/store/auth.model';
import {cartItems, userInfo} from 'src/app/shared/store/auth.selector';
import {Subject} from 'rxjs';
import {ToastrService} from 'ngx-toastr';
import {SetCartItems} from '../../../../shared/store/auth.action';

@Component({
  selector: 'app-checkout',
  templateUrl: './checkout.component.html',
  styleUrls: ['./checkout.component.scss']
})
export class CheckoutComponent implements OnInit, OnDestroy {

  private subscriptions = new Subject<void>();
  PAYMENT_URL = StudentHelperService.PAYMENT_URL;
  @ViewChild('couponCode', {static: false}) couponCode: ElementRef;
  isLoading = false;
  userInfo: any;
  oGCartList: any[] = [];
  cartList: any[] = [];
  couponList: any[] = [];
  totalAmount = 0;
  discountAmount = 0;
  coupon: any;
  isAppliedCoupon = false;

  constructor(private studentHelperService: StudentHelperService, private helperService: HelperService, private store$: Store<AuthState>,
              private toastrService: ToastrService) {
    this.store$.select(userInfo)
      .pipe(takeUntil(this.subscriptions))
      .subscribe(res => {
        if (res) {
          this.userInfo = res;
        }
      });
    this.store$.select(cartItems)
      .pipe(takeUntil(this.subscriptions))
      .subscribe(res => {
        if (res && res.length) {
          this.oGCartList = res;
        }
      });
  }

  ngOnInit() {
    this.getCommunities();
  }

  getCommunities(): void {
    this.isLoading = true;
    this.studentHelperService.getAllCommunities().subscribe(res => {
      this.isLoading = false;
      if (res && res.length) {
        const communitiesList = res.filter(_c => !_c.is_combo || (_c.is_combo && !_c.is_joining_fee_paid));
        communitiesList.forEach(_c => {
          _c['is_add_cart'] = this.oGCartList.length ? this.replaceCommunity(_c) : 0;
          _c['community_image'] = _c.attachments.filter(i => i.attachment_title === 'community_image')[0];
          _c['coupon'] = null;
        });
        this.cartList = communitiesList.filter(_c => _c.is_add_cart);
        this.calculateAmount();
        this.getCouponCodesList();
      }
    }, () => this.isLoading = false);
  }

  getCouponCodesList(): void {
    const payload = {community_id: this.cartList.map(_c => _c.community_id), is_public: 1};
    this.isLoading = true;
    this.studentHelperService.getCouponsList(payload).subscribe(res => {
      this.isLoading = false;
      if (res) {
        this.couponList = res;
      }
    }, () => this.isLoading = false);
  }

  validateCoupon(couponCode: string): void {
    if (couponCode === '') {
      this.toastrService.warning('Please enter Coupon code');
      return;
    }
    if (this.cartList.length === 0) {
      this.toastrService.warning('Please Add Item to the cart to Apply coupon');
      return;
    }
    const payload = {community_id: this.cartList.map(_c => _c.community_id), coupon: couponCode};
    this.isLoading = true;
    this.studentHelperService.validateCouponCode(payload).subscribe(res => {
      this.isLoading = false;
      if (res && res.status === 'success') {
        this.isAppliedCoupon = true;
        this.applyCoupon(res, false);
        this.toastrService.success('Valid Coupon code');
      } else {
        this.removeCoupon();
        this.toastrService.warning('Invalid Coupon code');
      }
    }, () => this.isLoading = false);
  }

  removeCouponValue(): void {
    this.isAppliedCoupon = false;
    this.couponCode.nativeElement.value = '';
  }

  removeItemFromCart(index: number): void {
    this.totalAmount -= this.checkOffer(this.cartList[index]) ? this.cartList[index].offer_discount : this.cartList[index].joining_fee;
    if (this.coupon && this.coupon.community_id.some(_coupon => _coupon === this.cartList[index].community_id)) {
      this.discountAmount -= this.coupon.discount_price;
    }
    this.cartList = this.cartList.filter((_c, i) => i !== index);
    this.getCouponCodesList();
  }

  applyCoupon(coupon: any, removeInput: boolean): void {
    if (this.cartList.length === 0) {
      this.toastrService.warning('Please Add Item to the cart to Apply coupon');
      return;
    }
    if (removeInput) {
      this.removeCouponValue();
    }
    this.coupon = coupon;
    this.discountAmount = coupon.discount_price;
    this.cartList.forEach(_c => _c['coupon'] = (coupon.community_id.some(_coupon => _coupon === _c.community_id)) ? coupon  : null );
  }

  removeCoupon(): void {
    this.coupon = null;
    this.discountAmount = 0;
    this.cartList.forEach(_c => {
      _c['coupon'] = null;
    });
  }

  calculateAmount(): void {
    this.totalAmount = this.cartList.map(_c => this.checkOffer(_c) ? _c.offer_discount : _c.joining_fee).reduce((a, b) => a + b, 0);
  }

  checkOffer(community: any): boolean {
    return this.helperService.checkOfferDate(community);
  }

  processCart(): string {
    return JSON.stringify(this.cartList.map(({community_id, coupon}) => ({community_id, coupon})));
  }

  doOneMoreCheck(_coupon): boolean {
    return this.coupon.community_id.some(_c => _c === _coupon.community_id[0]);
  }

  replaceCommunity(newCommunityData: any): number {
    const indexValue = this.oGCartList.findIndex(_cart => _cart.community_id === newCommunityData.community_id);
    if (indexValue !== -1) {
      return 1;
    }
    return 0;
  }

  ngOnDestroy(): void {
    this.store$.dispatch(new SetCartItems(this.cartList));
    this.subscriptions.next();
    this.subscriptions.complete();
  }
}
