import {Component, ElementRef, OnDestroy, OnInit, ViewChild} from '@angular/core';
import {interval, Subject} from 'rxjs';
import {Store} from '@ngrx/store';
import {AuthState, Portfolio} from '../../../shared/store/auth.model';
import {NEW_JOINER_TOUR, PREFERENCES} from '../../../shared/constants/constant';
import {SetCartItems, SetMyPortfolio, SetUser, UserDetailsAction} from '../../../shared/store/auth.action';
import {StudentHelperService} from '../student-helper.service';
import {ActivatedRoute, Router} from '@angular/router';
import * as moment from 'moment';
import {map, takeUntil} from 'rxjs/operators';
import {cartItems, myPortfolio, userInfo, userResponse} from 'src/app/shared/store/auth.selector';
import {ToastrService} from 'ngx-toastr';
import {NgbActiveModal, NgbModal} from '@ng-bootstrap/ng-bootstrap';
import {SuccessPaymentComponent} from '../payment-gateway/success-payment/success-payment.component';
import {FailurePaymentComponent} from '../payment-gateway/failure-payment/failure-payment.component';
import {HelperService} from '../../../shared/services/helper.service';
import { Subscription } from 'rxjs';
import { DataService } from '../../../shared/services/data.service';
import { FileUploadComponent } from 'src/app/shared/component/file-upload/file-upload.component';
import { CommunitySwitchService } from 'src/app/shared/services/community-switch.service';
import { PostRefreshService } from 'src/app/shared/services/post-refresh.service';
import { ChallengeCompletedComponent } from 'src/app/shared/component/level-completed/challenge-completed.component';
import Swiper, { Autoplay, Navigation, Pagination } from 'swiper';
import { ViewResponsesComponent } from 'src/app/shared/component/view-responses/view-responses.component';
import { ImageVideoViewComponent } from 'src/app/shared/component/image-video-view/image-video-view.component';


@Component({
  selector: 'app-join-community',
  templateUrl: './join-community.component.html',
  styleUrls: ['./join-community.component.css'],
})
export class JoinCommunityComponent implements OnInit, OnDestroy {
  private subscriptions = new Subject<void>();
  @ViewChild('finalSubmit', { static: false }) finalSubmitView: ElementRef;
  private subscription: Subscription;
  private subscriptionnew : Subscription;
  private subscriptionrefresh : Subscription;
  isLoading = false;
  userInfo: any;
  upcomingCommunityList: any[];
  belowCommunitiesList: any[];
  bannerCommunity: any;
  userCommunityPreference: any;
  communityTour = JSON.parse(JSON.stringify(NEW_JOINER_TOUR.COMMUNITY_TOUR));
  userResponse: any;
  myPortfolio: Portfolio;
  countdownTimer: string;
  oGCartList: any[] = [];
  cartList: any[] = [];
  newData: any;
  backButon: boolean=true;
  bannerCommunityOther: any;
  belowCommunitiesListOther: any=[];
  upcomingCommunityListOther: any=[];
  communityDetailsList: any = [];
  totalActivities: any;
  totalChallenges: any;
  dotCoins: any;
  activatedFlag: string = "myCommunities";
  showExploreTab:boolean = false;
  certifiedCommunitiesList: any[];
  competitionCommunitiesList:any[];
  isCertified: boolean = false;
  challenge: any;
  is_competition: boolean = false;
  competitionFlag: boolean = false;
  showScrollButton: boolean = false;
  allCommunities: any=[];
  showCart: boolean = false;
  levelId: any;
  viewFinalResponse: boolean;
  checkMandatory: number;
  flag: boolean = false;
  videoFiles = [];
  imageFiles = [];
  docFiles = []; 
  audioFiles=[];
  message: any ='';
  isEnable: boolean;
  communityId: any;
  isHomeAccess: any;
  userType: any;
  consentBox: any = false;
  currentUrl: string;
  allCommunitiesList: any;
  currentComm: any;
  toggled = false;
  data: any;
  showExplore: boolean = false;
  getcurrentCommunity: any;
  subscribedCommunitiesList: any= [];


   constructor(private store$: Store<AuthState>, private studentHelperService: StudentHelperService, private router: Router,
              private toastrService: ToastrService, private modalService: NgbModal, private activatedRoute: ActivatedRoute,private refreshService: PostRefreshService,
              private activeModal: NgbActiveModal,private helperService: HelperService,private dataService: DataService, private commService : CommunitySwitchService) {
    this.verifyTransactionDetails();
    this.store$.select(userResponse)
      .pipe(takeUntil(this.subscriptions))
      .subscribe(res => this.userResponse = res);
    this.store$.select(userInfo)
      .pipe(takeUntil(this.subscriptions))
      .subscribe(res => {
        if (res) {
          this.userInfo = res;
          const userCommunityPreference = res.preferences.find(s => s.entity_name === PREFERENCES.COMMUNITY.ENTITY_NAME && s.entity_type === PREFERENCES.COMMUNITY.ENTITY_TYPE);
          this.userCommunityPreference = userCommunityPreference ? userCommunityPreference : null;
        }
      });
    this.store$.select(myPortfolio)
      .pipe(takeUntil(this.subscriptions))
      .subscribe(res => this.myPortfolio = res);
    this.store$.select(cartItems)
      .pipe(takeUntil(this.subscriptions))
      .subscribe(res => {
        if (res && res.length) {
          this.oGCartList = res;
        }
      });
      this.subscription = this.dataService.refreshComponent$.subscribe(() => {
        this.refreshComponentLogic();
      });
      this.subscriptionnew = this.commService.refreshComponentinfo$.subscribe(() => {
        this.flag = false;
        this.showExploreTab = false;
        this.ngOnInit();
      });

      this.subscriptionrefresh = this.refreshService.postrefreshComponent$.subscribe(() => {
        this.refreshComponentLogic();
      });
      const data = this.router.getCurrentNavigation().extras.state;
      if (data !== undefined && data.data !== undefined) {
        // if(data.data.is_competition === 1){
        //   this.submitActionNew(data.data);
        // }else{
        //   this.getCommunitiesForB2B();
        //   this.showExplore = true;
        // 
       

        this.getCommunitiesToSave(data);
      }
      if(data !== undefined && data.path !== undefined && data.path === "Quest"){
        if(data.community !== undefined){
          this.submitActionNew(data.community);
        }
      }
  }

  ngOnInit(): void {
    /* same code for B2C or B2B for student and teacher */
    // if(this.userInfo.dot_registration_id){
      this.getCommunitiesForB2B();
      this.initSwiperSlider();
    // }else{
    //   this.getCommunitiesForB2B();
    // }
        
  }
  refreshComponentLogic(){
    // this.constructor();
    this.getCommunitiesForB2B();
  }

  getCommunities(): void {
    let closestDate = moment('1970-01-01').format('YYYY-MM-DD');
    let closestCommunity = {};
    const upcomingList = [];
    const activeList = [];
    this.isLoading = true;
    this.studentHelperService.getAllCommunities().subscribe(res => {
      if (res && res.length) {
        const filterResponse = res.filter(_c => !_c.is_combo || (_c.is_combo && !_c.is_joining_fee_paid));
        filterResponse.forEach(s => {
          s['is_add_cart'] = this.oGCartList.length ? this.replaceCommunity(s) : 0;
          s['community_image'] = s.attachments.filter(i => i.attachment_title === 'community_image')[0];
          if (moment(moment(s.community_start_date).format('YYYY-MM-DD')).isSameOrBefore(moment().format('YYYY-MM-DD')) && s.num_challenges > 0) {
            activeList.push(s);
          } else {
            if(s.is_intro!==1) upcomingList.push(s);
          }
        });
        this.cartList = filterResponse.filter(_c => _c.is_add_cart);
        // moment(startDate).isSameOrBefore(moment().format('YYYY-MM-DD')) &&
        activeList.forEach(item => {
          const startDate = moment(item.community_start_date).format('YYYY-MM-DD');
          if (moment(startDate).isSameOrAfter(closestDate)) {
            closestDate = item.community_start_date;
            closestCommunity = item;
           
            
          }
        });
        this.bannerCommunity = res ? res[0] : activeList[0];
        // this.bannerCommunity = closestCommunity ? closestCommunity : activeList[0];
        this.belowCommunitiesList = activeList.filter(community => community.community_id !== this.bannerCommunity.community_id);
        this.upcomingCommunityList = upcomingList;
      }
      this.isLoading = false;
    }, () => this.isLoading = false);
  }
  getCommunitiesForB2B(): void {
    let closestDate = moment('1970-01-01').format('YYYY-MM-DD');
    let closestCommunity = {};
    const upcomingList = [];
    const activeList = [];
    const otheractiveList = [];
    const otherupcomingList = [];
    
    this.isLoading = true;
    this.studentHelperService.getAllCommunitiesNew().subscribe(res => {
      this.isLoading = false;
      if (res) {
        sessionStorage.setItem('subsribedCommunities',JSON.stringify(res));
        this.subscribedCommunitiesList = res.my_communities.sort((a, b) => a.community_name.localeCompare(b.community_name));
        let otherCommunity = res.other_communities;
        let myCommunity = res.my_communities;  
        if(otherCommunity !== undefined){
          this.allCommunitiesList = otherCommunity.concat(myCommunity);
        }else{
          this.allCommunitiesList = myCommunity;
        }  
        const filterResponse = myCommunity.filter(_c => !_c.is_combo || (_c.is_combo && !_c.is_joining_fee_paid));
        filterResponse.forEach(s => {
          s['is_add_cart'] = this.oGCartList.length ? this.replaceCommunity(s) : 0;
          s['community_image'] = s.attachments.filter(i => i.attachment_title === 'community_image')[0];
          if (moment(moment(s.community_start_date).format('YYYY-MM-DD')).isSameOrBefore(moment().format('YYYY-MM-DD')) ) {
            activeList.push(s);
          } else {
            if(s.is_intro!==1) upcomingList.push(s);
          }
        });
        let adcart=filterResponse.filter(_c => _c.is_add_cart)
        adcart.length>0?this.cartList =adcart:'';
        // moment(startDate).isSameOrBefore(moment().format('YYYY-MM-DD')) &&
        activeList.forEach(item => {
          const startDate = moment(item.community_start_date).format('YYYY-MM-DD');
          if (moment(startDate).isSameOrAfter(closestDate)) {
            closestDate = item.community_start_date;
            closestCommunity = item;
          }
        });
        this.bannerCommunity = res ? res[0] : activeList[0];
        // this.bannerCommunity = closestCommunity ? closestCommunity : activeList[0];community.community_id !== this.bannerCommunity.community_id
        if(this.userInfo.user_type !== 'teacher'){
          if(this.userInfo.dot_registration_id !== null){
            this.belowCommunitiesList = activeList.filter(community => (community.community_id && (community.is_grade_wise === 1 || community.is_certified === 0)) );
            this.certifiedCommunitiesList = filterResponse.filter(community => ( community.is_certified === 1 && community.is_grade_wise === 0) );
          }else if(this.userInfo.dot_registration_id === null){
            this.belowCommunitiesList = activeList.filter(community => (community.is_certified === 0) );
            this.certifiedCommunitiesList = filterResponse.filter(community => ( community.is_certified === 1));
          }
        }else{
          this.belowCommunitiesList = activeList;
        }
      
        this.upcomingCommunityList = upcomingList;
      
      // other communities
      if(otherCommunity !== undefined){
      const filterResponseOther = otherCommunity.filter(_c => !_c.is_combo || (_c.is_combo && !_c.is_joining_fee_paid));
      filterResponseOther.forEach(s => {
          s['is_add_cart'] = this.oGCartList.length ? this.replaceCommunity(s) : 0;
          s['community_image'] = s.attachments.filter(i => i.attachment_title === 'community_image')[0];
          if (moment(moment(s.community_start_date).format('YYYY-MM-DD')).isSameOrBefore(moment().format('YYYY-MM-DD')) ) {
            otheractiveList.push(s);
          } else {
            if(s.is_intro!==1) otherupcomingList.push(s);
          }
        });
      }
        let otherData=filterResponse.filter(_c => _c.is_add_cart);
        otherData.length>0 ?this.cartList.push(otherData):'';
        // moment(startDate).isSameOrBefore(moment().format('YYYY-MM-DD')) &&
        otheractiveList.forEach(item => {
          const startDate = moment(item.community_start_date).format('YYYY-MM-DD');
          if (moment(startDate).isSameOrAfter(closestDate)) {
            closestDate = item.community_start_date;
            closestCommunity = item;
          }
        });
        this.bannerCommunityOther = res ? res[0] : otheractiveList[0];
        // this.bannerCommunity = closestCommunity ? closestCommunity : activeList[0];
        this.belowCommunitiesListOther = otheractiveList.filter(community => community.community_id && community.is_competition !== 1);
        this.competitionCommunitiesList = otheractiveList.filter(community => community.community_id && community.is_competition === 1)
        this.upcomingCommunityListOther = otherupcomingList;

        if(this.belowCommunitiesList.length > 0 || this.upcomingCommunityList.length > 0){
          this.activatedFlag = "myCommunities";
          this.backButon = true;
          this.competitionFlag = false;
        }else if(this.certifiedCommunitiesList.length > 0){
          this.activatedFlag = "certifiedCommunities";
          this.competitionFlag = false;
        }else if(this.competitionCommunitiesList.length > 0){
          this.activatedFlag = "competitionCommunities"
          this.competitionFlag = true;
          this.backButon = false;
        }else{
          this.activatedFlag = "otherCommunities";
          this.backButon = false;
          this.competitionFlag = false;
        }

      }
      if(this.showExplore === true){
        this.activatedFlag = "competitionCommunities";
        this.isCertified = false;
        this.backButon = false;
        this.competitionFlag = true;
        this.flag = false;
        this.showExploreTab = false;
      }
      
    }, () => this.isLoading = false);
  }

  getDiscountPercentage(offerPrice,actualPrice){
    const discountprice = actualPrice-offerPrice;
    const discountPercentage = (discountprice/actualPrice)*100;
    return Math.round(discountPercentage)+'% off';
  }
  scrollToTop() {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }
  

  submitAction(community: any): void {
    if(community){
      sessionStorage.setItem('toastFlag', 'Community');
    }
    // this.store$.dispatch(new UserDetailsAction({userId: this.userInfo.user_id, _page: 'community'}));
    // this.studentHelperService.getBadgesAndDotCoins(this.userInfo.user_id);
    if (!community.is_community_user && !community.is_joining_fee_paid && community.joining_fee > 0) {
      this.addItemToCart(community);
    } else {
      this.joinOrUpdateCommunity(community);
    }
    this.allCommunities.push(community);
  }
  submitActionNew(community: any): void {
    this.getcurrentCommunity = community;
    window.scrollTo({
      top: 0,
      behavior: 'smooth'
    });
    if(community.is_competition === 1 && community.is_joining_fee_paid === 1){
      this.isLoading = true;
    const payload = {
      id: this.userCommunityPreference !== null ? this.userCommunityPreference.id : community.community_id,
      user: this.userInfo.user_id,
      value: community.community_id.toString()
    };
    this.studentHelperService.updatePreference(payload).subscribe(res => {
      this.isLoading = false;
      if (res) {
        this.userCommunityPreference = res;
        this.flag = true;
        this.showExploreTab = true;
        this.store$.dispatch(new UserDetailsAction({ userId: this.userInfo.user_id, _page: 'quest' }));
        if(community.is_competition === 1){
          this.studentHelperService.getCompetitionCommunityInfo(community.community_id).subscribe(res => {
            this.challenge = res;
            this.is_competition = true;
            this.initSwiperSlider();
              this.getChallengeDetailsPublic(this.challenge.topic_id);
          },(err:any)=>{
            this.toastrService.remove(0);
            this.toastrService.clear();
            if(err){
              this.is_competition = false;
              this.flag = false;
              this.showExploreTab = false;
                  this.toastrService.error(err['error']['msg']);
              
            }
            
          })
        }
      }
    }, () => this.isLoading = false);
    }else{
    this.totalActivities = 0;
    this.totalChallenges = 0;
    this.dotCoins = 0;
    if (!community.is_community_user && !community.is_joining_fee_paid && community.joining_fee > 0) {
      this.newData=community;
      if(community.is_competition === 1){
        this.studentHelperService.getCompetitionCommunityInfo(community.community_id).subscribe(res => {
          this.challenge = res;
          this.is_competition = true;
          this.getCommunitiesListToStore();
            this.getChallengeDetailsPublic(this.challenge.topic_id);
        },(err:any)=>{
          if(err){
              this.toastrService.clear();
              setTimeout(() => {
                this.flag = false;
                this.showExploreTab = false;
                this.toastrService.error(err['error']['msg']);
              }, 500);
            
          }          
        })
      }else{
        this.studentHelperService.getCommunityDetailsInfo(community.community_id).subscribe(res =>{
          this.communityDetailsList =  res;
          this.is_competition = false;
          this.communityDetailsList.forEach(element => {
           this.totalActivities = element.activities + this.totalActivities;
           this.totalChallenges = element.challenges + this.totalChallenges;
           this.dotCoins = element.dotcoins + this.dotCoins;
           this.getCommunitiesListToStore();
          }); 
         })
      }
     
      this.showExploreTab = true;
    } else {
      this.joinOrUpdateCommunity(community);
      this.newData=[]
    }
    // this.newData=community
  }
  }

  getChallengeDetailsPublic(topicId): void {
    this.isLoading = true;
    this.studentHelperService.getTopicDetailsByIdPublic(topicId).subscribe(res => {
      this.isLoading = false;
      if (res) {
        this.levelId = res.level_id;
        // this.processResponse(res);
      }
    }, () => this.isLoading = false);
  }

  onUploadComment(evt, catagory, type) {
    const modalData = {
      headerName: 'Media',
      fileType: type,
      fileCategory: catagory,
      isMultipleFile: true
    };

    const modalRef = this.modalService.open(FileUploadComponent, {
      keyboard: false,
      backdrop: 'static',
      scrollable: true,
      windowClass: 'modal-cover modal-cover-fluid modal-upload'
    });
    modalRef.componentInstance.data = modalData;
    modalRef.result.then((res) => {
    }, (reason) => {
      if (reason && reason.length) {
        reason.forEach(file => {
          const fileExtension = file.file.split('.').pop();
          if (fileExtension.match(/(jpg|jpeg|png|gif)$/i)) {
            this.imageFiles.push({ ...file, type: 'image' });
          } else if (fileExtension.match(/(mp4|mov|wmv|avi|avchd|mp4|mpeg|webm)$/i)) {
            this.videoFiles.push({ ...file, type: 'video' });
          } else if(fileExtension.match(/(mp3|wav|aiff|flac|m4a|ogg|aac|wma|ape)$/i)){
            this.audioFiles.push({ ...file, type: 'audio' });
          }else {
            this.docFiles.push({ ...file, type: 'doc' });
          }
        });
      }
    });
  }

  handleSelection(event: any) {
    this.message += event.char;
  }

  deleteFiles(event: Event, file, type) {
    event.stopPropagation();
    if (type === 'video') {
      this.videoFiles = this.videoFiles.filter(item => item.file !== file.file);
    } else if (type === 'image') {
      this.imageFiles = this.imageFiles.filter(item => item.file !== file.file);
    } else if (type === 'doc') {
      this.docFiles = this.docFiles.filter(item => item.file !== file.file);
    }else if(type === 'audio'){
      this.audioFiles = this.audioFiles.filter(item => item.file !== file.file);
    }
  }



  acceptChallenge(): void {

    const payload = {
      community_id: this.communityId,
      user_id: this.userInfo.user_id,
      level_id: this.levelId ? this.challenge.level_id : '',
    };
    if (this.challenge.level_id === null) {
      const payload = {
        topic_id: this.challenge.topic_id
      };
      this.studentHelperService.JoinSoloChallenge(payload).subscribe(res => {
        this.challenge.topic_assign_id = res.topic_assign_id;
        // this.submitFinalComment();
        this.viewFinalResponse = true;
        setTimeout(() => this.finalSubmitView.nativeElement.scrollIntoView({ behavior: 'smooth' }),
          1);
      });
    } else {

      if (this.checkMandatory != 1) {
        // if (noOfMandatoryActivitiesPending.length === 0) {
        const params = { community_id: this.communityId, level_id: this.levelId };
        this.studentHelperService.getQuestTopics(params).subscribe(respose => {
          if (respose) {
            const pendingChallenges = respose.continue_challenges.concat(respose.recent_challenges);
            const noOfMandatoryChallengesPending = pendingChallenges.filter(x => x.is_mandatory === 1)
            if (this.userInfo.user_type === 'student') {
              if(this.challenge.is_classroom_reflection === 0){
              if (noOfMandatoryChallengesPending.length === 0) {
                const payload = {
                  topic_id: this.challenge.topic_id
                };
                this.studentHelperService.JoinSoloChallenge(payload).subscribe(res => {
                  this.challenge.topic_assign_id = res.topic_assign_id;
                  // this.submitFinalComment();
                  this.viewFinalResponse = true;
                  setTimeout(() => this.finalSubmitView.nativeElement.scrollIntoView({ behavior: 'smooth' }),
                    1);
                });
              } else {
                this.toastrService.warning("Complete the mandatory Challenges to proceed further");
              }
            }else{
               const payload1 = {
                  topic_id: this.challenge.topic_id
                };
                this.studentHelperService.JoinSoloChallenge(payload1).subscribe(res => {
                  this.challenge.topic_assign_id = res.topic_assign_id;
                  // this.submitFinalComment();
                  this.viewFinalResponse = true;
                  setTimeout(() => this.finalSubmitView.nativeElement.scrollIntoView({ behavior: 'smooth' }),
                    1);
                });
            }
            } else {
              const payload = {
                topic_id: this.challenge.topic_id
              };
              this.studentHelperService.JoinSoloChallenge(payload).subscribe(res => {
                this.challenge.topic_assign_id = res.topic_assign_id;
                // this.submitFinalComment();
                this.viewFinalResponse = true;
                setTimeout(() => this.finalSubmitView.nativeElement.scrollIntoView({ behavior: 'smooth' }),
                  1);
              });
            }
          }
        });

      } else {
        if (this.userInfo.user_type === "student") {
          this.studentHelperService.getQuestInfo(payload).subscribe(res => {

            const noOfMandatoryActivitiesPending = res.data.activities.filter(x => x.is_mandatory === 1 && x.status === "pending")
            if (noOfMandatoryActivitiesPending.length === 0) {
              const payload = {
                topic_id: this.challenge.topic_id
              };
              this.studentHelperService.JoinSoloChallenge(payload).subscribe(res => {
                this.challenge.topic_assign_id = res.topic_assign_id;
                this.viewFinalResponse = true;
                setTimeout(() => this.finalSubmitView.nativeElement.scrollIntoView({ behavior: 'smooth' }),
                  1);
              });
            } else {
              this.toastrService.warning("Complete the mandatory activities to proceed to Challenges");
            }
          });
        } else {
          const payload = {
            topic_id: this.challenge.topic_id
          };
          this.studentHelperService.JoinSoloChallenge(payload).subscribe(res => {
            this.challenge.topic_assign_id = res.topic_assign_id;
            this.viewFinalResponse = true;
            setTimeout(() => this.finalSubmitView.nativeElement.scrollIntoView({ behavior: 'smooth' }),
              1);
          });
        }
      }
    }

  }

  openViewerModel(type: string, url: string): void {
    const modalRef = this.modalService.open(ImageVideoViewComponent, {
      centered: true,
      size: 'lg'
    });
    modalRef.componentInstance.fileType = type;
    modalRef.componentInstance.fileUrl = url;
  }

  openDocument(event: any, fileUrl: string) {
    // event.stopPropagation();
    window.open(
      fileUrl,
      '_blank'
    );
  }

  closeModal() {
    this.activeModal.close({ status: "close" });
    this.refreshService.triggerRefresh();
  }

  submitFinalComment() {
    const TodayDate = moment().format('YYYY-MM-DD hh:mm:ss');
    const attachment = [...this.videoFiles, ...this.imageFiles, ...this.docFiles, ...this.audioFiles];
    if (!this.message || attachment.length === 0) {
      this.toastrService.warning('Please upload a file or write a description.');
      return false;
    } else {
      this.isLoading = true;
      const payload = {
        response_description: this.message.trim(),
        date_of_response: TodayDate,
        topic_assign: this.challenge.topic_assign_id,
        is_final_submit: 1,
        attachments: attachment
      };
      this.studentHelperService.addComments(payload).subscribe(res => {
        this.message = '';
        this.isLoading = false;
        if (res) {
          // this.store$.dispatch(new UserDetailsAction({userId: this.userInfo.user_id, _page: 'community'}));
          // this.studentHelperService.getBadgesAndDotCoins(this.userInfo.user_id);
          this.toastrService.success('Challenge successfully submitted');
          this.videoFiles = this.imageFiles = this.docFiles = [];
          this.refreshService.triggerRefresh();
        const comm =  this.allCommunitiesList.filter(x=> x.community_id === this.challenge.community_id)[0];
          if (comm.is_competition === 1) {
            const modelRef = this.modalService.open(ChallengeCompletedComponent, {
              centered: true,
              backdrop: 'static',
              size: 'md',
              windowClass: 'modal-challenge achievement-type',
            });
            modelRef.result.then(res => {
              if (res.status == "success") {
                this.getChallengeDetails(this.challenge.topic_id);
                setTimeout(() => {
                  this.viewOtherResponse();
                }, 1000);
              }
            });
          }
          // this.modalService.open(ChallengeSuccessComponent, {centered: true, size: 'lg', keyboard: false, backdrop: 'static', windowClass: 'bd-example-modal-lg modalCcongratulations-outer'});
        }
      }, err => this.isLoading = false);
    }
  }

  agreeConsentBox(event: any): void {
    this.consentBox = event.target.checked;
  }

  viewOtherResponse(): void {
    if (!this.isHomeAccess) {
      if (this.challenge.total_responses !== '0') {
        const modelRef = this.modalService.open(ViewResponsesComponent, {
          centered: true,
          scrollable: true,
          backdrop: 'static',
          size: 'xl',
          windowClass: 'modal-challenge'
        });
        modelRef.componentInstance.challenge = this.challenge;
        modelRef.componentInstance.userType = this.userInfo.user_type;
        modelRef.componentInstance.community = this.getcurrentCommunity;
        modelRef.result.then((res) => {
          setTimeout(() => {
            this.getChallengeDetails(this.challenge.topic_id);
          }, 1000);
        })

      } else {
        this.toastrService.warning('No Responses Found...');
      }
    } else {
      this.gotoSignup();
    }
  }

  
  gotoSignup(): void {
    this.toastrService.warning('Please Sign Up to explore more');
  }

  getChallengeDetails(topicId): void {
    this.isLoading = true;
    this.studentHelperService.getTopicDetailsById(topicId).subscribe(res => {
      this.isLoading = false;
      if (res) {
        this.levelId = res.level_id;
        this.communityId = res.community_id;
        this.checkMandatory = res.is_mandatory;
        this.processResponse(res);
      }
    }, () => this.isLoading = false);
  }

  processResponse(res: any): void {
    this.challenge = res;
    this.challenge.topic_end_date = moment(this.challenge.topic_end_date).format('ll');
    this.isEnable = moment(moment().format('ll')).isBetween(moment(this.challenge.topic_start_date).format('ll'), this.challenge.topic_end_date, undefined, '[]');
    this.challenge.topic_description = this.challenge.topic_description.replace(/&nbsp;/g, '');
    if (this.challenge && this.challenge.attachments && this.challenge.attachments.length) {
      this.challenge.attachments = this.challenge.attachments.filter(attach => (attach.attachment_title === 'challenge_image' || attach.attachment_title === 'challenge_video'));
    }
    this.initSwiperSlider();
  }

  initSwiperSlider() {
    setTimeout(() => {
      if (this.challenge.attachments.length > 1) {
        const swiper = new Swiper('.swiper.swiper-solo-challenge', {
          modules: [Navigation, Pagination, Autoplay],
          // Optional parameters
          loop: false,
          freeMode: true,

          // If we need pagination
          pagination: {
            clickable: true,
            el: '.swiper-pagination',
            type: 'bullets'
          },

          // autoplay: {
          //   delay: 2500,
          //   disableOnInteraction: false,
          //   pauseOnMouseEnter: true
          // },

          keyboard: {
            enabled: true,
            onlyInViewport: false,
          },

          // Navigation arrows
          navigation: {
            nextEl: '.swiper-button-next',
            prevEl: '.swiper-button-prev',
          },
        });
      } else {
        const swiper = new Swiper('.swiper.swiper-solo-challenge', {
          // Optional parameters
          enabled: false,
          navigation: {
            nextEl: null,
            prevEl: null,
          },
        });
      }
    });
  }

  back(){
    this.backButon = false;
    this.showExploreTab = false;
    this.activatedFlag = this.activatedFlag;

  }

  checkChallengeEndDate(challenge:any){
    challenge.topic_end_date = moment(challenge.topic_end_date).format('ll');
    const isEnable = moment(moment().format('ll')).isBetween(moment(challenge.topic_start_date).format('ll'), challenge.topic_end_date, undefined, '[]');
    return isEnable;
  }

  getCommunitiesToSave(data): void {
    this.studentHelperService.getAllCommunitiesNew().subscribe(res => {
      if(res){
      sessionStorage.setItem('subsribedCommunities',JSON.stringify(res));
      let otherCommunity = res.other_communities;
        let myCommunity = res.my_communities;  
        if(otherCommunity !== undefined){
          this.allCommunitiesList = otherCommunity.concat(myCommunity);
        }else{
          this.allCommunitiesList = myCommunity;
        } 

        const list = sessionStorage.getItem('subsribedCommunities');
        const myList = list !== null ? JSON.parse(list).my_communities : [];
        const commpCommunity = myList.find(x=> x.community_id ===  Number(data.data));
        if(commpCommunity !== undefined){
          this.submitActionNew(commpCommunity);
        }else{
          this.getCommunitiesForB2B();
          this.showExplore = true;
        }

      }
    })
}

  joinOrUpdateCommunity(community: any): void {
    if (community.redemption_dotcoins <= 0) {
      this.callCommunityService(community);
    } else {
      this.studentHelperService.getAchievements(this.userInfo.user_id).subscribe(res => {
        this.store$.dispatch(new SetMyPortfolio({ achievements: res && res.length ? res[0] : {}, badges: this.myPortfolio.badges }));
        if (res.length !== 0) {
          if (!(res && res.length) || (community.redemption_dotcoins && Number(res[0].total_dot_coins) < community.redemption_dotcoins)) {
            this.toastrService.warning('You don\'t have enough dotcoins to join community, these will be adjusted from future earnings');
          }
        }
        this.callCommunityService(community);
      },(err)=>{
      });
    }
  }

  callCommunityService(community: any): void {
    if (this.userCommunityPreference) {
      this.isLoading = true;
      const payload = {
        id: this.userCommunityPreference.id,
        user: this.userInfo.user_id,
        value: community.community_id.toString()
      };
      this.studentHelperService.updatePreference(payload).subscribe(res => {
        this.isLoading = false;
        if (res) {
          this.userCommunityPreference = res;
          this.store$.dispatch(new UserDetailsAction({userId: this.userInfo.user_id, _page: 'community'}));
          this.studentHelperService.getBadgesAndDotCoins(this.userInfo.user_id);
        }
      }, () => this.isLoading = false);
    } else {
      this.isLoading = true;
      const payload = {
        ...PREFERENCES.COMMUNITY,
        user: this.userInfo.user_id,
        value: community.community_id.toString(),
        is_active: 1
      };
      this.studentHelperService.createPreference(payload).subscribe(res => {
        this.isLoading = false;
        if (res) {
          this.userCommunityPreference = res;
          this.store$.dispatch(new UserDetailsAction({userId: this.userInfo.user_id, _page: 'community'}));
          this.studentHelperService.getBadgesAndDotCoins(this.userInfo.user_id);
        }
      }, () => this.isLoading = false);
    }
    this.isLoading = false;
  }

  nextStep(index: number): void {
    if (this.communityTour.length - 1 !== index) {
      this.communityTour[index].isView = false;
      this.communityTour[index + 1].isView = true;
    } else {
      const payload = Object.assign({}, this.userResponse);
      payload.is_firsttime_user = 0;
      this.store$.dispatch(new SetUser(payload));
    }
  }


  toggleTabs(data:any){
    if(data === "myCommunities"){
      this.activatedFlag = "myCommunities";
      this.isCertified = false;
      this.backButon = true;
      this.competitionFlag = false;
      this.flag = false;
      this.showExploreTab = false;
    }else if(data === "certifiedCommunities"){
      this.activatedFlag = "certifiedCommunities";
      this.isCertified = true;
      this.backButon = false;
      this.competitionFlag = false;
      this.flag = false;
      this.showExploreTab = false;
    }else if(data === "otherCommunities"){
      this.activatedFlag = "otherCommunities";
      this.isCertified = false;
      this.backButon = false;
      this.competitionFlag = false;
      this.flag = false;
      this.showExploreTab = false;
    }else{
      this.activatedFlag = "competitionCommunities";
      this.isCertified = false;
      this.backButon = false;
      this.competitionFlag = true;
      this.flag = false;
      this.showExploreTab = false;
    }
  }

  getCommunitiesListToStore(){
      this.studentHelperService.getAllCommunitiesNew().subscribe(res => {
        if(res){
        sessionStorage.setItem('subsribedCommunities',JSON.stringify(res));
        }
  });
}

  successPaymentPopup(): void {
    const modelRef = this.modalService.open(SuccessPaymentComponent, {
      centered: true,
      backdrop: 'static',
      size: 'sm'
    });
    modelRef.result.then(res => {
      if (res === 'success') {
        this.getCommunitiesListToStore();
        const urlObj = Number(window.location.href.split('=').pop());
        this.currentComm = this.allCommunitiesList.find(x => x.community_id === urlObj);
        this.router.navigate([], { relativeTo: this.activatedRoute, queryParams: {}, replaceUrl: true});
        if(this.currentComm.is_competition === 1){
        this.submitActionNew(this.currentComm);
        }
      }
    });
  }

  failurePaymentPopup(): void {
    const modelRef = this.modalService.open(FailurePaymentComponent, {
      centered: true,
      backdrop: 'static',
      size: 'sm'
    });
    modelRef.result.then(res => {
      if (res === 'close') {
        this.router.navigate([], { relativeTo: this.activatedRoute, queryParams: {}, replaceUrl: true});
        this.getCommunitiesForB2B();
      }
    });
  }

  openPaymentGateway(): void {
    const windowObjectRef = window.open('about:blank', 'payment_popup', 'popup');
  }

  verifyTransactionDetails() {
    this.activatedRoute.queryParams.subscribe(params => {
      if (params && params.status && params.t) {
        // this.isLoading = true;
        // const payload = { txnid: params.t };
        // this.studentHelperService.getTransactionDetails(payload).subscribe(res => {
        //   this.isLoading = false;
        // });
        if (params.status === 'success') {
          this.data = this.cartList[0];
          this.store$.dispatch(new SetCartItems([]));
          this.successPaymentPopup();
        } else if (params.status === 'failure') {
          this.failurePaymentPopup();
        }
      }
    });
  }

  getIsCountDownTimer(community: any): boolean {
    return moment(moment(community.community_start_date).format('YYYY-MM-DD')).isAfter(moment().format('YYYY-MM-DD'));
  }

  getCountDownTimer(community: any): string {
   const timer = interval(1000).pipe(
      takeUntil(this.subscriptions),
      map(x => this.helperService.calcDateDiff(new Date(community.community_start_date)))).subscribe(res => {
      this.countdownTimer = res;
      
    });
    timer.unsubscribe();
    return this.countdownTimer;
  }

  getButtonName(community: any): string {
    return community.status.toLowerCase() === 'suspend' ? 'Have a Break...' : community.status.toLowerCase() === 'closed'
      ? 'Community closed' : !community.is_community_user
      ? !community.is_joining_fee_paid && community.joining_fee > 0 ? 'Complete Registration' : this.getIsCountDownTimer(community) 
      ? this.getCountDownTimer(community) && community.is_intro 
      ? 'Explore Community' :this.getCountDownTimer(community): 'Join Community' : this.getCountDownTimer(community) && community.is_intro === 1 ? 'Take a Tour' : 'Continue' ;
  }
  
  isDisableCommunity(community: any): boolean {
    return community.status.toLowerCase() === 'suspend' || community.status.toLowerCase() === 'closed' || (community.is_joining_fee_paid && this.getIsCountDownTimer(community));
  }

  getClassName(community: any): string {
    return community.status.toLowerCase() === 'suspend' || community.status.toLowerCase() === 'closed' || community.is_community_user ? 'btn-c-secondary' : 'btn-c-primary';
  }

  replaceCommunity(newCommunityData: any): number {
    const indexValue = this.oGCartList.findIndex(_cart => _cart.community_id === newCommunityData.community_id);
    if (indexValue !== -1) {
      return 1;
    }
    return 0;
  }

  addItemToCart(community: any): void {
    const data = this.belowCommunitiesListOther.concat(this.competitionCommunitiesList);
    if (community.is_add_cart) {
      const communitiesinCart = data.filter(item =>  item.is_add_cart === 1);
      if(this.cartList.length === 0){
        const List = communitiesinCart;
        this.cartList = List.reduce((uniqueArray, obj) => {
          if (!uniqueArray.some(item => item.community_id === obj.community_id)) {
            uniqueArray.push(obj);
          }
          return uniqueArray;
        }, []);
      }
      this.showCart = true;
      window.scrollTo({
        top: 0,
        behavior: 'smooth'
      });
      this.toastrService.warning('Already in cart');
      return;
    }
    // if (this.cartList
    //   .some(_cart => (_cart.is_combo && _cart.child_community_ids.some(_child => _child === community.community_id) && !community.is_combo) ||
    //     (community.is_combo && community.child_community_ids.some(_child => _child === _cart.community_id)  && !_cart.is_combo))) {
    //   this.toastrService.warning('Community you are adding already be a part of Combo community');
    // } 
    else {
      community.is_add_cart = 1;
      const communitiesinCart = data.filter(item =>  item.is_add_cart === 1);
      this.cartList.push(community);
      const List = this.cartList.concat(communitiesinCart);
      this.cartList = List.reduce((uniqueArray, obj) => {
        // Check if ID is already in the result array
        if (!uniqueArray.some(item => item.community_id === obj.community_id)) {
          uniqueArray.push(obj);
        }
        return uniqueArray;
      }, []);
      window.scrollTo({
        top: 0,
        behavior: 'smooth'
      });
      this.toastrService.success('Item added to cart');
    }
  }

  getButton(data:any){
    const comm = this.cartList.find(item =>  item.community_id === data.community_id);
     if(comm !== undefined){
      return "Added to Cart"
     }else{
      return "Add to Cart"
     }
  }


  removeItemFromCart(index: number): void {
    // if (this.bannerCommunity['community_id'] === this.cartList[index].community_id) {
    //   this.bannerCommunity['is_add_cart'] = 0;
    // } else {
      if(this.cartList.length){
        this.cartList.forEach(_c => {
          if (_c.community_id === this.cartList[index].community_id) {
            _c.is_add_cart = 0;
          }
        });
      }
      if(this.belowCommunitiesListOther.length){
        this.belowCommunitiesListOther.forEach(_c => {
          if (_c.community_id === this.cartList[index].community_id) {
            _c.is_add_cart = 0;
          }
        });
      }
    this.cartList = this.cartList.filter((_c, i) => i !== index);
  }

  gotoCheckout(): void {
    this.router.navigate(['/auth/student/community/checkout']);
  }

  checkOffer(community: any): boolean {
    return this.helperService.checkOfferDate(community);
  }

  checkCommunityTabName(){
    let data = this.belowCommunitiesList.concat(this.upcomingCommunityList);
    if(data.length === 0){
      return "Communities"
    }else{
      return "Other Communities"
    }
  }
  onChangeCommunity(community: any, item): void {
      const data = this.subscribedCommunitiesList.find(x => x.community_id === Number(community.target.value));
      this.callCommunityService(data);
  }

  ngOnDestroy(): void {
    this.store$.dispatch(new SetCartItems(this.cartList));
    this.subscriptions.next();
    this.subscriptions.complete();
    this.subscription.unsubscribe();
    this.subscriptionnew.unsubscribe();
    this.subscriptionrefresh.unsubscribe();
  }
}
