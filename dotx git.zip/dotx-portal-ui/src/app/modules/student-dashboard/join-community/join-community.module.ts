import {NgModule} from '@angular/core';
import {SharedModule} from '../../../shared/shared.module';
import {JoinCommunityRoutingModule} from './join-community-routing.module';
import {JoinCommunityComponent} from './join-community.component';
import {CheckoutComponent} from './checkout/checkout.component';

@NgModule({
  declarations: [
    JoinCommunityComponent,
    CheckoutComponent
  ],
  imports: [
    JoinCommunityRoutingModule,
    SharedModule
  ]
})
export class JoinCommunityModule {}
