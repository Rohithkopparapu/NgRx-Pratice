import { Component } from '@angular/core';
import {NgbActiveModal} from '@ng-bootstrap/ng-bootstrap';
import {Router} from '@angular/router';

@Component({
  selector: 'app-failure-payment',
  templateUrl: './failure-payment.component.html',
  styleUrls: ['./failure-payment.component.scss']
})
export class FailurePaymentComponent {

  constructor(private activeModal: NgbActiveModal, private router: Router) { }

  closeModal() {
    this.activeModal.close('close');
  }

  gotoCheckout(): void {
    this.closeModal();
    this.router.navigate(['/auth/student/community/checkout']);
  }
}
