import {NgModule} from '@angular/core';
import {SuccessPaymentComponent} from './success-payment/success-payment.component';
import {FailurePaymentComponent} from './failure-payment/failure-payment.component';
import {ConfirmPaymentComponent} from './confirm-payment/confirm-payment.component';


@NgModule({
  declarations: [
    ConfirmPaymentComponent,
    SuccessPaymentComponent,
    FailurePaymentComponent
  ],
  imports: [],
  entryComponents: [
    ConfirmPaymentComponent,
    SuccessPaymentComponent,
    FailurePaymentComponent
  ]
})
export class PaymentModule {}
