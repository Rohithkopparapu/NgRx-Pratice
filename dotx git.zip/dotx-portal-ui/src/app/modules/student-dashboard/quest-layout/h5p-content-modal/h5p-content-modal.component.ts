import { AfterViewInit, Component, Input, OnInit } from '@angular/core';
import { SafeResourceUrl } from '@angular/platform-browser';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { QUEST_LAYOUT } from '../../../../shared/constants/constant';
import Swiper, { Navigation, Pagination } from 'swiper';
import { SoloChallengeModelComponent } from '../../../../shared/component/solo-challenge-model/solo-challenge-model.component';
import { GroupChallengeModelComponent } from '../../../../shared/component/group-challenge-model/group-challenge-model.component';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { StudentHelperService } from '../../student-helper.service';
import { AuthState } from '../../../../shared/store/auth.model';
import { Store } from '@ngrx/store';
import { userInfo } from '../../../../shared/store/auth.selector';
import { takeUntil } from 'rxjs/operators';
import { Subject } from 'rxjs';
import { ToastrService } from 'ngx-toastr';


declare const $: any;
@Component({
  selector: 'app-h5p-content-modal',
  templateUrl: './h5p-content-modal.component.html',
  styleUrls: ['./h5p-content-modal.component.scss']
})
export class H5pContentModalComponent implements OnInit, AfterViewInit {

  @Input() modalData;
  @Input() nextmodalData;
  @Input() pendingChallenges;
  @Input() previousLevelStatus;
  @Input() currentIndex;
  @Input() openActFromTable;
  @Input() startingFromIntro;
  @Input() viewsCount
  private subscriptions = new Subject<void>();
  h5pTitle: string;
  h5pUrl: SafeResourceUrl;
  h5pContentList: any[] = [];
  index: number = 0;
  flag: boolean = true;
  status: any;
  userInfo: any;
  currentActivityStatus: any;
  isMandatory: any;
  activity_id: any;
  dotCoins: any;
  usertype: any;
  views: any;
  nextActiviyView: any;
  isLoading: boolean = false;
  openNextAct:boolean = false;

  constructor(private ngbActiveModal: NgbActiveModal, private toastrService: ToastrService, private modalService: NgbModal, private store$: Store<AuthState>, private studentHelperService: StudentHelperService) {

    this.store$.select(userInfo)
      .pipe(takeUntil(this.subscriptions))
      .subscribe(res => {
        if (res) {
          this.userInfo = res;
        }
      });
  }

  ngOnInit() {
    this.usertype = JSON.parse(sessionStorage.getItem('auth'));
    if (!this.modalData.menuOrLayout) {
      this.h5pContentList = QUEST_LAYOUT.H5P_CONTENT_LIST[this.modalData.h5pContentKey];
      this.openH5pContent(this.h5pContentList[0]);
    } else {
      this.openH5pContent(this.modalData);

      console.log("this is list of data", this.modalData);

    }
  }

  openH5pContent(h5p: any): void {
    if (!this.modalData.menuOrLayout) {
      this.h5pUrl = `https://dotxprocom.h5p.com/content/${h5p.id}/embed`;
      this.h5pTitle = h5p.title;
      this.isMandatory = h5p.is_mandatory;
      this.status = h5p.status;
      this.dotCoins = h5p.dot_coins;
      this.views = this.viewsCount

    } else {
      this.h5pUrl = h5p.act_id;
      this.h5pTitle = h5p.act_name;
      this.isMandatory = h5p.is_mandatory;
      this.status = h5p.status;
      this.dotCoins = h5p.dot_coins;
      this.views = this.viewsCount
    }
  }

  getActivityViews(wp_activity_id) {
    const activityId = wp_activity_id
    const payload = {};
    payload['wp_activity_id'] = activityId;
    this.studentHelperService.getActivityViews(payload).subscribe(res => {
      if (res) {
        this.views = res.views
        this.flag = true;
      }
    })
  }

  openNextActivity(flag:any) {
    this.openNextAct = true;
    const payload = {
      "community_id": this.modalData.community.community_id,
      "user_id": this.userInfo.user_id,
      "activity_id": this.modalData.wp_activity_id,
      "level_id": this.modalData.questInfo.level_id
    }

    if (this.usertype.userInfo.user_type === 'student') {
      if (this.modalData.is_mandatory || this.modalData.is_intro) {
        this.isLoading = true;
        this.studentHelperService.getActivityInfo(payload).subscribe(res => {
          this.isLoading = false;
          if(flag === true){
            this.ngbActiveModal.close(true);
          }
          if (this.modalData.is_intro === 1) {
            this.currentActivityStatus = 1;
          } else {
            this.currentActivityStatus = res.activity_status
          }
          if (this.currentActivityStatus) {
            const noOfMandatoryActivities = this.nextmodalData.filter(x => x.is_mandatory === 1 && x.is_intro != 1)
            if (noOfMandatoryActivities.length <= 0) {
              this.flag = true;
            } else {
              this.flag = false;
            }
            if (!this.modalData.menuOrLayout) {
              this.h5pUrl = `https://dotxprocom.h5p.com/content/${this.nextmodalData.id}/embed`;
              this.h5pTitle = this.nextmodalData.title;
            } else {
              if (this.currentIndex < this.nextmodalData.length - 1) {
                if (this.modalData.is_intro === 1) {
                  this.currentIndex = this.currentIndex;
                  this.h5pUrl = this.nextmodalData[this.currentIndex].act_id;
                  this.h5pTitle = this.nextmodalData[this.currentIndex].act_name;
                  this.isMandatory = this.nextmodalData[this.currentIndex].is_mandatory;
                  this.status = this.nextmodalData[this.currentIndex].status;
                  this.dotCoins = this.nextmodalData[this.currentIndex].dot_coins;
                  this.modalData.wp_activity_id = this.nextmodalData[this.currentIndex].wp_activity_id;
                  if (this.modalData.wp_activity_id === this.nextmodalData[this.currentIndex].wp_activity_id) {
                    this.getActivityViews(this.modalData.wp_activity_id);
                  }
                  this.modalData.is_mandatory = this.nextmodalData[this.currentIndex].is_mandatory;
                  this.modalData.is_intro = 0;
                } else {
                  if (this.openActFromTable) {
                    if (this.startingFromIntro) {
                      this.currentIndex = this.currentIndex + 2;
                      this.h5pUrl = this.nextmodalData[this.currentIndex].act_id;
                      this.h5pTitle = this.nextmodalData[this.currentIndex].act_name;
                      this.isMandatory = this.nextmodalData[this.currentIndex].is_mandatory;
                      this.status = this.nextmodalData[this.currentIndex].status;
                      this.dotCoins = this.nextmodalData[this.currentIndex].dot_coins;
                      this.modalData.wp_activity_id = this.nextmodalData[this.currentIndex].wp_activity_id;
                      if (this.modalData.wp_activity_id === this.nextmodalData[this.currentIndex].wp_activity_id) {
                        this.getActivityViews(this.modalData.wp_activity_id);
                      }
                      this.modalData.is_mandatory = this.nextmodalData[this.currentIndex].is_mandatory;
                    } else {
                      this.currentIndex = this.currentIndex - 1;
                      this.h5pUrl = this.nextmodalData[this.currentIndex].act_id;
                      this.h5pTitle = this.nextmodalData[this.currentIndex].act_name;
                      this.isMandatory = this.nextmodalData[this.currentIndex].is_mandatory;
                      this.status = this.nextmodalData[this.currentIndex].status;
                      this.dotCoins = this.nextmodalData[this.currentIndex].dot_coins;
                      this.modalData.wp_activity_id = this.nextmodalData[this.currentIndex].wp_activity_id;
                      this.modalData.is_mandatory = this.nextmodalData[this.currentIndex].is_mandatory;
                      if (this.modalData.wp_activity_id === this.nextmodalData[this.currentIndex].wp_activity_id) {
                        this.getActivityViews(this.modalData.wp_activity_id);
                      }
                      this.modalData.is_intro = 0;
                    }
                    this.currentIndex = this.currentIndex - 1;
                    this.h5pUrl = this.nextmodalData[this.currentIndex].act_id;
                    this.h5pTitle = this.nextmodalData[this.currentIndex].act_name;
                    this.isMandatory = this.nextmodalData[this.currentIndex].is_mandatory;
                    this.status = this.nextmodalData[this.currentIndex].status;
                    this.dotCoins = this.nextmodalData[this.currentIndex].dot_coins;
                    this.modalData.wp_activity_id = this.nextmodalData[this.currentIndex].wp_activity_id;
                    this.modalData.is_mandatory = this.nextmodalData[this.currentIndex].is_mandatory;
                    if (this.modalData.wp_activity_id === this.nextmodalData[this.currentIndex].wp_activity_id) {
                      this.getActivityViews(this.modalData.wp_activity_id);
                    }
                    this.modalData.is_intro = 0;
                  } else {
                    this.currentIndex = this.currentIndex + 1;
                    this.h5pUrl = this.nextmodalData[this.currentIndex].act_id;
                    this.h5pTitle = this.nextmodalData[this.currentIndex].act_name;
                    this.isMandatory = this.nextmodalData[this.currentIndex].is_mandatory;
                    this.status = this.nextmodalData[this.currentIndex].status;
                    this.dotCoins = this.nextmodalData[this.currentIndex].dot_coins;
                    this.modalData.wp_activity_id = this.nextmodalData[this.currentIndex].wp_activity_id;
                    if (this.modalData.wp_activity_id === this.nextmodalData[this.currentIndex].wp_activity_id) {
                      this.getActivityViews(this.modalData.wp_activity_id);
                    }
                    this.modalData.is_mandatory = this.nextmodalData[this.currentIndex].is_mandatory;
                  }
                }
              } else {
                this.toastrService.warning('You have reached the last activity');
              }
            }

          } else {
            this.toastrService.warning('Complete the current activity to proceed further');
          }

        },(err)=>{
          this.isLoading = false;
        });
      } else {
        this.isLoading = true;
        this.studentHelperService.getActivityInfo(payload).subscribe(res => {
          this.isLoading = false;
          if (res) {
            if(flag === true){
              this.ngbActiveModal.close(true);
            }
            if (!this.modalData.menuOrLayout) {
              this.h5pUrl = `https://dotxprocom.h5p.com/content/${this.nextmodalData.id}/embed`;
              this.h5pTitle = this.nextmodalData.title;
            } else {
              if (this.currentIndex < this.nextmodalData.length - 1) {
                this.currentIndex = this.currentIndex + 1;
                this.h5pUrl = this.nextmodalData[this.currentIndex].act_id;
                this.h5pTitle = this.nextmodalData[this.currentIndex].act_name;
                this.isMandatory = this.nextmodalData[this.currentIndex].is_mandatory;
                this.status = this.nextmodalData[this.currentIndex].status;
                this.dotCoins = this.nextmodalData[this.currentIndex].dot_coins;
                this.modalData.wp_activity_id = this.nextmodalData[this.currentIndex].wp_activity_id;
                if (this.modalData.wp_activity_id === this.nextmodalData[this.currentIndex].wp_activity_id) {
                  this.getActivityViews(this.modalData.wp_activity_id);
                }
              } else {
                this.toastrService.warning('You have reached the last activity');
              }
            }
          }
        },(err)=>{
          this.isLoading = false;
        })
      }
    } else {
      if (!this.modalData.menuOrLayout) {
        this.h5pUrl = `https://dotxprocom.h5p.com/content/${this.nextmodalData.id}/embed`;
        this.h5pTitle = this.nextmodalData.title;
      } else {
        if (this.currentIndex <= this.nextmodalData.length - 1) {
          this.currentIndex = this.currentIndex + 1;
          this.h5pUrl = this.nextmodalData[this.currentIndex].act_id;
          this.h5pTitle = this.nextmodalData[this.currentIndex].act_name;
          this.isMandatory = this.nextmodalData[this.currentIndex].is_mandatory;
          this.status = this.nextmodalData[this.currentIndex].status;
          this.dotCoins = this.nextmodalData[this.currentIndex].dot_coins;
          this.modalData.wp_activity_id = this.nextmodalData[this.currentIndex].wp_activity_id;
          if (this.modalData.wp_activity_id === this.nextmodalData[this.currentIndex].wp_activity_id) {
            this.getActivityViews(this.modalData.wp_activity_id);
          }
        } else {
          this.toastrService.warning('You have reached the last activity');
        }
      }
    }
  }

  openChallenge(): void {
    const checkMandatoryActivities = this.nextmodalData.filter(x => x.is_mandatory === 1 && x.status === "pending")
    if (checkMandatoryActivities.length === 0) {
      this.ngbActiveModal.close({ navigate: "challenges", challenge: this.pendingChallenges[0] });
      // const challenge = this.pendingChallenges[0];
      // const data = {
      //   challenge
      // };
      // const component = this.pendingChallenges[0].topic_group_size === 1 ? SoloChallengeModelComponent : GroupChallengeModelComponent;
      // const modelRef = this.modalService.open(component, {
      //   centered: true,
      //   scrollable: true,
      //   backdrop: 'static',
      //   keyboard: false,
      //   size: 'xl',
      //   windowClass: 'modal-challenge'
      // });
      // modelRef.componentInstance.data = data;
    } else {
      this.toastrService.warning("Complete the mandatory activities to proceed to Challenges")
    }
  }

  closeModal(): void {
    if(this.openNextAct === false){
      if(this.usertype.userInfo.user_type === 'student'){
      this.openNextActivity(true);
      }else{
        this.ngbActiveModal.close(true);
      }
    }else{
      this.ngbActiveModal.close(true);
    }
  }

  ngAfterViewInit(): void {
    const swiperThumbnail = new Swiper('.swiper.swiper-thumbnail', {
      modules: [Navigation, Pagination],
      keyboard: {
        enabled: true,
        onlyInViewport: false,
      },

      breakpoints: {
        0: {
          slidesPerView: 1,
          spaceBetween: 10,
          slidesPerGroup: 1
        },
        576: {
          slidesPerView: 2,
          spaceBetween: 15,
          slidesPerGroup: 2
        },
        768: {
          slidesPerView: 3,
          spaceBetween: 20,
          slidesPerGroup: 3
        },
        1200: {
          slidesPerView: 4,
          spaceBetween: 20,
          slidesPerGroup: 4
        }
      },

      // Navigation arrows
      navigation: {
        nextEl: '.swiper-button-next',
        prevEl: '.swiper-button-prev',
      }
    });
  }
}
