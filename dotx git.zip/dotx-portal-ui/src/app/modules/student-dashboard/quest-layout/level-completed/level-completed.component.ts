import { Component, Input, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import {NgbActiveModal} from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-level-completed',
  templateUrl: './level-completed.component.html',
  styleUrls: ['./level-completed.component.scss']
})
export class LevelCompletedComponent implements OnInit {
  @Input() modalData;
  @Input() nextLevelData;
  @Input() challenge;
  @Input() nextChallenges;
  nextChallenge: any;

  constructor(private ngbActiveModal: NgbActiveModal, private router: Router) { }

  ngOnInit() {
    this.nextChallenges
    this.nextChallenge = this.nextChallenges[0]
  }

 

  navigateToQuest(): void {
    // this.closeModal();
    if (this.nextChallenges != undefined && this.nextChallenges.length > 0) {
      this.ngbActiveModal.close({ status: "success", nextChallenges: this.nextChallenges[0]});
    }
    else {
      this.closeModal();
      this.router.navigate(['/auth/student/quest']);

    }
  }

  closeModal(): void {  
    this.ngbActiveModal.close({ status: "success"});
  }

}
