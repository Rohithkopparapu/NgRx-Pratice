import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LevelLockedPopupComponent } from './level-locked-popup.component';

describe('LevelLockedPopupComponent', () => {
  let component: LevelLockedPopupComponent;
  let fixture: ComponentFixture<LevelLockedPopupComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LevelLockedPopupComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LevelLockedPopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
