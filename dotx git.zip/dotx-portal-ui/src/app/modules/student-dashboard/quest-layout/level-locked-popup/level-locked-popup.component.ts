import { Component, OnInit } from '@angular/core';
import {NgbActiveModal} from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-level-locked-popup',
  templateUrl: './level-locked-popup.component.html',
  styleUrls: ['./level-locked-popup.component.scss']
})
export class LevelLockedPopupComponent implements OnInit {

  constructor(private ngbActiveModal: NgbActiveModal) { }

  ngOnInit() {
  }

  closeModal(): void {
    this.ngbActiveModal.close();
  }

}
