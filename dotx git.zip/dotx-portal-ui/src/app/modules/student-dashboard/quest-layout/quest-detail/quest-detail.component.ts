import { AfterViewInit, Component, OnDestroy, OnInit } from '@angular/core';
import { NavigationStart, Router } from '@angular/router';
import { takeUntil } from 'rxjs/operators';
import { PREFERENCES, TEACHER_ROW, STUDENT_ROW } from '../../../../shared/constants/constant';
import { AuthState } from '../../../../shared/store/auth.model';
import { Store } from '@ngrx/store';
import { Subject, Subscription } from 'rxjs';
import { userInfo } from '../../../../shared/store/auth.selector';
import { StudentHelperService } from '../../student-helper.service';
import { ToastrService } from 'ngx-toastr';
import Swiper, { Navigation, Pagination } from 'swiper';
import { HelperService } from '../../../../shared/services/helper.service';
import { SoloChallengeModelComponent } from '../../../../shared/component/solo-challenge-model/solo-challenge-model.component';
import { GroupChallengeModelComponent } from '../../../../shared/component/group-challenge-model/group-challenge-model.component';
import { H5pContentModalComponent } from '../h5p-content-modal/h5p-content-modal.component';
import { LevelCompletedComponent } from '../level-completed/level-completed.component';
import { $ } from 'jquery';
import { ImageVideoViewComponent } from 'src/app/shared/component/image-video-view/image-video-view.component';
import { environment } from 'src/environments/environment';
import { DataService } from '../../../../shared/services/data.service';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';


@Component({
  selector: 'app-quest-detail',
  templateUrl: './quest-detail.component.html',
  styleUrls: ['./quest-detail.component.scss']
})
export class QuestDetailComponent implements OnInit, AfterViewInit, OnDestroy {
  private subscription: Subscription;
  private subscriptions = new Subject<void>();
  isLoading = false;
  userInfo: any;
  userCommunityPreference: any;
  questDataPass: any;
  nextQuestLevelData: any;
  community: any;
  questInfo: any;
  dateRangeSelected = 'Last 6 Months';
  searchType = 'Topic';
  searchKeyword: string;
  toggleLeaderBoard = true;
  pendingActivities: any[] = [];
  completedActivities: any[] = [];
  pendingChallenges: any[];
  questLevelData: any;
  allActivites: any[];
  introduction: any[] = [];
  onlyPendingActivities: any = [];
  completedChallenges: any[];
  totalChallenges: any[];
  usertype: any;
  questInfoCopy: any;
  pendingChallengesData: any[];
  completedChallengesData: any[];
  introductionVideoSwiper: any;
  pendingActivitiesSwiper: any;
  completedActivitiesSwiper: any;
  pendingChallengesSwiper: any;
  completedChallengesSwiper: any;
  checkMandatoryChallengeCompleted: any[];
  activitySwiperPendingType: any;
  activitySwiperVideoType: any;
  activitySwiperCompletedType: any;
  activitySwiperRecentType: any;
  activitySwiperComp2Type: any;
  allActivitesList: any[];
  currentActivity: any;
  currentActivityIndex: number;
  currentComActivity: any;
  currentComActivityIndex: number;
  views: number;
  view: number;
  techerRow: any = []
  studentrRow: any = []
  materialList: any = [];
  Fileheader: any;
  isClassRoomChallenges: any=[];
  // previousLevelStatus: number;

  constructor(private router: Router, private store$: Store<AuthState>, private studentHelperService: StudentHelperService,
    private toastrService: ToastrService, private _uhs: HelperService, private modalService: NgbModal,private dataService: DataService) {
    this.store$.select(userInfo)
      .pipe(takeUntil(this.subscriptions))
      .subscribe(res => {
        if (res) {
          this.userInfo = res;
          this.userCommunityPreference = res.preferences ? res.preferences.find(s => s.entity_name === PREFERENCES.COMMUNITY.ENTITY_NAME && s.entity_type === PREFERENCES.COMMUNITY.ENTITY_TYPE) : null;
        }
      });
    const data = this.router.getCurrentNavigation().extras.state;
    if (data) {
      this.questDataPass = data.questData;
      this.nextQuestLevelData = data.nextLevelData;
    } else {
      this.router.navigate(['/auth/student/quest']);
    }
    this.subscription = this.dataService.refreshComponent$.subscribe(() => {
      this.refreshComponentLogic();
    });
  }
  ngAfterViewInit(): void {
    this.getLevelInfoById();
    // this.swiperSlider.navigation.destroy();
    // this.swiperSlider.navigation.init();
    this.getLevelMaterials()
  }

  ngOnInit() {
    // this.getLevelInfoById();
    // this.getChallengesByLevelId();
    this.usertype = JSON.parse(sessionStorage.getItem('auth'));

    this.router.events.subscribe((event) => {
      if (event instanceof NavigationStart) {
        if (event.navigationTrigger === 'popstate') {
          this.modalService.dismissAll();
        }
      }
    });
  }

  refreshComponentLogic(){
    this.router.navigate(['/auth/student/quest']);
  }

  getLevelMaterials() {
    const payload = {
      community_id: Number(this.userCommunityPreference.value),
      user_id: this.userInfo.user_id,
      level_id: this.questDataPass.level_id
    };
    this.studentHelperService.getLevelMaterials(payload).subscribe(res => {
      this.isLoading = false;
      if (res) {
        this.materialList = res;

      }
    })
  }
  getLevelInfoById(): void {
    const payload = {
      community_id: Number(this.userCommunityPreference.value),
      user_id: this.userInfo.user_id,
      level_id: this.questDataPass.level_id
    };
    this.isLoading = true;
    this.studentHelperService.getQuestInfo(payload).subscribe(res => {
      this.isLoading = false;
      if (res && res.data) {
        this.community = res.community;
        this.questInfo = res.data;
        this.questInfoCopy = res.data;
        this.pendingActivities = this.questInfo.activities.filter(_act => _act.status === 'pending');
        this.onlyPendingActivities = this.questInfo.activities.filter(_act => _act.is_intro === 0 && _act.status === 'pending');
        this.completedActivities = this.questInfo.activities.filter(_act => _act.status === 'completed' && _act.is_intro === 0);
        this.allActivitesList = this.pendingActivities.concat(this.completedActivities);
        this.allActivites = this.allActivitesList.filter(act => act.is_intro === 0);
        // this.introduction= this.questInfo.activities.slice(0,1);
        this.introduction = this.questInfo.activities.filter(act => act.is_intro === 1);
        this.initChallengesSlider([], false);
        const params = { community_id: Number(this.userCommunityPreference.value), level_id: this.questDataPass.level_id };
        this.isLoading = true;
        this.studentHelperService.getQuestTopics(params).subscribe(res => {
          this.isLoading = false;
          if (res) {
            this.questLevelData = res;
            this.community = res['community'] ? res['community'] : {};
            this.pendingChallengesData = this.initChallengesSlider([...res['recent_challenges'], ...res['continue_challenges']], false);
            this.isClassRoomChallenges = this.pendingChallengesData.filter(x => x.is_classroom_reflection === 1);
            let data = this.pendingChallengesData.sort((a, b) => b.is_mandatory - a.is_mandatory);
            this.pendingChallenges = data.filter(item => item.is_classroom_reflection === 0);
            this.completedChallengesData = this.initChallengesSlider([...res['completedChallenges']], false);
            this.completedChallenges = this.completedChallengesData.sort((a, b) => b.is_mandatory - a.is_mandatory);
            this.checkMandatoryChallengeCompleted = this.completedChallengesData.filter(x => x.is_mandatory === 1 && x.final_submitted === 1);
            this.totalChallenges = this.initChallengesSlider([...res['recent_challenges'], ...res['continue_challenges'], ...res['completedChallenges']], false);
            if (res) {
              if (this.pendingActivities.length === 0 && this.questLevelData.quest_level.level_status === 1 && this.pendingChallenges.length === 0) {
                // this.openLevelCompletedPopup();
              }
            }
          }
        }, () => this.isLoading = false);
      }
    }, () => this.isLoading = false);
    // this.techerRow=TEACHER_ROW
    // this.studentrRow=STUDENT_ROW
  }
  openViewerModel(type: string, url: string, material, material_name, mtype): void {
    if (url != 'assets/img/image-icon.png' || !url) {


      let fileTypes = material.split('.')[material.split('.').length - 1]
      if (fileTypes === "docx" || fileTypes === "doc") {
        type = "doc"
      }
      if (fileTypes === "pdf") {
        type = "pdf"
      }
      if (fileTypes === 'xlsx' || fileTypes === 'xls' || fileTypes === 'csv') {
        type = "excel"
      }
      if (fileTypes === 'png' || fileTypes[1] == 'jpeg' || fileTypes === 'jpg') {
        type = "image"
      }
      const modalRef = this.modalService.open(ImageVideoViewComponent, {
        centered: true,
        size: 'xl',
        scrollable: true,
        backdrop: 'static',
      });
      modalRef.componentInstance.fileType = type;
      modalRef.componentInstance.fileUrl = url;
      modalRef.componentInstance.materialName = material_name;
      modalRef.componentInstance.mtype = mtype;
    } else {
      this.toastrService.warning('There is no Materials Available.');
    }

  }
  totalNoActivities(activities) {
    if (activities !== undefined) {
      return activities.filter(x => x.is_intro != 1);
    }
  }

  checkChallengeLocked(index: number) {
    if (this.usertype.userInfo.user_type === 'student') {
      const checkMandatoryActivitesStatus = this.onlyPendingActivities.filter(res => res.is_mandatory === 1);
      const checkMandatoryChallengesStatus = this.pendingChallenges.filter(res => res.is_mandatory === 1);
      if (checkMandatoryActivitesStatus.length === 0) {

        // return false;
        if (this.pendingChallenges.length != 0) {
          if (this.pendingChallenges[index].is_mandatory === 1) {
            return false;
          } else if (this.pendingChallenges[index].is_mandatory === 0) {
            if (checkMandatoryChallengesStatus != undefined && checkMandatoryChallengesStatus.length <= 0) {
              return false;
            } else {
              return true;
            }
          } else {
            return true;
          }
        }
      } else {
        // this.toastrService.warning('You need to completed the Activites to participate in challenge');
        return true;
      }
    } else {
      return false;
    }
  }

  download(data) {
    const port = environment.fetchUrl;
    const s3Url = data.material_file_path;
    fetch(s3Url, {
      headers: {
        'Content-Disposition': 'attachment',
        'Access-Control-Allow-Origin': port
      },
    })
      .then((response) => response.blob())
      .then((blob) => {
        const url = window.URL.createObjectURL(blob);

        const link = document.createElement('a');
        link.href = url;
        link.download = data.material_name;

        link.dispatchEvent(new MouseEvent('click'));

        window.URL.revokeObjectURL(url);
      });

  }

  getChallengesByLevelId(): void {
    // const params = {community_id: Number(this.userCommunityPreference.value), level_id: this.questDataPass.level_id};
    // this.isLoading = true;
    // this.studentHelperService.getQuestTopics(params).subscribe(res => {
    //   this.isLoading = false;
    //   if (res) {
    //     this.questLevelData= res;
    //     this.community = res['community'] ? res['community'] : {};
    //     this.pendingChallenges = this.initChallengesSlider([...res['recent_challenges'], ...res['continue_challenges']], false);
    //   }
    // }, () => this.isLoading = false);
  }

  initChallengesSlider(challenges: any[], isStack: boolean) {
    challenges = this._uhs.getOnlyImageFromChallenges(challenges);

    if (!isStack) {
      // this.swiperSlider;
      setTimeout(() => {
        this.activitySwiperPendingType = new Swiper('.activity-pending .swiper', {
          modules: [Navigation, Pagination],
          // Optional parameters
          // loop: true,

          keyboard: {
            enabled: true,
            onlyInViewport: false,
          },

          // Navigation arrows
          navigation: {
            nextEl: '.swiper-button-next',
            prevEl: '.swiper-button-prev',
            // enabled: true
          },
          breakpoints: {
            0: {
              slidesPerView: 1,
              spaceBetween: 10,
              slidesPerGroup: 1
            },
            576: {
              slidesPerView: 2,
              spaceBetween: 20,
              slidesPerGroup: 2
            },
            992: {
              slidesPerView: 3,
              spaceBetween: 25,
              slidesPerGroup: 3
            },
            1200: {
              slidesPerView: 4,
              spaceBetween: 30,
              slidesPerGroup: 4
            }
          }
        });
        this.activitySwiperVideoType = new Swiper('.activity-video .swiper', {
          modules: [Navigation, Pagination],
          // Optional parameters
          // loop: true,

          keyboard: {
            enabled: true,
            onlyInViewport: false,
          },

          // Navigation arrows
          navigation: {
            nextEl: '.swiper-button-vid-type-next',
            prevEl: '.swiper-button-vid-type-prev',
            // enabled: true
          },
          breakpoints: {
            0: {
              slidesPerView: 1,
              spaceBetween: 10,
              slidesPerGroup: 1
            },
            576: {
              slidesPerView: 2,
              spaceBetween: 20,
              slidesPerGroup: 2
            },
            992: {
              slidesPerView: 3,
              spaceBetween: 25,
              slidesPerGroup: 3
            },
            1200: {
              slidesPerView: 4,
              spaceBetween: 30,
              slidesPerGroup: 4
            }
          }
        });
        this.activitySwiperCompletedType = new Swiper('.activity-completed .swiper', {
          modules: [Navigation, Pagination],
          // Optional parameters
          // loop: true,

          keyboard: {
            enabled: true,
            onlyInViewport: false,
          },

          // Navigation arrows
          navigation: {
            nextEl: '.swiper-button-completed-next',
            prevEl: '.swiper-button-completed-prev',
            // enabled: true
          },
          breakpoints: {
            0: {
              slidesPerView: 1,
              spaceBetween: 10,
              slidesPerGroup: 1
            },
            576: {
              slidesPerView: 2,
              spaceBetween: 20,
              slidesPerGroup: 2
            },
            992: {
              slidesPerView: 3,
              spaceBetween: 25,
              slidesPerGroup: 3
            },
            1200: {
              slidesPerView: 4,
              spaceBetween: 30,
              slidesPerGroup: 4
            }
          }
        });
        this.activitySwiperRecentType = new Swiper('.activity-recent .swiper', {
          modules: [Navigation, Pagination],
          // Optional parameters
          // loop: true,

          keyboard: {
            enabled: true,
            onlyInViewport: false,
          },

          // Navigation arrows
          navigation: {
            nextEl: '.swiper-button-recent-next',
            prevEl: '.swiper-button-recent-prev',
            // enabled: true
          },
          breakpoints: {
            0: {
              slidesPerView: 1,
              spaceBetween: 10,
              slidesPerGroup: 1
            },
            576: {
              slidesPerView: 2,
              spaceBetween: 20,
              slidesPerGroup: 2
            },
            992: {
              slidesPerView: 3,
              spaceBetween: 25,
              slidesPerGroup: 3
            },
            1200: {
              slidesPerView: 4,
              spaceBetween: 30,
              slidesPerGroup: 4
            }
          }
        });
        this.activitySwiperComp2Type = new Swiper('.activity-completed2 .swiper', {
          modules: [Navigation, Pagination],
          // Optional parameters
          // loop: true,

          keyboard: {
            enabled: true,
            onlyInViewport: false,
          },

          // Navigation arrows
          navigation: {
            nextEl: '.swiper-button-comp2-next',
            prevEl: '.swiper-button-comp2-prev',
            // enabled: true
          },
          breakpoints: {
            0: {
              slidesPerView: 1,
              spaceBetween: 10,
              slidesPerGroup: 1
            },
            576: {
              slidesPerView: 2,
              spaceBetween: 20,
              slidesPerGroup: 2
            },
            992: {
              slidesPerView: 3,
              spaceBetween: 25,
              slidesPerGroup: 3
            },
            1200: {
              slidesPerView: 4,
              spaceBetween: 30,
              slidesPerGroup: 4
            }
          }
        });





        // console.log(swiperSlider);
        // swiperSlider.map((x, i) => swiperSlider[i].navigation.update());
        // swiperSlider[0].navigation.update();
        // swiperSlider[1].navigation.update();
        // swiperSlider[2].navigation.update();
        // swiperSlider[3].navigation.update();
        // swiperSlider[4].navigation.update();
        // swiperSlider[5].navigation.update();
        // this.introductionVideoSwiper.update();
        // this.pendingActivitiesSwiper.update();
        // this.completedActivitiesSwiper.update();
        // this.pendingChallengesSwiper.update();
        // this.completedChallengesSwiper.update();
      });

      // introductionVideoSwiper.navigation.init();
      // pendingActivitiesSwiper.navigation.init();
      // completedActivitiesSwiper.navigation.init();
      // pendingChallengesSwiper.navigation.init();
      // completedChallengesSwiper.navigation.init();



      // setTimeout(()=>{
      //   console.log(swiperSlider[1]);
      //   swiperSlider[1].navigation.update();
      // }, 200)
    } else {
      setTimeout(() => {
        const swiperSliderStack = new Swiper('.swiper.swiper-slider-stack', {
          modules: [Navigation, Pagination],
          // Optional parameters
          // loop: true,

          keyboard: {
            enabled: true,
            onlyInViewport: false,
          },

          // Navigation arrows
          navigation: {
            nextEl: '.swiper-button-next',
            prevEl: '.swiper-button-prev',
          },
          breakpoints: {
            0: {
              slidesPerView: 1,
              spaceBetween: 10,
              slidesPerGroup: 1
            },
            576: {
              slidesPerView: 2,
              spaceBetween: 30,
              slidesPerGroup: 2
            },
            992: {
              slidesPerView: 3,
              spaceBetween: 35,
              slidesPerGroup: 3
            },
            1200: {
              slidesPerView: 4,
              spaceBetween: 50,
              slidesPerGroup: 4
            }
          }
        });
      });
    }
    return challenges;
  }


  searchSpotlightChallenges(): void {
    this.isLoading = true;
    if (this.searchKeyword) {
      const data = {
        search_type: this.searchType,
        keyword: this.searchKeyword
      };
      // this._uhs.searchData = data;
      this.router.navigate(['/auth/student/challenge/search'], { state: { searchData: data } });
    } else {
      this.isLoading = false;
      this.toastrService.warning('Please enter valid input details', 'Search');
    }
  }

  openOrCloseLeaderBoardPopup() {
    this.toggleLeaderBoard = !this.toggleLeaderBoard;
  }

  onSearchFilter(value): void {
    this.searchType = value;
  }

  onDateRangeChanged(filterVal: any) {
    this.dateRangeSelected = filterVal.innerText;

    const payload = {
      time_filter: this.dateRangeSelected,
      community_id: this.userCommunityPreference.value
    };
  }

  openChallenge(challenge: any): any {
    const data = {
      challenge
    };
    const component = challenge.topic_group_size === 1 ? SoloChallengeModelComponent : GroupChallengeModelComponent;
    const modelRef = this.modalService.open(component, {
      centered: true,
      scrollable: true,
      backdrop: 'static',
      keyboard: false,
      size: 'xl',
      windowClass: 'modal-challenge'
    });
    modelRef.componentInstance.data = data;
    modelRef.result.then((res: any) => {
      if (res.status === "success") {

        this.refreshData();
        if (this.userInfo.user_type === "student") {
          const checkMandatoryChallenges = this.pendingChallenges.filter(x => x.topic_id != challenge.topic_id)
          const mandatoryChallenges = checkMandatoryChallenges.filter(x => x.is_mandatory);
          if (challenge.is_mandatory === 1) {
            if (mandatoryChallenges.length === 0) {
              this.openLevelCompletedPopup(challenge, mandatoryChallenges);
            } else {
              this.openChallenge(mandatoryChallenges[0]);
            }
          } else {
            this.refreshData();
            if(challenge.is_classroom_reflection === 0){
            const nextChallenges = this.pendingChallenges.filter(x => x.topic_id != challenge.topic_id);
            if (nextChallenges.length != 0) {
              this.openChallenge(nextChallenges[0]);
            } else {
              this.refreshData();
            }
          }
          }
          this.refreshData();
        } else {
          const nextChallenges = this.pendingChallenges.filter(x => x.topic_id != challenge.topic_id);
          if (nextChallenges.length != 0) {
            this.openChallenge(nextChallenges[0]);
          } else {
            this.refreshData();
          }
          this.refreshData();
        }
      } else {
        this.refreshData();
      }
    });
  }
  getViewData(actId) {
    const activitiesIds = actId;
    const payload = {};
    payload['wp_activity_id'] = activitiesIds;
    // this.studentHelperService.getActivityViews(payload).subscribe(res =>{
    //   if(res){
    //     this.views = res.views
    //   } 
    // });
  }

  openActivityIntro(index: number) {
    const nextActivities = this.allActivites;
    const activityId = this.introduction[index].wp_activity_id
    // this.getViewData(activityId);
    // let previousLevelStatus=1
    const payload = {};
    payload['wp_activity_id'] = activityId;
    this.studentHelperService.getActivityViews(payload).subscribe(res => {
      if (res) {
        this.view = res.views
        this.openH5pContentModelPopUp(this.introduction[index], nextActivities, this.pendingChallenges, 1, 0, this.view);
      }
    });

  }

  openActivity(index: number, actId: any) {
    const previousLevelStatus = 1
    const nextActivities = this.allActivites.filter(x => x.currentActivity !== actId);
    this.allActivites.find((id, index) => {
      if (id.wp_activity_id === actId) {
        this.currentActivity = id,
          this.currentActivityIndex = index
      }

    });
    const noOfMandatoryActivities = this.questInfo.activities.filter(_act => _act.is_mandatory === 1);
    const noOfMandatoryActivitiesPending = noOfMandatoryActivities.filter(_act => _act.status === "pending");
    if (this.usertype.userInfo.user_type === 'student') {
      if (index === 0) {
        const activityId = this.currentActivity.wp_activity_id
        // this.getViewData(activityId);
        // let previousLevelStatus=1
        const payload = {};
        payload['wp_activity_id'] = activityId;
        this.studentHelperService.getActivityViews(payload).subscribe(res => {
          if (res) {
            this.view = res.views
            this.openH5pContentModelPopUp(this.currentActivity, nextActivities, this.pendingChallenges, previousLevelStatus, this.currentActivityIndex, this.view);
          }
        })
      } else {
        if (this.allActivites[index].is_mandatory === 0 && this.allActivites[index].status === 'pending') {
          if (noOfMandatoryActivitiesPending.length === 0) {
            const activityId = this.currentActivity.wp_activity_id
            const payload = {};
            payload['wp_activity_id'] = activityId;
            this.studentHelperService.getActivityViews(payload).subscribe(res => {
              if (res) {
                this.view = res.views
                this.openH5pContentModelPopUp(this.currentActivity, nextActivities, this.pendingChallenges, previousLevelStatus, this.currentActivityIndex, this.view);
              }
            })
          } else {
            this.checkActivityLocked(index);
          }
        } else if (this.allActivites[index].status === 'completed') {
          const activityId = this.currentActivity.wp_activity_id
          const payload = {};
          payload['wp_activity_id'] = activityId;
          this.studentHelperService.getActivityViews(payload).subscribe(res => {
            if (res) {
              this.view = res.views
              this.openH5pContentModelPopUp(this.currentActivity, nextActivities, this.pendingChallenges, previousLevelStatus, this.currentActivityIndex, this.view);
            }
          })

        } else {
          this.checkActivityLocked(index);
        }
      }
    } else {
      const activityId = this.currentActivity.wp_activity_id
      const payload = {};
      payload['wp_activity_id'] = activityId;
      this.studentHelperService.getActivityViews(payload).subscribe(res => {
        if (res) {
          this.view = res.views
          this.openH5pContentModelPopUp(this.currentActivity, nextActivities, this.pendingChallenges, previousLevelStatus, this.currentActivityIndex, this.view);
        }
      })
    }
    // if(this.allActivites[index].is_mandatory === 0){
    //   const noOfMandatoryActivities = this.questInfo.activities.filter(_act => _act.is_mandatory === 1);
    //   const noOfMandatoryActivitiesPending = noOfMandatoryActivities.filter(_act => _act.status === "pending");

    //    if(noOfMandatoryActivitiesPending.length === 0){
    //    this.openH5pContentModelPopUp(this.allActivites[index], nextActivities );
    //    }else{
    //      this.checkActivityLocked(index);
    //    }
    //  }else{
    //    if(this.allActivites[index])
    //  this.toastrService.warning('To unlock this activity, you need to complete the previous activity');
    //  }
  }

  openCompletedActivity(indexdata: number, actId) {
    const index = this.onlyPendingActivities.length + indexdata;
    // const nextActivities = this.allActivites.slice(index + 1);
    const nextActivities = this.allActivites.filter(x => x.currentActivity !== actId);
    // const currentActivity = this.allActivites.find(id => id.wp_activity_id === actId); 
    this.allActivites.find((id, index) => {
      if (id.wp_activity_id === actId) {
        this.currentComActivity = id,
          this.currentComActivityIndex = index
      }
    });
    const noOfMandatoryActivities = this.questInfo.activities.filter(_act => _act.is_mandatory === 1);
    const noOfMandatoryActivitiesPending = noOfMandatoryActivities.filter(_act => _act.status === "pending");
    if (index === 0) {
      const activityId = this.currentComActivity.wp_activity_id
      const payload = {};
      payload['wp_activity_id'] = activityId;
      this.studentHelperService.getActivityViews(payload).subscribe(res => {
        if (res) {
          this.view = res.views
          this.openH5pContentModelPopUp(this.currentComActivity, nextActivities, this.pendingChallenges, 1, this.currentComActivityIndex, this.view);
        }
      })
    } else {
      if (this.allActivites[index].is_mandatory === 0 && this.allActivites[index].status === 'pending') {
        if (noOfMandatoryActivitiesPending.length === 0) {
          const activityId = this.currentComActivity.wp_activity_id
          const payload = {};
          payload['wp_activity_id'] = activityId;
          this.studentHelperService.getActivityViews(payload).subscribe(res => {
            if (res) {
              this.view = res.views
              this.openH5pContentModelPopUp(this.currentComActivity, nextActivities, this.pendingChallenges, 1, this.currentComActivityIndex, this.view);
            }
          })
        } else {
          this.checkActivityLocked(index);
        }
      } else if (this.allActivites[index].status === 'completed') {
        const activityId = this.currentComActivity.wp_activity_id
        const payload = {};
        payload['wp_activity_id'] = activityId;
        this.studentHelperService.getActivityViews(payload).subscribe(res => {
          if (res) {
            this.view = res.views
            this.openH5pContentModelPopUp(this.currentComActivity, nextActivities, this.pendingChallenges, 1, this.currentComActivityIndex, this.view);
          }
        })

      } else {
        this.checkActivityLocked(index);
      }
    }

  }
  checkActivityLocked(index: number) {
    let noOfMandatoryActivities;
    let noOfMandatoryActivitiesPending;
    if (this.usertype.userInfo.user_type === 'student') {
      if (this.questInfo.activities !== undefined) {
        noOfMandatoryActivities = this.questInfo.activities.filter(_act => _act.is_mandatory === 1);
        noOfMandatoryActivitiesPending = noOfMandatoryActivities.filter(_act => _act.status === "pending");
      }

      if (this.allActivites[index] !== undefined && this.allActivites[index].status !== undefined) {
        if (index === 0) {
          return false;
        } else if (this.allActivites[index].status === 'completed') {
          return false;
        } else if (this.allActivites[index].status === 'pending') {
          if (noOfMandatoryActivities != undefined && noOfMandatoryActivitiesPending.length <= 0) {
            return false;
          } else {
            return true;
          }
        } else {
          return true;
        }
      }


      // else{
      //   const noOfMandatoryActivities = this.questInfo.activities.filter(_act => _act.status === 'pending');
      //   if(noOfMandatoryActivities != undefined && noOfMandatoryActivities.length <= 0){
      //     return false;
      //   }else{
      //     return true;
      //   }
      // }
    } else {
      return false;
    }
  }

  openH5pContentModelPopUp(activity: any, nextActivities, pendingChallenges, previousLevelStatus, currentIndex, viewsCount) {
    const modelRef = this.modalService.open(H5pContentModalComponent, {
      centered: true,
      scrollable: true,
      backdrop: 'static',
      size: 'xl',
      windowClass: 'modal-challenge'
    });
    activity['menuOrLayout'] = true;
    activity['community'] = this.community;
    activity['questInfo'] = this.questInfo;
    modelRef.componentInstance.modalData = activity;
    if (nextActivities != undefined) {
      modelRef.componentInstance.nextmodalData = nextActivities;
      modelRef.componentInstance.pendingChallenges = pendingChallenges;
      modelRef.componentInstance.previousLevelStatus = previousLevelStatus;
      modelRef.componentInstance.currentIndex = currentIndex;
      modelRef.componentInstance.viewsCount = viewsCount;
    }
    modelRef.result.then(res => {
      if (res === true) {
        this.refreshData();
      } else if (res.navigate === "challenges") {
        this.openChallenge(res.challenge);
      }

    });
  }

  openLevelCompletedPopup(challenge, mandatoryChallenges): void {
    const modelRef = this.modalService.open(LevelCompletedComponent, {
      centered: true,
      backdrop: 'static',
      size: 'md',
      windowClass: 'modal-challenge achievement-type',
    });
    modelRef.componentInstance.modalData = this.questInfoCopy;
    modelRef.componentInstance.nextLevelData = this.nextQuestLevelData;
    modelRef.componentInstance.challenge = challenge;
    modelRef.componentInstance.nextChallenges = mandatoryChallenges
    modelRef.result.then(res => {
      if (res.nextChallenges != undefined && res.nextChallenges.length != 0) {
        this.refreshData();
        this.openChallenge(res.nextChallenges);
      } else {
        this.refreshData();
      }
    });
  }

  refreshData(): void {
    this.community = {};
    this.questInfo = {};
    this.pendingActivities = [];
    this.completedActivities = [];
    this.getLevelInfoById();
    this.studentHelperService.getBadgesAndDotCoins(this.userInfo.user_id);
  }

  navigateCreateChallenge(): void {
    this.router.navigate(['/auth/student/challenge/create'], { state: { page: 'quest', questData: this.questInfo } });
  }

  ngOnDestroy(): void {
    this.subscriptions.next();
    this.subscriptions.complete();
    this.subscription.unsubscribe();
  }
}
