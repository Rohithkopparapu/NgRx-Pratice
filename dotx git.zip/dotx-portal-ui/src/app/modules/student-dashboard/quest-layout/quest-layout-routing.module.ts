import {NgModule} from '@angular/core';
import {RouterModule, Routes} from '@angular/router';
import {QuestMenuComponent} from './quest-menu/quest-menu.component';
import {QuestLayoutComponent} from './quest-layout.component';
import { QuestDetailComponent } from './quest-detail/quest-detail.component';

const routes: Routes = [
  {
    path: '',
    component: QuestMenuComponent
  },
  {
    path: 'layout',
    component: QuestLayoutComponent
  },
  {
    path: 'details',
    component: QuestDetailComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})

export class QuestLayoutRoutingModule {}
