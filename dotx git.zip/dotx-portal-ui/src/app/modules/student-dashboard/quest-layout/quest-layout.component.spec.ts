import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { QuestLayoutComponent } from './quest-layout.component';

describe('MicroLearningComponent', () => {
  let component: QuestLayoutComponent;
  let fixture: ComponentFixture<QuestLayoutComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ QuestLayoutComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(QuestLayoutComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
