import {Component, OnInit} from '@angular/core';
import {NgbModal} from '@ng-bootstrap/ng-bootstrap';
import {QUEST_LAYOUT} from '../../../shared/constants/constant';
import {of} from 'rxjs';
import {delay} from 'rxjs/operators';
import {H5pContentModalComponent} from './h5p-content-modal/h5p-content-modal.component';

@Component({
  selector: 'app-quest-layout',
  templateUrl: './quest-layout.component.html',
  styleUrls: ['./quest-layout.component.scss']
})
export class QuestLayoutComponent implements OnInit {
  isLoading = false;
  isMapLoading = false;
  topicsList = QUEST_LAYOUT.QUEST_CHAPTERS;
  quest: any;
  questMap: any[];

  constructor(private modalService: NgbModal) {
  }

  ngOnInit() {
    this.isLoading = true;
    of(true).pipe(delay(1000)).subscribe(() => {
      this.isLoading = false;
      this.openQuestMap(this.topicsList[0]);
    });
  }

  openQuestModal(): void {
    const modelRef = this.modalService.open(H5pContentModalComponent, {
      centered: true,
      backdrop: 'static',
      size: 'xl',
      windowClass: 'modal-challenge',
      scrollable: true
    });
    modelRef.componentInstance.modalData = this.quest;
  }

  openQuestMap(quest: any) {
    this.quest = quest;
    this.processQuestMap(QUEST_LAYOUT.H5P_CONTENT_LIST[this.quest.h5pContentKey]);
  }

  processQuestMap(h5pContent: any[]): void {
    this.isMapLoading = true;
    this.questMap = [];
    const _questMap = QUEST_LAYOUT.LAYOUTS[this.quest.layout];
    of(true).pipe(delay(1000)).subscribe(() => {
      let h5pContentLength = 0;
      let questMapLength = _questMap.length;
      while (questMapLength--) {
        if (_questMap[questMapLength]['isAnchor'] && h5pContentLength < h5pContent.length) {
          _questMap[questMapLength]['content'] = h5pContent[h5pContentLength];
          _questMap[questMapLength]['seq'] = h5pContentLength + 1;
          h5pContentLength++;
        }
      }
      this.questMap = _questMap;
      this.isMapLoading = false;
    });
  }
}
