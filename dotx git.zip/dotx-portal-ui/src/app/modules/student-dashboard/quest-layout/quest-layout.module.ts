import {NgModule} from '@angular/core';
import {SharedModule} from '../../../shared/shared.module';
import {QuestLayoutRoutingModule} from './quest-layout-routing.module';
import {QuestMenuComponent} from './quest-menu/quest-menu.component';
import {QuestLayoutComponent} from './quest-layout.component';
import {H5pContentModalComponent} from './h5p-content-modal/h5p-content-modal.component';
import { LevelLockedPopupComponent } from './level-locked-popup/level-locked-popup.component';
import { LevelCompletedComponent } from './level-completed/level-completed.component';
import { QuestDetailComponent } from './quest-detail/quest-detail.component';


@NgModule({
  declarations: [
    QuestMenuComponent,
    QuestLayoutComponent,
    H5pContentModalComponent,
    LevelLockedPopupComponent,
    LevelCompletedComponent,
    QuestDetailComponent
  ],
  imports: [
    QuestLayoutRoutingModule,
    SharedModule
  ],
  entryComponents: [
    H5pContentModalComponent,
    LevelLockedPopupComponent,
    LevelCompletedComponent
  ]
})

export class QuestLayoutModule {}
