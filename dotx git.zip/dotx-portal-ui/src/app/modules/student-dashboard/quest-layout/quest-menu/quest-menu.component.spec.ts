import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { QuestMenuComponent } from './quest-menu.component';

describe('QuestMenuComponent', () => {
  let component: QuestMenuComponent;
  let fixture: ComponentFixture<QuestMenuComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ QuestMenuComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(QuestMenuComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
