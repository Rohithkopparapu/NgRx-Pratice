import { Component, OnDestroy, OnInit } from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { PREFERENCES } from '../../../../shared/constants/constant';
import * as moment from 'moment';
import { Subject, Subscription } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { StudentHelperService } from '../../student-helper.service';
import { LevelLockedPopupComponent } from '../level-locked-popup/level-locked-popup.component';
import { Store } from '@ngrx/store';
import { AuthState } from '../../../../shared/store/auth.model';
import { userInfo } from '../../../../shared/store/auth.selector';
import { UserDetailsAction } from '../../../../shared/store/auth.action';
import { Router } from '@angular/router';
import { H5pContentModalComponent } from '../h5p-content-modal/h5p-content-modal.component';
import { ToastrService } from 'ngx-toastr';
import { SoloChallengeModelComponent } from 'src/app/shared/component/solo-challenge-model/solo-challenge-model.component';
import { GroupChallengeModelComponent } from 'src/app/shared/component/group-challenge-model/group-challenge-model.component';
import { LevelCompletedComponent } from '../level-completed/level-completed.component';
import Swiper, { Navigation, Pagination } from 'swiper';
import { HelperService } from 'src/app/shared/services/helper.service';
import { DataService } from 'src/app/shared/services/data.service';
@Component({
  selector: 'app-quest-menu',
  templateUrl: './quest-menu.component.html',
  styleUrls: ['./quest-menu.component.scss']
})
export class QuestMenuComponent implements OnInit, OnDestroy {
  private subscriptions = new Subject<void>();
  private subscription: Subscription;
  CERTIFICATE_URL = StudentHelperService.CERTIFICATE_URL;
  isLoading = false;
  userInfo: any;
  userCommunityPreference: any;
  communityList: any[];
  community: any;
  questList: any[] = [];
  nextQuestLevelData: any;
  questStatus: any;
  prevQuestLevelData: any;
  communityFlag: boolean = false;
  QuestListFlag: boolean = false;
  usertype: any;
  pendingChallenges: any;
  questChallengeData: any;
  questLevelInfo: any;
  pendingActivities: any;
  onlyPendingActivities: any;
  completedActivities: any;
  allActivites: any[];
  nextActivities: any[];
  pendingChallengesData: any;
  showQuestTree : boolean = true;
  nextChallenge: any;
  previousLevelStatus: any;
  certificateData: any=[];
  levelStatus: any[];
  certificateId: any;
  userType: string;
  studentQuest: boolean= false;
  studentQuestData: any;

  constructor(private modalService: NgbModal, private _uhs: HelperService, private toastrService: ToastrService, private studentHelperService: StudentHelperService, private store$: Store<AuthState>,
    private router: Router, private dataService: DataService) {
    this.store$.select(userInfo)
      .pipe(takeUntil(this.subscriptions))
      .subscribe(res => {
        if (res) {
          this.userInfo = res;
          this.userCommunityPreference = res.preferences ? res.preferences.find(s => s.entity_name === PREFERENCES.COMMUNITY.ENTITY_NAME && s.entity_type === PREFERENCES.COMMUNITY.ENTITY_TYPE) : null;
          this.userType = res.user_type;
        }
      });
      const data = this.router.getCurrentNavigation().extras.state;
      if (data) {
        this.studentQuest = true
        this.studentQuestData = data.data;
      }

      this.subscription = this.dataService.refreshComponent$.subscribe(() => {
        this.refreshComponentLogic();
      });
    }
    
  ngOnInit(): void {
    this.getCommunities();
    this.studentHelperService.isRefreshHubPage
      .pipe(takeUntil(this.subscriptions))
      .subscribe(value => {
        if (value && value._page === 'quest') {
          this.refreshData();
        }
      });
      this.usertype = JSON.parse(sessionStorage.getItem('auth'));
  }

  refreshComponentLogic(){
    // this.getCommunities();
    this.refreshData();
  }

  getCommunities(): void {
    this.isLoading = true;
    this.studentHelperService.getAllCommunitiesNew().subscribe(res => {
      if (res && res.my_communities.length) {
        sessionStorage.setItem('subsribedCommunities',JSON.stringify(res));
        this.isLoading = false;      
        let arr1 = res.my_communities.filter(s =>
          !s.combo && moment(moment(s.community_start_date).format('YYYY-MM-DD')).isSameOrBefore(moment().format('YYYY-MM-DD'))).sort((a,b)=> a.community_name.localeCompare(b.community_name));
          if(this.userInfo.user_type === 'teacher'){
            this.communityList = arr1;
          }else{
            // this.communityList = arr1.filter(community => (community.community_id && community.is_grade_wise === 1) )
            if(this.userInfo.dot_registration_id !== null){
              this.communityList = arr1.filter(community => (community.community_id && community.is_grade_wise === 1) );
            }else if(this.userInfo.dot_registration_id === null){   
              this.communityList = arr1.filter(community => (community.is_certified ===0) );
            }

          }
            this.communityFlag = true;
            this.getQuestLevelsInfo();
            // this.getquestLevelCertificate();
            
      }
    },err => {
      this.isLoading = false;
    });
  }
  getQuestLevelsInfo(): void {
    this.isLoading = true;
    const payload = { community_id: Number(this.userCommunityPreference.value), user_id: this.userInfo.user_id };
    this.studentHelperService.getQuestInfo(payload).subscribe(res => {
      if(res && res.community){
        this.community = res.community;
        if(this.studentQuest === true){
          const studentComm =  this.communityList.find(x => x.community_id === this.studentQuestData.community_id);
          this.navigatetoQuest(studentComm);
          this.studentQuest = false;
          }
      }
      if (res.data && res.data.length) {
        this.questList = res.data;
        // setTimeout(() => {
          this.getquestLevelCertificate();
          this.QuestListFlag = true;
          this.isLoading = false;
        // }, 2000);
      }else{
        this.isLoading = false;
        let community;
        this.toastrService.warning("Competition community does not have a Quest. To join a Quest, join one of our Lifeskill communities");
        const list = JSON.parse(sessionStorage.getItem('subsribedCommunities'));
        if(list.my_communities !== undefined && list.my_communities.length !== 0){
        community = list.my_communities.find(x => x.community_id === res.community.community_id);
        }
        this.router.navigate(['/auth/student/community/join'] ,{ state: { community: community, path :"Quest"} });
      }
    }, () => this.isLoading = false);
    
  }
  noCompletedActivities(activities){
    return activities.filter(x => x.status === "completed" && x.is_intro != 1);
  }
  totalNoActivities(activities){
    return activities.filter(x => x.is_intro != 1);
  }
  changeIntroStatus(levelIndex: number, activityIndex: number) {
    if (activityIndex === 0) {
      if (this.questList[levelIndex].activities[activityIndex + 1].status != undefined) {
        if (this.questList[levelIndex].activities[1].status === "completed") {
          return true;
        } else {
          return false;
        }
      }
    }
  }
  initChallengesSlider(challenges: any[], isStack: boolean) {
    challenges = this._uhs.getOnlyImageFromChallenges(challenges);
    if (!isStack) {
      setTimeout(() => {
        const swiperSlider = new Swiper('.swiper.swiper-slider', {
          modules: [Navigation, Pagination],
          // Optional parameters
          // loop: true,
          keyboard: {
            enabled: true,
            onlyInViewport: false,
          },
          // Navigation arrows
          navigation: {
            nextEl: '.swiper-button-next',
            prevEl: '.swiper-button-prev',
          },
          breakpoints: {
            0: {
              slidesPerView: 1,
              spaceBetween: 10,
              slidesPerGroup: 1
            },
            576: {
              slidesPerView: 2,
              spaceBetween: 20,
              slidesPerGroup: 2
            },
            992: {
              slidesPerView: 3,
              spaceBetween: 25,
              slidesPerGroup: 3
            },
            1200: {
              slidesPerView: 4,
              spaceBetween: 30,
              slidesPerGroup: 4
            }
          }
        });
      });
    } else {
      setTimeout(() => {
        const swiperSliderStack = new Swiper('.swiper.swiper-slider-stack', {
          modules: [Navigation, Pagination],
          // Optional parameters
          // loop: true,
          keyboard: {
            enabled: true,
            onlyInViewport: false,
          },
          // Navigation arrows
          navigation: {
            nextEl: '.swiper-button-next',
            prevEl: '.swiper-button-prev',
          },
          breakpoints: {
            0: {
              slidesPerView: 1,
              spaceBetween: 10,
              slidesPerGroup: 1
            },
            576: {
              slidesPerView: 2,
              spaceBetween: 30,
              slidesPerGroup: 2
            },
            992: {
              slidesPerView: 3,
              spaceBetween: 35,
              slidesPerGroup: 3
            },
            1200: {
              slidesPerView: 4,
              spaceBetween: 50,
              slidesPerGroup: 4
            }
          }
        });
      });
    }
    return challenges;
  }
  
  getquestLevelCertificate(): void {
    this.certificateData = [];
    this.isLoading = true;
    const payload = { community_id: Number(this.userCommunityPreference.value),
                      user_id: this.userInfo.user_id 
                    };
    this.studentHelperService.getUserquestLevelCertificate(payload).subscribe(res => {
      this.isLoading = false;
      if (res) {
        this.certificateData = res;
        // console.log(this.certificateData);
        
      }else{
        this.certificateData = [];
      }
    }, () => this.isLoading = false);
  }

  generateCertificateUrl(certificate: any): string {
    return `${this.CERTIFICATE_URL}?id=${certificate.id}`;
  }

  getLevelInfo(levelIndex: number){
    const community_id =  Number(this.userCommunityPreference.value);
    const user_id = this.userInfo.user_id;
    const  level_id = this.questList[levelIndex].level_id ;
    const payload = {
      community_id: community_id,
      user_id: user_id,
      level_id: level_id
    };
    this.isLoading = true;
    this.studentHelperService.getQuestInfo(payload).subscribe(res => {
      this.isLoading = false;
      if (res && res.data) {
        this.community = res.community;
        this.questLevelInfo = res.data;
        this.pendingActivities = this.questLevelInfo.activities.filter(_act => _act.status === 'pending');
        this.onlyPendingActivities = this.questLevelInfo.activities.filter(_act => _act.is_intro === 0 && _act.status === 'pending');
        this.completedActivities = this.questLevelInfo.activities.filter(_act => _act.status === 'completed');
        this.allActivites = this.completedActivities.concat(this.pendingActivities).slice(1);
        this.checkQuestCertificateLocked()
        this.getquestLevelCertificate();
      }
    });
    const params = { community_id: community_id, level_id: level_id };
    this.isLoading = true;  
    this.studentHelperService.getQuestTopics(params).subscribe(res => {
      this.isLoading = false;
      if (res) {
        this.questChallengeData = res;
        this.community = res['community'] ? res['community'] : {};
        // this.pendingChallenges = [...res['recent_challenges'], ...res['continue_challenges']];
        this.pendingChallengesData = this.initChallengesSlider([...res['recent_challenges'], ...res['continue_challenges']], false);
        this.pendingChallenges = this.pendingChallengesData .sort((a,b) => b.is_mandatory - a.is_mandatory );
        this.getquestLevelCertificate();
      }
    });
  }
  toggleTreeView(x){    
      this.showQuestTree = x;   
  }

  
  goToActivity(levelIndex: number, activityIndex: number) {
    this.nextActivities = this.questLevelInfo.activities.slice(activityIndex + 1);
    if (this.usertype.userInfo.user_type === 'student') {
      const questInfo = this.questList[levelIndex];
      if (levelIndex === 0) {
        this.previousLevelStatus = 1;
        if (this.questList[levelIndex].activities[activityIndex].is_intro === 1) {
          this.validationToOpenActivity(questInfo, activityIndex, this.previousLevelStatus);
        } else {
          const mandatoryActivities = this.questList[levelIndex].activities.filter(x => x.is_mandatory === 1);
          if (this.questList[levelIndex].activities[activityIndex].is_mandatory === 1) {
            if (mandatoryActivities.length > 0 && mandatoryActivities.length === 1) {
              this.validationToOpenActivity(questInfo, activityIndex, this.previousLevelStatus);
            } else {
              const currentMandActId = this.questList[levelIndex].activities[activityIndex].wp_activity_id;
              const currentMandActIdIndex = mandatoryActivities.indexOf(x => x.wp_activity_id === currentMandActId);
              const prevMandAct = mandatoryActivities.slice(0, currentMandActIdIndex);
              const prevMandActStatus = prevMandAct[prevMandAct.length - 1].status;
              if (prevMandActStatus === 'completed') {
                this.validationToOpenActivity(questInfo, activityIndex, this.previousLevelStatus);
              } else {
                this.openLevelLockedPopup();
              }
            }
          } else {
            const mandatoryActNotComp = mandatoryActivities.filter(x => x.status === 'pending');
            if (mandatoryActNotComp.length !== 0) {
              this.openLevelLockedPopup();
            } else {
              this.validationToOpenActivity(questInfo, activityIndex, this.previousLevelStatus);
            }
          }
        }
      } else {
        if (this.questList[levelIndex].activities[activityIndex].is_intro === 1) {
          this.previousLevelStatus = this.questList[levelIndex-1].level_status;
          this.validationToOpenActivity(questInfo, activityIndex, this.previousLevelStatus);
        } else {
          this.previousLevelStatus = this.questList[levelIndex-1].level_status;
          if (this.previousLevelStatus === 1) {
            const mandatoryActivities = this.questList[levelIndex].activities.filter(x => x.is_mandatory === 1);
            if (this.questList[levelIndex].activities[activityIndex].is_mandatory === 1) {
              if (mandatoryActivities.length > 0 && mandatoryActivities.length === 1) {
                this.validationToOpenActivity(questInfo, activityIndex, this.previousLevelStatus);
              } else {
                const currentMandActId = this.questList[levelIndex].activities[activityIndex].wp_activity_id;
                const currentMandActIdIndex = mandatoryActivities.indexOf(x => x.wp_activity_id === currentMandActId);
                const prevMandAct = mandatoryActivities.slice(0, currentMandActIdIndex);
                const prevMandActStatus = prevMandAct[prevMandAct.length - 1].status;
                if (prevMandActStatus === 'completed') {
                  this.validationToOpenActivity(questInfo, activityIndex, this.previousLevelStatus);
                } else {
                  this.openLevelLockedPopup();
                }
              }
            } else {
              const mandatoryActNotComp = mandatoryActivities.filter(x => x.status === 'pending');
              if (mandatoryActNotComp.length !== 0) {
                this.openLevelLockedPopup();
              } else {
                this.validationToOpenActivity(questInfo, activityIndex, this.previousLevelStatus);
              }
            }
          } else {
            this.openLevelLockedPopup();
          }
        }
      }
    } else {
      const questInfo = this.questList[levelIndex];
      this.previousLevelStatus = 1;
      this.validationToOpenActivity(questInfo, activityIndex, this.previousLevelStatus);
    }
  }

  // goToActivity(levelIndex: number, activityIndex: number) {
  //   this.nextActivities = this.questLevelInfo.activities.slice(activityIndex + 1);
  //   if (this.usertype.userInfo.user_type === 'student') {
  //     const questInfo = this.questList[levelIndex];
  //     // && this.questList[levelIndex].activities[activityIndex].is_intro === 1
  //     if (levelIndex === 0 && activityIndex === 1 || this.questList[levelIndex].activities[activityIndex].is_intro === 1) {
  //       if(levelIndex === 0){
  //         this.previousLevelStatus = 1
  //       }else{
  //         this.previousLevelStatus = this.questList[levelIndex].level_status;
  //       }
  //       this.validationToOpenActivity(questInfo, activityIndex, this.previousLevelStatus);
  //     }else if(levelIndex === 0 && activityIndex !== 1){
  //       const checkNoOfMandatoryActivitiesPending = this.questList[levelIndex].activities.filter(x => x.is_mandatory && x.status !== "completed" && x.is_intro !== 1);
  //       if(this.questList[levelIndex].activities[activityIndex].is_mandatory === 1){
  //         checkNoOfMandatoryActivitiesPending.length = 0
  //       }
  //       if(checkNoOfMandatoryActivitiesPending.length === 0){
  //         if(levelIndex === 0){
  //           this.previousLevelStatus = 1
  //         }else{
  //           this.previousLevelStatus = this.questList[levelIndex].level_status;
  //         }
  //       this.validationToOpenActivity(questInfo, activityIndex, this.previousLevelStatus);
  //       }else{
  //         this.openLevelLockedPopup();
  //       }
  //     }else if(levelIndex !== 0){
  //       this.previousLevelStatus = this.questList[levelIndex-1].level_status;
  //       if(activityIndex === 0){
  //         const checkPrevLevelNoOfMandatoryActivitiesPending = this.questList[levelIndex-1].activities.filter(x => x.is_mandatory === 1 && x.status !== "completed");
  //         const checkCurrentLevelNoOfMandatoryActivitiesPending = this.questList[levelIndex].activities.filter(x => x.is_mandatory === 1 && x.status !== "completed");
  //         if(checkPrevLevelNoOfMandatoryActivitiesPending.length === 0 && checkCurrentLevelNoOfMandatoryActivitiesPending.length === 0){
  //           this.validationToOpenActivity(questInfo, activityIndex, this.previousLevelStatus);
  //         }else{
  //          if( checkCurrentLevelNoOfMandatoryActivitiesPending.find(act => act.wp_activity_id === this.questList[levelIndex].activities[activityIndex].wp_activity_id)){
  //           this.validationToOpenActivity(questInfo, activityIndex, this.previousLevelStatus);
  //          }else{
  //           this.openLevelLockedPopup();
  //          }
  //         }
  //       }else{
  //         const checkNoOfMandatoryActivitiesPending = this.questList[levelIndex].activities.filter(x => x.is_mandatory && x.status !== "completed");
  //         if(checkNoOfMandatoryActivitiesPending.length === 0){
  //           this.validationToOpenActivity(questInfo, activityIndex, this.previousLevelStatus);
  //         }else{
  //           const prevActivities = this.questList[levelIndex].activities.slice(0,activityIndex);
  //           const prevMandatoryActivities = prevActivities.filter(x => x.is_mandatory === 1);
  //           if(this.questList[levelIndex].activities[activityIndex].is_mandatory === 1 && prevMandatoryActivities.length === 0){
  //             this.validationToOpenActivity(questInfo, activityIndex, this.previousLevelStatus);
  //           }else{            
  //             this.openLevelLockedPopup();            
  //           }
  //         }
  //       }
  //     }
  //   } else {
  //     const questInfo = this.questList[levelIndex];
  //     this.previousLevelStatus = 1;
  //     this.validationToOpenActivity(questInfo, activityIndex, this.previousLevelStatus);
  //   }
  // }
  goToChallenge(levelIndex: number, challengeIndex: number) {
    const totalChallenges =   this.initChallengesSlider([...this.questChallengeData['recent_challenges'], ...this.questChallengeData['continue_challenges'],...this.questChallengeData['completedChallenges']], false);
    const questInfo = this.questList[levelIndex].challenges[challengeIndex];
    const currentChallengeObj = totalChallenges.find(x => x.topic_id === questInfo.topic_id);
    const checkMandatoryActivitiesStatus = this.questLevelInfo.activities.filter(x => x.is_mandatory === 1 && x.status === 'completed');
    // this.nextChallenge = this.questLevelInfo.challenge.slice(challengeIndex + 1);
    if (this.usertype.userInfo.user_type === 'student') {
      if(questInfo.is_mandatory === 1 ){
      if(checkMandatoryActivitiesStatus.length === 0){
        this.openChallenge(currentChallengeObj);
      }else{
        this.openLevelLockedPopup();
      }
      }else{
        const pendingMandatoryChallenges = totalChallenges.filter(x => x.is_mandatory === 1 && x.status === 'pending');
        if(pendingMandatoryChallenges.length === 0 && checkMandatoryActivitiesStatus.length === 0){
          this.openChallenge(currentChallengeObj);
        }else{
          this.openLevelLockedPopup();
        }
      }    
    } else {
      const questInfo = this.questList[levelIndex];
      this.openChallenge(challengeIndex);
    }
  }
  // validationToOpenChallenge(questInfo: any, index: number) {
  //   if (questInfo.challenges[index].status === 1) {
  //     this.openH5pContent(questInfo, index);
  //   } else {
  //     this.openH5pContent(questInfo, index);
  //   }
  // }
  validationToOpenActivity(questInfo: any, index: number, previousLevelStatus: any) {
    if (questInfo.activities[index].status === 'completed') {
      this.openH5pContent(questInfo, index, previousLevelStatus);
      // this.toastrService.warning('This Activity has been completed');
    } else {
      this.openH5pContent(questInfo, index, previousLevelStatus);
    }
  }
  openH5pContent(questInfo: any, index: number, previousLevelStatus:any) {
    let activity = this.questLevelInfo.activities[index];
    const modelRef = this.modalService.open(H5pContentModalComponent, {
      centered: true,
      scrollable: true,
      backdrop: 'static',
      size: 'xl',
      windowClass: 'modal-challenge'
    });
    activity['menuOrLayout'] = true;
    activity['community'] = this.community;
    activity['questInfo'] = this.questLevelInfo;
    modelRef.componentInstance.modalData = activity;
    modelRef.componentInstance.previousLevelStatus = previousLevelStatus;
    modelRef.componentInstance.currentIndex= index;
    modelRef.componentInstance.openActFromTable = true;
    if(activity.is_intro === 1){
      modelRef.componentInstance.startingFromIntro = true;       
    }else{
      modelRef.componentInstance.startingFromIntro = false;
    }

    if(this.nextActivities != undefined){
      modelRef.componentInstance.nextmodalData = this.nextActivities;
      modelRef.componentInstance.pendingChallenges = this.pendingChallenges;
    }
    if(questInfo === 0){
      modelRef.componentInstance.previousLevelStatus = 1;
    }else{
      modelRef.componentInstance.previousLevelStatus = previousLevelStatus;
    }
    modelRef.result.then(res => {
       if(res.navigate === "challenges" ){
        this.openChallenge(res.challenge);
      }else{
        this.refreshData();
      }
    });
  }
  openChallenge(challenge: any): any {
    const data = {
      challenge
    };
    const component = challenge.topic_group_size === 1 ? SoloChallengeModelComponent : GroupChallengeModelComponent;
    const modelRef = this.modalService.open(component, {
      centered: true,
      scrollable: true,
      backdrop: 'static',
      keyboard: false,
      size: 'xl',
      windowClass: 'modal-challenge'
    });
    modelRef.componentInstance.data = data;
    modelRef.result.then((res: any) => {
      if(res.status === "success"){
        if(this.userInfo.user_type === "student"){
        this.refreshData();
       const checkMandatoryChallenges = this.pendingChallenges.filter(x => x.topic_id != challenge.topic_id)
        const mandatoryChallenges = checkMandatoryChallenges.filter(x => x.is_mandatory);
        if (challenge.is_mandatory === 1) {
          if (mandatoryChallenges.length === 0) {
            this.openLevelCompletedPopup(challenge, mandatoryChallenges);
          } else {
            this.openChallenge(mandatoryChallenges[0]);
          }
        }else{
          this.refreshData();
          const nextChallenges = this.pendingChallenges.filter(x => x.topic_id != challenge.topic_id);
          if(nextChallenges.length != 0){
          this.openChallenge(nextChallenges[0]);
          }else{
            this.refreshData();
          }
        }
      }else{
        const nextChallenges = this.pendingChallenges.filter(x => x.topic_id != challenge.topic_id);
        if(nextChallenges.length != 0){
        this.openChallenge(nextChallenges[0]);
        }else{
          this.refreshData();
        }
      }
      } 
    });
  }
  openLevelCompletedPopup(challenge, mandatoryChallenges): void {
    const modelRef = this.modalService.open(LevelCompletedComponent, {
      centered: true,
      backdrop: 'static',
      size: 'md',
      windowClass: 'modal-challenge achievement-type',
    });
    modelRef.componentInstance.modalData = this.questLevelInfo;
    modelRef.componentInstance.nextLevelData = this.nextQuestLevelData;
    modelRef.componentInstance.challenge = challenge;
    modelRef.componentInstance.nextChallenges = mandatoryChallenges
    modelRef.result.then(res => {
      if (res.nextChallenges != undefined &&  res.nextChallenges.length != 0) {
        this.refreshData();
        this.openChallenge(res.nextChallenges);
      }else{
        this.refreshData();
      }
    });
  }
  // openH5pContent(questInfo: any, index: number) {
  //   let activity = questInfo.activities[index];
  //   const modelRef = this.modalService.open(H5pContentModalComponent, {
  //     centered: true,
  //     scrollable: true,
  //     backdrop: 'static',
  //     size: 'xl',
  //     windowClass: 'modal-challenge'
  //   });
  //   activity['menuOrLayout'] = true;
  //   activity['community'] = this.community;
  //   activity['questInfo'] = questInfo;
  //   modelRef.componentInstance.modalData = activity;
  //   modelRef.result.then(res => {
  //     if (res) {
  //       this.studentHelperService.getBadgesAndDotCoins(this.userInfo.user_id);
  //       this.refreshData();
  //     }
  //   });
  // }
  navigatetoQuest(community: any){
    if (community.is_community_user) {
      this.callCommunityService(community);
      this.getquestLevelCertificate();
    } else {
      this.router.navigate(['/auth/student/community/join']);
    }
  }
  onChangeCommunity(community: any): void {
    if (community.community_id !== this.community.community_id) {
      if (community.is_community_user) {
        this.callCommunityService(community);
        this.getquestLevelCertificate();
      } else {
        this.router.navigate(['/auth/student/community/join']);
      }
    }else{
      // this.router.navigate(['/auth/student/community/join']);
      this.toastrService.warning("Quest is not mapped to selected community Please contact adminstrator");
    }
  }
  callCommunityService(community): void {
    this.isLoading = true;
    const payload = {
      id: this.userCommunityPreference.id,
      user: this.userInfo.user_id,
      value: community.community_id.toString()
    };
    this.studentHelperService.updatePreference(payload).subscribe(res => {
      this.isLoading = false;
      if (res) {
        this.userCommunityPreference = res;
        this.store$.dispatch(new UserDetailsAction({ userId: this.userInfo.user_id, _page: 'quest' }));
      }
    }, () => this.isLoading = false);
  }
  openLevelLockedPopup(): void {
    const modelRef = this.modalService.open(LevelLockedPopupComponent, {
      centered: true,
      backdrop: 'static',
      size: 'md',
      windowClass: 'modal-challenge',
      scrollable: true
    });
  }
  gotoLevelPage(index: number): void {
    const nextSequence = this.questList[index].level_sequence + 1;
    this.nextQuestLevelData = this.questList.find(x => x.level_sequence === nextSequence);
    if (this.usertype.userInfo.user_type === 'student') {
      if (!this.checkQuestLocked(index)) {
        this.openLevelLockedPopup();
      } else {
        // this.getChallengesByLevelId();
        if (this.questList[index] - 1 > 0) {
          const prevSequence = this.questList[index] - 1;
          this.prevQuestLevelData = this.questList.find(x => x === prevSequence);
          // const params = { community_id: Number(this.userCommunityPreference.value), level_id: this.prevQuestLevelData.level_id };
          // this.isLoading = true;
          // this.studentHelperService.getQuestTopics(params).subscribe(res => {
            // this.isLoading = false;
            // if (res) {
              // this.questStatus = res.quest_level.level_status;
              if (this.prevQuestLevelData.level_status) {
                this.router.navigate(['/auth/student/quest/details'], { state: { questData: this.questList[index], nextLevelData: this.nextQuestLevelData } });
              } else {
                this.openLevelLockedPopup();
              }
            // }
          // }, () => this.isLoading = true);
        } else {
          this.router.navigate(['/auth/student/quest/details'], { state: { questData: this.questList[index], nextLevelData: this.nextQuestLevelData } });
        }
      }
    } else {
      this.router.navigate(['/auth/student/quest/details'], { state: { questData: this.questList[index], nextLevelData: this.nextQuestLevelData } });
    }
  }
  setQuestOrDefaultImage(quest: any): string {
    return quest.quest_level_file_path ? quest.quest_level_file_path : 'assets/img/spotlight-challenges-img.jpg';
  }
  checkActivitiesCompleted(quest: any): any {
    if (quest.level_status === 1){
      this.pendingActivities = quest.activities.filter(x => x.status === "pending");
      return true;
    } else {
      return false;
    }
  }
  checkActivitiesStatus(activities: any): any {
    if (activities.is_intro === 1) {
      const introStatus = this.allActivites[activities.index + 1].status;
      if (introStatus != undefined && introStatus === "completed") {
        return true;
      } else {
        return false;
      }
    } else {
      const introStatus = this.allActivites[activities.index].status;
      if (introStatus === "completed") {
        return true;
      } else {
        return false;
      }
    }
  }
  checkQuestLocked(index: number): boolean {
    if (this.usertype.userInfo.user_type === 'student') {
      if (index === 0) {
        return true;
      } else {
        return this.checkActivitiesCompleted(this.questList[index - 1]);
      }
    }else{
      return true;
    }
  }
  checkQuestCertificateLocked(): any {
    const questLevelStatus = this.questList.filter(x => x.level_status !== 1);
    if (questLevelStatus.length !== 0) {
      
      return false;
    } else {
      return true;
    }
  }

  refreshData(): void {
    this.community = {};
    this.communityList = [];
    this.questList = [];
    this.getCommunities();
    // this.getQuestLevelsInfo();
  }
  
  ngOnDestroy(): void {
    this.subscriptions.next();
    this.subscriptions.complete();
  }
}
