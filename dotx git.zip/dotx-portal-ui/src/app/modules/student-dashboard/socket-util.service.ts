import {Injectable, OnDestroy} from '@angular/core';
import {Manager, Socket} from 'socket.io-client';
import {environment} from '../../../environments/environment';
import {Observable, Subject} from 'rxjs';
import {SOCKET_EVENTS} from '../../shared/constants/constant';
import {takeUntil} from 'rxjs/operators';
import {Store} from '@ngrx/store';
import {AuthState} from '../../shared/store/auth.model';
import {accessToken, userInfo} from '../../shared/store/auth.selector';

@Injectable({
  providedIn: 'root'
})
export class SocketUtilService implements OnDestroy {

  private subscriptions = new Subject<void>();
  private userInfo: any;
  private accessToken: string;
  private manager: Manager;
  private readonly socket: Socket;
  buddyDetails = new Subject<any>();
  // notificationMessage = new Subject<any>();

  constructor(private store$: Store<AuthState>) {
    this.store$.select(userInfo)
      .pipe(takeUntil(this.subscriptions))
      .subscribe(res => this.userInfo = res);
    this.store$.select(accessToken)
      .pipe(takeUntil(this.subscriptions))
      .subscribe(res => this.accessToken = res);
    this.manager = new Manager(environment.SOCKET_URL, {
      reconnectionDelayMax: 10000,
      path: '/lifeskills/socket',
      autoConnect: false
    });
    this.socket = this.manager.socket('/chat');
  }

  setUpSocketConnection(): void {
    if (!this.socket.connected) {
      this.manager.opts.query = {
        uid: this.userInfo.user_id
      };
      this.socket.auth = {
        user_id: this.userInfo.user_id,
        access_token: this.accessToken
      };
      this.socket.connect();
      this.onConnectionError();
    }
  }

  disconnectConnection(): void {
    this.socket.disconnect();
  }

  getOnlineUsers(): Observable<any> {
    return new Observable((observer) => {
      this.socket.on(SOCKET_EVENTS.ONLINE_USERS, (users) => {
        observer.next(users);
      });
      return () => {
        this.socket.disconnect();
      };
    });
  }

  sendMessage(messagePayload: any): void {
    this.socket.emit(SOCKET_EVENTS.SEND_MESSAGE, messagePayload);
  }

  getMessage(): Observable<any> {
    return new Observable((observer) => {
      this.socket.on(SOCKET_EVENTS.RECEIVE_MESSAGE, (message) => {
        observer.next(message);
      });
      return () => {
        this.socket.disconnect();
      };
    });
  }

  onConnectionError(): void {
    this.socket.on(SOCKET_EVENTS.CONNECT_ERROR, () => {
      this.socket.auth = {
        user_id: this.userInfo.user_id,
        access_token: this.accessToken
      };
      setTimeout(() => {
        console.log('Reconnecting...');
        this.socket.connect();
      }, 1000);
    });
  }

  getSocket(): Socket {
    return this.socket;
  }

  ngOnDestroy(): void {
    if (this.socket.connected) {
      this.subscriptions.next();
      this.subscriptions.complete();
      this.socket.disconnect();
    }
  }
}
