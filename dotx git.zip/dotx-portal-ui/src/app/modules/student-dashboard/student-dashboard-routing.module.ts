import {Injectable, NgModule, OnDestroy} from '@angular/core';
import {ActivatedRouteSnapshot, Resolve, Router, RouterModule, RouterStateSnapshot, Routes} from '@angular/router';
import {StudentDashboardComponent} from './student-dashboard.component';
import {ToastrService} from 'ngx-toastr';
import {Observable, Subject} from 'rxjs';
import {PREFERENCES} from '../../shared/constants/constant';
import {AboutUsComponent} from '../../shared/component/about-us/about-us.component';
import {takeUntil} from 'rxjs/operators';
import {Store} from '@ngrx/store';
import {AuthState} from '../../shared/store/auth.model';
import {userInfo} from '../../shared/store/auth.selector';
import {DotcoinStoreComponent} from './dotcoin-store/dotcoin-store.component';
import { DotstorepopupComponent } from './dotcoin-store/dot-store/dotstorepopup/dotstorepopup.component';
import { TeacherDashboardComponent } from './teacher-dashboard/teacher-dashboard.component';


@Injectable({ providedIn: 'root' })
export class StudentDashboardResolver implements Resolve <any>, OnDestroy {

  private subscriptions = new Subject<void>();
  userInfo: any;
  userCommunityPreference: any;

  constructor(private router: Router, private toastrService: ToastrService, private store$: Store<AuthState>) {
    this.store$.select(userInfo)
      .pipe(takeUntil(this.subscriptions))
      .subscribe(res => {
        if (res) {
          this.userInfo = res;
          this.userCommunityPreference = res.preferences ? res.preferences.find(s => s.entity_name === PREFERENCES.COMMUNITY.ENTITY_NAME && s.entity_type === PREFERENCES.COMMUNITY.ENTITY_TYPE) : null;
        }
      });
  }

  resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<any> | Promise<any> | any {
    if (this.userCommunityPreference) {
      return this.userCommunityPreference;
    } else {
     const flag = sessionStorage.getItem('toastFlag');
      if(flag == undefined && flag !== 'Community'){
        this.toastrService.warning('Please Join Community');
      }
      this.router.navigate(['/auth/student/community/join']);
      sessionStorage.removeItem('toastFlag');
    }
  }

  ngOnDestroy(): void {
    this.subscriptions.next();
    this.subscriptions.complete();
  }
}

const routes: Routes = [
  {
    path: '',
    component: StudentDashboardComponent,
    children: [
      {
        path: 'community',
        loadChildren: () => import('./join-community/join-community.module').then(m => m.JoinCommunityModule),
      },
      {
        path: 'home',
        loadChildren: () => import('./home-layout/home-layout.module').then(m => m.HomeLayoutModule),
        resolve: {
          userPreferenceDetails: StudentDashboardResolver
        },
      },
      {
        path: 'challenge',
        loadChildren: () => import('./challenge-hub/challenge-hub.module').then(m => m.ChallengeHubModule),
        resolve: {
          userPreferenceDetails: StudentDashboardResolver
        },
      },
      {
        path: 'quest',
        loadChildren: () => import('./quest-layout/quest-layout.module').then(m => m.QuestLayoutModule),
        resolve: {
          userPreferenceDetails: StudentDashboardResolver
        },
      },
      {
        path: 'dot-store',
        component: DotcoinStoreComponent,
        resolve: {
          userPreferenceDetails: StudentDashboardResolver
        },
      },
      {
        path: 'dot-store-reddem',
        component: DotstorepopupComponent,
        resolve: {
          userPreferenceDetails: StudentDashboardResolver
        },
      },
      {
        path: 'about-us',
        component: AboutUsComponent
      },
      {
        path: '',
        redirectTo: 'home',
        pathMatch: 'full'
      },
      {
        path: 'teacher-dashboard',
        component:TeacherDashboardComponent,
        resolve: {
          userPreferenceDetails: StudentDashboardResolver
        },
      }
    ]
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class StudentDashboardRoutingModule {}
