import {Component, OnDestroy, OnInit} from '@angular/core';
import {SocketUtilService} from './socket-util.service';
import {SetOnlineUsers} from '../../shared/store/auth.action';
import {Message} from '../../shared/model/message.model';
import {Store} from '@ngrx/store';
import {AuthState} from '../../shared/store/auth.model';
import {ToastrService} from 'ngx-toastr';
import {NotificationPopupComponent} from '../../shared/component/notification-popup/notification-popup.component';

@Component({
  selector: 'app-student-dashboard',
  templateUrl: './student-dashboard.component.html'
})
export class StudentDashboardComponent implements OnInit, OnDestroy {

  buddyDetails: any;

  constructor(private socketUtilService: SocketUtilService, private store$: Store<AuthState>, private toastrService: ToastrService) {
    this.socketUtilService.setUpSocketConnection();
  }

  ngOnInit(): void {
    this.getConnectedSocketUsers();
    this.setBuddyDetails();
    this.onReceiveMessage();
  }

  setBuddyDetails(): void {
    this.socketUtilService.buddyDetails.subscribe(res => {
      this.buddyDetails = res;
    });
  }

  getConnectedSocketUsers(): void {
    this.socketUtilService.getOnlineUsers().subscribe(res => {
      this.store$.dispatch(new SetOnlineUsers(res));
    });
  }

  onReceiveMessage(): void {
    this.socketUtilService.getMessage().subscribe((message: Message) => {
      if ((this.buddyDetails && this.buddyDetails.user_id) !== message.from_user_id) {
        this.toastrService.info(message.message, message.display_name,{ timeOut: 100000 }); // temporary
        const messageNotification = new Audio('assets/audio/msg-notif.mp3'); // temporary
        messageNotification.play(); // temporary
        // const activateToast = this.toastrService.show(message.message, message.display_name, {
        //   toastComponent: NotificationPopupComponent,
        //   disableTimeOut: true
        // });
        // activateToast.toastRef.componentInstance.data = { messageDetails: message };
      }
    });
  }

  ngOnDestroy(): void {
    this.socketUtilService.buddyDetails.next();
    this.socketUtilService.buddyDetails.complete();
  }
}
