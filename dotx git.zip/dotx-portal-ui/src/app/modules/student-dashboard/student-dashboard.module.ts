/* Modules */
import {NgModule} from '@angular/core';
import {StudentDashboardRoutingModule} from './student-dashboard-routing.module';
import {SharedModule} from 'src/app/shared/shared.module';
import {ChallengeHubModule} from './challenge-hub/challenge-hub.module';
import {JoinCommunityModule} from './join-community/join-community.module';
// import {ModalModule} from 'ngx-bootstrap/modal';
/* Components  */
import {StudentDashboardComponent} from './student-dashboard.component';
import {StudentHeaderComponent} from './header-section/student-header/student-header.component';
import {EditStudentProfileComponent} from './header-section/edit-student-profile/edit-student-profile.component';
import {PersonalityQuizComponent} from './header-section/edit-student-profile/personality-quiz/personality-quiz.component';
import {TalentsFavouritesComponent} from './header-section/edit-student-profile/talents-favourites/talents-favourites.component';
import {MySpaceComponent} from './header-section/my-space/my-space.component';
import {PersonalInfoComponent} from './header-section/edit-student-profile/personal-info/personal-info.component';
import {AvatarComponent} from './header-section/edit-student-profile/avatar/avatar.component';
import {PaymentModule} from './payment-gateway/payment.module';
import {DotcoinStoreComponent} from './dotcoin-store/dotcoin-store.component';
import { MyGroupComponent } from './header-section/edit-student-profile/my-group/my-group.component';
import { DotstorePopComponent } from './dotcoin-store/dotstore-pop/dotstore-pop.component';
import { DotstorepopupComponent } from './dotcoin-store/dot-store/dotstorepopup/dotstorepopup.component';
import { CreateGroupComponent } from './header-section/create-group/create-group.component';
import { AddNewGroupComponent } from './header-section/add-new-group/add-new-group.component';
import { TeacherDashboardComponent } from './teacher-dashboard/teacher-dashboard.component';
import { ActivityInformationComponent } from './activitiy-information/activity-information.component';
import {NgbActiveModal, NgbModule} from '@ng-bootstrap/ng-bootstrap';


@NgModule({
  declarations: [
    StudentDashboardComponent,
    StudentHeaderComponent,
    EditStudentProfileComponent,
    PersonalityQuizComponent,
    TalentsFavouritesComponent,
    MySpaceComponent,
    PersonalInfoComponent,
    AvatarComponent,
    DotcoinStoreComponent,
    MyGroupComponent,
    DotstorePopComponent,
    DotstorepopupComponent,
    CreateGroupComponent,
    AddNewGroupComponent,
    TeacherDashboardComponent,
    ActivityInformationComponent
  ],
  imports: [
    StudentDashboardRoutingModule,
    SharedModule,
    ChallengeHubModule,
    JoinCommunityModule,
    PaymentModule,
    NgbModule
    // ModalModule.forRoot(),
  ],
  entryComponents: [
    MySpaceComponent,
    EditStudentProfileComponent,
    // DotstorePopComponent,
    CreateGroupComponent,
    AddNewGroupComponent,
    ActivityInformationComponent
  ],
  providers: [NgbActiveModal]
})
export class StudentDashboardModule {}
