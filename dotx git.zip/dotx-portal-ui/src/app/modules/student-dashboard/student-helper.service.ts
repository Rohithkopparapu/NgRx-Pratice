import {Inject, Injectable} from '@angular/core';
import {DOCUMENT} from '@angular/common';
import {HttpClient} from '@angular/common/http';
import {BehaviorSubject, Observable, ReplaySubject, throwError} from 'rxjs';
import {environment} from 'src/environments/environment';
import {SetMyPortfolio} from '../../shared/store/auth.action';
import {Store} from '@ngrx/store';
import {AuthState} from '../../shared/store/auth.model';
import {catchError} from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class StudentHelperService {

  private static USER_DETAILS_URL = `${environment.baseURL}/dot-user-details`;
  private static USER_SKILL_URL = `${environment.baseURL}/dot-user-skills`;
  private static DAILY_DOT_RECORDS_URL = `${environment.baseURL}/dot-daily-dot-records`;
  private static DAILY_DOT_RECORDS_DASHBOARD_URL = `${environment.baseURL}/dot-daily-dot-records/dashboard`;
  private static TOPIC_DETAILS_URL = `${environment.baseURL}/dot-topic-details`;
  private static LOGIN_HISTORY_URL = `${environment.baseURL}/dot-login-history`;
  private static TOPIC_RESPONSE_URL = `${environment.baseURL}/dot-topic-response`;
  private static TOPIC_RESP_COMMENT_URL = `${environment.baseURL}/dot-topic-resp-comments`;
  private static TOPIC_RESP_RATING_URL = `${environment.baseURL}/dot-topic-resp-ratings`;
  private static STUDENT_QUIZ_DETAILS_URL = `${environment.baseURL}/dot-std-per-quiz-details`;
  private static REWARD_ALLOCATION_URL = `${environment.baseURL}/dot-reward-allocation`;
  private static TOPIC_GROUP_URL = `${environment.baseURL}/dot-topic-group`;
  private static TOPIC_GROUP_ROLES_URL = `${environment.baseURL}/dot-topic-group-roles`;
  private static NOTIFICATION_URL = `${environment.baseURL}/dot-notifications`;
  private static USER_PREFERENCE_URL = `${environment.baseURL}/dot-user-preferences`;
  private static NEWS_FEED_URL = `${environment.baseURL}/dot-foryou`;
  private static OFFLINE_CHAT_URL = `${environment.baseURL}/dot-user-chat`;
  private static COMMUNITY_URL = `${environment.baseURL}/dot-community`;
  private static ANNOUNCEMENT_URL = `${environment.baseURL}/dot-announcements`;
  private static ANNOUNCEMENT_COMMENT_URL = `${environment.baseURL}/dot-announcement-comments`;
  private static USER_CERTIFICATES_URL = `${environment.baseURL}/dot-user-certificates`;
  private static COUPON_URL = `${environment.baseURL}/dot-discount-coupons`;
  private static QUEST_DETAILS_URL = `${environment.baseURL}/dot-quest-level-activities`;
  private static DOT_STORE_URL = `${environment.baseURL}/dot-store-category`;
  // private static DOT_STORE_URL = `${environment.baseURL}/dot-store-category`;
  private static DOT_STORE_REDEEM_URL = `${environment.baseURL}/dot-store-item`;
  // private static DOT_STORE_CAT_INFO_URL = `${environment.baseURL}/dot-store-category`;
  private static GET_GROUP_URL = `${environment.baseURL}/dot-user-group`;
  private static GET_GROUP_MEMBER_URL = `${environment.baseURL}/dot-user-group-members`;
  private static USER_DETAILS_URL_SCHOOL = `${environment.baseURL}/dot-user-group-members`;
  private static GET_TEACHER_DASHBOARD_URL = `${environment.baseURL}/dot-ajax/teacher-dashboard`;
  private static GET_ACTIVITIES_DETAILS_URL = `${environment.baseURL}/dot-ajax/activityScoreInfo`;
  static PAYMENT_URL = `${environment.baseURL}/dot-payment`;
  static CERTIFICATE_URL = `${environment.baseURL}/dot-files/get_certificate`;
  static BADGELISt = `${environment.baseURL}/dot-badge-configurations`;
  static OPENAI = `${environment.baseURL}/dot-ai-response`
  private isLoading$ = new BehaviorSubject<boolean>(false);
  _loadedLibraries: { [url: string]: ReplaySubject<any> } = {};
  isRefreshHubPage = new BehaviorSubject<any>({});
 
  constructor(public http: HttpClient, @Inject(DOCUMENT) private readonly document: Document, private store$: Store<AuthState>) {
  }

  setLoading(value: boolean): void {
    this.isLoading$.next(value);
  }

  getLoading(): Observable<boolean> {
    return this.isLoading$.asObservable();
  }

  getBadgesAndDotCoins(userId: any): void {
    this.getBadges(userId).subscribe((badges: any) => {
      this.getAchievements(userId).subscribe((achievements: any) => {
        this.store$.dispatch(new SetMyPortfolio({achievements: achievements && achievements.length ? achievements[0] : {}, badges}));
      });
    });
  }

  /* Student Dashboard  */

  getUserSkills(page?: string): Observable<any> {
    const url = page ? StudentHelperService.USER_SKILL_URL + '/' + page : StudentHelperService.USER_SKILL_URL;
    return this.http.get(url);
  }

  getUserSkillsByUserId(userId): Observable<any> {
    const url = `${StudentHelperService.USER_SKILL_URL}/userid/${userId}`;
    return this.http.get(url);
  }

  getAchievements(userId): Observable<any> {
    const data = {user_id: userId};
    return this.http.post(StudentHelperService.REWARD_ALLOCATION_URL + '/achievements', data);
  }

  getBadges(userId): Observable<any> {
    const data = {user_id: userId};
    return this.http.post(StudentHelperService.REWARD_ALLOCATION_URL + '/badges', data);
  }

  getStudentPersonalityQuiz(): Observable<any> {
    return this.http.get(`${StudentHelperService.STUDENT_QUIZ_DETAILS_URL}/student_quiz_details`);
  }

  savePersonalizeQuizDetails(payload): Observable<any> {
    return this.http.post(`${StudentHelperService.STUDENT_QUIZ_DETAILS_URL}`, payload);
  }

  updateSkills(payload): Observable<any> {
    return this.http.post(StudentHelperService.USER_SKILL_URL + '/update', payload);
  }

  updateUserProfile(payload): Observable<any> {
    return this.http.put(StudentHelperService.USER_DETAILS_URL, payload);
  }

  getMyBuddies(payload: any): Observable<any> {
    const url = `${StudentHelperService.USER_DETAILS_URL}/my_buddies`;
    return this.http.post(url, payload);
  }

  getUserInfo(userId): Observable<any> {
    const url = `${StudentHelperService.USER_DETAILS_URL}/${userId}`;
    // tslint:disable-next-line:object-literal-shorthand
    return this.http.get(url);
  }

  searchByValue(payload): Observable<any> {
    const url = `${StudentHelperService.USER_DETAILS_URL}/buddy_search`;
    // tslint:disable-next-line:object-literal-shorthand
    return this.http.post(url, payload);
  }

  getUserList(payload): Observable<any> {
    const url = `${StudentHelperService.USER_DETAILS_URL}/users_list`;
    return this.http.post(url, payload);
  }

  // -------------------------------------------------------------
  //  Daily quote services


  getDailyQuotes(payload): Observable<any> {
    const url = `${StudentHelperService.DAILY_DOT_RECORDS_URL}/filter`;
    console.log('url', url);
    // tslint:disable-next-line:object-literal-shorthand
    return this.http.post(url, payload);
  }

  postDailyQuote(payload): Observable<any> {
    const url = `${StudentHelperService.DAILY_DOT_RECORDS_URL}`;
    // tslint:disable-next-line:object-literal-shorthand
    return this.http.put(url, payload);
  }

  postDailyQuestion(payload): Observable<any> {
    const url = `${StudentHelperService.DAILY_DOT_RECORDS_URL}`;
    // tslint:disable-next-line:object-literal-shorthand
    return this.http.put(url, payload);
  }

  postDailyJournal(payload): Observable<any> {
    const url = `${StudentHelperService.DAILY_DOT_RECORDS_URL}`;
    // tslint:disable-next-line:object-literal-shorthand
    return this.http.put(url, payload);
  }

  retrievePolls(payload): Observable<any> {
    const url = `${StudentHelperService.DAILY_DOT_RECORDS_DASHBOARD_URL}`;
    // tslint:disable-next-line:object-literal-shorthand
    return this.http.post(url, payload);
  }

  retrieveQuestions(payload): Observable<any> {
    const url = `${StudentHelperService.DAILY_DOT_RECORDS_DASHBOARD_URL}`;
    // tslint:disable-next-line:object-literal-shorthand
    return this.http.post(url, payload);
  }

  retrieveJournals(payload): Observable<any> {
    const url = `${StudentHelperService.DAILY_DOT_RECORDS_DASHBOARD_URL}`;
    // tslint:disable-next-line:object-literal-shorthand
    return this.http.post(url, payload);
  }

  submitWorkLocation(payload): Observable<any> {
    return this.http.post(StudentHelperService.LOGIN_HISTORY_URL, payload);
  }


  // ------------------------- SpotlightChallenges----------------

  saveChallengeData(data: any): Observable<any> {
    const url = `${StudentHelperService.TOPIC_DETAILS_URL}/create_challenge`;
    return this.http.post(url, data).pipe(catchError(err => throwError(err)));
  }

  getChallenges(communityId): Observable<any> {
    return this.http.get(`${StudentHelperService.TOPIC_DETAILS_URL}/challenge_hub/${communityId}`);
  }

  getChallengesPublic(communityId): Observable<any> {
    return this.http.get(`${StudentHelperService.TOPIC_DETAILS_URL}/challenge_hub_public/${communityId}`);
  }

  spotLightChallenges(): Observable<any> {
    const url = `${StudentHelperService.TOPIC_DETAILS_URL}/spotlight_challenges`;
    // tslint:disable-next-line:object-literal-shorthand
    return this.http.get(url);
  }

  getChallengeTrend(payload): Observable<any> {
    const url = `${StudentHelperService.TOPIC_DETAILS_URL}/challenge_trend`;
    // tslint:disable-next-line:object-literal-shorthand
    return this.http.post(url, payload);
  }

  getChallengeMine(payload): Observable<any> {
    const url = `${StudentHelperService.TOPIC_DETAILS_URL}/my_profile_challenges${payload}`;
    return this.http.get(url);
  }

  getMyChallenges(payload): Observable<any> {
    const url = `${StudentHelperService.TOPIC_DETAILS_URL}/my_challenges`;
    return this.http.post(url, payload);
  }

  getUpcomingChallenges(payload): Observable<any> {
    const url = `${StudentHelperService.TOPIC_DETAILS_URL}/upcoming_challenges`;
    return this.http.post(url, payload);
  }

  getInfluencerChallenges(): Observable<any> {
    const url = `${StudentHelperService.TOPIC_DETAILS_URL}/influencer_challenges`;
    return this.http.get(url);
  }

  getChallengesContinue(payload): Observable<any> {
    const url = `${StudentHelperService.TOPIC_DETAILS_URL}/continue_challenges`;
    return this.http.post(url, payload);
  }

  getChallengesRecent(payload): Observable<any> {
    const url = `${StudentHelperService.TOPIC_DETAILS_URL}/recent_challenges`;
    return this.http.post(url, payload);
  }

  getTop10ResponsesChallenges(): Observable<any> {
    const url = `${StudentHelperService.TOPIC_DETAILS_URL}/top10_responses`;
    return this.http.get(url);
  }

  getChallengesTop10(payload): Observable<any> {
    const url = `${StudentHelperService.TOPIC_DETAILS_URL}/challenge_top10`;
    // tslint:disable-next-line:object-literal-shorthand
    return this.http.post(url, payload);
  }

  getResponseCards(topicId): Observable<any> {
    const url = `${StudentHelperService.TOPIC_DETAILS_URL}/response_cards/${topicId}`;
    return this.http.get(url);
  }

  getResponseCardsPublic(topicId): Observable<any> {
    const url = `${StudentHelperService.TOPIC_DETAILS_URL}/response_cards_public/${topicId}`;
    return this.http.get(url);
  }

  getTopicDetailsById(topic_id): Observable<any> {
    const url = `${StudentHelperService.TOPIC_DETAILS_URL}/${topic_id}`;
    return this.http.get(url);
  }

  getTopicDetailsByIdPublic(topicId): Observable<any> {
    const url = `${StudentHelperService.TOPIC_DETAILS_URL}/get/${topicId}`;
    return this.http.get(url);
  }

  getChallengesByCommunityId(payload): Observable<any> {
    const url = `${StudentHelperService.TOPIC_DETAILS_URL}/filter`;
    return this.http.post(url, payload);
  }

  groupMemById(payload): Observable<any> {
    const url = `${StudentHelperService.TOPIC_RESPONSE_URL}/submitted_comments`;
    return this.http.post(url, payload);
  }

  getSoloChallengeResponses(payload: any): Observable<any> {
    const url = `${StudentHelperService.TOPIC_RESPONSE_URL}/solo_responses`;
    return this.http.post(url, payload);
  }

  getCompetitionChallengeResponses(payload: any): Observable<any> {
    const url = `${StudentHelperService.TOPIC_RESPONSE_URL}/competition_responses`;
    return this.http.post(url, payload);
  }

  addComments(payload): Observable<any> {
    const url = `${StudentHelperService.TOPIC_RESPONSE_URL}`;
    // tslint:disable-next-line:object-literal-shorthand
    return this.http.post(url, payload);
  }

  getCommentRetrieveGroup(topic_id): Observable<any> {
    const url = `${StudentHelperService.TOPIC_RESPONSE_URL}/group_comments/${topic_id}`;
    // tslint:disable-next-line:object-literal-shorthand
    return this.http.get(url);
  }

  getSoloChallengeNotes(topicAssignId: number): Observable<any> {
    const url = `${StudentHelperService.TOPIC_RESPONSE_URL}/solo_challenge_notes/${topicAssignId}`;
    return this.http.get(url);
  }

  autoAssignChallenge(payload): Observable<any> {
    const url = `${StudentHelperService.TOPIC_GROUP_URL}/auto_assign`;
    return this.http.post(url, payload);
  }

  loadScript(url: string): Observable<any> {
    if (this._loadedLibraries[url]) {
      return this._loadedLibraries[url].asObservable();
    }

    this._loadedLibraries[url] = new ReplaySubject();

    const script = this.document.createElement('script');
    script.type = 'text/javascript';
    script.src = url;
    script.onload = () => {
      this._loadedLibraries[url].next();
      this._loadedLibraries[url].complete();
    };

    this.document.body.appendChild(script);

    return this._loadedLibraries[url].asObservable();
  }

  roles(payload): Observable<any> {
    const url = `${StudentHelperService.TOPIC_GROUP_ROLES_URL}/topic_roles`;
    return this.http.post(url, payload);
  }

  postSelectedRole(payload): Observable<any> {
    const url = `${StudentHelperService.TOPIC_GROUP_ROLES_URL}`;
    return this.http.post(url, payload);
  }

  saveGroup(data: any): Observable<any> {
    const url = `${StudentHelperService.TOPIC_GROUP_URL}/create_challenge_group`;
    return this.http.post(url, data).pipe(catchError(err => throwError(err)));
  }

  updateGroup(data: any): Observable<any> {
    const url = `${StudentHelperService.TOPIC_GROUP_URL}/update_challenge_group`;
    return this.http.put(url, data).pipe(catchError(err => throwError(err)));
  }

  checkGroup(payload): Observable<any> {
    const url = `${StudentHelperService.TOPIC_GROUP_URL}/check_groupname`;
    return this.http.post(url, payload);
  }

  groupMembers(payload): Observable<any> {
    const url = `${StudentHelperService.TOPIC_GROUP_ROLES_URL}/group_members`;
    return this.http.post(url, payload);
  }

  reactOnSubmission(payload): Observable<any> {
    const url = `${StudentHelperService.TOPIC_RESP_RATING_URL}/react_response`;
    return this.http.post(url, payload);
  }

  JoinSoloChallenge(payload): Observable<any> {
    const url = `${StudentHelperService.TOPIC_DETAILS_URL}/join_solo_challenge`;
    return this.http.post(url, payload);
  }

  postResponse(payload): Observable<any> {
    const url = `${StudentHelperService.TOPIC_RESP_COMMENT_URL}`;
    return this.http.post(url, payload);
  }

  postReview(payload): Observable<any> {
    const url = `${StudentHelperService.TOPIC_RESPONSE_URL}/response_evaluation`
    return this.http.post(url, payload);
  }

  updateResponse(payload): Observable<any> {
    const url = `${StudentHelperService.TOPIC_RESP_COMMENT_URL}`;
    return this.http.put(url, payload);
  }

  deleteComment(id: number): Observable<any> {
    const url = `${StudentHelperService.TOPIC_RESP_COMMENT_URL}/${id}`;
    return this.http.delete(url);
  }

  getResponses(payload): Observable<any> {
    const url = `${StudentHelperService.TOPIC_RESP_COMMENT_URL}/filter`;
    return this.http.post(url, payload);
  }

  /* Community services */

  getAllCommunities(): Observable<any> {
    const url = `${StudentHelperService.COMMUNITY_URL}`;
    return this.http.get(url);
  }
  
  getAllCommunitiesNew(): Observable<any> {
    const url = `${StudentHelperService.COMMUNITY_URL}/subscribedCommunities`;
    return this.http.get(url);
  }
  getAllCommunitiesPublic(): Observable<any> {
    const url = `${StudentHelperService.COMMUNITY_URL}/get_all`;
    return this.http.get(url);
  }


  // ----------- Streaks ---------------------------

  searchChallenges(payload): Observable<any> {
    const url = `${StudentHelperService.TOPIC_DETAILS_URL}/search`;
    return this.http.post(url, payload);
  }

  getLeaderboardDetails(queryParams): Observable<any> {
    const url = `${StudentHelperService.REWARD_ALLOCATION_URL}/leader_board${queryParams}`;
    return this.http.get(url);
  }

  getLeadeboardDetailsNew(startDate,endDate,commId,page,perpage):Observable <any>{
    const url = `${StudentHelperService.REWARD_ALLOCATION_URL}/leader-board${startDate}${endDate}${commId}&page=${page}${perpage}`
    return this.http.get(url);
  }

  getMultipleInvitesForChallenge(topicId): Observable<any> {
    const url = `${StudentHelperService.TOPIC_DETAILS_URL}/challenge_invitations/${topicId}`;
    return this.http.get(url);
  }

  getNotifications(payload: any): Observable<any> {
    const url = `${StudentHelperService.NOTIFICATION_URL}/filter`;
    return this.http.post(url, payload);
  }

  sendEmail(payload: any): Observable<any> {
    const url = `${StudentHelperService.USER_DETAILS_URL}/email_buddy`;
    return this.http.post(url, payload);
  }

  searchStudentByEmail(payload): Observable<any> {
    const url = `${StudentHelperService.USER_DETAILS_URL}/check-email`;
    return this.http.post(url, payload);
  }

  inviteBuddy(payload: any): Observable<any> {
    const url = `${StudentHelperService.USER_DETAILS_URL}/invite_buddy`;
    return this.http.post(url, payload);
  }

  deleteResponse(id: any): Observable<any> {
    const url = `${StudentHelperService.TOPIC_RESPONSE_URL}/${id}`;
    return this.http.delete(url);
  }

  // ------------------------- User Preferences ----------------------

  createPreference(payload): Observable<any> {
    const url = `${StudentHelperService.USER_PREFERENCE_URL}`;
    return this.http.post(url, payload);
  }

  updatePreference(payload): Observable<any> {
    const url = `${StudentHelperService.USER_PREFERENCE_URL}`;
    return this.http.put(url, payload);
  }

  // ------------------------- Home Layout ----------------------------

  retrieveBroadcastData(): Observable<any> {
    const url = `${StudentHelperService.NOTIFICATION_URL}/latest_broadcast`;
    return this.http.get(url);
  }

  getLatestChallenges(): Observable<any> {
    const url = `${StudentHelperService.TOPIC_DETAILS_URL}/latest_challenges`;
    return this.http.get(url);
  }

  getMyFriends(): Observable<any> {
    const url = `${StudentHelperService.USER_DETAILS_URL}/my_friends`;
    return this.http.get(url);
  }

  getNewsFeed(payload): Observable<any> {
    const url = `${StudentHelperService.NEWS_FEED_URL}/updates_wall?page=${payload.pageNumber}&size=${payload.pageSize}`;
    return this.http.post(url, payload.filter);
  }

  // ------------------------- Chat Layout ----------------------------

  // getChatHistory(param): Observable<any> {
  //   const url = `${StudentHelperService.OFFLINE_CHAT_URL}/data?user_id=${param.userId}&page=${param.pageNumber}&per_page=${param.pageSize}`;
  //   return this.http.get(url);
  // }
  getChatHistory(param): Observable<any> {
    const url = `${StudentHelperService.OFFLINE_CHAT_URL}/data?user_id=${param.userId}`;
    return this.http.get(url);
  }
  getSaveChat(param): Observable<any> {
    const url = `${StudentHelperService.OFFLINE_CHAT_URL}`;
    return this.http.post(url,param);
  }

  // ------------------------- Payment Details ----------------------------

  getTransactionDetails(payload): Observable<any> {
    const url = `${StudentHelperService.PAYMENT_URL}/txn-details`;
    return this.http.post(url, payload);
  }

  // ------------------------- Bulletin Board ----------------------------

  getBulletinDetailsByLatest(): Observable<any> {
    const url = `${StudentHelperService.ANNOUNCEMENT_URL}/latest`;
    return this.http.get(url);
  }

  getBulletinDetailsByFilter(payload: any): Observable<any> {
    const url = `${StudentHelperService.ANNOUNCEMENT_URL}/filter`;
    return this.http.post(url, payload);
  }

  saveAnnouncementComment(payload): Observable<any> {
    const url = `${StudentHelperService.ANNOUNCEMENT_COMMENT_URL}`;
    return this.http.post(url, payload);
  }

  // ------------------------- Bulletin Board Comments ----------------------------

  updateAnnouncementComment(payload): Observable<any> {
    const url = `${StudentHelperService.ANNOUNCEMENT_COMMENT_URL}`;
    return this.http.put(url, payload);
  }

  deleteAnnouncementComment(id: number): Observable<any> {
    const url = `${StudentHelperService.ANNOUNCEMENT_COMMENT_URL}/${id}`;
    return this.http.delete(url);
  }

  getAnnouncementComments(payload): Observable<any> {
    const url = `${StudentHelperService.ANNOUNCEMENT_COMMENT_URL}/filter`;
    return this.http.post(url, payload);
  }

  // ------------------------- User Certificates ----------------------------

  getUserCertificates(payload): Observable<any> {
    const url = `${StudentHelperService.USER_CERTIFICATES_URL}/filter`;
    return this.http.post(url, payload);
  }
  getUserquestLevelCertificate(payload):Observable<any>{
    const url=`${StudentHelperService.USER_CERTIFICATES_URL}/quest_certificate`;
    return this.http.post(url, payload)
  }
  // ------------------------- Coupon Code ----------------------------

  getCouponsList(payload): Observable<any> {
    const url = `${StudentHelperService.COUPON_URL}/get_all`;
    return this.http.post(url, payload);
  }

  validateCouponCode(payload): Observable<any> {
    const url = `${StudentHelperService.COUPON_URL}/validate_coupon`;
    return this.http.post(url, payload);
  }

  // ------------------------- QUEST Info ----------------------------

  getQuestInfo(payload): Observable<any> {
    const url = `${StudentHelperService.QUEST_DETAILS_URL}/quest_levels`;
    return this.http.post(url, payload);
  }
  getLevelMaterials(params): Observable<any> {
    const url = `${StudentHelperService.QUEST_DETAILS_URL}/quest_levels/materials?community_id=${params.community_id}&user_id=${params.user_id}&level_id=${params.level_id}`;
    return this.http.get(url);
  }
  // dot-quest-level-activities/quest_levels/materials?community_id=42&user_id=2285&level_id=902

  getQuestTopics(params): Observable<any> {
    const url = `${StudentHelperService.TOPIC_DETAILS_URL}/challenge_hub/${params.community_id}/${params.level_id}`;
    return this.http.get(url);
  }

  getActivityInfo(params): Observable<any>{
    const url =`${StudentHelperService.QUEST_DETAILS_URL}/quest_activity`;
    return this.http.post(url,params);
  }

  getActivityViews(payload): Observable<any>{
    const url =`${StudentHelperService.QUEST_DETAILS_URL}/viewCount`;
    return this.http.post(url,payload);
  }

  // -----------------------------DOT-STORE Info ---------------------------

  getDotStoreInfo(): Observable<any>{
    const url = `${StudentHelperService.DOT_STORE_URL}/categorydetails`;
    return this.http.get(url);
  }
  getDotStoreCategory(params):Observable<any>{
    const url =`${StudentHelperService.DOT_STORE_URL}/categorydetails`;
    return this.http.get(url);
    // return params;
  }
  getDotStoreCatDetails(params): Observable<any>{
    const url =`${StudentHelperService.DOT_STORE_URL}/categoryInfo`;
    return this.http.get(url);
  }
  // getRedeemsItems(params): Observable<any>{
  //   const url =`${StudentHelperService.DOT_STORE_REDEEM_URL}/items-list`;
  //   return this.http.post(url,params);
  // }
  getItemsListBasedonCatgories(params): Observable<any>{
    const url =`${StudentHelperService.DOT_STORE_REDEEM_URL}/items-list`;
    return this.http.post(url,params);
  }
  
  // -----------------------DOT STORE REDEEM--------------------------------
  getDotStoreRedeem(params): Observable<any>{
    const url =`${StudentHelperService.DOT_STORE_REDEEM_URL}/redeem`;
    return this.http.post(url,params);
  }
  getAllItemsList(payload): Observable<any>{

    const url = `${StudentHelperService.DOT_STORE_REDEEM_URL}/items-list`;

    return this.http.post(url, payload)

  }
  // --------------------GROUP-------------------------------------------------
  getGroupDetails(params): Observable<any>{
    const url =`${StudentHelperService.GET_GROUP_URL}/user-groups/${params.id}`;
    return this.http.get(url);
  }
  createGroupBy(params): Observable<any>{
    const url =`${StudentHelperService.GET_GROUP_URL}/create-group`;
    return this.http.post(url,params);
  }
  updateGroupBy(params): Observable<any>{
    const url =`${StudentHelperService.GET_GROUP_URL}`;
    return this.http.put(url,params);
  }
  deleteGroupBy(params): Observable<any>{
    const url =`${StudentHelperService.GET_GROUP_URL}/${params.id}`;
    return this.http.delete(url);
  }
  // dot-user-group-members/delete-members
  getGroupMembers(params): Observable<any>{
    const url =`${StudentHelperService.GET_GROUP_MEMBER_URL}/group-members/${params.id}`;
    return this.http.get(url);
  }
  deleteGroupMembers(params): Observable<any>{
    const url =`${StudentHelperService.GET_GROUP_MEMBER_URL}/delete-members`;
    return this.http.post(url,params);
  }
  addGroupMembers(params): Observable<any>{
    const url =`${StudentHelperService.GET_GROUP_MEMBER_URL}/add-members`;
    return this.http.post(url,params);
  }
 
  getMyBuddiesBasedSchool(payload: any): Observable<any> {
    const url = `${StudentHelperService.USER_DETAILS_URL_SCHOOL}/list-user`;
    return this.http.post(url, payload);
  }
  // --------Teacher Dashboard data--------- GET_TEACHER_DASHBOARD_URL
  // getTeacherDashboardData(params): Observable<any>{
  //   const url =`${StudentHelperService.GET_TEACHER_DASHBOARD_URL}`;
  //   return this.http.post(url,params);
  // }
  getTeacherDashboardData(params,page): Observable<any>{
    const url =`${StudentHelperService.GET_TEACHER_DASHBOARD_URL}/students-list?page=${page}&per_page=10`;
    return this.http.post(url,params);
  }
  getTeacherDashboardStudentData(params): Observable<any>{
    const url =`${StudentHelperService.GET_TEACHER_DASHBOARD_URL}/`;
    return this.http.post(url,params);
  }

  getCommunityDetailsInfo(comm_id:any){
    const url =`${StudentHelperService.COMMUNITY_URL}/communitiyInfo?community_id=${comm_id}`;
    return this.http.get(url);
  }

  getCompetitionCommunityInfo(id:any){
    const url = `${StudentHelperService.COMMUNITY_URL}/competitionChallenge?community_id=${id}` 
    return this.http.get(url); 
  }

  getActivitiesInfo(userId:any,comm_id:any){
    const url =`${StudentHelperService.GET_ACTIVITIES_DETAILS_URL}?user_id=${userId}&community_id=${comm_id}`;
    return this.http.get(url);
  }

  getBadgeList(){
    const url = `${StudentHelperService.BADGELISt}`;
    return this.http.get(url);
  }

  awardBadge(payload:any): Observable<any>{
    const url =`${StudentHelperService.BADGELISt}/award_badge`;
    return this.http.post(url,payload);
  }

  getOpenAiResponse(payload:any){
    const url = `${StudentHelperService.OPENAI}/get_response`;
    return this.http.post(url,payload)
  }

  SwitchSchool(payload:any){
    const url = `${StudentHelperService.USER_DETAILS_URL}/switch-school`;
    return this.http.post(url,payload)
  }

  getLastestCommunity(){
    const url = `${StudentHelperService.COMMUNITY_URL}/latestCompetition`;
    return this.http.get(url)
  }
}
