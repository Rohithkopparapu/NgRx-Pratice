import { Component, OnInit, QueryList, ViewChildren } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import {HelperService} from '../../../shared/services/helper.service';
import { StudentHelperService } from '../student-helper.service';
import {onlineSocketUsers, userInfo} from 'src/app/shared/store/auth.selector';
import { Subject } from 'rxjs';
import { AuthState } from 'src/app/shared/store/auth.model';
import { Store } from '@ngrx/store';
import { takeUntil } from 'rxjs/operators';
import * as moment from 'moment';
import { ToastrService } from 'ngx-toastr';
import { HttpClient } from '@angular/common/http';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ActivityInformationComponent } from '../activitiy-information/activity-information.component';
import { DataService } from '../../../shared/services/data.service';
import { Subscription } from 'rxjs';

@Component({
  selector: 'app-teacher-dashboard',
  templateUrl: './teacher-dashboard.component.html',
  styleUrls: ['./teacher-dashboard.component.scss']
})
export class TeacherDashboardComponent implements OnInit {
  private subscriptions = new Subject<void>();
  private subscription: Subscription;
  @ViewChildren('newsFeedPosts') newsFeedPostsElement: QueryList<any>;
  isShow: any;
  userInfo: any;
  classListData: any[];
  isLoading: boolean=false;
  communitiesList: any[];
  selectedFilter: any='';
  selectedGroup: any='';
  selectedClass: any='';
  selectCommunityId: any;
  groupListData: any;
  groupId: any;
  dataList: any[]=[];
  finalData:any[]=[]
  groupedPeople: any;
  page =1;
  total_record: any;
  totalLevels: any;
  subscribedCommunitiesList: any =[];
  totalActivities: any;
  totalChallenges: any;
  actvitiesinformation: Object;
  thName: boolean = true;
  thClass: boolean = false;
  thComm: boolean = false;
  thLevel: boolean = false;
  thActivity: boolean = false;
  thChallenge: boolean = false;
  namedesc :boolean = false;
  nameasc : boolean = true;
  classdesc:boolean = false;
  classasc:boolean= true;
  comdesc:boolean = false;
  comasc:boolean = true;
  leveldesc:boolean = false;
  levelasc:boolean = true;
  activitydesc:boolean = false;
  activityasc:boolean = true;
  challengedesc:boolean = false;
  challengeasc:boolean = true;
  dNameSort :boolean = false;
  dClassSort : boolean = true;
  dCommSort : boolean = true;
  dLevelSort : boolean = true;
  dActivitySort : boolean = true;
  dChallengeSort : boolean = true;
  
  constructor(private http: HttpClient,private studentHelperService: StudentHelperService,private _uhs: HelperService,
    private store$: Store<AuthState>,private toastrService: ToastrService,private helperService: HelperService,private fb: FormBuilder, private modalService: NgbModal,
    private dataService: DataService) {
    this.store$.select(userInfo)
      .pipe(takeUntil(this.subscriptions))
      .subscribe(res => {
        this.userInfo = res;
      });
      this.getSubscribedCommunities();
      this.subscription = this.dataService.refreshComponent$.subscribe(() => {
        this.refreshComponentLogic();
      });
   }
  header:any
  check:boolean=false;
  id:any;
  isBlockScroll: boolean;
  isLastPage: boolean;
  minDate = { month: 12, year: 2021, day: 5 };
  maxDate = this.helperService.getSpotlightFormattedStartMinDate();
  startDate: { month: number; year: number; day: number };
  setStartDate: { month: number; year: number; day: number };
  setEndDate: { month: number; year: number; day: number };
  data:any []=[]
  reportData:any []=[]
  pageSearch = 1;
  teacheDashbrdForm = this.fb.group({
      startDate: [''],
      endDate: [''],
      Certified:['']
    });
  ngOnInit() {
    const payload={}
    this.setStartDate = this.helperService.getLastDateByDays(1);
    this.setEndDate = this.minDate;
    this.getMyClass();
    // this.getTeacherDashboardData(payload);
    // this.getMyGroups();
  }

  refreshComponentLogic(){
    this.getSubscribedCommunities();
    this.getMyClass();
  }

  // getTeacherDashboardData(payload){
  //   this.studentHelperService.getTeacherDashboardData(payload).subscribe(res => {
  //     this.dataList = res.data;
  //     if(this.dataList){
  //       this.groupedPeople = this.groupBy(this.dataList, "user_id");
  //       let arr=[]
  //       if(this.groupedPeople){
  //           Object.keys(this.groupedPeople).forEach(element=> { arr.push(element)})
  //       }
  //       this.finalData =[]
  //       if(arr){
  //           arr.forEach((element,i) => { 
  //               let chalng=0,activity=0,votes=0,commnty=0;
  //               let dotcoin =0;
  //               let name;
  //               let classSection;
  //               this.dataList.forEach((elements,j)=> { 
  //                   if(element == elements.user_id){
  //                       chalng = chalng + Number(elements.challenges);
  //                       activity = activity + Number(elements.activities);
  //                       dotcoin = Number(dotcoin) + Number(elements.dotcoins);
  //                       votes = votes + Number(elements.votes);
  //                       commnty = commnty+1;
  //                       name = elements.name;
  //                       classSection =elements.class
  //                   }  
  //               })
  //           let paylod={
  //               "user_id": element,
  //               "community_id": 57,
  //               "activities": activity,
  //               "challenges": chalng,
  //               "dotcoins": dotcoin,
  //               "votes": votes,
  //               "community":commnty,
  //               "name":name,
  //               "class":classSection
  //               }
  //           this.finalData.push(paylod)
  //           })
  //       }
  //     }
  //   });
  // }
  // groupBy(objectArray, property) {
  //   return objectArray.reduce(function (accumulator, currentObject) {
  //     let key = currentObject[property];
  //     if (!accumulator[key]) {
  //       accumulator[key] = [];
  //     }
  //     accumulator[key].push(currentObject);
  //     return accumulator;
  //   }, {});
  // }

  openPopup(data){
    this.isLoading = true;
    this.studentHelperService.getActivitiesInfo(data.userId,data.community_id).subscribe(res =>{
     this.actvitiesinformation = res;
     this.isLoading = false;
     if(res){
      const modelRef = this.modalService.open(ActivityInformationComponent, {
        centered: true,
        scrollable: true,
        backdrop: 'static',
        keyboard: false,
        size: 'xl',
        windowClass: 'modal-challenge'
      });
      modelRef.componentInstance.data = res;
      modelRef.componentInstance.studentName = data.studentName;      
     }
    },(err)=>{
      this.isLoading = false;
    });
    

  }

  getNoOfActivites(MA,OA){
    return MA+OA;
  }

  getTeacherDashboardData(payload){
    if(this.thName){
      payload["column_name"]="name";
      if(this.nameasc){
        payload["sort_by"]="asc";
      }else if(this.namedesc){
        payload["sort_by"]="desc";
      }
    }else if(this.thClass){
      payload["column_name"]="class";
      if(this.classasc){
        payload["sort_by"]="asc";
      }else if(this.classdesc){
        payload["sort_by"]="desc";
      }
    }else if(this.thComm){
      payload["column_name"]="communities";
      if(this.comasc){
        payload["sort_by"]="asc";
      }else if(this.comdesc){
        payload["sort_by"]="desc";
      }
    }else if(this.thLevel){
      payload["column_name"]="levels";
      if(this.levelasc){
        payload["sort_by"]="asc";
      }else if(this.leveldesc){
        payload["sort_by"]="desc";
      }
    }else if(this.thActivity){
      payload["column_name"]="activities";
      if(this.activityasc){
        payload["sort_by"]="asc";
      }else if(this.activitydesc){
        payload["sort_by"]="desc";
      }
    }else if(this.thChallenge){
      payload["column_name"]="challenges";
      if(this.challengeasc){
        payload["sort_by"]="asc";
      }else if(this.challengedesc){
        payload["sort_by"]="desc";
      }
    }
    const Certified = this.teacheDashbrdForm.controls['Certified'].value;
    if(Certified === true){
      payload['is_certified'] = true;
    }else if(Certified === false){
      payload['is_certified'] = false;
    }
    this.isLoading=true;
    this.studentHelperService.getTeacherDashboardData(payload,this.page).subscribe(res => {
      if(res){
      this.isLoading=false;
      if(res.content !== undefined){
        let dataList1 = res.content;
        let totalInfo = res.questInfo;
       
        this.total_record=0
        if(dataList1.length !== 0){
         this.dataList = dataList1;
         this.total_record= res.total_records;
         this.totalLevels = totalInfo.total_levels;
         this.totalActivities = totalInfo.total_activities;
         this.totalChallenges = totalInfo.total_challenges;
        }else{
          this.dataList = dataList1;
          this.total_record= res.total_records;
        }
      }else{
        this.toastrService.error(res.message);
      }
    
      console.log(this.dataList);
    }
    },(err) =>{
      this.isLoading=false;
    });
    // this.isLoading=false;
  }
  
  onPageChange(offset: number) {
    console.log(offset);
    this.page = offset;
    const reportFormData = this.teacheDashbrdForm.value;
    const payload={}
    let start_date = reportFormData['startDate'] ? this._uhs.getFormattedDateToBind(reportFormData['startDate']) : '';
    let end_date = reportFormData['startDate'] && reportFormData['endDate'] ? this._uhs.getFormattedDateToBind(reportFormData['endDate']) : '';
    if(this.groupId) payload['group_id']=this.groupId;
    if(this.selectedClass) payload['selected_class']=this.selectedClass;
    if(this.selectCommunityId) payload['community_id']=this.selectCommunityId;
    if(end_date) payload['end_date']=end_date;
    if(start_date) payload['start_date']=start_date;
    if(!end_date && start_date){
      payload['end_date']=this._uhs.getFormattedDateToBind(this.maxDate);
    }
    // this.dataList=[]
    this.getTeacherDashboardData(payload)
    // this.reset();
  }

  getTeacherDashboardStudentData(user_id,name, i){
    // let community_id= this.selectCommunityId ? this.selectCommunityId:''
    //   "community_id":community_id
    let Certified = this.teacheDashbrdForm.controls['Certified'].value;
    const payload={
      "user_id":user_id
      }
      if(Certified === true){
        payload['is_certified'] = 1
      }else if(Certified === false){
        payload['is_certified'] = 0
      }
      if(this.selectCommunityId){
        payload['community_id']=this.selectCommunityId
      }
      this.isLoading = true;
    this.studentHelperService.getTeacherDashboardStudentData(payload).subscribe(res => {
      this.isLoading = false
      if(res.data){
        const bar = new Promise<void>((resolve) => {
        if(res.data.length !== 0){
          res.data.forEach((element,index,array) => {
            element['userId'] = user_id;
            element['studentName'] = name;
            if (index === array.length -1) resolve();
          });
        }
      });

        bar.then(() => {
          this.dataList[i].childTable= res.data;
      });
        // this.groupedPeople = res.data;
      }else{
        this.groupedPeople= ''
      }
    },(err)=>{
      this.isLoading = true;
    });
  }

  onChangeStartDate(event: any): void {
    if (event) {
      this.setEndDate = this.helperService.getSpotlightFormattedEndMinDate(event, 1);
    }
  }

  onChangeEndDate(event: any) {
    if (event) {
      this.setStartDate = this.helperService.getSpotlightFormattedEndMinDate(event, -1);
    }
  }
  getMyGroups(){
    const payload={
      id: this.userInfo.user_id
    }
    this.studentHelperService.getGroupDetails(payload).subscribe(res => {
      console.log("res",res)
      if(res.length >0){
        this.groupListData = res.sort((a: { group_name: string; }, b: { group_name: any; }) => a.group_name.localeCompare(b.group_name));
      }
      
    });
  }

  getMyClass(){
    if(this.userInfo.user_type=="teacher")
      this.store$.select(userInfo)
        .pipe(takeUntil(this.subscriptions))
        .subscribe(res => {
          this.userInfo = res;
        });
      this.classListData=this.userInfo.details.responsibilities;
      if(this.classListData.length){
        this.classListData = this.classListData;
      }
  }

  getHeight(){
    if(this.classListData.length === 0){
      return '50px';
    }else if(this.classListData.length === 1){
      return '100px';
    }else{
      return '195px';
    }
  }

  getCommunities(): void {
    this.isLoading = true;
    this.studentHelperService.getAllCommunities().subscribe(res => {
      this.isLoading = false;
      if (res && res.length !== 0) {
        this.communitiesList = res.filter(s =>
          !s.combo && moment(moment(s.community_start_date).format('YYYY-MM-DD')).isSameOrBefore(moment().format('YYYY-MM-DD')) && s.num_challenges > 0);
          this.communitiesList= this.communitiesList.sort((a, b) => a.community_name.localeCompare(b.community_name))

      }
    }, () => this.isLoading = false);
  }
  
  getSubscribedCommunities(): void {
    this.isLoading = true;
    this.studentHelperService.getAllCommunitiesNew().subscribe(res => {
      this.isLoading = false;
      if (res && res.my_communities.length !== 0) {
        sessionStorage.setItem('subsribedCommunities',JSON.stringify(res));
        this.subscribedCommunitiesList = res.my_communities.sort((a,b)=> a.community_name.localeCompare(b.community_name));
      }
    }, () => this.isLoading = false);
  }

  parseFloat(value: any): number {
    return parseFloat(value);
  }
  roundToInt(value: any): number {
    return Math.round(value);
  }

  getPercentage(MA:any,TMA:any,OA:any,TOA:any,MC:any,TMC:any,OC:any,TOC:any){
    const activitiespercentage = ((MA+OA)/(TMA+TOA))*100;
    const challengespercentage = ((MC+OC)/(TMC+TOC))*100;

    const totalpercentage = Math.round((activitiespercentage+challengespercentage)/2);

    if(totalpercentage > 0){
      return totalpercentage+'%';
    }else{
      return '-';
    }
  }

  getPercentagewithScore(AS:any,MC:any,TMC:any,OC:any,TOC:any){
    const activitiespercentage = this.parseFloat(AS);
    const challengespercentage = ((MC+OC)/(TMC+TOC))*100;

    const totalpercentage = Math.round((activitiespercentage+challengespercentage)/2);

    if(totalpercentage > 0){
      return totalpercentage+'%';
    }else{
      return '-';
    }
  }

  onChangeFilter(value): void {
    if(value.target.innerText=="Select"){
      this.selectedFilter = '';
      this.selectCommunityId=''
    }else{
      this.selectedFilter = value.target.innerText;
      this.selectCommunityId=value.target.id ? value.target.id:""
    }
  }
  onChangeMyclass(value): void {
    
    if(value=="Select"){
      this.selectedClass = '';
    }else{
      this.selectedClass = value;
    }
  }
  onChangeMygroup(value): void {
    if(value.target.innerText=="Select"){
      this.selectedGroup = value.target.innerText;
      this.groupId=''
    }else{
      this.selectedGroup = value.target.innerText;
      this.groupId= value.target.id ? value.target.id : "All"
    }
    
  }
  onSearch(){
    const reportFormData = this.teacheDashbrdForm.value;
    const payload={}
      let start_date = reportFormData['startDate'] ? this._uhs.getFormattedDateToBind(reportFormData['startDate']) : '';
      let end_date = reportFormData['startDate'] && reportFormData['endDate'] ? this._uhs.getFormattedDateToBind(reportFormData['endDate']) : '';
    if(this.groupId) payload['group_id']=this.groupId;
    if(this.selectedClass) payload['selected_class']=this.selectedClass;
    if(this.selectCommunityId) payload['community_id']=this.selectCommunityId;
    if(end_date) payload['end_date']=end_date;
    if(start_date) payload['start_date']=start_date;
    if(!end_date && start_date){
      // console.log(this._uhs.getFormattedDateToBind(this.maxDate));
      payload['end_date']=this._uhs.getFormattedDateToBind(this.maxDate);
    }
    if(!start_date && end_date) this.toastrService.warning("Please select start date...");
    this.getTeacherDashboardData(payload)
  }
  reset(){
    this.dataList = [];
    this.selectedClass=''
    this.groupId=''
    this.selectedGroup=''
    this.selectCommunityId=''
    this.selectedFilter='';
    this.page = 1;
    this.teacheDashbrdForm.controls['startDate'].setValue('');
    this.teacheDashbrdForm.controls['endDate'].setValue('');
    this.teacheDashbrdForm.controls['Certified'].setValue('');
  }
  toggleNameSort(){
    this.nameasc = !this.nameasc;
    this.namedesc = !this.namedesc;
    this.thName = true;
    this.thClass = false;
    this.thComm = false;
    this.thLevel = false;
    this.thActivity = false; 
    this.thChallenge = false; 
    this.dNameSort = false;
    this.dClassSort = true;
    this.dCommSort = true;
    this.dLevelSort = true;
    this.dActivitySort = true;
    this.dChallengeSort = true;
    this.onSearch();
  }

  toggleClassSort(){
    this.classasc = !this.classasc;
    this.classdesc = !this.classdesc;
    this.thClass = true;
    this.thName = false;
    this.thComm = false;
    this.thLevel = false;
    this.thActivity = false; 
    this.thChallenge = false; 
    this.dNameSort = true;
    this.dClassSort = false;
    this.dCommSort = true;
    this.dLevelSort = true;
    this.dActivitySort = true;
    this.dChallengeSort = true;
    this.onSearch();
  }

  toggleCommSort(){
    this.comdesc = !this.comdesc;
    this.comasc = !this.comasc;
    this.thComm = true;
    this.thClass = false;
    this.thName = false;
    this.thLevel = false;
    this.thActivity = false; 
    this.thChallenge = false; 
    this.dNameSort = true;
    this.dClassSort = true;
    this.dCommSort = false;
    this.dLevelSort = true;
    this.dActivitySort = true;
    this.dChallengeSort = true;
    this.onSearch();
  }

  toggleLevelSort(){
    this.levelasc = !this.levelasc;
    this.leveldesc = !this.leveldesc;
    this.thLevel = true;
    this.thComm = false;
    this.thClass = false;
    this.thName = false;
    this.thActivity = false; 
    this.thChallenge = false; 
    this.dNameSort = true;
    this.dClassSort = true;
    this.dCommSort = true;
    this.dLevelSort = false;
    this.dActivitySort = true;
    this.dChallengeSort = true; 
    this.onSearch();
  }

  toggleActivitySort(){
    this.activitydesc = !this.activitydesc;
    this.activityasc = !this.activityasc;
    this.thActivity = true;
    this.thComm = false;
    this.thClass = false;
    this.thName = false;
    this.thLevel = false;
    this.thChallenge = false;
    this.dNameSort = true;
    this.dClassSort = true;
    this.dCommSort = true;
    this.dLevelSort = true;
    this.dActivitySort = false;
    this.dChallengeSort = true;
    this.onSearch();
  }

  toggleChallegeSort(){
    this.challengedesc = !this.challengedesc;
    this.challengeasc = !this.challengeasc;
    this.thChallenge = true;
    this.thActivity = false;
    this.thComm = false;
    this.thClass = false;
    this.thName = false;
    this.thLevel = false;
    this.dNameSort = true;
    this.dClassSort = true;
    this.dCommSort = true;
    this.dLevelSort = true;
    this.dActivitySort = true;
    this.dChallengeSort = false;
    this.onSearch();

  }

  ngOnDestroy() {
    this.subscription.unsubscribe();
  }
  // onScroll(event: any) {
    
  //   if ((event.target.offsetHeight + event.target.scrollTop + 400 >= event.target.scrollHeight) && !this.isBlockScroll && !this.isLastPage) {
  //     this.isBlockScroll = true;
  //     this.page += 1;
  //     this.getTeacherDashboardData(m);
  //   }
  // }
  // loadMore(): void {
  //   this.page += 1;
  //   this.newsFeedPostsElement.last.nativeElement.scrollIntoView({ behavior: 'smooth'});
  //   const payload = {, pageNumber: this.page, pageSize: this.pageSize};
  //   this.getTeacherDashboardData(m);
  // }
}
