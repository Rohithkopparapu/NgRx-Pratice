import {Component, OnDestroy, OnInit} from '@angular/core';
import {Router} from '@angular/router';
import {takeUntil} from 'rxjs/operators';
import {Store} from '@ngrx/store';
import {AuthState} from '../../../shared/store/auth.model';
import {userInfo} from '../../../shared/store/auth.selector';
import {Subject} from 'rxjs';
import { SocketUtilService } from '../../student-dashboard/socket-util.service';
import {AuthLogout} from 'src/app/shared/store/auth.action';
import { environment } from 'src/environments/environment';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-complete-profile',
  templateUrl: './complete-profile.component.html',
  styleUrls: ['./complete-profile.component.scss']
})
export class CompleteProfileComponent implements OnInit, OnDestroy {
  private subscriptions = new Subject<void>();
  isLoading: boolean;
  userData: any;
  userProfilePic = 'assets/img/profile-completed.png';
  status: any;
  openOrHideMobileMenu = false;
  cmsLandingUrl: any;


  constructor(private router: Router,  private socketUtilService: SocketUtilService, private toastrService: ToastrService,
    private store$: Store<AuthState>) {
    this.store$.select(userInfo)
      .pipe(takeUntil(this.subscriptions))
      .subscribe(res => this.userData = res);
  }

  ngOnInit() {
    this.status = this.userData.status;
    this.cmsLandingUrl=environment.cmsUrl;
  }

  goToHomePage(): void {
    if(this.status === "approved"){
    this.router.navigate(['/auth/student/community/join']);
    }else if(this.status === "rejected"){ 
      this.router.navigate(['/home']);
      this.openOrHideMobileMenu = false;
      this.ngOnDestroy();
      this.socketUtilService.disconnectConnection();
      this.store$.dispatch(new AuthLogout());
      window.location.replace(this.cmsLandingUrl);
      this.toastrService.error('Authorization is denied');
    }else if(this.status === "pending"){
      this.router.navigate(['/home']);
      this.openOrHideMobileMenu = false;
      this.ngOnDestroy();
      this.socketUtilService.disconnectConnection();
      this.store$.dispatch(new AuthLogout());
      window.location.replace(this.cmsLandingUrl);
      this.toastrService.error('Authorization is pending');
    }
  }

  goToProfileCreation(): void {
    this.router.navigateByUrl('/onboard/personality-quiz');
  }

  ngOnDestroy(): void {
    this.subscriptions.next();
    this.subscriptions.complete();
  }
}
