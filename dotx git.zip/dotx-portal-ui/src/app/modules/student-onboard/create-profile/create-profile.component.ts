import {Component, OnDestroy, OnInit} from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { Store } from '@ngrx/store';
import { ToastrService } from 'ngx-toastr';
import { HelperService } from 'src/app/shared/services/helper.service';
import { AuthState } from 'src/app/shared/store/auth.model';
import {SetUserDetail} from '../../../shared/store/auth.action';
import {takeUntil} from 'rxjs/operators';
import { userInfo } from 'src/app/shared/store/auth.selector';
import {Subject} from 'rxjs';
import {CustomValidator} from '../../../shared/services/validators/customValidator';
import {StudentOnboardService} from '../student-onboard.service';
import {AVATAR_RELATIVE_PATH} from '../../../shared/constants/constant';
import {sample} from 'lodash';

@Component({
  selector: 'app-create-profile',
  templateUrl: './create-profile.component.html',
  styleUrls: ['./create-profile.component.scss']
})
export class CreateProfileComponent implements OnInit, OnDestroy {
  private subscriptions = new Subject<void>();
  createProfileForm: FormGroup;
  userInfo: any;
  userId: any;
  dobMaxDate: any;
  isLoading: boolean;
  minYear: number;
  maleAvatars: any[] = ['boy-13.svg', 'boy-14.svg', 'boy-15.svg',
    'boy-16.svg', 'boy-17.svg', 'boy-18.svg', 'boy-19.svg', 'boy-20.svg', 'boy-21.svg', 'boy-22.svg',
    'boy-23.svg', 'boy-24.svg', 'boy-26.svg', 'boy-27.svg', 'boy-28.svg', 'boy-29.svg', 'boy-30.svg',
    'boy-31.svg', 'boy-32.svg', 'boy-33.svg', 'boy-34.svg', 'boy-35.svg', 'boy-36.svg', 'boy-37.svg',
    'Boy-38.svg', 'Boy-39.svg', 'Boy-40.svg', 'Boy-41.svg', 'Boy-42.svg', 'Boy-43.svg', 'Boy-44.svg',
    'Boy-45.svg', 'Boy-46.svg', 'Boy-47.svg', 'Boy-48.svg', 'Boy-49.svg', 'Boy-50.svg', 'Boy-51.svg',
    'Boy-52.svg', 'Boy-53.svg', 'Boy-54.svg', 'Boy-55.svg', 'Boy-56.svg', 'Boy-57.svg', 'Boy-58.svg',
    'Boy-59.svg', 'Boy-60.svg', 'Boy-61.svg', 'Boy-62.svg', 'Boy-63.svg', 'Boy-64.svg', 'Boy-65.svg',
    'Boy-66.svg', 'Boy-67.svg', 'Boy-68.svg', 'Boy-69.svg', 'Boy-70.svg', 'Boy-71.svg', 'Boy-72.svg',
    'Boy-73.svg', 'Boy-74.svg', 'Boy-75.svg', 'Boy-76.svg', 'Boy-77.svg', 'Boy-78.svg', 'Boy-79.svg',
    'Boy-80.svg', 'Boy-81.svg', 'Boy-82.svg', 'Boy-83.svg', 'Boy-84.svg', 'Boy-85.svg', 'Boy-86.svg',
    'Boy-87.svg', 'Boy-88.svg'];
  femaleAvatars: any[] = ['Girl-01.svg',
    'Girl-02.svg', 'Girl-03.svg', 'Girl-04.svg', 'Girl-20.svg', 'Girl-21.svg', 'Girl-22.svg',
    'Girl-23.svg', 'Girl-24.svg', 'Girl-25.svg', 'Girl-26.svg', 'Girl-27.svg', 'Girl-28.svg', 'Girl-29.svg',
    'Girl-30.svg', 'Girl-31.svg', 'Girl-32.svg', 'Girl-33.svg', 'Girl-34.svg', 'Girl-35.svg', 'Girl-36.svg',
    'Girl-37.svg', 'Girl-38.svg', 'Girl-39.svg', 'Girl-40.svg', 'Girl-41.svg', 'Girl-42.svg', 'Girl-43.svg',
    'Girl-46.svg', 'Girl-47.svg', 'Girl-48.svg', 'Girl-49.svg', 'Girl-50.svg', 'Girl-51.svg', 'Girl-52.svg',
    'Girl-53.svg', 'Girl-54.svg', 'Girl-55.svg', 'Girl-56.svg', 'Girl-57.svg', 'Girl-58.svg', 'Girl-59.svg',
    'Girl-60.svg', 'Girl-61.svg', 'Girl-62.svg', 'Girl-63.svg', 'Girl-64.svg', 'Girl-65.svg', 'Girl-66.svg',
    'Girl-67.svg', 'Girl-68.svg', 'Girl-69.svg', 'Girl-70.svg', 'Girl-71.svg', 'Girl-72.svg', 'Girl-73.svg',
    'Girl-74.svg', 'Girl-75.svg', 'Girl-76.svg', 'Girl-77.svg', 'Girl-78.svg', 'Girl-79.svg', 'Girl-80.svg',
    'Girl-81.svg', 'Girl-82.svg', 'Girl-83.svg', 'Girl-89.svg', 'Girl-90.svg', 'Girl-91.svg', 'Girl-92.svg',
    'Girl-93.svg', 'Girl-94.svg', 'Girl-95.svg', 'Girl-96.svg', 'Girl-98.svg', 'Girl-99.svg'];
  schoolList: any;
  newschool_name: any='null';
  school_name: any;
  userType: any;
  regId:any
  constructor(private fb: FormBuilder,
              private store$: Store<AuthState>,
              public _uhs: HelperService,
              private studentOnboardService: StudentOnboardService,
              private toasterService: ToastrService,
              private router: Router) {
    this.store$.select(userInfo)
      .pipe(takeUntil(this.subscriptions))
      .subscribe(res => this.userInfo = res);
    this.userId = this.userInfo.user_id;
    this.buildForm();
  }

  ngOnInit() {
    // this.getUserInfo();
    this.updateForm();
    this.getSchool()
  }

  getSchool(){
    this.isLoading = true;
    this.studentOnboardService.getSchoolList(this.userId).subscribe(res => {
      this.isLoading = false;
      if (res) {
        this.schoolList = res.sort((a, b) => a.name.localeCompare(b.name));
        console.log("this.schoolList",this.schoolList);
        
      }
    }, () => this.isLoading = false);
  }
  

  buildForm(): void {
    this.dobMaxDate = this._uhs.getTodaysFormattedDate();
    this.minYear = this.dobMaxDate.year - 8;
    this.createProfileForm = this.fb.group({
      display_name: ['', [Validators.required]],
      // user_phone_num: ['', [Validators.required, CustomValidator.AllowNumericOnly]],
      user_email: ['', [Validators.required]],
      user_dob: ['', [Validators.required]],
      class_details: [null, [Validators.required]],
      gender: ['Male', [Validators.required]],
      school_name: [''],
      parent_name: ['',[Validators.required]],
      parent_email: ['', [CustomValidator.ValidateEmail]],
      parent_contact_no: ['', [CustomValidator.AllowNumericOnly,Validators.required]],
      onboard: [true],
      other_school_name:[''],
      type: [''],
    });
  }
  onChange(school_id: any) {
    this.schoolList.forEach((element,index)=> {
      if(index+1==school_id.currentTarget.options.selectedIndex){
        this.regId=element.id
    }
  })
    if(school_id.target.value=="others"){
      this.regId=''
      this.newschool_name = school_id.target.value;
      this.createProfileForm.controls['other_school_name'].setValidators(Validators.required);
      this.createProfileForm.controls['other_school_name'].updateValueAndValidity();
      this.createProfileForm.controls['type'].setValue('');
      this.createProfileForm.get('type').clearValidators();
      this.createProfileForm.controls['type'].updateValueAndValidity();
    }else{
      this.newschool_name=school_id.target.value
      this.createProfileForm.controls['other_school_name'].setValue('');
      this.createProfileForm.get('other_school_name').clearValidators();
      this.createProfileForm.get('other_school_name').updateValueAndValidity();
      this.createProfileForm.controls['type'].setValidators(Validators.required);
      this.createProfileForm.get('type').updateValueAndValidity;
    }
    if(school_id.currentTarget.options.selectedIndex==0){
      this.regId=''
    }
  }
  onUserChange(event:any){
    let timedata= event.target.value
    this.userType = timedata.trim();
    if(this.userType=='teacher'){
      this.createProfileForm.controls['parent_name'].setValue('');
      this.createProfileForm.controls['parent_contact_no'].setValue('');
      this.createProfileForm.controls['parent_email'].setValue('');
      this.createProfileForm.get('parent_name').clearValidators();
      this.createProfileForm.get('parent_name').updateValueAndValidity();
      this.createProfileForm.get('parent_contact_no').clearValidators();
      this.createProfileForm.get('parent_contact_no').updateValueAndValidity();
      this.createProfileForm.get('parent_email').clearValidators();
      this.createProfileForm.get('parent_email').updateValueAndValidity();
    }if(this.userType=='student'){
      this.createProfileForm.controls['parent_name'].setValidators(Validators.required);
      this.createProfileForm.controls['parent_name'].updateValueAndValidity();
      this.createProfileForm.controls['parent_contact_no'].setValidators(Validators.required);
      // this.createProfileForm.controls['parent_contact_no'].setValidators();
      this.createProfileForm.controls['parent_contact_no'].updateValueAndValidity();
      this.createProfileForm.controls['parent_email'].setValidators(CustomValidator.ValidateEmail);
      this.createProfileForm.controls['parent_email'].updateValueAndValidity();
    }
    
    
  }
  getUserInfo(): void {
    this.isLoading = true;
    this.studentOnboardService.getUserDetails(this.userId).subscribe(res => {
      this.isLoading = false;
      if (res) {
        this.userInfo = res;
        this.updateForm();
      }
    }, () => this.isLoading = false);
  }
  
  updateForm(): void {
    this.createProfileForm.patchValue({
      display_name: this.userInfo.display_name,
      // user_phone_num: this.userInfo.user_phone_num,
      user_email: this.userInfo.user_email,
      user_dob: this.userInfo.user_dob ? this._uhs.getFormattedDateForAdminChall(this.userInfo.user_dob) : null,
      gender: this.userInfo.gender,
      class_details: this.userInfo.class_details,
      school_name: this.userInfo.school_name,
      parent_name: this.userInfo.parent_name,
      parent_email: this.userInfo.parent_email,
      parent_contact_no: this.userInfo.parent_contact_no
    });
    this.regId=this.userInfo.id
  }

  profileMarkAsTouched() {
    Object.values(this.createProfileForm.controls).forEach((control: any) => {
      control.markAsTouched();
    });
  }

  submitCreateProfile(): void {
    if (!this.createProfileForm.valid) {
      this.profileMarkAsTouched();
      this.toasterService.warning('Please enter all required fields');
    } else {
      const {display_name, user_email, user_dob, gender,
        class_details, school_name, parent_name, parent_email, parent_contact_no, onboard,other_school_name,type} = this.createProfileForm.value;
        
      const payload = {
        user_id: this.userId,
        display_name,
        avatar_image_file: this.userInfo.avatar_image_file ? this.userInfo.avatar_image_file : this.getRandomAvatar(),
        user_phone_num: parent_contact_no,
        user_email,
        user_dob,
        gender,
        class_details,
        school_name: other_school_name !== null ? other_school_name : null,
        parent_name,
        parent_email,
        parent_contact_no,
        onboard,
        user_type:"student",
        dot_registration_id:this.regId?this.regId:null
      };
      // console.log("form valur",payload);
      // return
      payload.user_dob = this._uhs.getFormattedDateToBind(user_dob) + 'T00:00';
      this.isLoading = true;
      this.studentOnboardService.updateUserProfile(payload).subscribe(res => {
        this.isLoading = false;
        this.store$.dispatch(new SetUserDetail(res));
        this.toasterService.success('Profile updated successfully');
        this.router.navigateByUrl('/onboard/completed');
      }, err => {
        this.isLoading = false;
        this.toasterService.error('Something went wrong');
      });
    }
  }

  getRandomAvatar(): string {
    const avatarList = this.createProfileForm.get('gender').value === 'Male' ? this.maleAvatars : this.femaleAvatars;
    return AVATAR_RELATIVE_PATH + sample(avatarList);
  }

  backToOnBoarding(): void {
    this.router.navigateByUrl('/onboard/about-dotx');
  }

  ngOnDestroy(): void {
    this.subscriptions.next();
    this.subscriptions.complete();
  }
}
