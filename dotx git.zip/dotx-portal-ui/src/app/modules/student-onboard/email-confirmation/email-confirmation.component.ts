import {Component, OnDestroy, OnInit} from '@angular/core';
import {userInfo} from '../../../shared/store/auth.selector';
import {takeUntil} from 'rxjs/operators';
import {Store} from '@ngrx/store';
import {AuthState} from '../../../shared/store/auth.model';
import {Subject} from 'rxjs';
import {StudentOnboardService} from '../student-onboard.service';
import {ToastrService} from 'ngx-toastr';
import {Router} from '@angular/router';

@Component({
  selector: 'app-email-confirmation',
  templateUrl: './email-confirmation.component.html',
  styleUrls: ['./email-confirmation.component.scss']
})
export class EmailConfirmationComponent implements OnInit, OnDestroy {

  private subscriptions = new Subject<void>();
  userDetails: any;
  isLoading = false;

  constructor(private store$: Store<AuthState>, private studentOnboardService: StudentOnboardService, private toastrService: ToastrService,
              private router: Router) {
    this.store$.select(userInfo)
      .pipe(takeUntil(this.subscriptions))
      .subscribe(res => {
        this.userDetails = res;
      });
  }

  ngOnInit() {
    this.getUserDetailsByUserId();
  }

  getUserDetailsByUserId(): void {
    this.isLoading = true;
    this.studentOnboardService.getUserDetails(this.userDetails.user_id).subscribe(res => {
      this.isLoading = false;
      if (res) {
        this.userDetails = res;
        this.verificationProcess();
      }
    }, () => this.isLoading = false);
  }

  verificationProcess(): void {
    if (!this.userDetails.is_email_verified) {
      this.sendOrReSendVerificationEmail();
    } else {
      if (!this.userDetails.display_name) {
        this.router.navigate(['/onboard/profile']);
      }
      // else if (!this.userDetails.avatar_image_file) {
      //   this.router.navigate(['/onboard/avatar']);
      // }
    }
  }

  sendOrReSendVerificationEmail(): void {
    const payload = {
      user_email: this.userDetails.user_email
    };
    this.isLoading = true;
    this.studentOnboardService.verificationEmail(payload).subscribe(res => {
      this.isLoading = false;
      if (res.status === 'success') {
        this.toastrService.success(res.message);
      } else {
        this.toastrService.error(res.message);
      }
    }, () => this.isLoading = false);
  }

  ngOnDestroy(): void {
    this.subscriptions.next();
    this.subscriptions.complete();
  }
}
