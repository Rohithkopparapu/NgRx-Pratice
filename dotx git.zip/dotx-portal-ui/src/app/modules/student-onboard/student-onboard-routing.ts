import {NgModule} from '@angular/core';
import {RouterModule, Routes} from '@angular/router';
import {AboutDotxComponent} from './about-dotx/about-dotx.component';
import {CompleteProfileComponent} from './complete-profile/complete-profile.component';
import {PersonalityQuizComponent} from './personality-quiz/personality-quiz.component';
import {StudentOnboardComponent} from './student-onboard.component';
import {TalentFavOnboardComponent} from './talent-fav-onboard/talent-fav-onboard.component';
import {CreateAvatarComponent} from './create-avatar/create-avatar.component';
import {CreateProfileComponent} from './create-profile/create-profile.component';
import {WriteYourselfComponent} from './write-yourself/write-yourself.component';
import {AboutUsComponent} from '../../shared/component/about-us/about-us.component';
import {EmailConfirmationComponent} from './email-confirmation/email-confirmation.component';

const routes: Routes = [
  {
    path: '',
    component: StudentOnboardComponent,
    children: [
      {
        path: 'confirm-email',
        component: EmailConfirmationComponent
      },
      {
        path: 'about-dotx',
        component: AboutDotxComponent
      },
      {
        path: 'profile',
        component: CreateProfileComponent
      },
      {
        path: 'avatar',
        component: CreateAvatarComponent
      },
      {
        path: 'personality-quiz',
        component: PersonalityQuizComponent
      },
      {
        path: 'personality-quiz/:page',
        component: PersonalityQuizComponent
      },
      {
        path: 'skill/:page',
        component: TalentFavOnboardComponent
      },
      {
        path: 'about-me',
        component: WriteYourselfComponent
      },
      {
        path: 'completed',
        component: CompleteProfileComponent
      },
      {
        path: 'about-us',
        component: AboutUsComponent
      }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class StudentOnboardRoutingModule {
}
