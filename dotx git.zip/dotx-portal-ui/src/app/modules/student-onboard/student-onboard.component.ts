import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-student-onboard',
  templateUrl: './student-onboard.component.html',
  styleUrls: ['./student-onboard.component.scss']
})
export class StudentOnboardComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
