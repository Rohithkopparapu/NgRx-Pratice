import { NgModule } from '@angular/core';
import { StudentOnboardComponent } from './student-onboard.component';
import {StudentOnboardRoutingModule} from './student-onboard-routing';
import { SharedModule } from 'src/app/shared/shared.module';
import { CreateProfileComponent } from './create-profile/create-profile.component';
import { CreateAvatarComponent } from './create-avatar/create-avatar.component';
import { PersonalityQuizComponent } from './personality-quiz/personality-quiz.component';
import { TalentFavOnboardComponent } from './talent-fav-onboard/talent-fav-onboard.component';
import { CompleteProfileComponent } from './complete-profile/complete-profile.component';
import { WriteYourselfComponent } from './write-yourself/write-yourself.component';
import { AboutDotxComponent } from './about-dotx/about-dotx.component';
import { EmailConfirmationComponent } from './email-confirmation/email-confirmation.component';


@NgModule({
  declarations: [
    StudentOnboardComponent,
    CreateProfileComponent,
    CreateAvatarComponent,
    PersonalityQuizComponent,
    TalentFavOnboardComponent,
    CompleteProfileComponent,
    WriteYourselfComponent,
    AboutDotxComponent,
    EmailConfirmationComponent],
  imports: [
    StudentOnboardRoutingModule,
    SharedModule
  ]
})
export class StudentOnboardModule { }
