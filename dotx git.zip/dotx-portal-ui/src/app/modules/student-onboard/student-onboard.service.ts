import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import {Observable} from 'rxjs';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class StudentOnboardService {

  constructor(private httpClient: HttpClient) { }

  getUserDetails(userId: any): Observable<any> {
    return this.httpClient.get(`${environment.baseURL}/dot-user-details/${userId}`);
  }

  updateUserProfile(payload: any): Observable<any> {
    return this.httpClient.put(`${environment.baseURL}/dot-user-details`, payload);
  }

  getStudentPersonalityQuiz(): Observable<any> {
    return this.httpClient.get(`${environment.baseURL}/dot-std-per-quiz-details/student_quiz_details`);
  }

  savePersonalizeQuizDetails(payload): Observable<any> {
    return this.httpClient.post(`${environment.baseURL}/dot-std-per-quiz-details`, payload);
  }

  updateAboutMe(requestPayLoad: any): Observable<any> {
    return this.httpClient.put(`${environment.baseURL}/dot-user-details`, requestPayLoad);
  }

  verificationEmail(payload: any): Observable<any> {
    return this.httpClient.post(`${environment.baseURL}/dot-user-details/resend_verification_email`, payload);
  }
  getSchoolList(payload): Observable<any>{
    return this.httpClient.get(`${environment.baseURL}/dot-registration`);
    // const url = `${AdminHelperService.DOTSTORE_REG_SCHOOL_URL}`;
    // return this.http.get(url);
  }
}
