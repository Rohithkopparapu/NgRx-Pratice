import {Component, OnDestroy, OnInit} from '@angular/core';
import {ActivatedRoute, Router} from '@angular/router';
import {NgbModal} from '@ng-bootstrap/ng-bootstrap';
import {ToastrService} from 'ngx-toastr';
import {FileUploadComponent} from 'src/app/shared/component/file-upload/file-upload.component';
import {StudentHelperService} from '../../student-dashboard/student-helper.service';
import {takeUntil} from 'rxjs/operators';
import {Store} from '@ngrx/store';
import {AuthState} from '../../../shared/store/auth.model';
import {userInfo} from '../../../shared/store/auth.selector';
import {Subject} from 'rxjs';

@Component({
  selector: 'app-talent-fav-onboard',
  templateUrl: './talent-fav-onboard.component.html',
  styleUrls: ['./talent-fav-onboard.component.scss']
})
export class TalentFavOnboardComponent implements OnInit, OnDestroy {

  private subscriptions = new Subject<void>();
  page: any;
  userData: any;
  talents: any = [];
  isLoading = true;
  options: any[] = [];


  constructor(private studentHelperService: StudentHelperService,
              private toastrService: ToastrService,
              private modalService: NgbModal,
              private store$: Store<AuthState>,
              private route: ActivatedRoute,
              private router: Router) {
    this.route.params.subscribe(params => this.page = params.page);
    this.store$.select(userInfo)
      .pipe(takeUntil(this.subscriptions))
      .subscribe(res => this.userData = res);
  }

  ngOnInit() {
    this.getTalents();
  }

  getTalents(): void {
    this.isLoading = true;
    this.studentHelperService.getUserSkills(this.page).subscribe(res => {
      this.isLoading = false;
      if (res && res.length) {
        this.talents = res;
        this.talents.forEach(element => {
          element['selected'] = !!element.is_selected;
          if (element.attachments && element.attachments.length) {
            element['skill_files'] = element.attachments;
            element.skill_files.forEach(ele => {
              let fileExtension = ele.file.split('.').pop();
              if (fileExtension.match(/(jpg|jpeg|png|gif)$/i)) {
                fileExtension = 'image';
              } else {
                fileExtension = 'video';
                ele['streamUrl'] = ele.stream_url;
              }
              ele['filePath'] = ele.url;
              ele['fileType'] = fileExtension;
            });
          } else {
            element['skill_files'] = [];
          }
        });
      }
    }, () => this.isLoading = false);
  }

  save(): void {
    const requestPayload = {
      user_id: this.userData.user_id,
      skill_category: this.page,
      skills: this.buildRequestPayload()
    };
    this.isLoading = true;
    this.studentHelperService.updateSkills(requestPayload).subscribe(() => {
      this.isLoading = false;
      this.toastrService.success(this.page + ' Updated Successfully!');
      if (this.page === 'Talents') {
        this.page = 'Favourites';
        window.scroll(0, 0);
        this.getTalents();
      } else {
        this.router.navigateByUrl('/onboard/about-me');
      }
    }, () => {
      this.isLoading = false;
      this.toastrService.error('Unable to Update ' + this.page);
    });
  }

  buildRequestPayload(): any {
    const skills = [];
    this.talents.forEach(talent => {
      if (talent.selected) {
        const requestObj = {
          user: this.userData.user_id,
          skill: talent.skill_id,
          is_primary: 1,
          skill_files: talent.skill_files
        };
        skills.push(requestObj);
      }
    });
    return skills;
  }

  openUploadModel(skillId: number): void {
    const modalData = {
      headerName: 'Skill',
      fileType: 'image&video',
      fileCategory: 'skill',
      isMultipleFile: true
    };
    const modalRef = this.modalService.open(FileUploadComponent, {
      keyboard: false,
      backdrop: 'static',
      scrollable: true,
      windowClass: 'modal-cover modal-cover-fluid modal-upload'
    });
    modalRef.componentInstance.data = modalData;
    modalRef.result.then((reason) => {
      if (reason) {
      }
    }, (reason) => {
      if (reason) {
        if (reason && reason.length) {
          reason.forEach(res => {
            const fileObj = {};
            let fileExtension = res.file.split('.').pop();
            if (fileExtension.match(/(jpg|jpeg|png|gif)$/i)) {
              fileExtension = 'image';
            }
            fileObj['filePath'] = res.fileUrl;
            fileObj['fileType'] = fileExtension;
            fileObj['file'] = res.file;
            fileObj['display_name'] = res.display_name;
            this.talents.find(talent => talent.skill_id === skillId).skill_files.push(fileObj);
          });
        }
      }
    });
  }

  backToOnBoarding(): void {
    if (this.page === 'Favourites') {
      this.page = 'Talents';
      this.getTalents();
    } else {
      this.router.navigateByUrl('/onboard/personality-quiz/talents');
    }
  }

  removeFile(parentIndex, subIndex) {
    this.talents[parentIndex].skill_files = this.talents[parentIndex].skill_files.filter((s, index) => index !== subIndex);
  }

  ngOnDestroy(): void {
    this.subscriptions.next();
    this.subscriptions.complete();
  }

}
