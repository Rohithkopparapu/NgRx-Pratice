import {Component, OnDestroy, OnInit} from '@angular/core';
import {Router} from '@angular/router';
import {Store} from '@ngrx/store';
import {ToastrService} from 'ngx-toastr';
import {AuthState} from 'src/app/shared/store/auth.model';
import {userInfo} from 'src/app/shared/store/auth.selector';
import {StudentOnboardService} from '../student-onboard.service';
import {SetUserDetail} from '../../../shared/store/auth.action';
import {Subject} from 'rxjs';
import {takeUntil} from 'rxjs/operators';

@Component({
  selector: 'app-write-yourself',
  templateUrl: './write-yourself.component.html',
  styleUrls: ['./write-yourself.component.scss']
})
export class WriteYourselfComponent implements OnInit, OnDestroy {
  private subscriptions = new Subject<void>();
  aboutMe = '';
  userId: number;
  isLoading: boolean;
  userData: any;
  userProfilePic = 'assets/img/profile-completed.png';

  constructor(private store$: Store<AuthState>,
              private toastr: ToastrService,
              private studentOnboardService: StudentOnboardService,
              private router: Router) {
    this.store$.select(userInfo)
      .pipe(takeUntil(this.subscriptions))
      .subscribe(res => this.userData = res);
    this.userId = this.userData.user_id;
  }

  ngOnInit() {
  }

  save(): void {
    if (!this.aboutMe) {
      this.toastr.warning('Please write something about yourself');
      return;
    }
    const payload = {
      user_id: this.userId,
      user_about_me: this.aboutMe
    };
    this.isLoading = true;
    this.studentOnboardService.updateAboutMe(payload).subscribe((res) => {
        this.isLoading = false;
        this.store$.dispatch(new SetUserDetail(res));
        this.router.navigateByUrl('/onboard/completed');
      },
      () => this.isLoading = false);
  }

  backTo(): void {
    this.router.navigate(['/onboard/skill/Favourites']);
  }

  skipTo(): void {
    this.router.navigateByUrl('/onboard/completed');
  }

  ngOnDestroy(): void {
    this.subscriptions.next();
    this.subscriptions.complete();
  }
}
