import {Component} from '@angular/core';
import {ABOUT_DOTX_VIDEO_URL} from '../../constants/constant';

@Component({
  selector: 'app-about-us',
  templateUrl: './about-us.component.html',
  styleUrls: ['./about-us.component.scss']
})
export class AboutUsComponent {

  aboutUsVideoURL = ABOUT_DOTX_VIDEO_URL;

  constructor() {}
}
