import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AnnouncementResponsesComponent } from './announcement-responses.component';

describe('AnnouncementResponsesComponent', () => {
  let component: AnnouncementResponsesComponent;
  let fixture: ComponentFixture<AnnouncementResponsesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AnnouncementResponsesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AnnouncementResponsesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
