import {Component, OnDestroy, OnInit} from '@angular/core';
import {NgbActiveModal, NgbModal} from '@ng-bootstrap/ng-bootstrap';
import {StudentHelperService} from '../../../modules/student-dashboard/student-helper.service';
import {DeleteComponent} from '../delete/delete.component';
import {ToastrService} from 'ngx-toastr';
import {debounceTime, distinctUntilChanged, takeUntil} from 'rxjs/operators';
import {onlineSocketUsers, userInfo} from '../../store/auth.selector';
import {Store} from '@ngrx/store';
import {AuthState} from '../../store/auth.model';
import {Subject} from 'rxjs';
import {MySpaceComponent} from '../../../modules/student-dashboard/header-section/my-space/my-space.component';
import {ViewOtherProfileComponent} from '../view-other-profile/view-other-profile.component';
import {SUCCESS_MESSAGE} from '../../constants/constant';
import Swiper, {Autoplay, Navigation, Pagination} from 'swiper';
import {FormBuilder} from '@angular/forms';

@Component({
  selector: 'app-announcement-responses',
  templateUrl: './announcement-responses.component.html',
  styleUrls: ['./announcement-responses.component.scss']
})
export class AnnouncementResponsesComponent implements OnInit, OnDestroy {

  private subscriptions = new Subject<void>();
  data: any;
  isLoading = false;
  userInfo: any;
  userType: any;
  onlineUsersList: any;
  searchForm = this.fb.group({
    name: ['']
  });
  announcementList: any[];
  selectedAnnouncement: any;
  commentsList: any[];
  isHoverVotesDef = false;
  comment = '';
  filterPayload = {
    status: 'Open'
  };
  imageUrl: string;
  isCard:any;
  selcards: any =[];
  selectedItemsArray: any=[];
  checked: boolean= false;
  items:any[];
  isdisplay: boolean;
  toggled = false;
  constructor(private studentHelperService: StudentHelperService, private activeModel: NgbActiveModal, private modalService: NgbModal,
              private toastrService: ToastrService, private store$: Store<AuthState>, private fb: FormBuilder) {
    this.store$.select(userInfo)
      .pipe(takeUntil(this.subscriptions))
      .subscribe(res => this.userInfo = res);
    this.store$.select(onlineSocketUsers)
      .pipe(takeUntil(this.subscriptions))
      .subscribe(res => this.onlineUsersList = res);
  }

  ngOnInit() {
    this.getAllAnnouncements();

    this.searchForm.get('name').valueChanges.pipe(
      debounceTime(500),
      distinctUntilChanged()).subscribe(search => {
      if (search) {
        this.filterPayload['name'] = search;
        this.getAllAnnouncements();
      } else {
        delete this.filterPayload['name'];
        this.getAllAnnouncements();
      }
    });
    // this.getItemlist(2);
  }

  getAllAnnouncements(): void {
    this.isLoading = true;
    this.studentHelperService.getBulletinDetailsByFilter(this.filterPayload).subscribe(res => {
      this.isLoading = false;
      if (res && res.length) {
        this.announcementList = res;
        this.isLoading = false;
      } else {
        this.toastrService.warning('No Announcements Found...');
        this.activeModel.close();
        this.isLoading = false;
      }
      this.viewSelectedOrDefaultCard();
    }, () => this.isLoading = false);
  }

  viewSelectedOrDefaultCard(announcement?: any): void {
    if (announcement) {
      this.comment = '';
      this.selectedAnnouncement = announcement;
    } else if (this.data) {
      this.selectedAnnouncement = this.data;
    } else if (!this.selectedAnnouncement) {
      this.selectedAnnouncement = this.announcementList[0];
    }
    this.initSwiperSlider();
    this.getAnnouncementComments();
  }

  initSwiperSlider() {
    setTimeout(() => {
      if (this.selectedAnnouncement.original_image && this.selectedAnnouncement.video) {
        const swiper = new Swiper('.swiper.swiper-announcement-responses', {
          modules: [Navigation, Pagination, Autoplay],
          // Optional parameters
          loop: true,
          freeMode: true,

          // If we need pagination
          pagination: {
            clickable: true,
            el: '.swiper-pagination',
            type: 'bullets'
          },

          autoplay: {
            delay: 2500,
            disableOnInteraction: false,
            pauseOnMouseEnter: true
          },

          keyboard: {
            enabled: true,
            onlyInViewport: false,
          },

          // Navigation arrows
          navigation: {
            nextEl: '.swiper-button-next',
            prevEl: '.swiper-button-prev',
          },
        });
      } else {
        const swiper = new Swiper('.swiper.swiper-announcement-responses', {
          // Optional parameters
          enabled: false,
          navigation: {
            nextEl: null,
            prevEl: null,
          },
        });
      }
    });
  }

  submitReaction(value: any): void {
    if (this.selectedAnnouncement.rating_reaction === value) {
      return;
    }
    this.isLoading = true;
    const payload = {
      topic_resp_rating_id: this.selectedAnnouncement.topic_resp_rating_id,
      announcement_id: this.selectedAnnouncement.id,
      rating_reaction: value
    };
    this.studentHelperService.reactOnSubmission(payload).subscribe(response => {
      this.isLoading = false;
      if (response) {
        this.selectedAnnouncement.topic_resp_rating_id = response.topic_resp_rating_id;
        this.selectedAnnouncement.rating_reaction = value;
        this.selectedAnnouncement.for_real = response.reactions[0].for_real;
        this.selectedAnnouncement.rad = response.reactions[0].rad;
        this.selectedAnnouncement.og = response.reactions[0].og;
      }
    }, () => this.isLoading = false);
  }

  onClickAbuseFlag(comment): void {
    if (!comment.is_reported) {
      const deleteModelRef = this.modalService.open(DeleteComponent, { centered: true, backdrop: 'static' });
      deleteModelRef.componentInstance.message = 'Are you sure you want to report this as a Abuse Comment?';
      deleteModelRef.result.then((res) => {
        if (res) {
          this.reportAbuseComment(comment);
        }
      }, (reason) => {
        if (reason) {
          this.reportAbuseComment(comment);
        }
      });
    } else {
      this.reportUnAbuseComment(comment);
    }
  }

  reportAbuseComment(comment: any): void {
    const payload = {
      announcement_id: this.selectedAnnouncement.id,
      id: comment.id,
      report_comments: 'reporting abuse comment',
      is_reported: 1,
      comments: comment.comments
    };
    this.isLoading = true;
    this.studentHelperService.updateAnnouncementComment(payload).subscribe(res => {
      this.isLoading = false;
      if (res) {
        comment.is_reported = res.is_reported;
        this.toastrService.success('Reported Successfully');
      }
    }, () => this.isLoading = false);
  }

  reportUnAbuseComment(comment: any): void {
    const payload = {
      announcement_id: this.selectedAnnouncement.id,
      id: comment.id,
      report_comments: null,
      is_reported: 0,
      comments: comment.comments
    };
    this.isLoading = true;
    this.studentHelperService.updateAnnouncementComment(payload).subscribe(res => {
      this.isLoading = false;
      if (res) {
        comment.is_reported = res.is_reported;
        this.toastrService.success('Reported Successfully');
      }
    }, () => this.isLoading = false);
  }

  getAnnouncementComments(): void {
    this.isLoading = true;
    const payload = {
      announcement_id: this.selectedAnnouncement.id
    };
    this.studentHelperService.getAnnouncementComments(payload).subscribe(res => {
      this.isLoading = false;
      if (this.userType === 'admin') {
        this.commentsList = res;
      } else {
        this.commentsList = res.filter(comment => !comment.is_reported);
      }
    }, () => this.isLoading = false);
  }
  // new chat for flash card
  handleSelection(event: any) {
    this.comment += event.char;
    this.isdisplay= false;
  }
  closeBtn(){
    this.isdisplay= false;
  }
  openImages(){
    this.isdisplay= !this.isdisplay;
    this.getItemlist(2);
  }
  getItemlist(id: any){
    // console.log("id =", id);
    const payload ={
      category_id : id,
      redeemed : true,
    };
    this.studentHelperService.getAllItemsList(payload).subscribe(res =>{
      if(res.items){
        this.items = res.items;
        // console.log(this.items);
      }
      else{
        this.toastrService.warning("You don't have items");
        // console.log("You don't have items",res);
      }
    })
  }
  selectComment(url, index) {
    if(this.selcards.length){
    // const data =  this.selcards.find(el => el.item_image === url);
    // if(data === undefined){
      this.selcards.push(this.items[index]);
    // }else{
    //   this.selcards = this.selcards.filter(item => (item.item_image !== url));
    // }
    }else{
      this.selcards.push(this.items[index]);
    }
    // console.log("tt",this.selcards)  
  }
  selectCommentClose(url, index1){
    this.selcards = this.selcards.filter((item,index) => (index !== index1))
  }
  checkSelected(url:any){
   return this.selcards.some(x =>{
      if(x.item_image === url){
        return true;
        this.checked = true;
      }else{
        return false;
        this.checked = false;
      }
     });
  }
  submitComment(): void {
    // this.isCard=isText;
    // this.imageUrl=url;
    // console.log("text",this.isCard,this.imageUrl,"comment",this.comment)
    this.comment=this.comment.trim();
    if (this.comment || this.selcards.length>0) {
      this.isLoading = true;
      
      const payload = {
        user: this.userInfo.user_id,
        announcement_id: this.selectedAnnouncement.id,
        comments: this.comment,
      };
      
      let ar=[]
      this.selcards.forEach((element,index) => {
        const obj = {};
        // obj["item_image"]=element.item_image.split("uploads/")[1]
        obj["item_image"]=element.item_image
        obj["item_sequence"]=index+1
        obj["item_name"]=element.item_name
        ar.push(obj)
      });
        payload["attachments"] =  ar;
      // return;

      this.studentHelperService.saveAnnouncementComment(payload).subscribe(res => {
        this.isLoading = false;
        this.comment = '';
        this.imageUrl= '';
        this.selcards=[];
        this.selectedItemsArray =[];
        this.commentsList.unshift(res);
        // console.log("This submitComment", this.commentsList);
      }, () => this.isLoading = false);
    }
  }
  // submitComment(): void {
  //   if (this.comment) {
  //     this.isLoading = true;
  //     const payload = {
  //       user: this.userInfo.user_id,
  //       announcement_id: this.selectedAnnouncement.id,
  //       comments: this.comment
  //     };
  //     this.studentHelperService.saveAnnouncementComment(payload).subscribe(res => {
  //       this.isLoading = false;
  //       this.comment = '';
  //       this.commentsList.unshift(res);
  //     }, () => this.isLoading = false);
  //   }
  // }

  openBuddyProfile(buddie: any): void {
    const modalRef = this.modalService.open(buddie.user_id === this.userInfo.user_id ? MySpaceComponent : ViewOtherProfileComponent, {
      centered: true,
      backdrop: 'static',
      size: 'xl',
      windowClass: 'custom-modal'
    });
    if (buddie.user_id !== this.userInfo.user_id) {
      modalRef.componentInstance.data = { userId: buddie.user_id };
    }
  }

  deleteComment(delComment: any): void {
    const deleteModelRef = this.modalService.open(DeleteComponent, {centered: true, backdrop: 'static'});
    deleteModelRef.componentInstance.message = 'Are you sure you want to delete the comment?';
    deleteModelRef.componentInstance.notes = '';
    deleteModelRef.result.then((res) => {
      if (res) {
        this.deleteCommentRecordById(delComment);
      }
    }, (reason) => {
      if (reason) {
        this.deleteCommentRecordById(delComment);
      }
    });
  }

  deleteCommentRecordById(delComment: any): void {
    this.isLoading = true;
    this.studentHelperService.deleteAnnouncementComment(delComment.id).subscribe(res => {
      this.isLoading = false;
      if (res.success) {
        this.toastrService.success(`Comment ${SUCCESS_MESSAGE.RECORD_DELETED}`);
        this.commentsList = this.commentsList.filter(comment => comment.id !== delComment.id);
      }
    }, () => this.isLoading = false);
  }

  close(): void {
    this.activeModel.close('center_panel');
  }

  ngOnDestroy(): void {
    this.subscriptions.next();
    this.subscriptions.complete();
  }
}
