import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BadgesDotcoinsPopupComponent } from './badges-dotcoins-popup.component';

describe('BadgesDotcoinsPopupComponent', () => {
  let component: BadgesDotcoinsPopupComponent;
  let fixture: ComponentFixture<BadgesDotcoinsPopupComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BadgesDotcoinsPopupComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BadgesDotcoinsPopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
