import {Component, Input, OnDestroy, OnInit} from '@angular/core';
import {StudentHelperService} from '../../../modules/student-dashboard/student-helper.service';
import {NgbActiveModal} from '@ng-bootstrap/ng-bootstrap';
import {takeUntil} from 'rxjs/operators';
import {myPortfolio, userInfo} from '../../store/auth.selector';
import {Store} from '@ngrx/store';
import {AuthState, Portfolio} from '../../store/auth.model';
import {Subject} from 'rxjs';
import {Router} from '@angular/router';

@Component({
  selector: 'app-badges-dotcoins-popup',
  templateUrl: './badges-dotcoins-popup.component.html',
  styleUrls: ['./badges-dotcoins-popup.component.scss']
})
export class BadgesDotcoinsPopupComponent implements OnInit, OnDestroy {

  private subscriptions = new Subject<void>();

  @Input() data;
  userDetails: any;
  myPortfolio: Portfolio;
  viewPopup: string;
  accessViewType: string;
  badgesList: any;
  achievementsList: any;
  buddyDetails: any;
  redemption_dot_coins: number;

  constructor(private store$: Store<AuthState>, private studentHelperService: StudentHelperService, private activeModal: NgbActiveModal,
              private router: Router) {
    this.store$.select(myPortfolio)
      .pipe(takeUntil(this.subscriptions))
      .subscribe(res => this.myPortfolio = res);
    this.store$.select(userInfo)
      .pipe(takeUntil(this.subscriptions))
      .subscribe(res => this.userDetails = res);
  }

  ngOnInit() {
    this.buddyDetails = this.data.buddyDetails;
    if (this.buddyDetails.user_id === this.userDetails.user_id) {
      this.badgesList = this.myPortfolio.badges;
      this.achievementsList = this.myPortfolio.achievements;
    } else {
      this.badgesList = this.data.badgesList;
      this.achievementsList = this.data.achievementsList;
    }
    this.viewPopup = this.data.viewPopup;
    this.accessViewType = this.data.accessViewType;
    this.redemption_dot_coins = -1 * this.achievementsList.redemption_dot_coins;
  }

  closeModal(value?: string): void {
    if (value === 'closeAll') {
      this.activeModal.close(value);
    } else {
      this.activeModal.close();
    }
  }

  gotoDotStore(): void {
    this.closeModal('closeAll');
    this.router.navigate(['/auth/student/dot-store']);
  }

  ngOnDestroy(): void {
    this.subscriptions.next();
    this.subscriptions.complete();
  }
}
