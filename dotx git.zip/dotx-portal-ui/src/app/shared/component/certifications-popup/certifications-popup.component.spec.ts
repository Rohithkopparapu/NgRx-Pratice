import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CertificationsPopupComponent } from './certifications-popup.component';

describe('CertificationsPopupComponent', () => {
  let component: CertificationsPopupComponent;
  let fixture: ComponentFixture<CertificationsPopupComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CertificationsPopupComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CertificationsPopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
