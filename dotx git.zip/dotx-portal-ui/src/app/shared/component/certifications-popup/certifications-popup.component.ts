import {Component, Input, OnInit} from '@angular/core';
import {NgbActiveModal} from '@ng-bootstrap/ng-bootstrap';
import {takeUntil} from 'rxjs/operators';
import {Subject} from 'rxjs';
import {myPortfolio, userInfo} from '../../store/auth.selector';
import {AuthState, Portfolio} from '../../store/auth.model';
import {Store} from '@ngrx/store';
import {StudentHelperService} from '../../../modules/student-dashboard/student-helper.service';

@Component({
  selector: 'app-certifications-popup',
  templateUrl: './certifications-popup.component.html',
  styleUrls: ['./certifications-popup.component.scss']
})
export class CertificationsPopupComponent implements OnInit {

  private subscriptions = new Subject<void>();
  CERTIFICATE_URL = StudentHelperService.CERTIFICATE_URL;
  isLoading = false;
  @Input() data;
  userInfo: any;
  myPortfolio: Portfolio;
  accessViewType: string;
  achievementsList: any;
  buddyDetails: any;
  certificateList: any[];

  constructor(private activeModal: NgbActiveModal, private store$: Store<AuthState>, private studentHelperService: StudentHelperService) {
    this.store$.select(userInfo)
      .pipe(takeUntil(this.subscriptions))
      .subscribe(res => this.userInfo = res);
    this.store$.select(myPortfolio)
      .pipe(takeUntil(this.subscriptions))
      .subscribe(res => this.myPortfolio = res);
  }

  ngOnInit() {
    this.accessViewType = this.data.accessViewType;
    this.buddyDetails = this.data.buddyDetails;
    if (this.buddyDetails.user_id === this.userInfo.user_id) {
      this.achievementsList = this.myPortfolio.achievements;
    } else {
      this.achievementsList = this.data.achievementsList;
    }
    this.getAllUserCertificates();
  }

  getAllUserCertificates(): void {
    this.isLoading = true;
    const payload = { user_id: this.buddyDetails.user_id };
    this.studentHelperService.getUserCertificates(payload).subscribe(res => {
      this.isLoading = false;
      if (res) {
        this.certificateList = res;
      }
    }, () => this.isLoading = false);
  }

  generateCertificateUrl(certificate: any): string {
    return `${this.CERTIFICATE_URL}?id=${certificate.id}`;
  }

  closeModal(): void {
    this.activeModal.close();
  }
}
