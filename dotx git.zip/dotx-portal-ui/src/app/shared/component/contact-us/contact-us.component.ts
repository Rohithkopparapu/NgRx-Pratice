import {Component, OnInit} from '@angular/core';
import {NgbActiveModal} from '@ng-bootstrap/ng-bootstrap';
import {ToastrService} from 'ngx-toastr';
import {FormBuilder, Validators} from '@angular/forms';
import {HelperService} from '../../services/helper.service';
import {takeUntil} from 'rxjs/operators';
import {Store} from '@ngrx/store';
import {AuthState} from '../../store/auth.model';
import {userInfo} from '../../store/auth.selector';
import {Subject} from 'rxjs';
import {AuthorizeService} from '../../services/auth.service';
import {ERROR_MESSAGE} from '../../constants/constant';
import {CustomValidator} from '../../services/validators/customValidator';

@Component({
  selector: 'app-contact-us',
  templateUrl: './contact-us.component.html',
  styleUrls: ['./contact-us.component.scss']
})
export class ContactUsComponent implements OnInit {

  private subscriptions = new Subject<void>();
  isSaving = false;
  isDisabled = false;
  userInfo: any;
  contactForm = this.formBuilder.group({
    name: [{value: '', disabled: this.isDisabled}, [Validators.required]],
    email: [{value: '', disabled: this.isDisabled}, [Validators.required, CustomValidator.ValidateEmailRegex]],
    mobile: ['', [CustomValidator.AllowNumericOnly]],
    subject: ['', [Validators.maxLength(50)]],
    message: ['', [Validators.required]],
    type: ['Contact']
  });

  constructor(private activeModal: NgbActiveModal,
              private authorizeService: AuthorizeService,
              private toastr: ToastrService,
              private formBuilder: FormBuilder,
              public _uhs: HelperService,
              private store$: Store<AuthState>) {
    this.store$.select(userInfo)
      .pipe(takeUntil(this.subscriptions))
      .subscribe(res => this.userInfo = res);
  }

  ngOnInit() {
    this.initializeForm();
  }

  initializeForm(): void {
    if (this.userInfo) {
      this.contactForm.patchValue({
        name: this.userInfo.display_name,
        email: this.userInfo.user_email,
        mobile: this.userInfo.user_phone_num
      });
      this.isDisabled = true;
    }
  }

  submit(): void {
    if (this.contactForm.valid) {
      this.isSaving = true;
      this.authorizeService.postContactDetails(this.contactForm.value).subscribe(() => {
        this.isSaving = false;
        this.toastr.success('Submitted successfully');
        this.activeModal.close();
      }, () => this.isSaving = false);
    } else {
      this.toastr.warning(ERROR_MESSAGE.FIELDS_REQUIRED);
      this._uhs.validateAllFormFields(this.contactForm);
    }
  }

  close() {
    this.activeModal.close();
  }
}
