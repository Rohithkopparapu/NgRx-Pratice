import { Component, Input, OnInit } from '@angular/core';
import { FormControl, Validators } from '@angular/forms';
import { ValidationService } from '../../services/validators/validation.service';

@Component({
  selector: 'app-control-messages',
  templateUrl: './control-messages.component.html',
  styleUrls: ['./control-messages.component.scss']
})
export class ControlMessagesComponent implements OnInit {

  @Input()
  public control: FormControl;
  @Input()
  public labelName: string;

  get errorMessage(): any {
    if (this.control && this.control.errors) {
      for (let propertyName in this.control.errors) {
        if (this.control.errors.hasOwnProperty(propertyName) && this.control.touched) {
          if (propertyName === 'ngbDate') {
            return this.getDateValidationErrors();
          } else if (this.labelName.includes('Password')) {
            return this.getPasswordValidationErrors(propertyName, this.labelName, this.control.errors[propertyName]);
          }else if(this.labelName.includes('Email')){
            return this.getEmailValidationErrors(propertyName, this.labelName, this.control.errors[propertyName]);
          }
          return ValidationService.getValidationErrorMessage(
            propertyName,
            this.labelName,
            this.control.errors[propertyName]
          );
        }
      }
    }


    return undefined;
  }

  constructor() { }

  ngOnInit() {
  }

  getDateValidationErrors(): string {
    if (this.control.errors.ngbDate.invalid) {
      return 'Invalid Date';
    } else if (this.control.errors.ngbDate.requiredAfter) {
      const date = this.control.errors.ngbDate.requiredAfter;
      return  `Date Should be less than than ${date.day}-${date.month}-${date.year}`;
    } else if (this.control.errors.ngbDate.requiredBefore) {
      const date = this.control.errors.ngbDate.requiredBefore;
      return  `Date Should be greater than ${date.day}-${date.month}-${date.year}`;
    }
  }

  getPasswordValidationErrors(validatorName: string, labelName: string, validatorValue?: any): string {
    const config = {
      required: `${labelName} is required`,
      minlength: `${labelName} should be at least ${validatorValue.requiredLength} characters`,
      pattern: `${labelName} must include 1 upper case, 1 lower case, 1 digit and 1 special character`,
      notSame: 'Password do not match'
    };
    return config[validatorName];
  }

  getEmailValidationErrors(validatorName: string, labelName: string, validatorValue?: any): string {
    const config = {
      required: `${labelName} is required`,
      email: `Please Enter a valid ${labelName}`,
      notSame: 'Emails do not match',
      invalidEmail:  `$Please Enter valid ${Validators.email}`
    };
    return config[validatorName];
  }

}
