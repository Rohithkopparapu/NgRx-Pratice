import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FestModalComponent } from './fest-modal.component';

describe('FestModalComponent', () => {
  let component: FestModalComponent;
  let fixture: ComponentFixture<FestModalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FestModalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FestModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
