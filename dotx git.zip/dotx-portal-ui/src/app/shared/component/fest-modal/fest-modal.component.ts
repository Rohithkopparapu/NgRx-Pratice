import {Component, OnDestroy, OnInit} from '@angular/core';
import {NgbActiveModal} from '@ng-bootstrap/ng-bootstrap';
import {Router} from '@angular/router';
import {takeUntil} from 'rxjs/operators';
import {Store} from '@ngrx/store';
import {AuthState} from '../../store/auth.model';
import { isLoggedIn } from '../../store/auth.selector';
import {Subject} from 'rxjs';

@Component({
  selector: 'app-fest-modal',
  templateUrl: './fest-modal.component.html',
  styleUrls: ['./fest-modal.component.scss']
})
export class FestModalComponent implements OnInit, OnDestroy {

  private subscriptions = new Subject<void>();
  isLoggedIn;

  constructor(private store$: Store<AuthState>, private activeModal: NgbActiveModal, private router: Router) {
    this.store$.select(isLoggedIn)
      .pipe(takeUntil(this.subscriptions))
      .subscribe(res => this.isLoggedIn = res);
  }

  ngOnInit() {
  }

  closeModal(): void {
    this.activeModal.close();
  }

  navigateAction(action: string): void {
    if (action === 'login') {
      this.router.navigate(['/login']);
    } else if (action === 'signup') {
      this.router.navigate(['/sign-up']);
    }
    this.closeModal();
  }

  ngOnDestroy(): void {
    this.subscriptions.next();
    this.subscriptions.complete();
  }
}
