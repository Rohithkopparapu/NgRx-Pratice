import {ALLOWED_FILE_TYPES, ERROR_MESSAGE} from 'src/app/shared/constants/constant';
import {UploadService} from '../../services/upload.service';
import {Component, Input, OnDestroy, OnInit} from '@angular/core';
import {NgbActiveModal} from '@ng-bootstrap/ng-bootstrap';
import {ToastrService} from 'ngx-toastr';
import {takeUntil} from 'rxjs/operators';
import {Subject} from 'rxjs';
import {Store} from '@ngrx/store';
import {AuthState} from '../../store/auth.model';
import {userInfo} from '../../store/auth.selector';
import * as _ from 'lodash';
import * as XLSX from 'xlsx'

type AOA = any[][];
@Component({
  selector: 'app-file-upload',
  templateUrl: './file-upload.component.html',
  styleUrls: ['./file-upload.component.scss']
})
export class FileUploadComponent implements OnInit, OnDestroy {
  private subscriptions = new Subject<void>();
  @Input() data;
  userInfo: any;
  isLoading: boolean;
  attachmentList: any[] = [];
  maxFileSize = 2097152;
  headerName: string;
  fileType: string;
  isMultipleFile: boolean;
  isShowing: boolean;
  fileErrorName: string;
  fileAccepts: string;
  allowedFileTypes: any[];
  fileSupport: string;
  schoolNames: any;
  dataEXL: AOA = [[], []];
  issUp:boolean=false;
  lessonplan:boolean=false;
  planfor:any
  constructor(
    private toastrService: ToastrService,
    private activeModal: NgbActiveModal,
    private uploadService: UploadService,
    private store$: Store<AuthState>
  ) {
    this.store$.select(userInfo)
      .pipe(takeUntil(this.subscriptions))
      .subscribe(res => this.userInfo = res);
  }

  ngOnInit() {
    this.headerName = this.data.headerName;
    this.fileType = this.data.fileType;
    this.isMultipleFile = this.data.isMultipleFile;
    this.checkAllowTypesFiles(this.fileType);
    if(this.fileType === 'excel'){
      this.schoolNames = this.data.schoolNames;
      this.isShowing = true
    }
    if(this.headerName==='Upload Plan'){
      this.lessonplan=true;
      this.planfor = this.data.planfor;
    }
  }

  checkAllowTypesFiles(fileType: string): void {
    if (fileType === 'image') {
      this.fileSupport = 'JPEG, SVG, PNG, WEBP, GIF, TIFF';
      this.fileAccepts = 'image/*';
      this.allowedFileTypes = [...ALLOWED_FILE_TYPES.IMAGE];
      this.maxFileSize = (this.userInfo.user_type === 'admin') ? (20 * 1024 * 1024) : (20 * 1024 * 1024); // 20 MB and 2MB
      this.fileErrorName = 'an Image';
    } else if (fileType === 'video') {
      this.fileSupport = 'MP4, AVI, MOV, MPEG, WEBM';
      this.fileAccepts = 'video/*';
      this.maxFileSize = (this.userInfo.user_type === 'admin') ? (2 * 1024 * 1024 * 1024) : (1 * 1024 * 1024 * 1024); // 2GB and 1GB
      this.allowedFileTypes = [...ALLOWED_FILE_TYPES.VIDEO];
      this.fileErrorName = 'an Video file';
    } else if (fileType === 'audio') {
      this.fileSupport = 'MP3, MP4, MPEG, WEBM';
      this.fileAccepts = 'audio/*';
      this.allowedFileTypes = [...ALLOWED_FILE_TYPES.AUDIO];
      this.maxFileSize = (this.userInfo.user_type === 'admin') ? (20 * 1024 * 1024) : (20 * 1024 * 1024);
      this.fileErrorName = 'an Audio file';
    } else if (fileType === 'doc') {
      this.fileSupport = 'PDF, DOC, DOCX, TXT, XLS, XLSX, HTML, PPT, ODP';
      this.fileAccepts = '.doc, .docx, .xls, .xlsx, .ppt, .pptx, .odp, text/html, text/plain, application/pdf, application/msword, application/vnd.ms-excel, application/vnd.openxmlformats-officedocument.wordprocessingml.document';
      this.allowedFileTypes = [...ALLOWED_FILE_TYPES.DOCUMENT];
      this.maxFileSize = (this.userInfo.user_type === 'admin') ? (20 * 1024 * 1024) : (20 * 1024 * 1024);
      this.fileErrorName = 'a Document file';
    } else if (fileType === 'image&video') {
      this.fileSupport = 'JPEG, SVG, PNG, WEBP, GIF, TIFF, MP4, AVI, MOV, MPEG, WEBM';
      this.fileAccepts = 'image/*, video/*';
      this.allowedFileTypes = [...ALLOWED_FILE_TYPES.IMAGE, ...ALLOWED_FILE_TYPES.VIDEO];
      this.maxFileSize = (this.userInfo.user_type === 'admin') ? (2 * 1024 * 1024 * 1024) : (1 * 1024 * 1024 * 1024); // 2GB and 1GB
      this.fileErrorName = 'a Image/Video file';
    } else if (fileType === 'image&video&doc') {
      this.fileSupport = 'JPEG, SVG, PNG, WEBP, GIF, TIFF, MP4, AVI, MOV, MPEG, WEBM, PDF, DOC, DOCX, TXT, XLS, XLSX, HTML, PPT, ODP';
      this.fileAccepts = 'image/*, video/*, .doc, .docx, .xls, .xlsx, .ppt, .pptx, .odp, text/html, text/plain, application/pdf, application/msword, application/vnd.ms-excel, application/vnd.openxmlformats-officedocument.wordprocessingml.document';
      this.allowedFileTypes = [...ALLOWED_FILE_TYPES.IMAGE, ...ALLOWED_FILE_TYPES.VIDEO, ...ALLOWED_FILE_TYPES.DOCUMENT];
      this.maxFileSize = (this.userInfo.user_type === 'admin') ? (2 * 1024 * 1024 * 1024) : (1 * 1024 * 1024 * 1024); // 2GB and 1GB
      this.fileErrorName = 'a Image/Video/Document file';
    }else if (fileType === 'excel'){
      this.fileSupport = 'XLSX, CSV, XLS';
      this.fileAccepts = '.xlsx, .csv, .xls';
      this.allowedFileTypes = [...ALLOWED_FILE_TYPES.CSV,...ALLOWED_FILE_TYPES.EXCEL];
      this.maxFileSize = (this.userInfo.user_type === 'admin') ? (2 * 1024 * 1024 * 1024) : (1 * 1024 * 1024 * 1024); // 2GB and 1GB
    }else if(fileType=== "docnew"){
      this.fileSupport = 'PDF, DOC, DOCX, TXT, XLS, XLSX, HTML, PPT, ODP,JPEG, SVG, PNG, WEBP, GIF';
      this.fileAccepts = '.doc, .docx, .xls, .xlsx, .ppt, .pptx, .odp,image/*, text/html, text/plain, application/pdf, application/msword, application/vnd.ms-excel, application/vnd.openxmlformats-officedocument.wordprocessingml.document';
      this.allowedFileTypes = [...ALLOWED_FILE_TYPES.DOCUMENT, ...ALLOWED_FILE_TYPES.CSV,...ALLOWED_FILE_TYPES.EXCEL,...ALLOWED_FILE_TYPES.IMAGE];
      this.maxFileSize = (this.userInfo.user_type === 'admin') ? (20 * 1024 * 1024) : (20 * 1024 * 1024);
      this.fileErrorName = 'a Document file';
    }else if (fileType === 'image&video&doc&audio') {
      this.fileSupport = 'JPEG, SVG, PNG, WEBP, GIF, TIFF, MP4, AVI, MOV, MPEG, WEBM, PDF, DOC, DOCX, TXT, XLS, XLSX, HTML, PPT, ODP','MP3, MP4, MPEG, WEBM';
      this.fileAccepts = 'image/*, video/*, .doc, .docx, .xls, .xlsx, .ppt, .pptx, .odp, text/html, text/plain, application/pdf, application/msword, application/vnd.ms-excel, application/vnd.openxmlformats-officedocument.wordprocessingml.document','audio/*';
      this.allowedFileTypes = [...ALLOWED_FILE_TYPES.IMAGE, ...ALLOWED_FILE_TYPES.VIDEO, ...ALLOWED_FILE_TYPES.DOCUMENT,...ALLOWED_FILE_TYPES.AUDIO];
      this.maxFileSize = (this.userInfo.user_type === 'admin') ? (2 * 1024 * 1024 * 1024) : (1 * 1024 * 1024 * 1024); // 2GB and 1GB
      this.fileErrorName = 'a Image/Video/Document/Audio file';
    }
  }

  onSelectFile(event: any): void {
    let files: any[];
    const sizeInMB = (this.maxFileSize / (1024 * 1024)).toFixed(2);
    if (event.target) {
      files = event.target.files;
    } else {
      files = event;
    }
    if (this.headerName === 'Profile Pic') {
      this.attachmentList = [];
    }
    if(this.headerName === 'Excel'){
      let test:any;
      test = this.onFileChange(event)
      // if(test){
      //   test.forEach(element => {
      //     if(element.user_type =="student" || element.user_type =="teacher"){
      //     }else{
      //       this.issUp=true;
      //       this.toastrService.warning("Please add Student or Teacher only!")
      //     }
      //   });
      // }
      this.attachmentList= []
    }
    if (files && files.length <= 10) {
      Array.from(files).forEach((file) => {
        const splittedFileName = file.name.split('.');
        const fileName = splittedFileName.slice(0, -1).join('.');
        const fileExtension = splittedFileName.pop();
        let fileType = '';
        if (fileName.length > 60) {
          this.toastrService.warning('File name should be less than 60 characters', 'Invalid File name');
        } else if (!this.validateFileName(file.name)) {
          this.toastrService.warning('Only underscore and hyphen special characters are allowed in a Filename.', 'Invalid File name');
        } else if (this.allowedFileTypes.indexOf(file.type) === -1) {
          this.toastrService.warning('Please select valid File / Format');
        } else if (file.size && file.size > this.maxFileSize) {
          this.toastrService.warning('File size should be less than ' + sizeInMB + 'MB');
        } else if (file.name) {
          if (fileExtension.match(/(jpg|jpeg|png|gif|svg|tiff)$/i)) {
            fileType = 'image';
          } else if (fileExtension.match(/(mp4|mov|mpeg|wmv|webm|qt|avi|avchd)$/i)) {
            fileType = 'video';
          } else if(fileExtension.match(/(xlsx|csv)$/i)){
            fileType = 'excel'
          }else if(fileExtension.match(/(mp3|wav|aiff|flac|m4a|ogg|aac|wma|ape)$/i)){
            fileType = 'audio'
          }else {
            fileType = 'doc';
          }
          // const reader = new FileReader();
          // reader.readAsDataURL(file);
          this.attachmentList.push({file, name: fileName, fileType});
          
        }
      });
    } else {
      this.toastrService.warning('Please upload only 10 attachments at a time');
    }
  }

  validateFileName(name: string): any {
    return name.match(/^[0-9a-zA-Z\_\-. ()]+$/);
  }

  removeUpload(i) {
    this.attachmentList = this.attachmentList.filter((item, index) => index !== i);
  }

  uploadAttachments(): void {
    let isFlag = false;
    if (this.attachmentList && this.attachmentList.length === 0) {
      this.toastrService.warning(`Please select ${this.fileErrorName}`);
      return;
    }
    this.attachmentList.forEach(attach => {
      if (attach.name === '') {
        isFlag = true;
      }
    });
    if (isFlag) {
      this.toastrService.warning('File name should not be empty', 'Invalid File name');
      return;
    }
    this.uploadFiles();
  }

  buildImageArray(resp: any): any {
    const imageArray = [];
    if (resp && resp.length) {
      resp.forEach(element => {
        const imageObj = {
          display_name: this.attachmentList.find(img => img.file.name === element.display_name).name,
          file: element.file,
          fileUrl: element.file_url,
          name: element.display_name
        };
        imageArray.push(imageObj);
      });
    }
    return imageArray;
  }

  uploadFiles(): void {
    this.isLoading = true;
    if(this.data.fileCategory === 'excel'){
      const file = this.attachmentList[0];
      const files = this.attachmentList.map(res => res.file);
      this.uploadService.excelFile(file.file,this.data.schoolId, this.data.schoolNames).subscribe(res => {
        if (res) {
          this.toastrService.success(ERROR_MESSAGE.FILE_UPLOADED);
          const reason = this.buildImageArray(res);
          this.activeModal.close('Excel_upload');
          // this.activeModal.dismiss(reason);
        }
        this.isLoading = false;
      }, (error) => {
        if(this.toastrService.toasts.length !== 0){
          if(this.toastrService.toasts[0].message.includes('something')){
            this.toastrService.clear();
            this.toastrService.remove(this.toastrService.toasts[0].toastId);
          }
        }
        if(error.error.status === 'failed' || error.error.status === 400){
          this.toastrService.error(error.error.message);
        }
        this.isLoading = false;
      });
     
    }else{
      const files = this.attachmentList.map(res => res.file);
      this.uploadService.uploadDocument(files, this.data.fileCategory).subscribe((resp) => {
        if (resp) {
          this.toastrService.success(ERROR_MESSAGE.FILE_UPLOADED);
          const reason = this.buildImageArray(resp);
          this.activeModal.dismiss(reason);
        }
        this.isLoading = false;
      }, err => {
        this.toastrService.error(err.error.msg);
        this.isLoading = false;
      });
    }
   
  }
  onFileChange(evt: any) {
    /* wire up file reader */
    const target: DataTransfer = <DataTransfer>(evt.target);
    if (target.files.length !== 1) throw new Error('Cannot use multiple files');
    const reader: FileReader = new FileReader();
    reader.onload = (e: any) => {
      /* read workbook */
      const bstr: string = e.target.result;
      const wb: XLSX.WorkBook = XLSX.read(bstr, { type: 'binary' });

      /* grab first sheet */
      const wsname: string = wb.SheetNames[0];
      const ws: XLSX.WorkSheet = wb.Sheets[wsname];

      /* save data */
      this.dataEXL = <AOA>(XLSX.utils.sheet_to_json(ws));
      // console.log("test",this.dataEXL);
      if(this.dataEXL.length){
        let test:any;
        test =this.dataEXL
        test.forEach(element => {
          if(!element.name){
            this.issUp=true;
            this.toastrService.warning("Please fill mandatory field Name!")
          }
          if(!element.gender ){
            this.issUp=true;
            this.toastrService.warning("Please fill mandatory field Gender!")
          }
          if(!element.email){
            this.issUp=true;
            this.toastrService.warning("Please fill mandatory field Email!")
          }
          if(!element.date_of_birth && element.user_type.toLowerCase() =="student"){
            this.issUp=true;
            this.toastrService.warning("Please fill mandatory field Date of Birth!")
          }
          if(!element.class && element.user_type.toLowerCase() =="student"){
            this.issUp=true;
            this.toastrService.warning("Please fill mandatory field Class!")
          }
          if(element.class>13 || element.class<5){
            this.issUp=true;
            this.toastrService.warning("Class should be 5 to 12 !")
          }
          if(element.parent_number>9999999999){
            this.issUp=true;
            this.toastrService.warning("Parent Number must contain 10 digits. Ex.9987654321")
          }
          if(element.phone_number>9999999999){
            this.issUp=true;
            this.toastrService.warning("Phone Number must contain 10 digits. Ex.9987654321")
          }
          if(element.user_type.toLowerCase() =="student" || element.user_type.toLowerCase() =="teacher"){
          }else{
            this.issUp=true;
            this.toastrService.warning("Please add Student or Teacher only in user type!")
          }
        });
      }else{
        this.issUp=true;
        this.toastrService.warning("File is Empty!")
      }
      
    };
    
    reader.readAsBinaryString(target.files[0]);
    
    // return this.dataEXL;
  }

  close(): void {
    this.activeModal.close();
  }

  // removeVideo(event: any, index: number) {
  //   const p = event.clientX;
  //   const q = event.clientY;
  //   const closeRect = event.target['offsetParent'].children[0].getBoundingClientRect();
  //   if ((p >= closeRect.left && p <= closeRect.left + closeRect.width) &&
  //     (q >= closeRect.top && q <= closeRect.top + closeRect.height)) {
  //     event.target.pause();
  //     this.removeUpload(index);
  //   }
  // }

  ngOnDestroy(): void {
    this.subscriptions.next();
    this.subscriptions.complete();
  }
}
