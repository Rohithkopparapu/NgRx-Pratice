import { Component, OnInit, ViewChild } from '@angular/core';
import { NgbActiveModal, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import * as moment from 'moment';
import { StudentHelperService } from '../../../modules/student-dashboard/student-helper.service';
import { ChallengeWorkAreaComponent } from '../../../modules/student-dashboard/challenge-hub/challenge-work-area/challenge-work-area.component';
import { AssignRoleComponent } from '../../../modules/student-dashboard/challenge-hub/assign-role/assign-role.component';
import { ToastrService } from 'ngx-toastr';
import { CreateGroupComponent } from '../../../modules/student-dashboard/challenge-hub/create-group/create-group.component';
import { ViewResponsesComponent } from '../view-responses/view-responses.component';
import { ModalUtilService } from '../../services/modal-util.service';
import Swiper, { Autoplay, Navigation, Pagination } from 'swiper';
import { Store } from '@ngrx/store';
import { AuthState } from '../../store/auth.model';
import { userInfo } from '../../store/auth.selector';
import { takeUntil } from 'rxjs/operators';
import { Subject } from 'rxjs';
import { FormBuilder, FormGroup } from '@angular/forms';
import { PostRefreshService } from '../../services/post-refresh.service';

@Component({
  selector: 'app-group-challenge-model',
  templateUrl: './group-challenge-model.component.html',
  styleUrls: ['./group-challenge-model.component.scss']
})
export class GroupChallengeModelComponent implements OnInit {
  private subscriptions = new Subject<void>();
  data: any;
  @ViewChild('videoplayer', { static: false }) videoplayer;
  isLoading = false;
  challenge: any;
  multipleInvitesList: any[];
  acceptedGroupMembers: any;
  slides: any[] = [];

  userType: string;
  isEnable: boolean;
  isHomeAccess: any;
  levelId: any;
  communityId: any;
  checkMandatory: any;
  userInfo: any;
  showDottie: boolean = false;
  dottieForm: FormGroup;
  automatedres: Object;
  automatedResponseArray: any = [];
  buddyDetails: any;


  constructor(private activeModal: NgbActiveModal, private studentHelperService: StudentHelperService, private modalService: NgbModal,
    private toastrService: ToastrService, private store$: Store<AuthState>, private modalUtilService: ModalUtilService, private fb: FormBuilder, private refreshService: PostRefreshService) {
    this.store$.select(userInfo)
      .pipe(takeUntil(this.subscriptions))
      .subscribe(res => this.userInfo = res)
    this.buddyDetails = this.userInfo;

  }

  ngOnInit() {
    if (!this.isHomeAccess) {
      this.getChallengeDetails(this.data.challenge.topic_id);
    } else {
      this.getChallengeDetailsPublic(this.data.challenge.topic_id);
    }
    this.createForm();
  }

  closeModal() {
    this.activeModal.close();
    this.refreshService.triggerRefresh();
  }

  getChallengeDetails(topicId): void {
    this.isLoading = true;
    this.studentHelperService.getTopicDetailsById(topicId).subscribe(res => {
      this.isLoading = false;
      if (res) {
        this.levelId = res.level_id;
        this.communityId = res.community_id;
        this.checkMandatory = res.is_mandatory;
        this.processResponse(res);
        this.getMultipleInvitesForUser();
      }
    }, () => this.isLoading = false);
  }

  createForm() {
    this.dottieForm = this.fb.group({
      user_input: [""]
    });
  }

  getChallengeDetailsPublic(topicId): void {
    this.isLoading = true;
    this.studentHelperService.getTopicDetailsByIdPublic(topicId).subscribe(res => {
      this.isLoading = false;
      if (res) {
        this.levelId = res.level_id;
        this.communityId = res.community_id;
        this.checkMandatory = res.is_mandatory;
        this.processResponse(res);
      }
    }, () => this.isLoading = false);
  }

  processResponse(res: any): void {
    this.challenge = res;
    this.challenge.topic_end_date = moment(this.challenge.topic_end_date).format('ll');
    this.isEnable = moment(moment().format('ll')).isBetween(moment(this.challenge.topic_start_date).format('ll'), this.challenge.topic_end_date, undefined, '[]');
    this.challenge.topic_description = this.challenge.topic_description.replace(/&nbsp;/g, '');
    if (this.challenge && this.challenge.attachments && this.challenge.attachments.length) {
      this.challenge.attachments = this.challenge.attachments.filter(attach => (attach.attachment_title === 'challenge_image' || attach.attachment_title === 'challenge_video'));
    }
    this.initSwiperSlider();
  }

  initSwiperSlider() {
    setTimeout(() => {
      if (this.challenge.attachments.length > 1) {
        const swiper = new Swiper('.swiper.swiper-group-challenge', {
          modules: [Navigation, Pagination, Autoplay],
          // Optional parameters
          loop: true,
          freeMode: true,

          // If we need pagination
          pagination: {
            clickable: true,
            el: '.swiper-pagination',
            type: 'bullets'
          },

          autoplay: {
            delay: 2500,
            disableOnInteraction: false,
            pauseOnMouseEnter: true
          },

          keyboard: {
            enabled: true,
            onlyInViewport: false,
          },

          // Navigation arrows
          navigation: {
            nextEl: '.swiper-button-next',
            prevEl: '.swiper-button-prev',
          },
        });
      } else {
        const swiper = new Swiper('.swiper.swiper-group-challenge', {
          // Optional parameters
          enabled: false,
          navigation: {
            nextEl: null,
            prevEl: null,
          },
        });
      }
    });
  }

  viewOtherResponse(): void {
    if (!this.isHomeAccess) {
      if (this.challenge.total_responses !== '0') {
        const modelRef = this.modalService.open(ViewResponsesComponent, {
          centered: true,
          scrollable: true,
          backdrop: 'static',
          size: 'xl',
          windowClass: 'modal-challenge'
        });
        modelRef.componentInstance.challenge = this.challenge;
        modelRef.componentInstance.userType = this.userType;
      } else {
        this.toastrService.warning('No responses found...');
      }
    } else {
      this.gotoSignup();
    }
  }

  acceptGroup(): void {
    if (!this.acceptedGroupMembers) {
      this.toastrService.warning('Please select a group and accept the invitation');
      return;
    } else {
      this.challenge.group_id = this.acceptedGroupMembers.group_id;
      // this.activeModal.close();
      const modelRef = this.modalService.open(AssignRoleComponent, {
        centered: true,
        scrollable: true,
        backdrop: 'static',
        keyboard: false,
        size: 'lg',
        windowClass: 'modal-challenge'
      });
      modelRef.componentInstance.challenge = this.challenge;
      modelRef.result.then(res => {
        if (res === 'Assign Role') {
          this.activeModal.close();
        }
      });
    }
  }

  gotoChallengeWorkArea(): void {

    const payload = {
      community_id: this.communityId,
      user_id: this.userInfo.user_id,
      level_id: this.levelId ? this.data.challenge.level_id : '',
    };
    if (this.data.challenge.level_id === null) {
      const modelRef = this.modalService.open(ChallengeWorkAreaComponent, {
        centered: true,
        backdrop: 'static',
        scrollable: true,
        size: 'xl',
        // windowClass: 'modalChallengeStoryTelling'
        windowClass: 'modal-challenge'
      });
      modelRef.componentInstance.challenge = this.challenge;
      modelRef.result.then((res) => {
        if (res === 'close') {
          this.activeModal.close();
        }
      });
    } else {
      if (this.userInfo.user_type === "student") {
        if (this.checkMandatory != 1) {
          // if (noOfMandatoryActivitiesPending.length === 0) {
          const params = { community_id: this.communityId, level_id: this.levelId };
          this.studentHelperService.getQuestTopics(params).subscribe(respose => {
            if (respose) {
              const pendingChallenges = respose.continue_challenges.concat(respose.recent_challenges);
              const noOfMandatoryChallengesPending = pendingChallenges.filter(x => x.is_mandatory === 1)
              if (noOfMandatoryChallengesPending.length === 0) {
                const modelRef = this.modalService.open(ChallengeWorkAreaComponent, {
                  centered: true,
                  backdrop: 'static',
                  scrollable: true,
                  size: 'xl',
                  // windowClass: 'modalChallengeStoryTelling'
                  windowClass: 'modal-challenge'
                });
                modelRef.componentInstance.challenge = this.challenge;
                modelRef.result.then((res) => {
                  if (res === 'close') {
                    this.activeModal.close();
                  }
                });
              } else {
                this.toastrService.warning("Complete the mandatory challenges to proceed further");
              }
            }
          });

        } else {
          this.studentHelperService.getQuestInfo(payload).subscribe(res => {

            const noOfMandatoryActivitiesPending = res.data.activities.filter(x => x.is_mandatory === 1 && x.status === "pending")
            if (noOfMandatoryActivitiesPending.length === 0) {
              const modelRef = this.modalService.open(ChallengeWorkAreaComponent, {
                centered: true,
                backdrop: 'static',
                scrollable: true,
                size: 'xl',
                // windowClass: 'modalChallengeStoryTelling'
                windowClass: 'modal-challenge'
              });
              modelRef.componentInstance.challenge = this.challenge;
              modelRef.result.then((res) => {
                if (res === 'close') {
                  this.activeModal.close();
                }
              });
            } else {
              this.toastrService.warning("Complete the mandatory activities to proceed to Challenges");
            }
          });
        }
      } else {
        const modelRef = this.modalService.open(ChallengeWorkAreaComponent, {
          centered: true,
          backdrop: 'static',
          scrollable: true,
          size: 'xl',
          // windowClass: 'modalChallengeStoryTelling'
          windowClass: 'modal-challenge'
        });
        modelRef.componentInstance.challenge = this.challenge;
        modelRef.result.then((res) => {
          if (res === 'close') {
            this.activeModal.close();
          }
        });
      }
    }

    // const modelRef = this.modalService.open(ChallengeWorkAreaComponent, {
    //   centered: true,
    //   backdrop: 'static',
    //   scrollable: true,
    //   size: 'xl',
    //   // windowClass: 'modalChallengeStoryTelling'
    //   windowClass: 'modal-challenge'
    // });
    // modelRef.componentInstance.challenge = this.challenge;
    // modelRef.result.then((res) => {
    //   if (res === 'close') {
    //     this.activeModal.close();
    //   }
    // });
  }

  getMultipleInvitesForUser(): void {
    if (this.challenge.topic_assign_id && !this.challenge.group_role_id) {
      this.isLoading = true;
      this.studentHelperService.getMultipleInvitesForChallenge(this.challenge.topic_id).subscribe(res => {
        this.isLoading = false;
        if (res) {
          this.multipleInvitesList = res;
        }
      }, () => this.isLoading = false);
    }
  }

  getAcceptedGroupMembers(selectedGroup): void {
    selectedGroup['group_members'] = selectedGroup.group_members.filter(s => s.role_id !== 'NULL' && s.group_role_id !== 'NULL');
    this.acceptedGroupMembers = selectedGroup;
  }

  createGroup(): void {
    // this.activeModal.close();
    const data = { challenge: this.challenge, groupMembers: [], formName: 'Create', isPendingInvitesExist: false };
    const modelRef = this.modalService.open(CreateGroupComponent, {
      centered: true,
      scrollable: true,
      backdrop: 'static',
      keyboard: false,
      size: 'xl',
      windowClass: 'modal-challenge modal-challenge-fluid'
    });
    modelRef.componentInstance.data = data;
    modelRef.result.then(res => {
      if (res === 'Create') {
        this.activeModal.close();
      }
    });
  }

  afterChange(): void {
    if (this.videoplayer && this.videoplayer.nativeElement) {
      this.videoplayer.nativeElement.pause();
    }
  }

  openProfile(user: any): void {
    if (!this.isHomeAccess) {
      this.modalUtilService.openBuddyProfile(user);
    }
  }

  gotoSignup(): void {
    this.toastrService.warning('Please Sign Up to explore more');
  }

  submitInput() {
    const currentres = this.dottieForm.controls['user_input'].value.trim();
    const payload = {};
    this.dottieForm.controls['user_input'].setValue("");
    payload['user_input'] = currentres;
    payload['topic_id'] = this.challenge.topic_id;
    if (currentres !== "") {
      const obj = { "userinput": currentres }
      this.automatedResponseArray.splice(this.automatedResponseArray.length, 0, obj);
      this.studentHelperService.getOpenAiResponse(payload).subscribe(res => {
        if (res) {
          this.automatedres = res;

          this.automatedResponseArray[this.automatedResponseArray.length - 1]["openAiRes"] = res;
        }
      })
    } else {
      this.toastrService.error("Please provide the required input")
    }
  }

  openDottie() {
    this.showDottie = !this.showDottie;
  }
  closeDottie() {
    this.showDottie = false;
  }
}
