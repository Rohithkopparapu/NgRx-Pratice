import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ImageVideoViewComponent } from './image-video-view.component';

describe('ImageVideoViewComponent', () => {
  let component: ImageVideoViewComponent;
  let fixture: ComponentFixture<ImageVideoViewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ImageVideoViewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ImageVideoViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
