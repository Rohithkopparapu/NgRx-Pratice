import {Component, OnInit} from '@angular/core';
import {NgbActiveModal} from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-image-video-view',
  templateUrl: './image-video-view.component.html',
  styleUrls: ['./image-video-view.component.scss']
})
export class ImageVideoViewComponent implements OnInit {
  fileType: string;
  fileUrl: string;
  isUrlLoading: boolean;
  materialName:string;
  mtype:string;
  filepath: string;

  constructor(private activeModel: NgbActiveModal) {
  }

  ngOnInit() {
    this.filepath = this.fileUrl
  }

  close(): void {
    this.activeModel.close();
  }

}
