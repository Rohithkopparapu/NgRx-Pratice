import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InviteBuddyByEmailComponent } from './invite-buddy-by-email.component';

describe('InviteBuddyByEmailComponent', () => {
  let component: InviteBuddyByEmailComponent;
  let fixture: ComponentFixture<InviteBuddyByEmailComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InviteBuddyByEmailComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InviteBuddyByEmailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
