import { Component, OnInit } from '@angular/core';
import {NgbActiveModal} from '@ng-bootstrap/ng-bootstrap';
import {HelperService} from '../../services/helper.service';
import {StudentHelperService} from '../../../modules/student-dashboard/student-helper.service';
import {ToastrService} from 'ngx-toastr';
import {EMAIL} from '../../constants/validationConstants';

@Component({
  selector: 'app-invite-buddy-by-email',
  templateUrl: './invite-buddy-by-email.component.html',
  styleUrls: ['./invite-buddy-by-email.component.scss']
})
export class InviteBuddyByEmailComponent implements OnInit {

  isLoading = false;
  emailRegexPattern = EMAIL.REGEX_EMAIL;

  constructor(private activeModal: NgbActiveModal, public _uhs: HelperService, private studentHelperService: StudentHelperService,
              private toastrService: ToastrService) { }

  ngOnInit() {
  }

  closeModal() {
    this.activeModal.close();
  }

  sendInvite(email: any): void {
    if (email.value === '') {
      this.toastrService.warning('Please enter an buddy email');
      return;
    }
    if (email.valid) {
      this.isLoading = true;
      const payload = {
        email: email.value
      };
      this.studentHelperService.inviteBuddy(payload).subscribe((res) => {
        this.isLoading = false;
        if (res.status === 'Success') {
          this.toastrService.success('Joincode sent successfully to buddy');
        } else {
          this.toastrService.error(res.message);
        }
        this.activeModal.close();
      }, () => this.isLoading = false);
    }
  }
}
