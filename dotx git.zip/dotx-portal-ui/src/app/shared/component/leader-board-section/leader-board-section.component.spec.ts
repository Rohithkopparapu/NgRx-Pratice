import {async, ComponentFixture, TestBed} from '@angular/core/testing';

import {LeaderBoardSectionComponent} from './leader-board-section.component';

describe('LeaderBoardSectionComponent', () => {
  let component: LeaderBoardSectionComponent;
  let fixture: ComponentFixture<LeaderBoardSectionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [LeaderBoardSectionComponent]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LeaderBoardSectionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
