import { Component, EventEmitter, Input, OnDestroy, OnInit, Output } from '@angular/core';
import * as moment from 'moment';
import { PLATFORM_START_DATE, PREFERENCES } from '../../constants/constant';
import { DATE_FORMAT_MOMENT } from '../../constants/input.constants';
import { StudentHelperService } from '../../../modules/student-dashboard/student-helper.service';
import { MySpaceComponent } from '../../../modules/student-dashboard/header-section/my-space/my-space.component';
import { ViewOtherProfileComponent } from '../view-other-profile/view-other-profile.component';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { takeUntil } from 'rxjs/operators';
import { Subject, Subscription } from 'rxjs';
import { userInfo } from '../../store/auth.selector';
import { Store } from '@ngrx/store';
import { AuthState } from '../../store/auth.model';
import { HelperService } from '../../../shared/services/helper.service';
import { ActivatedRoute } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { FormBuilder, FormGroup } from '@angular/forms';
import { DataService } from '../../../shared/services/data.service';

@Component({
  selector: 'app-leader-board-section',
  templateUrl: './leader-board-section.component.html',
  styleUrls: ['./leader-board-section.component.scss']
})
export class LeaderBoardSectionComponent implements OnInit, OnDestroy {
  private subscription: Subscription;
  LEADERBOARD_START_DATE = moment(PLATFORM_START_DATE, DATE_FORMAT_MOMENT, true);
  private subscriptions = new Subject<void>();
  @Input() data: any;
  @Output() closeEmitter = new EventEmitter<boolean>();
  isLeaderBoardLoading = false;
  className: any;
  userInfo: any;
  leaderboardUserList: any[];
  isShowLeaderboardRules = false;
  weekStart: any;
  weekEnd: any;
  tabName: string;
  selectedFilter: string;
  selectCommunityId: string;
  selectedFilterDate: any;
  communityItem: any;
  toDate: { year: number; month: number; day: number; };
  fromDate: { year: number; month: number; day: number; };
  fromDate1: string;
  communitiesList: any = [];
  selectedOption: any;
  isLoading: boolean;
  userCommunityPreference: any;
  defaultCommunity: any;
  leaderBoardForm: FormGroup;
  periodList = [{ id: "Last Week", value: "Last Week" },
  { id: "Last Week", value: "Last Week" },
  { id: "Last Month", value: "Last Month" },
  { id: "Last 3 Months", value: "Last 3 Months" },
  { id: "Last 6 Months", value: "Last 6 Months" },
  { id: "Last Year", value: "Last Year" }]
  page: any = 1;
  perPage: any = 10;
  startDate: any;
  pageSearch = 1;
  total_record: any;
  userId: any;
  datainfo: any;
  dataQuest: any = [];



  constructor(private fb: FormBuilder, private studentHelperService: StudentHelperService, private modalService: NgbModal, private store$: Store<AuthState>,
    private activatedRoute: ActivatedRoute, private helperService: HelperService, private toastrService: ToastrService, private dataService: DataService) {
    this.store$.select(userInfo)
      .pipe(takeUntil(this.subscriptions))
      .subscribe(res => {
        if (res) {
          this.userInfo = res;
          this.userId = this.userInfo.user_id;
        }
      });
    this.store$.select(userInfo)
      .pipe(takeUntil(this.subscriptions))
      .subscribe(res => {
        this.userInfo = res;
        const community = res.preferences.find(s => s.entity_name === PREFERENCES.COMMUNITY.ENTITY_NAME && s.entity_type === PREFERENCES.COMMUNITY.ENTITY_TYPE);
        this.communityItem = community ? community : null;
      });
    this.fromDate1 = moment().subtract(1, 'months').format('DD-MM-YYYY');
    this.subscription = this.dataService.refreshComponent$.subscribe(() => {
      this.refreshComponentLogic();
    });

  }

  refreshComponentLogic() {
    this.getLeaderboardupdated();
  }

  ngOnInit() {
    this.activatedRoute.data.subscribe((response) => {
      this.userCommunityPreference = response && response.userPreferenceDetails;
    });
    this.className = this.data.className;
    this.resetWeek();
    console.log("fdf", this.communityItem);
    this.toDate = this.helperService.getSpotlightFormattedStartMinDate();
    this.getCommunities();
    this.createForm();
  }

  createForm() {
    this.leaderBoardForm = this.fb.group({
      community: [''],
      period: ["Last Month"]
    });
  }

  loadLeaderboardDetails() {
    this.isLeaderBoardLoading = true;
    // this.leaderboardUserList = [];
    // const queryParams = weekDate !== undefined ? `?week_date=${moment(weekDate).format('DD-MM-YYYY')}` : '';
    // this.studentHelperService.getLeaderboardDetails(queryParams).subscribe( res => {
    //   this.isLeaderBoardLoading = false;
    //   this.leaderboardUserList = res;
    // }, () => this.isLeaderBoardLoading = false);

    const startDate = this.fromDate1 !== undefined ? `?start_date=${this.fromDate1}` : '';
    const endDate = `&end_date=${moment().format('DD-MM-YYYY')}`;
    const commId = this.selectCommunityId !== undefined ? `&community_id=${this.selectCommunityId}` : '';
    //  const page = this.page !== undefined ? `&page=${this.page}` : '';
    const perPage = this.perPage !== undefined ? `&per_page=${this.perPage}` : '';

    this.studentHelperService.getLeadeboardDetailsNew(startDate, endDate, commId, this.page, perPage).subscribe(res => {
      this.leaderboardUserList = [];
      this.isLeaderBoardLoading = false;
      this.leaderboardUserList = res.data;
      this.total_record = 0
      // if(res.data !== undefined){
      this.total_record = res.total_records;
      // }
    }, err => {
      this.isLeaderBoardLoading = false;
    })
  }

  onChangeDateWeek(math: string, days: number): void {
    if (math === '-') {
      if (this.LEADERBOARD_START_DATE.isBefore(this.weekStart, 'date')) {
        this.weekEnd = moment(this.weekStart, true).subtract(1, 'days');
        this.weekStart = moment(this.weekEnd, true).subtract(days, 'days');
        this.tabName = 'Week - ' + moment(this.weekStart).diff(this.LEADERBOARD_START_DATE, 'weeks');
        this.loadLeaderboardDetails();
      }
    } else {
      if (moment(this.weekStart, true).week() !== moment().week()) {
        this.weekStart = moment(this.weekEnd, true).add(1, 'days');
        this.weekEnd = moment(this.weekStart, true).add(days, 'days');
        this.tabName = 'Week - ' + moment(this.weekStart).diff(this.LEADERBOARD_START_DATE, 'weeks');
        this.loadLeaderboardDetails();
      }
    }
  }

  resetWeek(): void {
    // const currentWeek = moment().subtract(moment().day(), 'days').format('DD/MMM/YYYY');
    // this.weekEnd = moment(currentWeek).subtract(1, 'days').format('DD/MMM/YYYY');
    // this.weekStart = moment(this.weekEnd).subtract(6, 'days').format('DD/MMM/YYYY');

    // this.weekStart = moment().subtract(moment().day(), 'days');
    this.weekStart = moment('15-05-2022', DATE_FORMAT_MOMENT, true);
    this.weekEnd = moment(this.weekStart, true).add(6, 'days');
    // this.tabName = 'Week - ' + moment(this.weekStart).diff(this.LEADERBOARD_START_DATE, 'weeks');
    this.loadLeaderboardDetails();

  }

  openBuddyProfile(buddie): void {
    const modalRef = this.modalService.open(buddie.user_id == this.userInfo.user_id ? MySpaceComponent : ViewOtherProfileComponent, {
      centered: true,
      backdrop: 'static',
      size: 'xl',
      windowClass: 'custom-modal'
    });
    if (buddie.user_id != this.userInfo.user_id) {
      modalRef.componentInstance.data = { userId: buddie.user_id };
    }
  }

  ngOnDestroy(): void {
    this.subscriptions.next();
    this.subscriptions.complete();
    this.subscription.unsubscribe();
  }

  onChangeFilter(): void {
    // if(value.target.innerText=="Select"){
    //   this.selectedFilter = '';
    //   this.selectCommunityId=''
    // }else{
    //   this.selectedFilter = value.target.innerText;
    //   this.selectCommunityId=value.target.id ? value.target.id:""
    // }
    this.selectCommunityId = this.leaderBoardForm.controls['community'].value;
  }
  onChangeFilterDate(): void {
    // this.selectedFilterDate = value.target.innerText;
    let check = this.leaderBoardForm.controls['period'].value;

    if (check == "Last Week") this.fromDate1 = moment().subtract(6, 'days').format('DD-MM-YYYY');
    if (check == "Last Month") this.fromDate1 = moment().subtract(1, 'months').format('DD-MM-YYYY');
    if (check == "Last 3 Months") this.fromDate1 = moment().subtract(3, 'months').format('DD-MM-YYYY');
    if (check == "Last 6 Months") this.fromDate1 = moment().subtract(6, 'months').format('DD-MM-YYYY');
    if (check == "A Year") this.fromDate1 = moment().subtract(1, 'years').format('DD-MM-YYYY');

    // let toDate = this.helperService.getFormattedDateToBind(this.toDate)
    // console.log(this.fromDate1,toDate);


  }

  getLeaderboardupdated() {
    this.loadLeaderboardDetails();

  }

  onPageChange(offset: number) {
    console.log(offset);
    this.page = offset;
    this.loadLeaderboardDetails();
  }

  getCommunities(): void {
    this.isLoading = true;
    this.studentHelperService.getAllCommunitiesNew().subscribe(res => {
      this.isLoading = false;
      if (res && res.my_communities.length) {
        sessionStorage.setItem('subsribedCommunities',JSON.stringify(res));
        // this.communitiesList = res.my_communities.filter(s =>
        let arr1 = res.my_communities.filter(s =>
          !s.combo && moment(moment(s.community_start_date).format('YYYY-MM-DD')).isSameOrBefore(moment().format('YYYY-MM-DD'))).sort((a, b) => a.community_name.localeCompare(b.community_name));
        if (this.userInfo.dot_registration_id !== null) {
          this.communitiesList = arr1.filter(community => (community.community_id && community.is_grade_wise === 1))
        } else if (this.userInfo.dot_registration_id === null) {
          this.communitiesList = arr1.filter(community => (community.is_certified === 0));
        }
        // this.communitiesList = arr1.filter(community => (community.community_id && community.is_grade_wise === 1) )
        if (this.userInfo.user_type === 'teacher') {
          this.dataQuest = arr1;
          if (arr1.length !== 0) {
            this.leaderBoardForm.patchValue({ community: arr1[0].community_id });
          }
        } else {
          this.studentCommunityInfo();
        }
        this.defaultCommunity = this.communitiesList.filter(community => community.community_id === Number(this.userCommunityPreference.value)).map(({ community_id, community_name }) => ({ community_id, community_name }));
        if (this.communitiesList.length !== 0) {
          this.leaderBoardForm.patchValue({ community: this.communitiesList[0].community_id });
        }
      }
    }, () => this.isLoading = false);
  }


  studentCommunityInfo() {
    const payload = {
      "user_id": this.userId
    }
    this.isLoading = true;
    this.studentHelperService.getTeacherDashboardStudentData(payload).subscribe(res => {
      this.datainfo = res.data;
      this.dataQuest = this.datainfo.reduce((result, obj1) => {
        if (this.communitiesList.some(obj2 => obj2.community_id === obj1.community_id)) {
          result.push(obj1);
        }
        return result;
      }, []);
      this.isLoading = false;

    }, err => {
      this.isLoading = false;
    })

  }
}
