import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ChallengeCompletedComponent } from './challenge-completed.component';

describe('LevelCompletedComponent', () => {
  let component: ChallengeCompletedComponent;
  let fixture: ComponentFixture<ChallengeCompletedComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ChallengeCompletedComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ChallengeCompletedComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
