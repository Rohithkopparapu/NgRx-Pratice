import {Component, Input, OnInit} from '@angular/core';
import {NgbActiveModal, NgbModal} from '@ng-bootstrap/ng-bootstrap';
import {StudentHelperService} from '../../../modules/student-dashboard/student-helper.service';
import {HelperService} from '../../services/helper.service';
import {ViewResponsesComponent} from '../view-responses/view-responses.component';
import {Router} from '@angular/router';
import { AuthState } from '../../store/auth.model';
import { Store } from '@ngrx/store';
import { userInfo } from '../../store/auth.selector';
import { takeUntil } from 'rxjs/operators';
import { Subject } from 'rxjs';

@Component({
  selector: 'app-my-challenges-popup',
  templateUrl: './my-challenges-popup.component.html',
  styleUrls: ['./my-challenges-popup.component.scss']
})
export class MyChallengesPopupComponent implements OnInit {
  private subscriptions = new Subject<void>();
  @Input() data;
  badges: any;
  dotcoins: any;
  accessViewType: string;
  completedChallenges: any[];
  createdChallenges: any[];
  isLoading = false;
  buddyDetails: any;
  userInfo: any;

  constructor(private store$: Store<AuthState>,private activeModal: NgbActiveModal, private studentHelperService: StudentHelperService,
              private _uhs: HelperService, private modalService: NgbModal, private router: Router) {
                this.store$.select(userInfo)
                .pipe(takeUntil(this.subscriptions))
                .subscribe(res => {
                  if (res) {
                    this.userInfo = res;
                  }
                });
  }

  ngOnInit() {
    this.badges = this.data.badges;
    this.dotcoins = this.data.dotcoins;
    this.accessViewType = this.data.accessViewType;
    this.buddyDetails = this.data.buddyDetails;
    this.getParticipatedChallenges();
  }

  getParticipatedChallenges(): void {
    this.isLoading = true;
    this.completedChallenges = [];
    this.createdChallenges = [];
    const payload = this.accessViewType === 'buddie' ? '?user=' + this.buddyDetails.user_id : '';

    // const payload = '?user=' + 1945;
    this.studentHelperService.getChallengeMine(payload).subscribe(res => {
      this.isLoading = false;
      if (res) {
        this.completedChallenges = this._uhs.getOnlyImageFromChallenges(res.completed_challenges);
        this.createdChallenges = this._uhs.getOnlyImageFromChallenges(res.created_challenges);
      }
    }, err => this.isLoading = false);
  }

  openMyChallengesResponses(challenge: any): any {
    if (challenge.final_submitted) {
      const modelRef = this.modalService.open(ViewResponsesComponent, {
        centered: true,
        scrollable: true,
        backdrop: 'static',
        size: 'xl',
        windowClass: 'modal-challenge'
      });
      modelRef.componentInstance.userType = this.userInfo.user_type;
      modelRef.componentInstance.challenge = challenge;
      modelRef.componentInstance.fromPage = 'my_challenge_popup';
      modelRef.componentInstance._page = 'MyChallenges';
      modelRef.componentInstance.isResponseSelect = true;
      const communities = JSON.parse(sessionStorage.getItem('subsribedCommunities'));
      if(communities.my_communities !== undefined && communities.my_communities.length !== 0){
        modelRef.componentInstance.community = communities.my_communities.find(x => x.community_id === challenge.community_id);
      }
    }
  }

  closeModal(value?: string): void {
    if (value === 'closeAll') {
      this.activeModal.close(value);
    } else {
      this.activeModal.close();
    }
  }

  gotoCommunity(): void {
    this.closeModal('closeAll');
    this.router.navigateByUrl('/auth/student/challenge');
  }
}
