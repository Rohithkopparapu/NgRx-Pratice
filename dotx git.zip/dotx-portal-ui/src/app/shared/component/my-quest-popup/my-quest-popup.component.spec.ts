import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MyQuestPopupComponent } from './my-quest-popup.component';

describe('MyQuestPopupComponent', () => {
  let component: MyQuestPopupComponent;
  let fixture: ComponentFixture<MyQuestPopupComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MyQuestPopupComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MyQuestPopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
