import {Component, Input, OnInit} from '@angular/core';
import {NgbActiveModal} from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-my-quest-popup',
  templateUrl: './my-quest-popup.component.html',
  styleUrls: ['./my-quest-popup.component.scss']
})
export class MyQuestPopupComponent implements OnInit {
  @Input() data;
  badges: any;
  dotcoins: any;

  constructor(private activeModal: NgbActiveModal) { }

  ngOnInit() {
    this.badges = this.data.badges;
    this.dotcoins = this.data.dotcoins;
  }

  closeModal() {
    this.activeModal.close();
  }

}
