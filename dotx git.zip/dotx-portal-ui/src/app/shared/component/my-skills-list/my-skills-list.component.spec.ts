import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MySkillsListComponent } from './my-skills-list.component';

describe('MySkillsListComponent', () => {
  let component: MySkillsListComponent;
  let fixture: ComponentFixture<MySkillsListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MySkillsListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MySkillsListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
