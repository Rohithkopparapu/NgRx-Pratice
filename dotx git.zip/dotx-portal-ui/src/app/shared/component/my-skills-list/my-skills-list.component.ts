import {Component, EventEmitter, Input, OnChanges, Output, SimpleChanges} from '@angular/core';
import {ImageVideoViewComponent} from '../image-video-view/image-video-view.component';
import {NgbModal} from '@ng-bootstrap/ng-bootstrap';

@Component({
  selector: 'app-my-skills-list',
  templateUrl: './my-skills-list.component.html',
  styleUrls: ['./my-skills-list.component.scss']
})
export class MySkillsListComponent implements OnChanges {

  @Input() data;
  @Output() addSkills = new EventEmitter();
  skillsList: any[];
  otherSkillsList: any[];
  partialAccess: any;
  skillCategory: string;

  constructor(private modalService: NgbModal) { }

  openViewerModel(type: string, url: string): void {
    const modalRef = this.modalService.open(ImageVideoViewComponent, {
      centered: true,
      size: 'lg'
    });
    modalRef.componentInstance.fileType = type;
    modalRef.componentInstance.fileUrl = url;
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes.data) {
      const data = changes.data.currentValue;
      this.partialAccess = data.partialAccess;
      this.skillCategory = data.skillCategory;
      this.skillsList = data.skillsListWithAttachments;
      this.otherSkillsList = data.skillsListWithOutAttachments;
    }
  }

  editStudentProfile(skillCategory) {
    this.addSkills.emit(skillCategory);
  }
}
