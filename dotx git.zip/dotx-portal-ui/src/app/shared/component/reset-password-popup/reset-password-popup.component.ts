import { Component, OnInit } from '@angular/core';
import {NgbActiveModal} from '@ng-bootstrap/ng-bootstrap';
import {CommonApiService} from '../../services/common-api.service';

@Component({
  selector: 'app-reset-password-popup',
  templateUrl: './reset-password-popup.component.html',
  styleUrls: ['./reset-password-popup.component.scss']
})
export class ResetPasswordPopupComponent implements OnInit {

  constructor(public activeModal: NgbActiveModal, private commonApiService: CommonApiService) {}

  ngOnInit(): void {
    this.commonApiService.isResetPassword.subscribe( res => {
      if (res) {
        this.commonApiService.isResetPassword.next(false);
        this.activeModal.close();
      }
    });
  }

  closeModal() {
    this.activeModal.close();
  }

}
