import {Component, OnInit} from '@angular/core';
import {NgbActiveModal} from '@ng-bootstrap/ng-bootstrap';
import { StudentHelperService } from 'src/app/modules/student-dashboard/student-helper.service';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-send-message-popup',
  templateUrl: './send-message-popup.component.html',
  styleUrls: ['./send-message-popup.component.scss']
})
export class SendMessagePopupComponent implements OnInit {

  data;
  userData: any;
  emailAddress: any;
  popupType: string;
  isLoading = false;

  constructor(private activeModal: NgbActiveModal,
              private studentHelperService: StudentHelperService,
              private toastr: ToastrService) {
  }

  ngOnInit() {
    this.userData = this.data.userDetails;
    this.popupType = this.data.popupType;
  }

  submit(message: any): void {
    if (message === '') {
      this.toastr.warning('Please type a message');
      return;
    }
    if (this.popupType === 'Feedback') {
      this.activeModal.close({ message, result: 'Rejected' });
    } else {
      this.sendMessage(message);
    }
  }

  sendMessage(message: any): void {
    this.isLoading = true;
    const payLoad = {
      to_email: this.userData.user_email,
      to_buddy_name: this.userData.display_name,
      msg: message
    };
    this.studentHelperService.sendEmail(payLoad).subscribe(() => {
      this.isLoading = false;
      this.toastr.success('Email sent successfully');
      this.activeModal.close();
    }, () => this.isLoading = false);
  }

  close() {
    this.activeModal.close();
  }
}
