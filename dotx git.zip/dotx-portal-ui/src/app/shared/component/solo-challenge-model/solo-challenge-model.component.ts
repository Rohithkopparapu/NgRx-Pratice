import { Component, ElementRef, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { NgbActiveModal, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import * as moment from 'moment';
import { StudentHelperService } from '../../../modules/student-dashboard/student-helper.service';
import { ViewResponsesComponent } from '../view-responses/view-responses.component';
import { ToastrService } from 'ngx-toastr';
import { ChallengeSuccessComponent } from '../../../modules/student-dashboard/challenge-hub/challenge-success/challenge-success.component';
import { FileUploadComponent } from '../file-upload/file-upload.component';
import { ImageVideoViewComponent } from '../image-video-view/image-video-view.component';
import { takeUntil } from 'rxjs/operators';
import { Store } from '@ngrx/store';
import { AuthState } from '../../store/auth.model';
import { userInfo } from '../../store/auth.selector';
import { Subject } from 'rxjs';
import { ModalUtilService } from '../../services/modal-util.service';
import Swiper, { Autoplay, Navigation, Pagination } from 'swiper';
import { FormBuilder, FormGroup } from '@angular/forms';
import { PostRefreshService } from '../../services/post-refresh.service';
import { ChallengeCompletedComponent } from '../level-completed/challenge-completed.component';
import { UserDetailsAction } from '../../store/auth.action';

@Component({
  selector: 'app-solo-challenge-model',
  templateUrl: './solo-challenge-model.component.html',
  styleUrls: ['./solo-challenge-model.component.scss']
})
export class SoloChallengeModelComponent implements OnInit, OnDestroy {

  private subscriptions = new Subject<void>();
  data: any;
  @ViewChild('scrollContainer', { static: false }) scrollContainer: ElementRef;
  @ViewChild('videoplayer', { static: false }) videoplayer;
  @ViewChild('finalSubmit', { static: false }) finalSubmitView: ElementRef;
  challenge: any;
  isLoading = false;
  slides: any[] = [];
  userType: string;
  userInfo: any;
  message = '';
  toggled = false;
  videoFiles = [];
  imageFiles = [];
  docFiles = [];
  viewFinalResponse: boolean;
  isEnable: boolean;
  consentBox = false;
  isHomeAccess: any;
  levelId: any;
  communityId: any;
  checkMandatory: any;
  showDottie: boolean = false;
  dottieForm: FormGroup;
  automatedres: Object;
  automatedResponseArray: any = [];
  buddyDetails: any;
  audioFiles=[];
  community: any;

  constructor(private activeModal: NgbActiveModal, private studentHelperService: StudentHelperService, private modalService: NgbModal,
    private toastrService: ToastrService, private store$: Store<AuthState>, private modalUtilService: ModalUtilService, private fb: FormBuilder, private refreshService: PostRefreshService) {
    this.store$.select(userInfo)
      .pipe(takeUntil(this.subscriptions))
      .subscribe(res => this.userInfo = res);
    this.buddyDetails = this.userInfo;
  }

  ngOnInit() {
    if (!this.isHomeAccess) {
      this.getChallengeDetails(this.data.challenge.topic_id);
    } else {
      this.getChallengeDetailsPublic(this.data.challenge.topic_id);
    }
    this.createForm();
    const communities = JSON.parse(sessionStorage.getItem('subsribedCommunities'));
    if(communities.my_communities.length !== 0){
      this.community = communities.my_communities.find(x => x.community_id ===  this.data.challenge.community_id)
    }

  }

  ngAfterViewInit() {
    // this.scrollToBottom();
  }

  // scrollToBottom() {
  //   const scrollContainerEl = this.scrollContainer.nativeElement;
  //   scrollContainerEl.scrollTop = scrollContainerEl.scrollHeight;
  // }

  createForm() {
    this.dottieForm = this.fb.group({
      user_input: [""]
    });
  }
  continueChallenge(): void {
    const payload = {
      community_id: this.communityId,
      user_id: this.userInfo.user_id,
      level_id: this.levelId ? this.data.challenge.level_id : '',
    };
    if (this.data.challenge.level_id === null) {
      this.viewFinalResponse = true;
      setTimeout(() => this.finalSubmitView.nativeElement.scrollIntoView({ behavior: 'smooth' }),
        1);
    } else {
      this.studentHelperService.getQuestInfo(payload).subscribe(res => {
        if (res) {
          if (this.userInfo.user_type === "student") {
            const noOfMandatoryActivitiesPending = res.data.activities.filter(x => x.is_mandatory === 1 && x.status === "pending");
            if(this.challenge.is_classroom_reflection === 0){
            if (this.checkMandatory != 1) {
              if (noOfMandatoryActivitiesPending.length === 0) {
                const params = { community_id: this.communityId, level_id: this.levelId };
                this.studentHelperService.getQuestTopics(params).subscribe(respose => {
                  if (respose) {
                    const pendingChallenges = respose.continue_challenges.concat(respose.recent_challenges);
                    const noOfMandatoryChallengesPending = pendingChallenges.filter(x => x.is_mandatory === 1)
                    if (noOfMandatoryChallengesPending.length === 0) {
                      this.viewFinalResponse = true;
                      setTimeout(() => this.finalSubmitView.nativeElement.scrollIntoView({ behavior: 'smooth' }),
                        1);
                    } else {
                      this.toastrService.warning("you need to complete the previous levels");
                    }
                  }
                });
              } else {
                this.toastrService.warning("you need to complete the previous levels");
              }
            } else {
              if (noOfMandatoryActivitiesPending.length === 0) {
                this.viewFinalResponse = true;
                setTimeout(() => this.finalSubmitView.nativeElement.scrollIntoView({ behavior: 'smooth' }),
                  1);
              } else {
                this.toastrService.warning("you need to complete the previous levels");
              }
            }
          }else{
            this.viewFinalResponse = true;
                setTimeout(() => this.finalSubmitView.nativeElement.scrollIntoView({ behavior: 'smooth' }),
                  1);
          }
          } else {
            this.viewFinalResponse = true;
            setTimeout(() => this.finalSubmitView.nativeElement.scrollIntoView({ behavior: 'smooth' }),
              1);
          }
        }

      });
    }
  }

  acceptChallenge(): void {

    const payload = {
      community_id: this.communityId,
      user_id: this.userInfo.user_id,
      level_id: this.levelId ? this.data.challenge.level_id : '',
    };
    if (this.data.challenge.level_id === null) {
      const payload = {
        topic_id: this.challenge.topic_id
      };
      this.studentHelperService.JoinSoloChallenge(payload).subscribe(res => {
        this.challenge.topic_assign_id = res.topic_assign_id;
        this.viewFinalResponse = true;
        setTimeout(() => this.finalSubmitView.nativeElement.scrollIntoView({ behavior: 'smooth' }),
          1);
      });
    } else {

      if (this.checkMandatory != 1) {
        // if (noOfMandatoryActivitiesPending.length === 0) {
        const params = { community_id: this.communityId, level_id: this.levelId };
        this.studentHelperService.getQuestTopics(params).subscribe(respose => {
          if (respose) {
            const pendingChallenges = respose.continue_challenges.concat(respose.recent_challenges);
            const noOfMandatoryChallengesPending = pendingChallenges.filter(x => x.is_mandatory === 1)
            if (this.userInfo.user_type === 'student') {
              if(this.challenge.is_classroom_reflection === 0){
              if (noOfMandatoryChallengesPending.length === 0) {
                const payload = {
                  topic_id: this.challenge.topic_id
                };
                this.studentHelperService.JoinSoloChallenge(payload).subscribe(res => {
                  this.challenge.topic_assign_id = res.topic_assign_id;
                  this.viewFinalResponse = true;
                  setTimeout(() => this.finalSubmitView.nativeElement.scrollIntoView({ behavior: 'smooth' }),
                    1);
                });
              } else {
                this.toastrService.warning("Complete the mandatory Challenges to proceed further");
              }
            }else{
               const payload1 = {
                  topic_id: this.challenge.topic_id
                };
                this.studentHelperService.JoinSoloChallenge(payload1).subscribe(res => {
                  this.challenge.topic_assign_id = res.topic_assign_id;
                  this.viewFinalResponse = true;
                  setTimeout(() => this.finalSubmitView.nativeElement.scrollIntoView({ behavior: 'smooth' }),
                    1);
                });
            }
            } else {
              const payload = {
                topic_id: this.challenge.topic_id
              };
              this.studentHelperService.JoinSoloChallenge(payload).subscribe(res => {
                this.challenge.topic_assign_id = res.topic_assign_id;
                this.viewFinalResponse = true;
                setTimeout(() => this.finalSubmitView.nativeElement.scrollIntoView({ behavior: 'smooth' }),
                  1);
              });
            }
          }
        });

      } else {
        if (this.userInfo.user_type === "student") {
          this.studentHelperService.getQuestInfo(payload).subscribe(res => {

            const noOfMandatoryActivitiesPending = res.data.activities.filter(x => x.is_mandatory === 1 && x.status === "pending")
            if (noOfMandatoryActivitiesPending.length === 0) {
              const payload = {
                topic_id: this.challenge.topic_id
              };
              this.studentHelperService.JoinSoloChallenge(payload).subscribe(res => {
                this.challenge.topic_assign_id = res.topic_assign_id;
                this.viewFinalResponse = true;
                setTimeout(() => this.finalSubmitView.nativeElement.scrollIntoView({ behavior: 'smooth' }),
                  1);
              });
            } else {
              this.toastrService.warning("Complete the mandatory activities to proceed to Challenges");
            }
          });
        } else {
          const payload = {
            topic_id: this.challenge.topic_id
          };
          this.studentHelperService.JoinSoloChallenge(payload).subscribe(res => {
            this.challenge.topic_assign_id = res.topic_assign_id;
            this.viewFinalResponse = true;
            setTimeout(() => this.finalSubmitView.nativeElement.scrollIntoView({ behavior: 'smooth' }),
              1);
          });
        }
      }
    }

  }

  showFlag(){
    if(this.community.is_competition === 1 && this.userInfo.user_type === 'teacher'){
      return false;
    }else if(this.community.is_competition === 1 && this.userInfo.user_type === 'student'){
      return true;
    }else if(this.community.is_competition !== 1 && this.userInfo.user_type === 'student'){
      return true;
    }else if(this.community.is_competition !== 1 && this.userInfo.user_type === 'teacher'){
      return true;
    }
  }

  viewOtherResponse(): void {
    if (!this.isHomeAccess) {
      if (this.challenge.total_responses !== '0') {
        const modelRef = this.modalService.open(ViewResponsesComponent, {
          centered: true,
          scrollable: true,
          backdrop: 'static',
          size: 'xl',
          windowClass: 'modal-challenge'
        });
        modelRef.componentInstance.challenge = this.challenge;
        modelRef.componentInstance.userType = this.userInfo.user_type;
        modelRef.componentInstance.community = this.community
      } else {
        this.toastrService.warning('No Responses Found...');
      }
    } else {
      this.gotoSignup();
    }
  }

  getChallengeDetailsPublic(topicId): void {
    this.isLoading = true;
    this.studentHelperService.getTopicDetailsByIdPublic(topicId).subscribe(res => {
      this.isLoading = false;
      if (res) {
        this.levelId = res.level_id;
        this.processResponse(res);
      }
    }, () => this.isLoading = false);
  }

  getChallengeDetails(topicId): void {
    this.isLoading = true;
    this.studentHelperService.getTopicDetailsById(topicId).subscribe(res => {
      this.isLoading = false;
      if (res) {
        this.levelId = res.level_id;
        this.communityId = res.community_id;
        this.checkMandatory = res.is_mandatory;
        this.processResponse(res);
      }
    }, () => this.isLoading = false);
  }

  processResponse(res: any): void {
    this.challenge = res;
    this.challenge.topic_end_date = moment(this.challenge.topic_end_date).format('ll');
    this.isEnable = moment(moment().format('ll')).isBetween(moment(this.challenge.topic_start_date).format('ll'), this.challenge.topic_end_date, undefined, '[]');
    this.challenge.topic_description = this.challenge.topic_description.replace(/&nbsp;/g, '');
    if (this.challenge && this.challenge.attachments && this.challenge.attachments.length) {
      this.challenge.attachments = this.challenge.attachments.filter(attach => (attach.attachment_title === 'challenge_image' || attach.attachment_title === 'challenge_video'));
    }
    this.initSwiperSlider();
  }

  initSwiperSlider() {
    setTimeout(() => {
      if (this.challenge.attachments.length > 1) {
        const swiper = new Swiper('.swiper.swiper-solo-challenge', {
          modules: [Navigation, Pagination, Autoplay],
          // Optional parameters
          loop: true,
          freeMode: true,

          // If we need pagination
          pagination: {
            clickable: true,
            el: '.swiper-pagination',
            type: 'bullets'
          },

          // autoplay: {
          //   delay: 2500,
          //   disableOnInteraction: false,
          //   pauseOnMouseEnter: true
          // },

          keyboard: {
            enabled: true,
            onlyInViewport: false,
          },

          // Navigation arrows
          navigation: {
            nextEl: '.swiper-button-next',
            prevEl: '.swiper-button-prev',
          },
        });
      } else {
        const swiper = new Swiper('.swiper.swiper-solo-challenge', {
          // Optional parameters
          enabled: false,
          navigation: {
            nextEl: null,
            prevEl: null,
          },
        });
      }
    });
  }

  closeModal() {
    this.activeModal.close({ status: "close" });
    this.refreshService.triggerRefresh();
  }

  afterChange(): void {
    if (this.videoplayer && this.videoplayer.nativeElement) {
      this.videoplayer.nativeElement.pause();
    }
  }

  openViewerModel(type: string, url: string): void {
    const modalRef = this.modalService.open(ImageVideoViewComponent, {
      centered: true,
      size: 'lg'
    });
    modalRef.componentInstance.fileType = type;
    modalRef.componentInstance.fileUrl = url;
  }

  onUploadComment(evt, catagory, type) {
    const modalData = {
      headerName: 'Media',
      fileType: type,
      fileCategory: catagory,
      isMultipleFile: true
    };

    const modalRef = this.modalService.open(FileUploadComponent, {
      keyboard: false,
      backdrop: 'static',
      scrollable: true,
      windowClass: 'modal-cover modal-cover-fluid modal-upload'
    });
    modalRef.componentInstance.data = modalData;
    modalRef.result.then((res) => {
      console.log(res);
    }, (reason) => {
      if (reason && reason.length) {
        reason.forEach(file => {
          const fileExtension = file.file.split('.').pop();
          if (fileExtension.match(/(jpg|jpeg|png|gif)$/i)) {
            this.imageFiles.push({ ...file, type: 'image' });
          } else if (fileExtension.match(/(mp4|mov|wmv|avi|avchd|mp4|mpeg|webm)$/i)) {
            this.videoFiles.push({ ...file, type: 'video' });
          } else if(fileExtension.match(/(mp3|wav|aiff|flac|m4a|ogg|aac|wma|ape)$/i)){
            this.audioFiles.push({ ...file, type: 'audio' });
          }else {
            this.docFiles.push({ ...file, type: 'doc' });
          }
        });
      }
    });
  }

  deleteFiles(event: Event, file, type) {
    event.stopPropagation();
    if (type === 'video') {
      this.videoFiles = this.videoFiles.filter(item => item.file !== file.file);
    } else if (type === 'image') {
      this.imageFiles = this.imageFiles.filter(item => item.file !== file.file);
    } else if (type === 'doc') {
      this.docFiles = this.docFiles.filter(item => item.file !== file.file);
    }else if(type === 'audio'){
      this.audioFiles = this.audioFiles.filter(item => item.file !== file.file);
    }
  }

  openDocument(event: any, fileUrl: string) {
    // event.stopPropagation();
    window.open(
      fileUrl,
      '_blank'
    );
  }

  submitFinalComment() {
    const TodayDate = moment().format('YYYY-MM-DD hh:mm:ss');
    const attachment = [...this.videoFiles, ...this.imageFiles, ...this.docFiles, ...this.audioFiles];
    if (!this.message || attachment.length === 0) {
      this.toastrService.warning('Please upload a file or write a description.');
      return false;
    } else {
      this.isLoading = true;
      const payload = {
        response_description: this.message.trim(),
        date_of_response: TodayDate,
        topic_assign: this.challenge.topic_assign_id,
        is_final_submit: 1,
        attachments: attachment
      };
      this.studentHelperService.addComments(payload).subscribe(res => {
        this.message = '';
        this.isLoading = false;
        if (res) {
          this.store$.dispatch(new UserDetailsAction({userId: this.userInfo.user_id, _page: 'community'}));
          this.studentHelperService.getBadgesAndDotCoins(this.userInfo.user_id);
          this.toastrService.success('Challenge successfully submitted');
          this.videoFiles = this.imageFiles = this.docFiles = [];
          this.activeModal.close({ status: "success" });
          this.refreshService.triggerRefresh();
          if (this.challenge.is_competition === 1) {
            const modelRef = this.modalService.open(ChallengeCompletedComponent, {
              centered: true,
              backdrop: 'static',
              size: 'md',
              windowClass: 'modal-challenge achievement-type',
            });
            modelRef.result.then(res => {
              if (res.status == "success") {
                this.getChallengeDetails(this.data.challenge.topic_id);
                setTimeout(() => {
                  this.viewOtherResponse();
                }, 1000);
              }
            });
          }
          // this.modalService.open(ChallengeSuccessComponent, {centered: true, size: 'lg', keyboard: false, backdrop: 'static', windowClass: 'bd-example-modal-lg modalCcongratulations-outer'});
        }
      }, err => this.isLoading = false);
    }
  }

  handleSelection(event: any) {
    this.message += event.char;
  }

  checkChallengeEndDate(challenge:any){
    challenge.topic_end_date = moment(this.challenge.topic_end_date).format('ll');
    const isEnable = moment(moment().format('ll')).isBetween(moment(this.challenge.topic_start_date).format('ll'), this.challenge.topic_end_date, undefined, '[]');
    return isEnable;
  }

  ngOnDestroy(): void {
    this.subscriptions.next();
    this.subscriptions.complete();
  }

  agreeConsentBox(event: any): void {
    this.consentBox = event.target.checked;
  }

  openProfile(user: any): void {
    if (!this.isHomeAccess) {
      this.modalUtilService.openBuddyProfile(user);
    }
  }

  gotoSignup(): void {
    this.toastrService.warning('Please Sign Up to explore more');
  }
  openDottie() {
    this.showDottie = !this.showDottie;
  }

  submitInput() {
    const currentres = this.dottieForm.controls['user_input'].value.trim();
    const payload = {};
    this.dottieForm.controls['user_input'].setValue("");
    payload['user_input'] = currentres;
    payload['topic_id'] = this.challenge.topic_id;
    if (currentres !== "") {
      const obj = { "userinput": currentres }
      this.automatedResponseArray.splice(this.automatedResponseArray.length, 0, obj);
      this.studentHelperService.getOpenAiResponse(payload).subscribe(res => {
        if (res) {
          this.automatedres = res;

          this.automatedResponseArray[this.automatedResponseArray.length - 1]["openAiRes"] = res;
        }
      })
    } else {
      this.toastrService.error("Please provide the required input")
    }
  }

  closeDottie() {
    this.showDottie = false;
  }
}
