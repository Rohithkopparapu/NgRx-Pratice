import {Component, Input, OnInit} from '@angular/core';
import {ImageVideoViewComponent} from '../image-video-view/image-video-view.component';
import {MyChallengesPopupComponent} from '../my-challenges-popup/my-challenges-popup.component';
import {MyQuestPopupComponent} from '../my-quest-popup/my-quest-popup.component';
import {NgbActiveModal, NgbModal} from '@ng-bootstrap/ng-bootstrap';
import {StudentHelperService} from '../../../modules/student-dashboard/student-helper.service';
import {BadgesDotcoinsPopupComponent} from '../badges-dotcoins-popup/badges-dotcoins-popup.component';
import {HelperService} from '../../services/helper.service';
import {CertificationsPopupComponent} from '../certifications-popup/certifications-popup.component';

@Component({
  selector: 'app-view-other-profile',
  templateUrl: './view-other-profile.component.html',
  styleUrls: ['./view-other-profile.component.scss']
})
export class ViewOtherProfileComponent implements OnInit {
  @Input() data;
  isLoading = false;
  badgesList: any;
  badges = 0;
  dotCoins = 0;
  totalCertificates = 0;
  totalChallengesCount = 0;
  userId: any;
  userDetails: any;
  age: number;
  achievementsList: any;
  selectedTab = 'Talents';
  isMySkillsLoaded: boolean;
  myTalentsList: any[] = [];
  myFavouritesList: any[] = [];
  mySkills: any;

  constructor(public activeModal: NgbActiveModal, private modalService: NgbModal, private studentHelperService: StudentHelperService,
              private helperService: HelperService) { }

  ngOnInit() {
    if (this.data.userId) {
      this.userId = this.data.userId;
      this.getUserDetails();
      this.getUserSkillsInfo();
      this.getAchievements();
      this.getBadges();
    }
  }

  closeModal() {
    this.activeModal.close();
  }

  getUserDetails() {
    this.isLoading = true;
    this.studentHelperService.getUserInfo(this.userId).subscribe((res) => {
      this.isLoading = false;
      if (res) {
        this.userDetails = res;
        this.age = this.helperService.getAge(this.userDetails.user_dob);
      }
    }, () => this.isLoading = false);
  }

  getAchievements() {
    this.studentHelperService.getAchievements(this.userId).subscribe(result => {
      if (result && result.length) {
        this.achievementsList = result[0];
        this.badges = result[0].winning_badges_count;
        this.dotCoins = result[0].total_dot_coins;
        this.totalChallengesCount = result[0].total_challenges_count;
        this.totalCertificates = result[0].total_certificates;
      }
    });
  }

  getBadges(): void {
    this.studentHelperService.getBadges(this.userId).subscribe(res => {
      this.badgesList = res;
    });
  }

  getUserSkillsInfo() {
    this.isMySkillsLoaded = true;
    this.studentHelperService.getUserSkillsByUserId(this.userId).subscribe((resp) => {
      this.isMySkillsLoaded = false;
      if (resp && resp.length) {
        this.myTalentsList = resp.filter(res => res.skill_category === 'Talents' && res.is_selected);
        this.myFavouritesList = resp.filter(res => res.skill_category === 'Favourites' && res.is_selected);
        this.myTalentsList.forEach(element => {
          if (element.attachments && element.attachments.length) {
            element['attachmentsList'] = this.processAttachments(element);
          }
        });
        this.myFavouritesList.forEach(element => {
          if (element.attachments && element.attachments.length) {
            element['attachmentsList'] = this.processAttachments(element);
          }
        });
        this.openTalentsOrFavouriteTab(this.selectedTab);
      }
    }, () => this.isMySkillsLoaded = false);
  }

  openTalentsOrFavouriteTab(value): void {
    if (value !== 'Talents\n\nFavourites') {
      let data = {
        partialAccess: false,
        skillsListWithAttachments: [],
        skillsListWithOutAttachments: [],
        skillCategory: ''
      };
      if (value === 'Talents') {
        this.selectedTab = value;
        data.skillCategory = 'talents';
        data.skillsListWithAttachments = this.myTalentsList.filter(talent => talent.attachmentsList);
        data.skillsListWithOutAttachments = this.myTalentsList.filter(talent => !talent.attachmentsList);
        this.mySkills = data;
      } else if (value === 'Favourites') {
        this.selectedTab = value;
        data.skillCategory = 'favourites';
        data.skillsListWithAttachments = this.myFavouritesList.filter(favourite => favourite.attachmentsList);
        data.skillsListWithOutAttachments = this.myFavouritesList.filter(favourite => !favourite.attachmentsList);
        this.mySkills = data;
      }
    }
  }

  openMyChallengesPopup(value) {
    if (this.totalChallengesCount) {
      const myChallengeDetails = {
        badges: this.badges,
        dotcoins: this.dotCoins,
        accessViewType: 'buddie',
        buddyDetails: this.userDetails,
      };
      const modalRef = this.modalService.open(value === 'challenge' ? MyChallengesPopupComponent : MyQuestPopupComponent, {
        centered: true,
        scrollable: true,
        backdrop: 'static',
        keyboard: false,
        size: 'xl',
        windowClass: 'modal-challenge'
      });
      modalRef.componentInstance.data = myChallengeDetails;
    }
  }

  openViewerModel(type: string, url: string): void {
    const modalRef = this.modalService.open(ImageVideoViewComponent, {
      centered: true,
      size: 'lg'
    });
    modalRef.componentInstance.fileType = type;
    modalRef.componentInstance.fileUrl = url;
  }

  openBadgesOrDotCoinsPopup(value: string): void {
    const data = {
      viewPopup: value,
      accessViewType: 'buddie',
      buddyDetails: this.userDetails,
      achievementsList: this.achievementsList,
      badgesList: this.badgesList
    };
    const modalRef = this.modalService.open(BadgesDotcoinsPopupComponent, {
      // centered: true,
      size: 'xl',
      windowClass: 'modal-cover modal-cover-graphical',
      scrollable: true
    });
    modalRef.componentInstance.data = data;
  }

  processAttachments(skillsList) {
    const attachmentsList = [];
    skillsList.attachments.forEach(ele => {
      let file = {};
      let fileExtension = ele.file.split('.').pop();
      if (fileExtension.match(/(jpg|jpeg|png|gif)$/i)) {
        fileExtension = 'image';
      } else {
        fileExtension = 'video';
        file['streamUrl'] = ele.stream_url;
      }
      file = { ...file, fileName: ele.display_name, filePath: ele.url, fileType: fileExtension };
      attachmentsList.push(file);
    });
    return attachmentsList;
  }

  openCertificationsPopup(): void {
    if (this.totalCertificates > 0) {
      const data = {
        accessViewType: 'buddie',
        buddyDetails: this.userDetails,
        achievementsList: this.achievementsList
      };
      const modalRef = this.modalService.open(CertificationsPopupComponent, {
        // centered: true,
        size: 'xl',
        windowClass: 'modal-cover modal-cover-graphical',
        scrollable: true
      });
      modalRef.componentInstance.data = data;
    }
  }
}
