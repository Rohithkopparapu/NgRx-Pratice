import {Component, ElementRef, OnDestroy, OnInit, ViewChild} from '@angular/core';
import {NgbActiveModal, NgbModal, NgbModule} from '@ng-bootstrap/ng-bootstrap';
import {ToastrService} from 'ngx-toastr';
import {StudentHelperService} from '../../../modules/student-dashboard/student-helper.service';
import {SoloChallengeModelComponent} from '../solo-challenge-model/solo-challenge-model.component';
import {GroupChallengeModelComponent} from '../group-challenge-model/group-challenge-model.component';
import {DeleteComponent} from '../delete/delete.component';
import {SUCCESS_MESSAGE} from '../../constants/constant';
import {MySpaceComponent} from '../../../modules/student-dashboard/header-section/my-space/my-space.component';
import {ViewOtherProfileComponent} from '../view-other-profile/view-other-profile.component';
import {debounceTime, distinctUntilChanged, takeUntil} from 'rxjs/operators';
import {Subject} from 'rxjs';
import {Store} from '@ngrx/store';
import {AuthState} from '../../store/auth.model';
import {onlineSocketUsers, userInfo} from '../../store/auth.selector';
import {FormControl, FormGroup, Validators} from '@angular/forms';
import {HelperService} from '../../services/helper.service';
import Swiper, {Autoplay, Navigation, Pagination} from 'swiper';
import { Router} from '@angular/router';
import { escape } from 'querystring';
import { PostRefreshService } from '../../services/post-refresh.service';
import * as moment from 'moment';
@Component({
  selector: 'app-view-responses',
  templateUrl: './view-responses.component.html',
  styleUrls: ['./view-responses.component.scss']
})
export class ViewResponsesComponent implements OnInit, OnDestroy {
  private subscriptions = new Subject<void>();
  @ViewChild('videoPlayer', {static: false}) videoPlayer: ElementRef;
  @ViewChild('myInput',{static: false}) inputElement: ElementRef;
  challenge: any;
  userType: string;
  community: any;

  isLoading = false;
  challengeResponsesList: any[] = [];
  currentChallenge: any;
  commentsList: any[]=[];
  comment = '';
  image_file:any;
  userInfo: any;
  responseType = 'Most Recent';
  responseAge = 'Junior';
  items:any[];
  teacherComment:any ="";
  isdisplay:boolean = false;
  searchResponsesForm = new FormGroup({
    buddyName: new FormControl('', [Validators.required])
  }); 
  // commentForm = new FormGroup({
  //   comment : new FormControl('')
  // })
  fromPage: string;
  _page: string;
  placeholder: string;
  isResponseSelect: boolean;
  isHoverVotesDef = false;
  toggled = false;
  onlineUsersList: any;
  swiperSlider: Swiper;
  imageUrl: string;
  isCard:any;
  selcards: any =[];
  selectedItemsArray: any=[];
  checked: boolean= false;
  // required: boolean = false;
  selectedBadge :any;
  user_Type: any;
  arr: any = [];
  badges: Object;
  flagReal: boolean = false;
  flagRad: boolean = false;
  flagOG: boolean = false;
  badge: any = [];
  filteredArrayforBadge: any =[];
  showEarnedBadgeTab:boolean = false;
  showChooseBadgeTab:boolean = false;
  activateShowEarnedBadgeTab = false;
  activatedShowChooseBadgeTab = false;
  judgeVoteFlag: boolean = false;
  showBadgeContainer:boolean = false;
  isBlockScroll: boolean;
  page = 1;
  isLastPage: boolean;
  toggleSchoolList: boolean = false;
  reviewStatus='Pending';
  // reviewStatusOption:any;
  showFlag: boolean = false;
  pendingStatus: any;
  disqualifiedStatus:any;
  promotedStatus:any;
  currentChallengeCount: any;
  submittedCount:any;
  approvedCount:any;
  rejectedCount:any;
  changePendingFlag: boolean = true;
  changePromotedFlag: boolean = false;
  changeRejectedFlag: boolean = false;
  isEnable: boolean;


  constructor(private router:Router, private activeModel: NgbActiveModal, private studentHelperService: StudentHelperService, private toastrService: ToastrService,
              private modalService: NgbModal, private store$: Store<AuthState>, private helperService: HelperService,private refreshService: PostRefreshService) {
    this.store$.select(userInfo)
      .pipe(takeUntil(this.subscriptions))
      .subscribe(res => this.userInfo = res);
    this.store$.select(onlineSocketUsers)
      .pipe(takeUntil(this.subscriptions))
      .subscribe(res => this.onlineUsersList = res);
      this.user_Type = this.userInfo.user_type; 
  }

  ngOnInit() {
    // console.log("this.challenge",this.challenge);
    
    if (this.challenge) {
      this.filterViewResponses();
    }

    this.searchResponsesForm.get('buddyName').valueChanges.pipe(
      debounceTime(500),
      distinctUntilChanged()).subscribe(search => {
        this.filterViewResponses();
    });
   
    this.getBadges();
    if(this.community.is_competition === 1 && (this.responseType === "R" || this.responseType === "S")){
      this.responseType = 'A'
    }else if(this.community.is_competition === 1 && (this.responseType === "S" || this.responseType === "A")){
      this.responseType = 'S'
    }
  }

  checkUser(){
    if(this.userInfo.user_type === 'teacher'){
      return 'is-teacher'
    }else{
      return '';
    }
  }

  getBadges(){
    this.studentHelperService.getBadgeList().subscribe(res =>{
      this.badges = res;
    })
  }

  // check to activate the vote in the list

  checkForReal(data){
    if(data.attachments !== undefined && data.attachments.length !== 0){
      if(data.attachments[0].rating_reaction.length !== 0){
        if(data.attachments[0].rating_reaction.includes('For Real')){
          return "For Real";
        }
      }
    }
  }

  checkRad(data){
    if(data.attachments !== undefined &&  data.attachments.length !== 0){
      if(data.attachments[0].rating_reaction.length !== 0){
        if(data.attachments[0].rating_reaction.includes('Rad')){
          return "Rad";
        }
      }
    }
  }

  checkOriginal(data){
    if(data.attachments !== undefined &&  data.attachments.length !== 0){
      if(data.attachments[0].rating_reaction.length !== 0){
        if(data.attachments[0].rating_reaction.includes('OG')){
          return "OG";
        }
      }
    }
  }

  checkBadgeComment(com: any) {
    if (com.attachments !== null) {
      const abc = com.attachments.some(att => att.is_teacher === 1);
      if (abc === true) {
        
        return true;
      } else {
    
        return false;
      }
    } else {
      return false;
    }
  }

  getClass(data:any){
    if(data === 'S'){
      return 'badge-primary'
    }else if(data === 'R'){
      return 'badge-danger'
    }else{
      return 'badge-success'
    }
  }
  

  checkBadgeType(comment:any){
    if(comment.attachments[0].item_name === "Grandmaster" ){
      return 'grand-master-pastel'
    }else if(comment.attachments[0].item_name === "Platinum"){
      return 'platinum-pastel'
    }else if(comment.attachments[0].item_name === "Silver"){
      return 'silver-pastel'
    }else if(comment.attachments[0].item_name === "Bronze"){
      return 'bronze-pastel'
    }else if(comment.attachments[0].item_name === "Gold"){
      return 'gold-pastel'
    }
  }
  
  getVoteSubtitle(vote:any){
    if(vote === "For Real"){
      return "Keep it Truthful"
    }else if(vote === "Rad"){
      return "Keep it Rad"
    }else{
      return "Keep it Original"
    }
    
  }
  submitBadgeResponse(){
    
    let arr =[];
    const payload =
    {    
    "topic_response_id":Number(this.currentChallenge.topic_response_id),
    "user_id":Number(this.currentChallenge.buddy_id),
    "rating_reaction": [],
    "comment_notes":this.teacherComment,    
    "id":this.badge.id,
    "is_teacher":1,
    "topic_id":Number(this.currentChallenge.topic_id)
    }

    if(this.flagReal){
      arr.push("For Real")
    }
    
    if(this.flagRad){
      arr.push("Rad")
    }
    if(this.flagOG){
      arr.push("OG")
    }
    payload['rating_reaction'] = arr;
    if(payload['id'] !== undefined && arr.length !== 0 && this.teacherComment !== ""){
     this.studentHelperService.awardBadge(payload).subscribe(res =>{
      console.log(res,"award");
      this.selectedBadge = -1;
      this.flagReal = false;
      this.flagRad = false;
      this.flagOG = false;
      this.teacherComment = "";
      this.commentsList.unshift(res);
      this.judgeVoteFlag = false;
      this.getChallengeComments();
      // this.viewSelectedCard(0);
      this.filterViewResponses();
      this.toastrService.success("Badge submitted successfully");
     })
    }else{
      if(payload['id'] === undefined ){
        this.toastrService.warning("please select badge");
      }else if(arr.length === 0 ){
        this.toastrService.warning("please vote");
      }else if(this.teacherComment === "" ){
        this.toastrService.warning("please write the comment");
      }
  }
  }
  
  filterViewResponses(): void {
    const payload = {
      topic_id: this.challenge.topic_id,
      topic_response_id: this.challenge.topic_response_id,
      page: this.page,
      per_page: 10
    };
    this.responseAge = this.challenge.age_category !== undefined ? this.challenge.age_category : this.responseAge;
    var date = new Date(this.challenge.topic_start_date);
    var year = date.getUTCFullYear();
    var month = ('0' + (date.getUTCMonth() + 1)).slice(-2);
    var day = ('0' + date.getUTCDate()).slice(-2);
    var hours = ('0' + date.getUTCHours()).slice(-2);
    var minutes = ('0' + date.getUTCMinutes()).slice(-2);
    var seconds = ('0' + date.getUTCSeconds()).slice(-2);
    var formattedDate = year + '-' + month + '-' + day + ' ' + hours + ':' + minutes + ':' + seconds;
    payload["topic_start_date"] =  formattedDate;

    if (this.responseType === 'My Response') {
      payload['my_response'] = 1;
    }
    if (this.responseType === 'Top Rated') {
      payload['top_rated'] = 1;
    }
    if (this.responseType === 'Buddies' && this.searchResponsesForm.value.buddyName.trim()) {
      payload['buddy_name'] = this.searchResponsesForm.value.buddyName.trim();
    }
    if(this.userInfo.user_type !== 'student'){
      payload['age_category'] = this.responseAge;
    }
    if(this.userInfo.user_type !== 'student'){
    if (this.responseType === 'S') {
      payload['review_status'] = "S";
    }
    if (this.responseType === 'R') {
      payload['review_status'] = "R";
    }
    if (this.responseType === 'A') {
      payload['review_status'] = "A";
    }
    if(this.community.is_competition === 1 && this.responseType === 'Most Recent'){
      if(this.challenge !== undefined && this.challenge.review_status !== undefined && this.challenge.review_status === "A"){
        payload['review_status'] = this.challenge.review_status !== undefined ? this.challenge.review_status : "A";
        this.changePromotedFlag = true;
        this.changePendingFlag = false;
        this.changeRejectedFlag = false;
      }else if(this.challenge !== undefined && this.challenge.review_status !== undefined && this.challenge.review_status === "S"){
        payload['review_status'] = this.challenge.review_status !== undefined ? this.challenge.review_status : "S";
        this.changePendingFlag = true;
        this.changePromotedFlag = false;
        this.changeRejectedFlag = false;
      }else if(this.challenge !== undefined && this.challenge.review_status !== undefined && this.challenge.review_status === "R"){
        payload['review_status'] = this.challenge.review_status !== undefined ? this.challenge.review_status : "R";
        this.changePendingFlag = false;
        this.changePromotedFlag = false;
        this.changeRejectedFlag = true;
      }else{
        payload['review_status'] = "S"
      }
      
    }
  }
    if(this.community.is_competition === 1){
      this.placeholder = 'Search buddy';
      this.getCompetitionChallengeResponses(payload);
    }else{
      if (this.challenge.topic_group_size === 1) {
        this.placeholder = 'Search buddy';
        this.getSoloChallengeResponses(payload);
      } else {
        this.placeholder = 'Search Group/buddy';
        this.getGroupChallengeResponses(payload);
      }
    }
    
  }
// old
  // close(fromPage?: string): void {
  //   this.activeModel.close(fromPage);
  // }
  // new
  close(): void {
    this.activeModel.close({status: 'success'});
    this.refreshService.triggerRefresh();
  }


  getCompetitionChallengeResponses(payload): void {
    this.isLoading = true;
    this.studentHelperService.getCompetitionChallengeResponses(payload).subscribe(res => {
      this.isLoading = false;
        if(this.responseAge === "Junior"){
          this.submittedCount = res.junior_submitted_count;
          this.approvedCount = res.junior_approved_count;
          this.rejectedCount = res.junior_rejected_count;
        }else{
          this.submittedCount = res.senior_submitted_count;
          this.approvedCount = res.senior_approved_count;
          this.rejectedCount = res.senior_rejected_count;
        }
      if (res.responses && res.responses.length) {
        this.isBlockScroll = false;
        // this.challengeResponsesList = [];
        this.currentChallenge = {};
        this.currentChallengeCount = res;
        const data = res.responses;
        if(this.showFlag === false){
          const datainfo = this.challengeResponsesList.concat(data);
          const uniqueArray = Array.from(new Set(datainfo.map(obj => obj.topic_response_id))).map(topic_response_id => {
            return datainfo.find(obj => obj.topic_response_id === topic_response_id);
          });
          this.challengeResponsesList = uniqueArray;
        }else{
          this.challengeResponsesList = [];
          this.challengeResponsesList = data;
        }
        
        this.processViewResponses(this.challengeResponsesList);
      } else {
        // this.toastrService.warning('No Responses Found...');
        if(payload.page === 1){
          this.challengeResponsesList = [];
          // this.activeModel.close();
          // this.toastrService.warning("No responses found");
          if(this.responseAge === "Junior"){
            this.responseAge = "Junior";
            if(res.junior_count !== 0 &&  res.junior_submitted_count === 0 && res.junior_approved_count !== 0){
              this.responseType = "A";
              this.changePromotedFlag = true;
              this.changePendingFlag = false;
              this.changeRejectedFlag = false;
              this.filterViewResponses();
            }else if(res.junior_count !== 0 &&  res.junior_submitted_count === 0 && res.junior_rejected_count !== 0){
              this.responseType = "R";
              this.changeRejectedFlag = true;
              this.changePendingFlag = false;
              this.changePromotedFlag = false;
              this.filterViewResponses();
            }
          }else{
            this.responseAge = "Senior";
            if(res.senior_count !== 0 && res.senior_rejected_count === 0 && res.senior_approved_count !== 0){
              this.responseType = "A"
              this.changePromotedFlag = true;
              this.changePendingFlag = false;
              this.changeRejectedFlag = false;
              this.filterViewResponses();
            }else if(res.senior_count !== 0 && res.senior_approved_count === 0 && res.senior_rejected_count !== 0){
              this.responseType = "R";
              this.changePromotedFlag = false;
              this.changePendingFlag = false;
              this.changeRejectedFlag = true;
              this.filterViewResponses();
            }
          }
          if(res.junior_count === 0 && res.senior_count === 0){
            this.activeModel.close();
            this.toastrService.warning("No responses found");
          }
        }else if (this.challengeResponsesList && this.challengeResponsesList.length === 0) {
          // this.activeModel.close();
        }
      }
    },(err) =>{
      this.isLoading = false;
      // this.activeModel.close();
    } );
    this.isLoading = false;
  }



  getSoloChallengeResponses(payload): void {
    this.isLoading = true;
    this.studentHelperService.getSoloChallengeResponses(payload).subscribe(res => {
      this.isLoading = false;
      if (res.responses && res.responses.length) {
        this.isBlockScroll = false;
        // this.challengeResponsesList = [];
        this.currentChallenge = {};
        const data = res.responses;
        if(this.showFlag === false){
          this.challengeResponsesList = this.challengeResponsesList.concat(data);
        }else{
          this.challengeResponsesList = [];
          this.challengeResponsesList = data;
        }
        
        this.processViewResponses(this.challengeResponsesList);
      } else {
        // this.toastrService.warning('No Responses Found...');
        if(payload.page === 1){
          this,this.challengeResponsesList = [];
          this.activeModel.close();
          this.toastrService.warning("No responses found")
        }else if (this.challengeResponsesList && this.challengeResponsesList.length === 0) {
          this.activeModel.close();
        }
      }
    }, () => this.isLoading = false);
  }

  checkUserType(){
    if(this.user_Type ==='teacher'){
      return 'none'
    }else{
      return ""
    }
  }

  // enableTextInputFocus(event:any){
  //   if (this.inputField && event.target.checked === true) {
  //     this.inputField.nativeElement.focus();
  //   }
  // }

  handleSelectChange(event: any) {
    this.reviewStatus = event;
    if(event === 'S'){
      this.pendingStatus = 'active';
      this.promotedStatus = '';
      this.disqualifiedStatus = ''
    }else if(event === 'R'){
      this.disqualifiedStatus = 'active';
      this.promotedStatus = '';
      this.pendingStatus = ''
    }else{
      this.promotedStatus = 'active';
      this.disqualifiedStatus = '';
      this.pendingStatus = ''
    }
    // const data = this.reviewStatusOption;
    if (this.reviewStatus) {
      this.inputElement.nativeElement.focus();
    } 
  }


  showDiv() {
    this.toggleSchoolList = true;
  }

  hideDiv() {
    this.toggleSchoolList = false;
  }

  getGroupChallengeResponses(payload): void {
    this.isLoading = true;
    this.studentHelperService.groupMemById(payload).subscribe(res => {
      this.isLoading = false;
      if (res.responses && res.responses.length) {
        this.challengeResponsesList = [];
        this.currentChallenge = {};
        this.challengeResponsesList = res.responses;
        this.processViewResponses(this.challengeResponsesList);
      } else {
        this.toastrService.warning('No Responses Found...');
        if (this.challengeResponsesList && this.challengeResponsesList.length === 0) {
          this.close();
        }
      }
    });
  }

  checkSelectedBadge(id:any){
   this.selectedBadge = id;
   this.badge = this.badges[id];
  }

  showJudgeVote(){
    if(this.user_Type === "teacher"){
    this.judgeVoteFlag = !this.judgeVoteFlag;
    }else if(this.filteredArrayforBadge.length !== 0){
      this.judgeVoteFlag = !this.judgeVoteFlag;
    }else{
      this.judgeVoteFlag = false;
      this.toastrService.warning("No Badges Earned")
    }
  }

  checkVoteReal(){
    this.flagReal = !this.flagReal;
  }

  checkVoteRad(){
    this.flagRad = !this.flagRad;
  }

  checkVoteOG(){
    this.flagOG = !this.flagOG;
  }

  checkChallengeEndDate(challenge:any){
    challenge.topic_end_date = moment(this.challenge.topic_end_date).format('ll');
    const isEnable = moment(moment().format('ll')).isBetween(moment(this.challenge.topic_start_date).format('ll'), this.challenge.topic_end_date, undefined, '[]');
    return isEnable;
  }

  processViewResponses(challengeResponsesList: any[]) {
    challengeResponsesList.forEach(chall => {
      chall['winner_notes'] = this.helperService.getWinnerNotes(chall);
      if (chall.attachments && chall.attachments.length) {
        const imageObj = chall.attachments.find(attach => attach.type === 'image');
        chall['response_image'] = imageObj && imageObj.file ? imageObj.url : '';
        this.getAttachmentsSeparatedByType(chall);
      }
    });
    if (this.isResponseSelect) {
      const index = challengeResponsesList.findIndex(s => s.topic_response_id == this.challenge.topic_response_id);
      this.currentChallenge = index !== -1 ? challengeResponsesList[index] : challengeResponsesList[0];
      if(this.currentChallenge.review_status === 'S'){
        this.changePendingFlag = true;
        this.changePromotedFlag = false;
        this.changeRejectedFlag = false;
        this.pendingStatus = 'active';
      }else if(this.currentChallenge.review_status === 'A'){
        this.changePendingFlag = false;
        this.changePromotedFlag = true;
        this.changeRejectedFlag = false;
        this.promotedStatus = 'active';
      }else{
        this.changePendingFlag = false;
        this.changePromotedFlag = false;
        this.changeRejectedFlag = true;
        this.disqualifiedStatus = 'active';
      }
      this.isResponseSelect = false;
      // this.reviewStatus = this.currentChallenge.review_status === 'S' ? 'Submitted': ;
    } else {
      this.currentChallenge = challengeResponsesList[0];
      this.reviewStatus = this.currentChallenge.review_status;
      this.pendingStatus ='';
      this.disqualifiedStatus= '';
      this.promotedStatus = '';
      if(this.reviewStatus === 'S'){
        this.pendingStatus = 'active';
      }else if(this.reviewStatus === 'R'){
        this.disqualifiedStatus = 'active';
      }else{
        this.promotedStatus = 'active';
      }
    }
    this.initSwiperSlider();
    this.getChallengeComments();
  }

  getAttachmentsSeparatedByType(challenge): void {
    challenge['imageList'] = challenge.attachments.filter(i => i.type === 'image');
    challenge['videoList'] = challenge.attachments.filter(i => i.type === 'video');
    challenge['audioList'] = challenge.attachments.filter(i => i.type === 'audio');
    challenge['docList'] = challenge.attachments.filter(i => i.type === 'doc');
  }

  viewSelectedCard(responseIndex: number): void {
    this.pendingStatus ='';
    this.disqualifiedStatus= '';
    this.promotedStatus = '';
    this.currentChallenge = {};
    this.comment = '';
    this.resetVideo();
    
    this.currentChallenge = this.challengeResponsesList[responseIndex];
    if(this.currentChallenge.review_status === 'S'){
      this.pendingStatus = 'active';
    }else if(this.currentChallenge.review_status === 'R'){
      this.disqualifiedStatus = 'active';
    }else{
      this.promotedStatus = 'active';
    }
    this.initSwiperSlider();
    this.getChallengeComments();
  }

  getChallengeComments(): void {
    
    this.isLoading = true;
    const payload = {
      topic_response_id: this.currentChallenge.topic_response_id
    };
    this.studentHelperService.getResponses(payload).subscribe(res => {
      this.isLoading = false;
      if (this.user_Type === 'admin' || this.userInfo.user_id === this.currentChallenge.buddy_id) {
        if(res.length === 0){
          // this.disableEarnedBadges = false;
          // this.disableBadges = true;
          // this.showChooseBadgeTab = true;
          // this.activatedShowChooseBadgeTab = true;
          // this.activateShowEarnedBadgeTab = false;
          // this.showEarnedBadgeTab = false;
          this.judgeVoteFlag = false;
          // this.toastrService.warning("No badges earned")
        }else{
          this.commentsList = res;
          // this.commentsList.forEach(( element,index) => { this.commentsList[index]["attachments"] = element.attachments});
          const info = this.commentsList.filter(x => x.attachments.length !== 0);
          this.filteredArrayforBadge  = info.filter(obj =>
            obj.attachments.some(att => att.is_teacher === 1)
          );
          if(this.filteredArrayforBadge.length !== 0){
            // this.judgeVoteFlag = true;
            this.showEarnedBadgeTab = true;
              this.activateShowEarnedBadgeTab = true;
              this.showChooseBadgeTab = false;
              this.activatedShowChooseBadgeTab = false;
          }else{
            // this.judgeVoteFlag = false;
            // this.toastrService.warning("No badges earned")

          }
        }
        
      } else {
        // this.judgeVoteFlag = true;
         if(res.length === 0){
          // this.disableEarnedBadges = false;
          // this.disableBadges = true;
          this.showChooseBadgeTab = true;
          this.activatedShowChooseBadgeTab = true;
          this.showEarnedBadgeTab = false;
          this.activateShowEarnedBadgeTab = false;
        }else{
          // const filteredArrayAttachments = res.filter(obj => obj.attachments.length > 0);
            const filteredArrayAttachments = res.filter(obj => {
            const attachments = obj.attachments;
            if(attachments.length !== 0){
            return attachments.some(att => att.is_teacher === 1);
            }else{
              return attachments;
            }
            });
            const badgeCommentUserId = filteredArrayAttachments.map(obj => obj.user_id);
            const checkLoggedInUser = badgeCommentUserId.find(x => x === this.userInfo.user_id);
            if(checkLoggedInUser === undefined){
              const filteredArrayWithOutAttachments = res.filter(obj => obj.attachments.length === 0 );

              if(filteredArrayWithOutAttachments.length !== 0){
                if(filteredArrayAttachments.length === 0){
                  this.showEarnedBadgeTab = false;
                  this.activateShowEarnedBadgeTab = false;
                  this.showChooseBadgeTab = true;
                  this.activatedShowChooseBadgeTab = true;
                }else{
                  this.showEarnedBadgeTab = true;
                  this.activateShowEarnedBadgeTab = true;
                  this.showChooseBadgeTab = true;
                  this.activatedShowChooseBadgeTab = false;
                }
             
              }else{
              this.showEarnedBadgeTab = true;
              this.activateShowEarnedBadgeTab= true;
              this.showChooseBadgeTab = true;
              this.activatedShowChooseBadgeTab = false
              }
            }else{
              this.showEarnedBadgeTab = true;
              this.activateShowEarnedBadgeTab = true;
              this.showChooseBadgeTab = false;
              this.activatedShowChooseBadgeTab = false;
            }

            // const filteredArrayWithOutAttachments = res.filter(obj => obj.attachments.length === 0 );

            //   if(filteredArrayWithOutAttachments.length === 0){
            //     this.showEarnedBadgeTab = false;
            //     this.activateShowEarnedBadgeTab = false;
            //     this.showChooseBadgeTab = true;
            //     this.activatedShowChooseBadgeTab = true;
            //   }

        }
        this.commentsList = res.filter(comment => !comment.is_reported);
        this.commentsList.forEach(( element,index) => { this.commentsList[index]["attachments"] = element.attachments});
        const info = this.commentsList.filter(x => x.attachments.length !== 0);
        this.filteredArrayforBadge  = info.filter(obj =>
          obj.attachments.some(att => att.is_teacher === 1)
        );
      }
      
    }, () => this.isLoading = false);
  }

  submitReaction(value: any): void {
    if (this.currentChallenge.rating_reaction === value) {
      return;
    }
    this.isLoading = true;
    const payload = {
      topic_resp_rating_id: this.currentChallenge.topic_resp_rating_id,
      topic_response: this.currentChallenge.topic_response_id,
      rating_reaction: value
    };
    this.studentHelperService.reactOnSubmission(payload).subscribe(response => {
      this.isLoading = false;
      if (response) {
        this.currentChallenge.topic_resp_rating_id = response.topic_resp_rating_id;
        this.currentChallenge.rating_reaction = value;
        this.currentChallenge.for_real = response.reactions[0].for_real;
        this.currentChallenge.rad = response.reactions[0].rad;
        this.currentChallenge.og = response.reactions[0].og;
      }
    }, () => this.isLoading = false);
  }
  handleSelection(event: any) {
    this.comment += event.char;
    this.isdisplay= false;
  }

  openImages(){
    this.isdisplay= !this.isdisplay;
    this.getItemlist(2);
  }
  getItemlist(id: any){
    const payload ={
      category_id : id,
      redeemed : true,
    };
    this.studentHelperService.getAllItemsList(payload).subscribe(res =>{
      if(res.items){
        this.items = res.items;
      }
      else{
        this.toastrService.warning("You don't have items");
      }
    })
  }
  closeBtn(){
    this.isdisplay= false;
  }
  onClickAbuseFlag(comment): void {
    if (!comment.is_reported) {
      const deleteModelRef = this.modalService.open(DeleteComponent, { centered: true, backdrop: 'static' });
      deleteModelRef.componentInstance.message = 'Are you sure you want to report this as a Abuse Comment?';
      deleteModelRef.result.then((res) => {
        if (res) {
          this.reportAbuseComment(comment);
        }
      }, (reason) => {
        if (reason) {
          this.reportAbuseComment(comment);
        }
      });
    } else {
      this.reportUnAbuseComment(comment);
    }
  }

  reportAbuseComment(comment: any): void {
    const payload = {
      topic_resp_comment_id: comment.topic_resp_comment_id,
      report_comments: 'reporting abuse comment',
      is_reported: 1,
      comment_notes: comment.comment_notes
    };
    this.isLoading = true;
    this.studentHelperService.updateResponse(payload).subscribe(res => {
      this.isLoading = false;
      if (res) {
        comment.is_reported = res.is_reported;
        this.toastrService.success('Reported Successfully');
      }
    }, () => this.isLoading = false);
  }

  reportUnAbuseComment(comment: any): void {
    const payload = {
      topic_resp_comment_id: comment.topic_resp_comment_id,
      report_comments: null,
      is_reported: 0,
      comment_notes: comment.comment_notes
    };
    this.isLoading = true;
    this.studentHelperService.updateResponse(payload).subscribe(res => {
      this.isLoading = false;
      if (res) {
        comment.is_reported = res.is_reported;
        this.toastrService.success('Reported Successfully');
      }
    }, () => this.isLoading = false);
  }

  // select flass card for comments 
  // note don't remove the commented code
  selectComment(url, index) {
    if(this.selcards.length){
      // const data =  this.selcards.find(el => el.item_image === url);
      // if(data === undefined){
        this.selcards.push(this.items[index]);
      // }else{
      //   this.selcards = this.selcards.filter(item => (item.item_image !== url));
      // }
    }else{
      this.selcards.push(this.items[index]);
    }
     
  }
  selectCommentClose(url, index1){
    this.selcards = this.selcards.filter((item,index) => (index !== index1))
  }
  checkSelected(url:any){
   return this.selcards.some(x =>{
      if(x.item_image === url){
        return true;
        this.checked = true;
      }else{
        return false;
        this.checked = false;
      }
     });
  }
  submitComment(): void {
    this.comment=this.comment.trim();
    if(this.community.is_competition !== 1){
    if (this.comment || this.selcards.length>0 ) {
      this.isLoading = true;
      const payload = {
        user_id: this.userInfo.user_id,
        topic_response_id: this.currentChallenge.topic_response_id,
        comment_notes: this.comment,
      };
      
      let ar=[]
      this.selcards.forEach((element,index) => {
        const obj = {};
        // obj["item_image"]=element.item_image.split("uploads/")[1]
        obj["item_image"]=element.item_image
        obj["item_sequence"]=index+1
        obj["item_name"]=element.item_name
        ar.push(obj)
      });
        payload["attachments"] =  ar;
      // return;

      this.studentHelperService.postResponse(payload).subscribe(res => {
        this.isLoading = false;
        this.comment = '';
        this.imageUrl= '';
        this.selcards=[];
        this.selectedItemsArray =[];
        this.commentsList.unshift(res);
      }, () => this.isLoading = false);
    }else{
      this.toastrService.warning("Please Enter the Comment")
    }
    }else{
      if(this.comment === ''){
        this.toastrService.error("Comment is Required");
      }else{
        this.isLoading = true;
        const payload = {
          user_id: this.userInfo.user_id,
          topic_response_id: this.currentChallenge.topic_response_id,
          comment_notes: this.comment,
          review_status: this.reviewStatus,
          reviewed_by: this.userInfo.created_by
        };
        
        let ar=[]
        this.selcards.forEach((element,index) => {
          const obj = {};
          obj["item_image"]=element.item_image
          obj["item_sequence"]=index+1
          obj["item_name"]=element.item_name
          obj["review_status"]=element.review_status
          obj["reviewed_by"] = element.reviewed_by
          ar.push(obj)
        });
          payload["attachments"] =  ar;
  
        this.studentHelperService.postReview(payload).subscribe(res => {
          this.isLoading = false;
          this.comment = '';
          this.imageUrl= '';
          this.selcards=[];
          this.selectedItemsArray =[];
          this.commentsList.unshift(res);
          this.filterViewResponses();
        }, () => this.isLoading = false);
      }
    }
  }


  onSelectAgeCategory(value: any) {
    if(this.responseAge === value){
      this.showFlag = false;
      this.responseAge = value;
    }else{
      this.showFlag = true;
      this.responseAge = value;
    }
    this.challenge.age_category = undefined;
    // this.responseAge = value;
    this.filterViewResponses();
  }

  onSelectResponseCategory(value: any) {
    window.scrollTo({ top: 0, behavior: 'smooth' });
    if (this.responseType !== 'Buddies') {
      this.page = 1;
      if(this.responseType === value){
        this.showFlag = false;
        this.responseType = value;
      }else{
        this.showFlag = true;
        this.responseType = value;
      }
      this.filterViewResponses();
    }else{
      this.responseType = value;
    }
    if(this.responseType === 'S'){
      this.changePendingFlag = true;
      this.changePromotedFlag = false;
      this.changeRejectedFlag = false;
    }else if(this.responseType === 'A'){
      this.changePendingFlag = false;
      this.changePromotedFlag = true;
      this.changeRejectedFlag = false;
    }else{
      this.changePendingFlag = false;
      this.changePromotedFlag = false;
      this.changeRejectedFlag = true;
    }
    
    this.filterViewResponses();
  }

  viewChallenge(): void {
    this.activeModel.close();
    if (this._page === 'MyChallenges') {
      const data = {
        challenge: this.challenge
      };
      const modelRef = this.modalService.open(this.challenge.topic_group_size === 1 ? SoloChallengeModelComponent : GroupChallengeModelComponent, {
        centered: true,
        scrollable: true,
        backdrop: 'static',
        keyboard: false,
        size: 'xl',
        windowClass: 'modal-challenge'
      });
      modelRef.componentInstance.data = data;
    }
  }

  resetVideo(): void {
    if (this.videoPlayer && this.videoPlayer.nativeElement) {
      this.videoPlayer.nativeElement.pause();
      // this.videoPlayer.nativeElement.load();
    }
  }

  initSwiperSlider() {
    if (this.swiperSlider && !this.swiperSlider.destroyed) {
      this.swiperSlider.destroy();
    }
    if (this.currentChallenge !== undefined && this.currentChallenge.attachments && this.currentChallenge.attachments.length > 1) {
      setTimeout(() => {
        this.swiperSlider = new Swiper('.swiper.swiper-view-responses', {
          modules: [Navigation, Pagination, Autoplay],
          // Optional parameters
          loop: true,
          freeMode: true,

          // If we need pagination
          pagination: {
            clickable: true,
            el: '.swiper-pagination',
            type: 'bullets'
          },

          autoplay: {
            delay: 2500,
            disableOnInteraction: false,
            pauseOnMouseEnter: true
          },

          keyboard: {
            enabled: true,
            onlyInViewport: false,
          },

          // Navigation arrows
          navigation: {
            nextEl: '.swiper-button-next',
            prevEl: '.swiper-button-prev',
          },
        });
      });
    } else {
      setTimeout(() => {
        this.swiperSlider = new Swiper('.swiper.swiper-view-responses', {
          // Optional parameters
          enabled: false,
          navigation: {
            nextEl: null,
            prevEl: null,
          },
        });
      });
    }
  }

  onScroll(event: any) {
    // visible height + pixel scrolled >= total height
    if ((event.target.offsetHeight + event.target.scrollTop + 600 >= event.target.scrollHeight) && !this.isBlockScroll && !this.isLastPage) {
      this.isBlockScroll = true;
      this.page += 1;
      this.showFlag = false;
      this.filterViewResponses();
    }
  }

  deleteResponse(responseId): void {
    const deleteModelRef = this.modalService.open(DeleteComponent, {centered: true, backdrop: 'static'});
    deleteModelRef.componentInstance.message = 'Are you sure you want to delete the response?';
    deleteModelRef.componentInstance.notes = '(This will remove all comments and reactions)';
    deleteModelRef.result.then((res) => {
      if (res) {
        this.deleteRecord(responseId);
        this.activeModel.close();
        this.refreshService.triggerRefresh();
      }
    }, (reason) => {
      if (reason) {
        this.deleteRecord(responseId);
        this.activeModel.close();
        this.refreshService.triggerRefresh();
      }
    });
  }

  deleteRecord(responseId): void {
    this.isLoading = true;
    this.studentHelperService.deleteResponse(responseId).subscribe(res => {
      this.isLoading = false;
      if (res.success) {
        this.toastrService.success(`Response ${SUCCESS_MESSAGE.RECORD_DELETED}. Please resubmit again`);
        this.challengeResponsesList = this.challengeResponsesList.filter(_response => _response.topic_response_id !== responseId);
        this.viewSelectedCard(0);
        if (this.challengeResponsesList.length === 0) {
          this.close();
        }
      }
      this.close();
    }, () => this.isLoading = false);
  }

  openBuddyProfile(buddie: any, userId: any): void {
    const modalRef = this.modalService.open(userId == this.userInfo.user_id ? MySpaceComponent : ViewOtherProfileComponent, {
      centered: true,
      backdrop: 'static',
      size: 'xl',
      windowClass: 'custom-modal'
    });
    if (userId != this.userInfo.user_id) {
      modalRef.componentInstance.data = { userId };
    }
  }

  deleteComment(commentId: number, commentIndex: number, commentType:any): void {
    const deleteModelRef = this.modalService.open(DeleteComponent, {centered: true, backdrop: 'static'});
    deleteModelRef.componentInstance.message = 'Are you sure you want to delete the comment?';
    deleteModelRef.componentInstance.notes = '';
    deleteModelRef.result.then((res) => {
      if (res) {
        this.challengeResponsesList = [];
        this.deleteCommentRecordById(commentId, commentIndex,commentType);
        this.filterViewResponses();
      }
    }, (reason) => {
      if (reason) {
        this.challengeResponsesList = [];
        this.deleteCommentRecordById(commentId, commentIndex,commentType);
        this.filterViewResponses();
      }
    });
  }

  deleteCommentRecordById(commentId: number, commentIndex: number,commentType:any): void {
    this.isLoading = true;
    this.studentHelperService.deleteComment(commentId).subscribe(res => {
      this.isLoading = false;
      if (res.success) {
        this.getChallengeComments();
        this.filterViewResponses();
        this.toastrService.success(commentType +" "+ `${SUCCESS_MESSAGE.RECORD_DELETED}`);
        this.commentsList = this.commentsList.filter((i, index) => commentIndex !== index);
      }
    }, () => this.isLoading = false);
  }

  addEmoji(event): void {
    this.comment += event.emoji.native;
  }

  ngOnDestroy(): void {
    this.subscriptions.next();
    this.subscriptions.complete();
  }
  // for rotating image
  anglesV = -90;
   rotationV = 0;
   oldPositionV:any;
  rotate(postV: any) {

    const rotatedV = document.getElementById(postV);
    if (this.oldPositionV !== rotatedV) {
      this.oldPositionV = rotatedV;
      this.rotationV = 0
      this.anglesV = -90
    }
    this.rotationV = (this.rotationV + this.anglesV) % 360;
    rotatedV.style.transform = `rotate(${this.rotationV}deg)`;
  }
  navigateTo(){
    this.isdisplay = false;
      this.modalService.dismissAll();    
      this.router.navigate(['/auth/student/dot-store']);



  }
}
