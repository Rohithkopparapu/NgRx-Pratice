import {Injectable} from '@angular/core';
import {tap} from 'rxjs/operators';
import {HttpBackend, HttpClient} from '@angular/common/http';

let endpoints;

@Injectable({
  providedIn: 'root'
})
export class ConfigService {

  appConfig: any;
  http: HttpClient;
  constructor(private httpBackend: HttpBackend) {
    this.http = new HttpClient(httpBackend);
  }

  loadConfig(): any {
    return this.http.get('assets/app-config.json').pipe(
      tap(res => {
        if (res) {
          this.appConfig = this.getEnvironmentData(res);
        }
      })
    ).toPromise();
  }
  getEnvironmentData(environment: any): any {
    endpoints = {
       tokenUrl: '/'
    };

    return [endpoints, environment];
  }
}
