export enum Authority {
  ADMIN = 'admin',
  STUDENT = 'student',
  TEACHER = 'teacher'
}
export const Role = {
  ADMIN: 'admin',
  STUDENT: 'student',
  TEACHER: 'teacher'
};
