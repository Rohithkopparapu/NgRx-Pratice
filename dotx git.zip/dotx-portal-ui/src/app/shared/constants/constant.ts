export const PLATFORM_START_DATE = '05-12-2021';
export const ABOUT_DOTX_VIDEO_URL = 'https://d3l1n3m056n16d.cloudfront.net/ed505873-357f-481e-b916-7f1077602e3b/AppleHLS1/My Movie 31.m3u8';
export const REFRESH_PAGES = ['challenge', 'quest'];
export const PAGE_SIZE = 10;
export const MOBILE_PAGE_SIZE = 5;


export const DELIMITERS = {
  VIEW_QUERY_COLUMN_SEPARATOR: '__',
  CAPTION_JOINER: ', '
};
export const CONTENT_TYPE = {
  APPLICATION_JSON: 'application/json',
  APPLICATION_TEXT: 'text/plain',
  APPLICATION_HTML: 'text/html',
  APPLICATION_XML: 'application/xml',
  APPLICATION_PDF: 'application/pdf',
  APPLICATION_URL_ENCODED: 'application/x-www-form-urlencoded',
  APPLICATION_EXCEL: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8',
  APPLICATION_CSV: 'application/octet-stream'
};
export const FILE_EXD = {
  PDF: '.pdf',
  XML: '.xml',
  IIF: '.iif',
  TXT: '.txt',
  CSV: '.csv',
  EXCEL: '.xlsx'
};
export const FILE_TYPE = {
  PDF: 'PDF',
  XML: 'XML',
  IIF: 'IIF',
  TXT: 'TXT',
  CSV: 'CSV',
  EXCEL: 'EXCEL'
};
export const AUTHORIZED_GRANT_TYPES = {
  PASSWORD: 'password',
  AUTHORIZATION_CODE: 'authorization_code',
  REFRESH_TOKEN: 'refresh_token',
  IMPLICIT: 'implicit'
};
export const SEARCH_TYPE = {
  School: 'school_name',
  Skill: 'skill',
  Name: 'display_name',
  Age: 'age',
  Class: 'class_details'
};
export const ERROR_MESSAGE = {
  DAILY_DOT_DATE_FORMAT: 'Please enter date format as yyyy-mm-dd 00:00:00',
  RECORD_DELETED: 'Record deleted successfully',
  RECORD_UPDATED: 'Record updated successfully',
  RECORD_ADDED: 'Record added successfully',
  USER_CREATED: 'User created successfully',
  FIELDS_REQUIRED: 'Please fill all required details',
  VALID_FILE: 'Please select a valid csv file and submit',
  FILE_UPLOADED: 'File uploaded successfully',
};
export const ICON_AVATAR = {
  femaleAvatars: ['1.svg', '2.svg', '3.svg', '4.svg', '5.svg', '6.svg', '7.svg', '8.svg', '9.svg', 'Girl-01.svg',
    'Girl-02.svg', 'Girl-03.svg', 'Girl-04.svg', 'Girl-05.svg', 'Girl-06.svg', 'Girl-07.svg', 'Girl-08.svg',
    'Girl-09.svg', 'Girl-10.svg', 'Girl-11.svg', 'Girl-12.svg', 'Girl-13.svg', 'Girl-14.svg', 'Girl-15.svg',
    'Girl-16.svg', 'Girl-17.svg', 'Girl-18.svg', 'Girl-19.svg', 'Girl-20.svg', 'Girl-21.svg', 'Girl-22.svg',
    'Girl-23.svg', 'Girl-24.svg', 'Girl-25.svg', 'Girl-26.svg', 'Girl-27.svg', 'Girl-28.svg', 'Girl-29.svg',
    'Girl-30.svg', 'Girl-31.svg', 'Girl-32.svg', 'Girl-33.svg', 'Girl-34.svg', 'Girl-35.svg', 'Girl-36.svg',
    'Girl-37.svg', 'Girl-38.svg', 'Girl-39.svg', 'Girl-40.svg', 'Girl-41.svg', 'Girl-42.svg', 'Girl-43.svg',
    'Girl-46.svg', 'Girl-47.svg', 'Girl-48.svg', 'Girl-49.svg', 'Girl-50.svg', 'Girl-51.svg', 'Girl-52.svg',
    'Girl-53.svg', 'Girl-54.svg', 'Girl-55.svg', 'Girl-56.svg', 'Girl-57.svg', 'Girl-58.svg', 'Girl-59.svg',
    'Girl-60.svg', 'Girl-61.svg', 'Girl-62.svg', 'Girl-63.svg', 'Girl-64.svg', 'Girl-65.svg', 'Girl-66.svg',
    'Girl-67.svg', 'Girl-68.svg', 'Girl-69.svg', 'Girl-70.svg', 'Girl-71.svg', 'Girl-72.svg', 'Girl-73.svg',
    'Girl-74.svg', 'Girl-75.svg', 'Girl-76.svg', 'Girl-77.svg', 'Girl-78.svg', 'Girl-79.svg', 'Girl-80.svg',
    'Girl-81.svg', 'Girl-82.svg', 'Girl-83.svg', 'Girl-89.svg', 'Girl-90.svg', 'Girl-91.svg', 'Girl-92.svg',
    'Girl-93.svg', 'Girl-94.svg', 'Girl-95.svg', 'Girl-96.svg', 'Girl-98.svg', 'Girl-99.svg'],
  maleAvatars: ['1.svg', '2.svg', '3.svg', '4.svg', '5.svg', '6.svg', '7.svg', '8.svg', '9.svg', 'boy-01.svg',
    'boy-02.svg', 'boy-03.svg', 'boy-04.svg', 'boy-05.svg', 'boy-06.svg', 'boy-07.svg', 'boy-08.svg',
    'boy-09.svg', 'boy-10.svg', 'boy-11.svg', 'boy-12.svg', 'boy-13.svg', 'boy-14.svg', 'boy-15.svg',
    'boy-16.svg', 'boy-17.svg', 'boy-18.svg', 'boy-19.svg', 'boy-20.svg', 'boy-21.svg', 'boy-22.svg',
    'boy-23.svg', 'boy-24.svg', 'boy-26.svg', 'boy-27.svg', 'boy-28.svg', 'boy-29.svg', 'boy-30.svg',
    'boy-31.svg', 'boy-32.svg', 'boy-33.svg', 'boy-34.svg', 'boy-35.svg', 'boy-36.svg', 'boy-37.svg',
    'Boy-38.svg', 'Boy-39.svg', 'Boy-40.svg', 'Boy-41.svg', 'Boy-42.svg', 'Boy-43.svg', 'Boy-44.svg',
    'Boy-45.svg', 'Boy-46.svg', 'Boy-47.svg', 'Boy-48.svg', 'Boy-49.svg', 'Boy-50.svg', 'Boy-51.svg',
    'Boy-52.svg', 'Boy-53.svg', 'Boy-54.svg', 'Boy-55.svg', 'Boy-56.svg', 'Boy-57.svg', 'Boy-58.svg',
    'Boy-59.svg', 'Boy-60.svg', 'Boy-61.svg', 'Boy-62.svg', 'Boy-63.svg', 'Boy-64.svg', 'Boy-65.svg',
    'Boy-66.svg', 'Boy-67.svg', 'Boy-68.svg', 'Boy-69.svg', 'Boy-70.svg', 'Boy-71.svg', 'Boy-72.svg',
    'Boy-73.svg', 'Boy-74.svg', 'Boy-75.svg', 'Boy-76.svg', 'Boy-77.svg', 'Boy-78.svg', 'Boy-79.svg',
    'Boy-80.svg', 'Boy-81.svg', 'Boy-82.svg', 'Boy-83.svg', 'Boy-84.svg', 'Boy-85.svg', 'Boy-86.svg',
    'Boy-87.svg', 'Boy-88.svg', 'Boy-89.svg', 'Boy-90.svg', 'Boy-91.svg', 'Boy-92.svg', 'Boy-94.svg',
    'Boy-96.svg', 'Boy-101.svg', 'Boy-102.svg', 'Boy-103.svg', 'Boy-104.svg'],
  otherAvatars: ['friend-1.png', 'friend-2.png', 'friend-3.png', 'friend-4.png', 'friend-5.png']
};
export const HTTP_ERROR_MESSAGE = [
  'Email already exist',
];
export const SUCCESS_MESSAGE = {
  RECORD_DELETED: 'deleted successfully',
  RECORD_UPDATED: 'Updated successfully',
  RECORD_ADDED: 'Added successfully',
  DATA_ADDED: 'Data added successfully',
  FIELDS_REQUIRED: 'Please enter all required fields',
  RECORD_SENT: 'Challenge created and sent for approval',
  RECORD_APPROVED: 'Approved successfully',
  RECORD_REJECTED: 'Rejected successfully',
};
export const ADMIN_ERROR_MESSAGES = {
  DAILY_DOT_DATE_FORMAT: '{"date_of_publish":["Not a valid datetime."],"record_date":["Not a valid datetime."]}',
};
export const languages = [
  {
    displayname: 'US English',
    fieldName: 'en'
  },
  {
    displayname: 'Pilipino',
    fieldName: 'fil'
  },
  {
    displayname: 'తెలుగు',
    fieldName: 'te'
  },
  {
    displayname: 'हिन्दी',
    fieldName: 'hi'
  },
];
export const PREFERENCES = {
  COMMUNITY: { ENTITY_TYPE: 'dot_community', ENTITY_NAME: 'community_id'},
  BULLETIN_BOARD: { ENTITY_TYPE: 'dot_announcements', ENTITY_NAME: 'view_maximize'}
};
export const NEW_JOINER_TOUR = {
  COMMUNITY_TOUR : [
    {
      Quote: 'vibe with your tribe',
      Description: 'Join the communities on the community page and proceed to participate in the challenges. Lead the leader board and reap rewards',
      activeInnerHTML: `<span class="on-boarding-steps-pointer active"></span>
              <span class="on-boarding-steps-pointer"></span>
              <span class="on-boarding-steps-pointer"></span>`,
      buttonName: 'NEXT',
      isView: true
    }, {
      Quote: 'earn to learn',
      Description: 'Learn and complete the fun filled activities to earn dotcoins and badges',
      activeInnerHTML: `<span class="on-boarding-steps-pointer"></span>
              <span class="on-boarding-steps-pointer active"></span>
              <span class="on-boarding-steps-pointer"></span>`,
      buttonName: 'NEXT',
      isView: false
    }, {
      Quote: 'Cheer for your peers',
      Description: 'Respond to the challenges, encourage your buddies by voting for their content',
      activeInnerHTML: `<span class="on-boarding-steps-pointer"></span>
              <span class="on-boarding-steps-pointer"></span>
              <span class="on-boarding-steps-pointer active"></span>`,
      buttonName: 'FINISH',
      isView: false
    }
  ],
  HOME_TOUR: [
    {
      Title: 'Take a Tour',
      Quote: '',
      Description: 'Welcome to the DotX home. Take a quick tour and know the exciting options.',
      activeInnerHTML: `<span class="on-boarding-steps-pointer active"></span>
              <span class="on-boarding-steps-pointer"></span>
              <span class="on-boarding-steps-pointer"></span>`,
      buttonNext: 'NEXT',
      buttonBack: 'SKIP',
      isView: true
    }, {
      Title: 'Challenge',
      Quote: '',
      Description: 'You can go and view the challenge details',
      activeInnerHTML: `<span class="on-boarding-steps-pointer"></span>
              <span class="on-boarding-steps-pointer active"></span>
              <span class="on-boarding-steps-pointer"></span>`,
      buttonNext: 'NEXT',
      buttonBack: 'BACK',
      isView: false
    }, {
      Title: 'User Name',
      Quote: '',
      Description: 'You can click and view the user profile',
      activeInnerHTML: `<span class="on-boarding-steps-pointer"></span>
              <span class="on-boarding-steps-pointer"></span>
              <span class="on-boarding-steps-pointer active"></span>`,
      buttonNext: 'FINISH',
      buttonBack: '',
      isView: false
    }
  ]
};
export const EVENT_TYPE = {
  RESPONSE: 'response',
};
export const NOTIFICATION_TYPES = {
  Notifications: 'Notification',
  Broadcast: 'Broadcast'
};
export const AVATAR_RELATIVE_PATH = 'avatars/SVG/';
export const QUEST_MENU = {
  COMMUNITY_QUESTS: [
    {
      id: 1,
      title: 'Time Keepers',
      description: 'Time Keepers',
      isActive: true,
      challengesQuest: [1, 3, 5, 6, 7, 8, 9, 10, 13, 14, 16],
      community_id: 2
    },
    {
      id: 2,
      title: 'The Hackers',
      description: 'The Hackers',
      isActive: true,
      challengesQuest: [2, 4, 11, 12, 15, 17, 18, 19, 20],
      community_id: 4
    }
  ],
  SPOTLIGHT_CHALLENGES: [
    {
      id: 1,
      title: 'The Story of Time',
      description: 'Years within a Year! Where does it all start from and how old is Samay?',
      imageBanner: 'assets/img/micro-learning/ml-banner-1.jpg',
      enableDate: '2022-04-25',
      isExplore: true,
      isEnable: true,
      h5pContentKey: 1
    },
    {
      id: 2,
      title: 'How does your Brain work?',
      description: 'Did you know the brain size is not related to your body size? How do you make the most out of your 86 billion brain cells?',
      imageBanner: 'assets/img/micro-learning/ml-banner-11.jpg',
      enableDate: '2022-04-25',
      isExplore: true,
      isEnable: true,
      h5pContentKey: 2
    },
    {
      id: 3,
      title: 'Finding your Rhythm',
      description: 'Did you know you’ve your own personalised clock? Dig in to know if you’re Team Lark or Team owl!',
      imageBanner: 'assets/img/micro-learning/ml-banner-2.JPG',
      enableDate: '2022-04-25',
      isExplore: true,
      isEnable: true,
      h5pContentKey: 3
    },
    {
      id: 4,
      title: 'Mind Maps',
      description: 'Would you like to create a map of your learning?',
      imageBanner: 'assets/img/micro-learning/ml-banner-12.jpg',
      enableDate: '2022-04-25',
      isExplore: true,
      isEnable: true,
      h5pContentKey: 4
    },
    {
      id: 5,
      title: 'Time is Energy',
      description: 'Do you know there is a way you can "build" time? Learn the 4 secrets of managing your energy wisely.',
      imageBanner: 'assets/img/micro-learning/ml-banner-5.jpg',
      enableDate: '2022-04-25',
      isExplore: true,
      isEnable: true,
      h5pContentKey: 5
    },
    {
      id: 6,
      title: 'Focus Pocus',
      description: 'Revealing all the Virat Kohli’s secrets! What’s more? A three step guideline to be modern day Arjuna!',
      imageBanner: 'assets/img/micro-learning/ml-banner-3.JPG',
      enableDate: '2022-05-02',
      isExplore: true,
      isEnable: true,
      h5pContentKey: 6
    },
    {
      id: 7,
      title: 'Procrasti-NATION',
      description: 'Hacks to get out of procrasti-NATION! And it’s scientifically proven that eating a frog can save your day! Tap to know more!',
      imageBanner: 'assets/img/micro-learning/ml-banner-4.png',
      enableDate: '2022-05-02',
      isExplore: true,
      isEnable: true,
      h5pContentKey: 7
    },
    {
      id: 8,
      title: 'Eat the frog',
      description: 'Eat a live frog first thing in the morning and nothing worse will happen to you the rest of the day.',
      imageBanner: 'assets/img/micro-learning/ml-banner-6.jpg',
      enableDate: '2022-05-02',
      isExplore: true,
      isEnable: true,
      h5pContentKey: 8
    },
    {
      id: 9,
      title: 'Pomodoro Technique',
      description: 'Do you work smart or do you work hard?',
      imageBanner: 'assets/img/micro-learning/ml-banner-8.jpg',
      enableDate: '2022-05-02',
      isExplore: true,
      isEnable: true,
      h5pContentKey: 9
    },
    {
      id: 10,
      title: 'Flow',
      description: 'Have you been in the Zone where Time stands still, yet Time flies?',
      imageBanner: 'assets/img/micro-learning/ml-banner-7.jpg',
      enableDate: '2022-05-02',
      isExplore: true,
      isEnable: true,
      h5pContentKey: 10
    },
    {
      id: 11,
      title: 'Memory Palace',
      description: 'Be as smart as Sherlock Holmes by just making mind palaces in and around your surroundings. Dig in more to know how!',
      imageBanner: 'assets/img/micro-learning/ml-banner-13.jpg',
      enableDate: '2022-05-09',
      isExplore: true,
      isEnable: true,
      h5pContentKey: 11
    },
    {
      id: 12,
      title: 'Growth Mindset',
      description: 'Replacing failure with "Not Yet" in our vocabulary is the secret to mastering learning. Know more about fixed and growth mindset',
      imageBanner: 'assets/img/micro-learning/ml-banner-14.jpg',
      enableDate: '2022-05-09',
      isExplore: true,
      isEnable: true,
      h5pContentKey: 12
    },
    {
      id: 13,
      title: 'Eisenhower Matrix',
      description: 'Urgent or Important? Do you know the difference?',
      imageBanner: 'assets/img/micro-learning/ml-banner-15.jpg',
      enableDate: '2022-05-09',
      isExplore: true,
      isEnable: true,
      h5pContentKey: 13
    },
    {
      id: 14,
      title: 'Power of Now',
      description: 'Have you ever wondered how long is \'Now\'? Watch and find out!',
      imageBanner: 'assets/img/micro-learning/ml-banner-9.jpg',
      enableDate: '2022-05-09',
      isExplore: true,
      isEnable: true,
      h5pContentKey: 14
    },
    {
      id: 15,
      title: 'Feynman Technique',
      description: 'Richard Feynman, the nobel-prize winning physicist has created a very easy 4-step guide to test if you just know the topic or if you’ve actually learnt about it! Let’s get started!',
      imageBanner: 'assets/img/micro-learning/ml-banner-16.jpg',
      enableDate: '2022-05-09',
      isExplore: true,
      isEnable: true,
      h5pContentKey: 15
    },
    {
      id: 16,
      title: 'Excellence Formula',
      description: 'Samay\'s formula for excellence',
      imageBanner: 'assets/img/micro-learning/ml-banner-10.jpg',
      enableDate: '2022-05-16',
      isExplore: true,
      isEnable: true,
      h5pContentKey: 16
    },
    {
      id: 17,
      title: 'Think like a scientist',
      description: 'We’re spilling Elon Musk’s secrets in this video. Watch this video to know how he built the spaceX rocket 10x cheaper using the First Principles technique.',
      imageBanner: 'assets/img/micro-learning/ml-banner-17.jpg',
      enableDate: '2022-05-16',
      isExplore: true,
      isEnable: true,
      h5pContentKey: 17
    },
    {
      id: 18,
      title: 'Curiosity did not kill the cat',
      description: 'Did curiosity kill the cat? Naah, in fact it helped Nachiketa to find answers to what happens after death. Let’s see how far he went to know the unknown!',
      imageBanner: 'assets/img/micro-learning/ml-banner-18.jpg',
      enableDate: '2022-05-16',
      isExplore: true,
      isEnable: true,
      h5pContentKey: 18
    },
    {
      id: 19,
      title: 'Thought experiments',
      description: 'Albert Einstein used to daydream just like you but that’s also how he discovered General Relativity. Wait, how? Well, he went to the extremes to find the answers of the impossible.',
      imageBanner: 'assets/img/micro-learning/ml-banner-19.jpg',
      enableDate: '2022-05-16',
      isExplore: true,
      isEnable: true,
      h5pContentKey: 19
    },
    {
      id: 20,
      title: 'Learning formula',
      description: 'The formula for learning better and learning faster',
      imageBanner: 'assets/img/micro-learning/ml-banner-20.jpg',
      enableDate: '2022-05-16',
      isExplore: true,
      isEnable: true,
      h5pContentKey: 20
    }
  ],
  TOPIC_CHALLENGES: [
    {
      id: 1,
      title: 'The Story of Time',
      imageBanner: 'assets/img/micro-learning/ml-th-1.png',
      enableDate: '2022-04-25',
      isExplore: true,
      isEnable: true,
      h5pContentKey: 1
    },
    {
      id: 2,
      title: 'How does your Brain work?',
      imageBanner: 'assets/img/micro-learning/ml-th-11.jpg',
      enableDate: '2022-04-25',
      isExplore: true,
      isEnable: true,
      h5pContentKey: 2
    },
    {
      id: 3,
      title: 'Finding your Rhythm',
      imageBanner: 'assets/img/micro-learning/ml-th-2.png',
      enableDate: '2022-04-25',
      isExplore: true,
      isEnable: true,
      h5pContentKey: 3
    },
    {
      id: 4,
      title: 'Mind Maps',
      imageBanner: 'assets/img/micro-learning/ml-th-12.jpg',
      enableDate: '2022-04-25',
      isExplore: true,
      isEnable: true,
      h5pContentKey: 4
    },
    {
      id: 5,
      title: 'Time is Energy',
      imageBanner: 'assets/img/micro-learning/ml-th-5.png',
      enableDate: '2022-04-25',
      isExplore: true,
      isEnable: true,
      h5pContentKey: 5
    },
    {
      id: 6,
      title: 'Focus Pocus',
      imageBanner: 'assets/img/micro-learning/ml-th-3.png',
      enableDate: '2022-05-02',
      isExplore: true,
      isEnable: true,
      h5pContentKey: 6
    },
    {
      id: 7,
      title: 'Procrasti-NATION',
      imageBanner: 'assets/img/micro-learning/ml-th-4.png',
      enableDate: '2022-05-02',
      isExplore: true,
      isEnable: true,
      h5pContentKey: 7
    },
    {
      id: 8,
      title: 'Eat the frog',
      imageBanner: 'assets/img/micro-learning/ml-th-6.jpg',
      enableDate: '2022-05-02',
      isExplore: true,
      isEnable: true,
      h5pContentKey: 8
    },
    {
      id: 9,
      title: 'Pomodoro Technique',
      imageBanner: 'assets/img/micro-learning/ml-th-8.jpg',
      enableDate: '2022-05-02',
      isExplore: true,
      isEnable: true,
      h5pContentKey: 9
    },
    {
      id: 10,
      title: 'Flow',
      imageBanner: 'assets/img/micro-learning/ml-th-7.jpg',
      enableDate: '2022-05-02',
      isExplore: true,
      isEnable: true,
      h5pContentKey: 10
    },
    {
      id: 11,
      title: 'Memory Palace',
      imageBanner: 'assets/img/micro-learning/ml-th-13.jpg',
      enableDate: '2022-05-09',
      isExplore: true,
      isEnable: true,
      h5pContentKey: 11
    },
    {
      id: 12,
      title: 'Growth Mindset',
      imageBanner: 'assets/img/micro-learning/ml-th-14.jpg',
      enableDate: '2022-05-09',
      isExplore: true,
      isEnable: true,
      h5pContentKey: 12
    },
    {
      id: 13,
      title: 'Eisenhower Matrix',
      imageBanner: 'assets/img/micro-learning/ml-th-15.jpg',
      enableDate: '2022-05-09',
      isExplore: true,
      isEnable: true,
      h5pContentKey: 13
    },
    {
      id: 14,
      title: 'Power of Now',
      imageBanner: 'assets/img/micro-learning/ml-th-9.jpg',
      enableDate: '2022-05-09',
      isExplore: true,
      isEnable: true,
      h5pContentKey: 14
    },
    {
      id: 15,
      title: 'Feynman Technique',
      imageBanner: 'assets/img/micro-learning/ml-th-16.jpg',
      enableDate: '2022-05-09',
      isExplore: true,
      isEnable: true,
      h5pContentKey: 15
    },
    {
      id: 16,
      title: 'Excellence Formula',
      imageBanner: 'assets/img/micro-learning/ml-th-10.jpg',
      enableDate: '2022-05-16',
      isExplore: true,
      isEnable: true,
      h5pContentKey: 16
    },
    {
      id: 17,
      title: 'Think like a scientist',
      imageBanner: 'assets/img/micro-learning/ml-th-17.jpg',
      enableDate: '2022-05-16',
      isExplore: true,
      isEnable: true,
      h5pContentKey: 17
    },
    {
      id: 18,
      title: 'Curiosity did not kill the cat',
      imageBanner: 'assets/img/micro-learning/ml-th-18.jpg',
      enableDate: '2022-05-16',
      isExplore: true,
      isEnable: true,
      h5pContentKey: 18
    },
    {
      id: 19,
      title: 'Thought experiments',
      imageBanner: 'assets/img/micro-learning/ml-th-19.jpg',
      enableDate: '2022-05-16',
      isExplore: true,
      isEnable: true,
      h5pContentKey: 19
    },
    {
      id: 20,
      title: 'Learning formula',
      imageBanner: 'assets/img/micro-learning/ml-th-20.jpg',
      enableDate: '2022-05-16',
      isExplore: true,
      isEnable: true,
      h5pContentKey: 20
    }
  ],
  H5P_CONTENT_LIST: {
    1: [
      {
        id: '1291481560005861619',
        title: 'The Story of Time',
        imageBanner: 'assets/img/micro-learning/chapter-1/sot.png'
      },
      {
        id: '1291492612656358949',
        title: 'Quiz - 1',
        imageBanner: 'assets/img/micro-learning/chapter-1/activity-1.png'
      },
      {
        id: '1291492637008531489',
        title: 'Quiz - 2',
        imageBanner: 'assets/img/micro-learning/chapter-1/activity-2.png'
      },
      {
        id: '1291492650098761839',
        title: 'Quiz - 3',
        imageBanner: 'assets/img/micro-learning/chapter-1/activity-3.png'
      },
      {
        id: '1291481649119511979',
        title: 'Find the Missing Word',
        imageBanner: 'assets/img/micro-learning/chapter-1/activity-4.png'
      },
      {
        id: '1291481630810284669',
        title: 'Image Pairing',
        imageBanner: 'assets/img/micro-learning/chapter-1/activity-5.png'
      },
      {
        id: '1291492756279454459',
        title: 'Events before December',
        imageBanner: 'assets/img/micro-learning/chapter-1/activity-6.png'
      },
      {
        id: '1291492804393580059',
        title: 'Events in December',
        imageBanner: 'assets/img/micro-learning/chapter-1/activity-6-1.png'
      },
      {
        id: '1291492782985539669',
        title: 'Image Sequencing',
        imageBanner: 'assets/img/micro-learning/chapter-1/activity-7.png'
      },
      {
        id: '1291492747008974039',
        title: 'Crossword',
        imageBanner: 'assets/img/micro-learning/chapter-1/activity-8.png'
      },
      {
        id: '1291492759585384359',
        title: 'Drag the Words',
        imageBanner: 'assets/img/micro-learning/chapter-1/activity-9.png'
      },
      {
        id: '1291504978499436499',
        title: 'Memory Game',
        imageBanner: 'assets/img/micro-learning/chapter-1/activity-10.png'
      }
    ],
    2: [
      {
        id: '1291621467427374969',
        title: 'How does your Brain work?',
        imageBanner: 'assets/img/micro-learning/fun-facts.png'
      },
      {
        id: '1291613688585951899',
        title: 'Quiz - 1',
        imageBanner: 'assets/img/micro-learning/question-set-1.png'
      },
      {
        id: '1291613689953760889',
        title: 'Crossword',
        imageBanner: 'assets/img/micro-learning/crossword-1.png'
      },
      {
        id: '1291613691901861409',
        title: 'Quiz - 2',
        imageBanner: 'assets/img/micro-learning/question-set-2.png'
      },
      {
        id: '1291613700066732179',
        title: 'Choose & Pick - 1',
        imageBanner: 'assets/img/micro-learning/image-choice-1.png'
      },
      {
        id: '1291613700739937769',
        title: 'Choose & Pick - 2',
        imageBanner: 'assets/img/micro-learning/image-choice-2.png'
      },
      {
        id: '1291613704456495149',
        title: 'Quiz - 3',
        imageBanner: 'assets/img/micro-learning/question-set-3.png'
      },
      {
        id: '1291613707203199999',
        title: 'Quiz - 4',
        imageBanner: 'assets/img/micro-learning/question-set-4.png'
      },
      {
        id: '1291613711837673689',
        title: 'Image Pairing',
        imageBanner: 'assets/img/micro-learning/image-choice-3.png'
      }
    ],
    3: [
      {
        id: '1291510180127521969',
        title: 'Finding your Rhythm',
        imageBanner: 'assets/img/micro-learning/chapter-2/fyr.png'
      },
      {
        id: '1291504712132084639',
        title: 'Quiz - 1',
        imageBanner: 'assets/img/micro-learning/chapter-2/activity-1.png'
      },
      {
        id: '1291506546018741519',
        title: 'Quiz - 2',
        imageBanner: 'assets/img/micro-learning/chapter-2/activity-2.png'
      },
      {
        id: '1291506565460262519',
        title: 'Quiz - 3',
        imageBanner: 'assets/img/micro-learning/chapter-2/activity-3.png'
      },
      {
        id: '1291506574228260489',
        title: 'Find the Missing Word',
        imageBanner: 'assets/img/micro-learning/chapter-2/activity-4.png'
      },
      {
        id: '1291506646251711029',
        title: 'Image Pairing',
        imageBanner: 'assets/img/micro-learning/chapter-2/activity-5.png'
      },
      {
        id: '1291506571349918259',
        title: 'Crossword',
        imageBanner: 'assets/img/micro-learning/chapter-2/activity-6.png'
      },
      {
        id: '1291506639541072839',
        title: 'Image Sequencing',
        imageBanner: 'assets/img/micro-learning/chapter-2/activity-7.png'
      },
      {
        id: '1291506674329752609',
        title: 'Choose & Pick - 1',
        imageBanner: 'assets/img/micro-learning/chapter-2/activity-8.png'
      },
      {
        id: '1291506667227574319',
        title: 'Choose & Pick - 2',
        imageBanner: 'assets/img/micro-learning/chapter-2/activity-9.png'
      },
      {
        id: '1291506576643153359',
        title: 'Memory Game',
        imageBanner: 'assets/img/micro-learning/chapter-2/activity-10.png'
      },
      // {
      //   id: '1291506600131532789',
      //   title: 'Drag and Drop',
      //   imageBanner: 'assets/img/micro-learning/chapter-2/activity-11.png'
      // }
    ],
    4: [
      {
        id: '1291621469394256649',
        title: 'Mind Maps',
        imageBanner: 'assets/img/micro-learning/mind-map.png'
      },
      {
        id: '1291617148808496639',
        title: 'Image Sequencing',
        imageBanner: 'assets/img/micro-learning/image-choice-2.png'
      },
      {
        id: '1291617158548392289',
        title: 'Quiz - 1',
        imageBanner: 'assets/img/micro-learning/question-set-1.png'
      },
      {
        id: '1291617170900737199',
        title: 'Quiz - 2',
        imageBanner: 'assets/img/micro-learning/question-set-2.png'
      },
      {
        id: '1291617896974330689',
        title: 'Image Pairing',
        imageBanner: 'assets/img/micro-learning/image-choice-1.png'
      },
      {
        id: '1291617907713286969',
        title: 'Choose & Pick - 1',
        imageBanner: 'assets/img/micro-learning/image-choice-3.png'
      },
      {
        id: '1291617905582757929',
        title: 'Choose & Pick - 2',
        imageBanner: 'assets/img/micro-learning/image-choice-4.png'
      },
      {
        id: '1291617920216089649',
        title: 'Quiz - 3',
        imageBanner: 'assets/img/micro-learning/question-set-4.png'
      },
      {
        id: '1291617923826560269',
        title: 'Crossword',
        imageBanner: 'assets/img/micro-learning/crossword-1.png'
      }
    ],
    5: [
      {
        id: '1291512636238440229',
        title: 'Time is Energy',
        imageBanner: 'assets/img/micro-learning/chapter-3/te.png'
      },
      {
        id: '1291511639056124289',
        title: 'Choose & Pick - 1',
        imageBanner: 'assets/img/micro-learning/chapter-3/activity-1.png'
      },
      {
        id: '1291511643901218679',
        title: 'Quiz - 2',
        imageBanner: 'assets/img/micro-learning/chapter-3/activity-2.png'
      },
      {
        id: '1291511646871797729',
        title: 'Crossword',
        imageBanner: 'assets/img/micro-learning/chapter-3/activity-3.png'
      },
      {
        id: '1291511649046888269',
        title: 'Choose & Pick - 2',
        imageBanner: 'assets/img/micro-learning/chapter-3/activity-4.png'
      },
      {
        id: '1291508529289980079',
        title: 'Choose & Pick - 3',
        imageBanner: 'assets/img/micro-learning/chapter-3/activity-5.png'
      }
    ],
    6: [
      {
        id: '1291514353991963599',
        title: 'Focus Pocus',
        imageBanner: 'assets/img/micro-learning/chapter-4/fp.png'
      },
      {
        id: '1291511055872442639',
        title: 'Memory Game',
        imageBanner: 'assets/img/micro-learning/chapter-4/activity-1.png'
      },
      {
        id: '1291510857173622069',
        title: 'Crossword',
        imageBanner: 'assets/img/micro-learning/chapter-4/activity-2.png'
      },
      {
        id: '1291510881891045329',
        title: 'Personality Quiz',
        imageBanner: 'assets/img/micro-learning/chapter-4/activity-3.png'
      },
      {
        id: '1291510898413868209',
        title: 'Quiz - 4',
        imageBanner: 'assets/img/micro-learning/chapter-4/activity-4.png'
      },
      {
        id: '1291511108813871809',
        title: 'Quiz - 5',
        imageBanner: 'assets/img/micro-learning/chapter-4/activity-5.png'
      },
      {
        id: '1291511060240137519',
        title: 'Crossword',
        imageBanner: 'assets/img/micro-learning/chapter-4/activity-6.png'
      },
      {
        id: '1291511624971691659',
        title: 'Image Sequencing',
        imageBanner: 'assets/img/micro-learning/chapter-4/activity-7.png'
      },
      {
        id: '1291511111867412989',
        title: 'Quiz - 8',
        imageBanner: 'assets/img/micro-learning/chapter-4/activity-8.png'
      },
      {
        id: '1291511136669756559',
        title: 'Choose & Pick',
        imageBanner: 'assets/img/micro-learning/chapter-4/activity-9.png'
      }
    ],
    7: [
      {
        id: '1291520274415678019',
        title: 'Procrasti-NATION',
        imageBanner: 'assets/img/micro-learning/chapter-5/pn.png'
      },
      {
        id: '1291520375813213879',
        title: 'Quiz - 1',
        imageBanner: 'assets/img/micro-learning/chapter-5/activity-1.png'
      },
      {
        id: '1291520378236479029',
        title: 'Crossword - 1',
        imageBanner: 'assets/img/micro-learning/chapter-5/activity-2.png'
      },
      {
        id: '1291520386703777689',
        title: 'Flashcards',
        imageBanner: 'assets/img/micro-learning/chapter-5/activity-3.png'
      },
      {
        id: '1291520392082752819',
        title: 'Crossword - 2',
        imageBanner: 'assets/img/micro-learning/chapter-5/activity-4.png'
      },
      {
        id: '1291520400441430309',
        title: 'Quiz - 2',
        imageBanner: 'assets/img/micro-learning/chapter-5/activity-5.png'
      },
      {
        id: '1291520425868105599',
        title: 'Quiz - 3',
        imageBanner: 'assets/img/micro-learning/chapter-5/activity-6.png'
      },
      {
        id: '1291520428257244239',
        title: 'Memory Game',
        imageBanner: 'assets/img/micro-learning/chapter-5/activity-7.png'
      },
      {
        id: '1291520430293269079',
        title: 'Choose & Pick',
        imageBanner: 'assets/img/micro-learning/chapter-5/activity-8.png'
      }
    ],
    8: [
      {
        id: '1291520271192400909',
        title: 'Eat the frog',
        imageBanner: 'assets/img/micro-learning/chapter-6/etf.png'
      },
      {
        id: '1291511657126367679',
        title: 'Drag the Words',
        imageBanner: 'assets/img/micro-learning/chapter-6/activity-1.png'
      },
      {
        id: '1291511669991234709',
        title: 'Quiz - 1',
        imageBanner: 'assets/img/micro-learning/chapter-6/activity-2.png'
      },
      {
        id: '1291511654277718659',
        title: 'Memory Game',
        imageBanner: 'assets/img/micro-learning/chapter-6/activity-3.png'
      },
      {
        id: '1291511955766731989',
        title: 'Personality Quiz',
        imageBanner: 'assets/img/micro-learning/chapter-6/activity-4.png'
      }
    ],
    9: [
      {
        id: '1291530701361422089',
        title: 'Pomodoro Technique',
        imageBanner: 'assets/img/micro-learning/chapter-8/pt.png'
      },
      {
        id: '1291532470682686939',
        title: 'Quiz - 1',
        imageBanner: 'assets/img/micro-learning/chapter-8/activity-1.png'
      },
      {
        id: '1291532408724257079',
        title: 'Crossword',
        imageBanner: 'assets/img/micro-learning/chapter-8/activity-2.png'
      },
      {
        id: '1291532464404377699',
        title: 'Image Sequencing',
        imageBanner: 'assets/img/micro-learning/chapter-8/activity-3.png'
      }
    ],
    10: [
      {
        id: '1291527526363047939',
        title: 'Flow',
        imageBanner: 'assets/img/micro-learning/chapter-7/flow.png'
      },
      {
        id: '1291522039864692159',
        title: 'Quiz - 1',
        imageBanner: 'assets/img/micro-learning/chapter-7/activity-1.png'
      },
      {
        id: '1291522164669572449',
        title: 'Quiz - 2',
        imageBanner: 'assets/img/micro-learning/chapter-7/activity-2.png'
      },
      {
        id: '1291522172949980109',
        title: 'Flashcards',
        imageBanner: 'assets/img/micro-learning/chapter-7/activity-3.png'
      },
      {
        id: '1291522175363101109',
        title: 'Choose & Pick',
        imageBanner: 'assets/img/micro-learning/chapter-7/activity-4.png'
      },
      {
        id: '1291522169481023999',
        title: 'Crossword',
        imageBanner: 'assets/img/micro-learning/chapter-7/activity-5.png'
      },
      {
        id: '1291522168092118149',
        title: 'Image Sequencing',
        imageBanner: 'assets/img/micro-learning/chapter-7/activity-6.png'
      }
    ],
    11: [
      {
        id: '1291632590554642309',
        title: 'Memory Palace',
        imageBanner: 'assets/img/micro-learning/memory-palace.png'
      },
      {
        id: '1291617918175548129',
        title: 'Image Sequencing',
        imageBanner: 'assets/img/micro-learning/image-choice-1.png'
      },
      {
        id: '1291617919529179829',
        title: 'Crossword',
        imageBanner: 'assets/img/micro-learning/crossword-1.png'
      },
      {
        id: '1291617921318952369',
        title: 'Memory Game',
        imageBanner: 'assets/img/micro-learning/memory-game.png'
      },
      {
        id: '1291617924204559349',
        title: 'Quiz - 1',
        imageBanner: 'assets/img/micro-learning/question-set-1.png'
      },
      {
        id: '1291617929117508609',
        title: 'Quiz - 2',
        imageBanner: 'assets/img/micro-learning/question-set-2.png'
      },
      {
        id: '1291617936326982319',
        title: 'Image Pairing',
        imageBanner: 'assets/img/micro-learning/image-choice-1.png'
      }
    ],
    12: [
      {
        id: '1291632635928299919',
        title: 'Growth Mindset',
        imageBanner: 'assets/img/micro-learning/growth-mindset.png'
      },
      {
        id: '1291615337535013669',
        title: 'Quiz',
        imageBanner: 'assets/img/micro-learning/question-set-1.png'
      },
      {
        id: '1291632746654415579',
        title: 'Flashcards',
        imageBanner: 'assets/img/micro-learning/image-choice-1.png'
      },
      {
        id: '1291632634961914409',
        title: 'Image Pairing',
        imageBanner: 'assets/img/micro-learning/image-choice-4.png'
      },
      {
        id: '1291632669597166049',
        title: 'Drag the Words',
        imageBanner: 'assets/img/micro-learning/drag-words.png'
      },
      {
        id: '1291632689427390909',
        title: 'Choose & Pick - 1',
        imageBanner: 'assets/img/micro-learning/image-choice-2.png'
      },
      {
        id: '1291632690986141139',
        title: 'Choose & Pick - 2',
        imageBanner: 'assets/img/micro-learning/image-choice-3.png'
      },
      {
        id: '1291615342736760059',
        title: 'Crossword',
        imageBanner: 'assets/img/micro-learning/crossword-1.png'
      }
    ],
    13: [
      {
        id: '1291612750065341239',
        title: 'Eisenhower Matrix',
        imageBanner: 'assets/img/micro-learning/eisenhower-matrix.png'
      },
      {
        id: '1291521161799881069',
        title: 'Quiz - 1',
        imageBanner: 'assets/img/micro-learning/question-set-1.png'
      },
      {
        id: '1291521340363498319',
        title: 'Drag and Drop',
        imageBanner: 'assets/img/micro-learning/drag-drop.png'
      },
      {
        id: '1291521163549586549',
        title: 'Crossword',
        imageBanner: 'assets/img/micro-learning/crossword-1.png'
      },
      {
        id: '1291521165209604469',
        title: 'Image Sequencing',
        imageBanner: 'assets/img/micro-learning/image-choice-1.png'
      },
      {
        id: '1291521167530300809',
        title: 'Memory Game',
        imageBanner: 'assets/img/micro-learning/memory-game.png'
      },
      {
        id: '1291521176763304669',
        title: 'Quiz - 2',
        imageBanner: 'assets/img/micro-learning/question-set-2.png'
      },
      {
        id: '1291521185137653439',
        title: 'Quiz - 3',
        imageBanner: 'assets/img/micro-learning/image-choice-2.png'
      }
    ],
    14: [
      {
        id: '1291551739211949809',
        title: 'Power of Now',
        imageBanner: 'assets/img/micro-learning/chapter-9/pow.png'
      },
      {
        id: '1291533260766066109',
        title: 'Crossword',
        imageBanner: 'assets/img/micro-learning/chapter-9/activity-1.png'
      },
      {
        id: '1291533263107317409',
        title: 'Image Sequencing',
        imageBanner: 'assets/img/micro-learning/chapter-9/activity-2.png'
      },
      {
        id: '1291533264093448739',
        title: 'Memory Game',
        imageBanner: 'assets/img/micro-learning/chapter-9/activity-3.png'
      },
      {
        id: '1291533339732620949',
        title: 'Quiz-1',
        imageBanner: 'assets/img/micro-learning/chapter-9/activity-4.png'
      },
      {
        id: '1291533358602664959',
        title: 'Quiz-2',
        imageBanner: 'assets/img/micro-learning/chapter-9/activity-5.png'
      },
      {
        id: '1291533516591897589',
        title: 'Quiz-3',
        imageBanner: 'assets/img/micro-learning/chapter-9/activity-6.png'
      },
      {
        id: '1291534293203006839',
        title: 'Personality Quiz',
        imageBanner: 'assets/img/micro-learning/chapter-9/activity-7.jpg'
      }
    ],
    15: [
      {
        id: '1291632824840791919',
        title: 'Feynman Technique',
        imageBanner: 'assets/img/micro-learning/feynman-technique.png'
      },
      {
        id: '1291632696161190649',
        title: 'Quiz-1',
        imageBanner: 'assets/img/micro-learning/question-set-1.png'
      },
      {
        id: '1291632690031255509',
        title: 'Image Sequencing',
        imageBanner: 'assets/img/micro-learning/image-choice-2.png'
      },
      {
        id: '1291632700879500589',
        title: 'Flashcards',
        imageBanner: 'assets/img/micro-learning/image-choice-1.png'
      },
      {
        id: '1291632702448404409',
        title: 'Quiz-2',
        imageBanner: 'assets/img/micro-learning/question-set-2.png'
      },
      {
        id: '1291632704386046459',
        title: 'Crossword',
        imageBanner: 'assets/img/micro-learning/crossword-1.png'
      },
      {
        id: '1291632705859247069',
        title: 'Choose & Pick',
        imageBanner: 'assets/img/micro-learning/image-choice-3.png'
      },
      {
        id: '1291632744491032259',
        title: 'Quiz-3',
        imageBanner: 'assets/img/micro-learning/question-set-3.png'
      },
      {
        id: '1291632706042554929',
        title: 'Memory Game',
        imageBanner: 'assets/img/micro-learning/memory-game.png'
      }
    ],
    16: [
      {
        id: '1291554825292236119',
        title: 'Excellence Formula',
        imageBanner: 'assets/img/micro-learning/chapter-10/ef.png'
      },
      {
        id: '1291554862419686549',
        title: 'Choose & Pick',
        imageBanner: 'assets/img/micro-learning/chapter-10/activity-1.png'
      },
      {
        id: '1291554865967692729',
        title: 'Quiz-1',
        imageBanner: 'assets/img/micro-learning/chapter-10/activity-2.png'
      },
      {
        id: '1291554886671537569',
        title: 'Flashcards',
        imageBanner: 'assets/img/micro-learning/chapter-10/activity-3.png'
      },
      {
        id: '1291556668041074319',
        title: 'Quiz-2',
        imageBanner: 'assets/img/micro-learning/chapter-10/activity-4.png'
      },
      {
        id: '1291556682541011079',
        title: 'Image Sequencing',
        imageBanner: 'assets/img/micro-learning/chapter-10/activity-5.png'
      }
    ],
    17: [
      {
        id: '1291638660015188479',
        title: 'Think like a scientist',
        imageBanner: 'assets/img/micro-learning/think-scientist.png'
      },
      {
        id: '1291632866354823479',
        title: 'Quiz - 1',
        imageBanner: 'assets/img/micro-learning/question-set-1.png'
      },
      {
        id: '1291632868535623039',
        title: 'Crossword',
        imageBanner: 'assets/img/micro-learning/crossword-1.png'
      },
      {
        id: '1291632907960585819',
        title: 'Quiz - 2',
        imageBanner: 'assets/img/micro-learning/question-set-2.png'
      },
      {
        id: '1291632929895965619',
        title: 'Flashcards',
        imageBanner: 'assets/img/micro-learning/image-choice-1.png'
      },
      {
        id: '1291632944572063749',
        title: 'Quiz - 3',
        imageBanner: 'assets/img/micro-learning/question-set-3.png'
      },
      {
        id: '1291632956374551519',
        title: 'Memory Game',
        imageBanner: 'assets/img/micro-learning/memory-game.png'
      }
    ],
    18: [
      {
        id: '1291638660740230949',
        title: 'Curiosity did not kill the cat',
        imageBanner: 'assets/img/micro-learning/curiosity.png'
      },
      {
        id: '1291637138520868249',
        title: 'Quiz - 1',
        imageBanner: 'assets/img/micro-learning/question-set-1.png'
      },
      {
        id: '1291637141347695359',
        title: 'Crossword',
        imageBanner: 'assets/img/micro-learning/crossword-1.png'
      },
      {
        id: '1291637149063520149',
        title: 'Choose & Pick',
        imageBanner: 'assets/img/micro-learning/image-choice-2.png'
      },
      {
        id: '1291637161653128649',
        title: 'Quiz - 2',
        imageBanner: 'assets/img/micro-learning/question-set-2.png'
      },
      {
        id: '1291637326249447129',
        title: 'Memory Game',
        imageBanner: 'assets/img/micro-learning/memory-game.png'
      },
      {
        id: '1291637335668182849',
        title: 'Quiz - 3',
        imageBanner: 'assets/img/micro-learning/question-set-3.png'
      },
      {
        id: '1291637340382250519',
        title: 'Flashcards',
        imageBanner: 'assets/img/micro-learning/image-choice-1.png'
      }
    ],
    19: [
      {
        id: '1291638661600340279',
        title: 'Thought experiments',
        imageBanner: 'assets/img/micro-learning/thought-experiment.png'
      },
      {
        id: '1291632967960519449',
        title: 'Quiz - 1',
        imageBanner: 'assets/img/micro-learning/question-set-1.png'
      },
      {
        id: '1291632971837039649',
        title: 'Image Pairing',
        imageBanner: 'assets/img/micro-learning/image-choice-2.png'
      },
      {
        id: '1291632974068286549',
        title: 'Crossword',
        imageBanner: 'assets/img/micro-learning/crossword-1.png'
      },
      {
        id: '1291632976372962709',
        title: 'Choose & Pick',
        imageBanner: 'assets/img/micro-learning/image-choice-3.png'
      },
      {
        id: '1291632986493469539',
        title: 'Quiz - 2',
        imageBanner: 'assets/img/micro-learning/question-set-2.png'
      },
      {
        id: '1291632988049509579',
        title: 'Memory Game',
        imageBanner: 'assets/img/micro-learning/memory-game.png'
      }
    ],
    20: [
      {
        id: '1291638662287225049',
        title: 'Learning formula',
        imageBanner: 'assets/img/micro-learning/learning-formula.png'
      },
      {
        id: '1291637823699704479',
        title: 'Choose & Pick - 1',
        imageBanner: 'assets/img/micro-learning/image-choice-1.png'
      },
      {
        id: '1291637829545729309',
        title: 'Quiz - 1',
        imageBanner: 'assets/img/micro-learning/question-set-1.png'
      },
      {
        id: '1291637833014100769',
        title: 'Flashcards',
        imageBanner: 'assets/img/micro-learning/image-choice-2.png'
      },
      {
        id: '1291637839170275259',
        title: 'Quiz - 2',
        imageBanner: 'assets/img/micro-learning/question-set-2.png'
      },
      {
        id: '1291637842874075089',
        title: 'Choose & Pick - 2',
        imageBanner: 'assets/img/micro-learning/image-choice-3.png'
      },
      {
        id: '1291637821623514909',
        title: 'Quiz - 3',
        imageBanner: 'assets/img/micro-learning/question-set-3.png'
      },
      {
        id: '1291637904290098039',
        title: 'Quiz - 4',
        imageBanner: 'assets/img/micro-learning/question-set-4.png'
      }
    ]
  }
};
export const QUEST_LAYOUT = {
  LAYOUTS: {
    1: [
      {isAnchor: true, isExtra: false},
      {isAnchor: false, isExtra: false},
      {
        isAnchor: true,
        isExtra: true,
        imageBanner: 'assets/img/micro-learning/sun.png',
        className: 'grid-img--floated grid-img--floated-top-right'
      },
      {isAnchor: false, isExtra: false},
      {isAnchor: true, isExtra: false},
      {isAnchor: true, isExtra: false},
      {isAnchor: true, isExtra: false},
      {isAnchor: true, isExtra: false},
      {
        isAnchor: false,
        isExtra: true,
        imageBanner: 'assets/img/micro-learning/rocket.png',
        className: 'grid-img--floated grid-img--floated-top-left'
      },
      {isAnchor: false, isExtra: false},
      {
        isAnchor: true,
        isExtra: true,
        imageBanner: 'assets/img/micro-learning/dartboard.png',
        className: 'grid-img--floated grid-img--floated-top-left'
      },
      {isAnchor: false, isExtra: false},
      {isAnchor: true, isExtra: false},
      {isAnchor: false, isExtra: false},
      {isAnchor: true, isExtra: false},
      {
        isAnchor: true,
        isExtra: true,
        imageBanner: 'assets/img/micro-learning/telescope.png',
        className: 'grid-img--floated grid-img--floated-top-left'
      },
      {isAnchor: true, isExtra: false},
      {
        isAnchor: true,
        isExtra: true,
        imageBanner: 'assets/img/play-ico.png',
        className: 'd-block py-2 w-25'
      }
    ],
    2: [
      {isAnchor: true, isExtra: false},
      {isAnchor: true, isExtra: false},
      {isAnchor: false, isExtra: false},
      {isAnchor: true, isExtra: false},
      {isAnchor: false, isExtra: false},
      {
        isAnchor: false,
        isExtra: true,
        imageBanner: 'assets/img/micro-learning/sun.png',
        className: 'grid-img--floated grid-img--floated-top-left'
      },
      {isAnchor: true, isExtra: false},
      {isAnchor: false, isExtra: false},
      {isAnchor: false, isExtra: false},
      {isAnchor: true, isExtra: false},
      {
        isAnchor: false,
        isExtra: true,
        imageBanner: 'assets/img/micro-learning/dartboard.png',
        className: 'grid-img--floated grid-img--floated-top-left'
      },
      {isAnchor: true, isExtra: false},
      {isAnchor: false, isExtra: false},
      {
        isAnchor: true,
        isExtra: true,
        imageBanner: 'assets/img/micro-learning/layout-2/Bitmap Copy 6.png',
        className: 'quest-item-img'
      }
    ]
  },
  QUEST_CHAPTERS: [
    {
      id: 1,
      title: 'The Story of Time',
      description: 'Years within a Year! Where does it all start from and how old is Samay?',
      imageBanner: 'assets/img/micro-learning/sm-banner-1.png',
      isExplore: true,
      layout: 1,
      h5pContentKey: 1
    },
    {
      id: 2,
      title: 'Finding your Rhythm',
      description: 'Did you know you’ve your own personalised clock? Dig in to know if you’re Team Lark or Team owl!',
      imageBanner: 'assets/img/micro-learning/sm-banner-2.png',
      isExplore: true,
      layout: 1,
      h5pContentKey: 2
    },
    {
      id: 3,
      title: 'Time is Energy',
      description: 'Do you know there is a way you can "build" time? Learn the 4 secrets of managing your energy wisely.',
      imageBanner: 'assets/img/micro-learning/sm-banner-3.png',
      isExplore: true,
      layout: 2,
      h5pContentKey: 3
    },
    {
      id: 4,
      title: 'Focus Pocus',
      description: 'Revealing all the Virat Kohli’s secrets! What’s more? A three step guideline to be modern day Arjuna!',
      imageBanner: 'assets/img/micro-learning/sm-banner-4.png',
      isExplore: true,
      layout: 1,
      h5pContentKey: 4
    },
    {
      id: 5,
      title: 'Procrasti-NATION',
      description: 'Hacks to get out of procrasti-NATION! And it’s scientifically proven that eating a frog can save your day! Tap to know more!',
      imageBanner: 'assets/img/micro-learning/sm-banner-5.png',
      isExplore: true,
      layout: 1,
      h5pContentKey: 5
    },
    {
      id: 6,
      title: 'Eat the frog',
      description: 'Eat a live frog first thing in the morning and nothing worse will happen to you the rest of the day.',
      imageBanner: 'assets/img/micro-learning/sm-banner-6.png',
      isExplore: true,
      layout: 2,
      h5pContentKey: 6
    },
    {
      id: 7,
      title: 'Flow',
      description: 'Have you been in the Zone where Time stands still, yet Time flies?',
      imageBanner: 'assets/img/micro-learning/sm-banner-7.png',
      isExplore: true,
      layout: 2,
      h5pContentKey: 7
    },
    {
      id: 8,
      title: 'Pomodoro Technique',
      description: 'Do you work smart or do you work hard?',
      imageBanner: 'assets/img/micro-learning/sm-banner-8.png',
      isExplore: true,
      layout: 2,
      h5pContentKey: 8
    },
    {
      id: 9,
      title: 'Power of Now',
      description: 'Have you ever wondered how long is \'Now\'? Watch and find out!',
      imageBanner: 'assets/img/micro-learning/sm-banner-9.png',
      isExplore: true,
      layout: 1,
      h5pContentKey: 9
    },
    {
      id: 10,
      title: 'Excellence Formula',
      description: 'Samay\'s formula for excellence',
      imageBanner: 'assets/img/micro-learning/sm-banner-10.png',
      isExplore: true,
      layout: 2,
      h5pContentKey: 10
    }
  ],
  H5P_CONTENT_LIST: {
    1: [
      {
        id: '1291481560005861619',
        title: 'The Story of Time',
        description: 'Start this topic with this interesting video',
        imageBanner: 'assets/img/micro-learning/chapter-1/sot.png'
      },
      {
        id: '1291492612656358949',
        title: 'Quiz - 1',
        description: 'Answer the total 6 questions',
        imageBanner: 'assets/img/micro-learning/chapter-1/activity-1.png'
      },
      {
        id: '1291492637008531489',
        title: 'Quiz - 2',
        description: 'Answer the total 6 questions',
        imageBanner: 'assets/img/micro-learning/chapter-1/activity-2.png'
      },
      {
        id: '1291492650098761839',
        title: 'Quiz - 3',
        description: 'Answer the total 6 questions',
        imageBanner: 'assets/img/micro-learning/chapter-1/activity-3.png'
      },
      {
        id: '1291481649119511979',
        title: 'Find the Missing Word',
        description: 'Find the and place the missing words',
        imageBanner: 'assets/img/micro-learning/chapter-1/activity-4.png'
      },
      {
        id: '1291481630810284669',
        title: 'Image Pairing',
        description: 'Drag the corresponding images',
        imageBanner: 'assets/img/micro-learning/chapter-1/activity-5.png'
      },
      {
        id: '1291492756279454459',
        title: 'Events before December',
        description: 'Find all the events before December',
        imageBanner: 'assets/img/micro-learning/chapter-1/activity-6.png'
      },
      {
        id: '1291492804393580059',
        title: 'Events in December',
        description: 'Find all the events in December',
        imageBanner: 'assets/img/micro-learning/chapter-1/activity-6-1.png'
      },
      {
        id: '1291492782985539669',
        title: 'Image Sequencing',
        description: 'Order the image from start to end',
        imageBanner: 'assets/img/micro-learning/chapter-1/activity-7.png'
      },
      {
        id: '1291492747008974039',
        title: 'Crossword',
        description: 'Create the words',
        imageBanner: 'assets/img/micro-learning/chapter-1/activity-8.png'
      },
      {
        id: '1291492759585384359',
        title: 'Drag the Words',
        description: 'Drag and drop the correct word in correct place',
        imageBanner: 'assets/img/micro-learning/chapter-1/activity-9.png'
      },
      {
        id: '1291504978499436499',
        title: 'Memory Game',
        description: 'Remember and match the image',
        imageBanner: 'assets/img/micro-learning/chapter-1/activity-10.png'
      }
    ],
    2: [
      {
        id: '1291510180127521969',
        title: 'Finding your Rhythm',
        description: 'Start this topic with this interesting video',
        imageBanner: 'assets/img/micro-learning/chapter-2/fyr.png'
      },
      {
        id: '1291504712132084639',
        title: 'Quiz - 1',
        description: 'Answer the total 6 questions',
        imageBanner: 'assets/img/micro-learning/chapter-2/activity-1.png'
      },
      {
        id: '1291506546018741519',
        title: 'Quiz - 2',
        description: 'Answer the total 6 questions',
        imageBanner: 'assets/img/micro-learning/chapter-2/activity-2.png'
      },
      {
        id: '1291506565460262519',
        title: 'Quiz - 3',
        description: 'Answer the total 6 questions',
        imageBanner: 'assets/img/micro-learning/chapter-2/activity-3.png'
      },
      {
        id: '1291506574228260489',
        title: 'Find the Missing Word',
        description: 'Find the and place the missing words',
        imageBanner: 'assets/img/micro-learning/chapter-2/activity-4.png'
      },
      {
        id: '1291506646251711029',
        title: 'Image Pairing',
        description: 'Drag the corresponding images',
        imageBanner: 'assets/img/micro-learning/chapter-2/activity-5.png'
      },
      {
        id: '1291506571349918259',
        title: 'Crossword',
        description: 'Create the words',
        imageBanner: 'assets/img/micro-learning/chapter-2/activity-6.png'
      },
      {
        id: '1291506639541072839',
        title: 'Image Sequencing',
        description: 'Order the image from start to end',
        imageBanner: 'assets/img/micro-learning/chapter-2/activity-7.png'
      },
      {
        id: '1291506674329752609',
        title: 'Choose & Pick - 1',
        description: 'Choose the correct image',
        imageBanner: 'assets/img/micro-learning/chapter-2/activity-8.png'
      },
      {
        id: '1291506667227574319',
        title: 'Choose & Pick - 2',
        description: 'Choose the correct image',
        imageBanner: 'assets/img/micro-learning/chapter-2/activity-9.png'
      },
      {
        id: '1291506576643153359',
        title: 'Memory Game',
        description: 'Remember and match the image',
        imageBanner: 'assets/img/micro-learning/chapter-2/activity-10.png'
      },
      // {
      //   id: '1291506600131532789',
      //   title: 'Drag and Drop',
      //   imageBanner: 'assets/img/micro-learning/chapter-2/activity-11.png'
      // }
    ],
    3: [
      {
        id: '1291512636238440229',
        title: 'Time is Energy',
        description: 'Start this topic with this interesting video',
        imageBanner: 'assets/img/micro-learning/chapter-3/te.png'
      },
      {
        id: '1291511639056124289',
        title: 'Choose & Pick - 1',
        description: 'Choose the correct image',
        imageBanner: 'assets/img/micro-learning/chapter-3/activity-1.png'
      },
      {
        id: '1291511643901218679',
        title: 'Quiz - 2',
        description: 'Answer the total 6 questions',
        imageBanner: 'assets/img/micro-learning/chapter-3/activity-2.png'
      },
      {
        id: '1291511646871797729',
        title: 'Crossword',
        description: 'Create the words',
        imageBanner: 'assets/img/micro-learning/chapter-3/activity-3.png'
      },
      {
        id: '1291511649046888269',
        title: 'Choose & Pick - 2',
        description: 'Choose the correct image',
        imageBanner: 'assets/img/micro-learning/chapter-3/activity-4.png'
      },
      {
        id: '1291508529289980079',
        title: 'Choose & Pick - 3',
        description: 'Choose the correct image',
        imageBanner: 'assets/img/micro-learning/chapter-3/activity-5.png'
      }
    ],
    4: [
      {
        id: '1291514353991963599',
        title: 'Focus Pocus',
        description: 'Start this topic with this interesting video',
        imageBanner: 'assets/img/micro-learning/chapter-4/fp.png'
      },
      {
        id: '1291511055872442639',
        title: 'Memory Game',
        description: 'Remember and match the image',
        imageBanner: 'assets/img/micro-learning/chapter-4/activity-1.png'
      },
      {
        id: '1291510857173622069',
        title: 'Crossword',
        description: 'Create the words',
        imageBanner: 'assets/img/micro-learning/chapter-4/activity-2.png'
      },
      {
        id: '1291510881891045329',
        title: 'Personality Quiz',
        description: 'Answer the total 6 questions',
        imageBanner: 'assets/img/micro-learning/chapter-4/activity-3.png'
      },
      {
        id: '1291510898413868209',
        title: 'Quiz - 4',
        description: 'Answer the total 6 questions',
        imageBanner: 'assets/img/micro-learning/chapter-4/activity-4.png'
      },
      {
        id: '1291511108813871809',
        title: 'Quiz - 5',
        description: 'Choose the correct image',
        imageBanner: 'assets/img/micro-learning/chapter-4/activity-5.png'
      },
      {
        id: '1291511060240137519',
        title: 'Crossword',
        description: 'Create the words',
        imageBanner: 'assets/img/micro-learning/chapter-4/activity-6.png'
      },
      {
        id: '1291511624971691659',
        title: 'Image Sequencing',
        description: 'Order the image from start to end',
        imageBanner: 'assets/img/micro-learning/chapter-4/activity-7.png'
      },
      {
        id: '1291511111867412989',
        title: 'Quiz - 8',
        description: 'Choose the correct image',
        imageBanner: 'assets/img/micro-learning/chapter-4/activity-8.png'
      },
      {
        id: '1291511136669756559',
        title: 'Choose & Pick',
        description: 'Choose the correct image',
        imageBanner: 'assets/img/micro-learning/chapter-4/activity-9.png'
      }
    ],
    5: [
      {
        id: '1291520274415678019',
        title: 'Procrasti-NATION',
        description: 'Start this topic with this interesting video',
        imageBanner: 'assets/img/micro-learning/chapter-5/pn.png'
      },
      {
        id: '1291520375813213879',
        title: 'Quiz - 1',
        description: 'Answer the total 6 questions',
        imageBanner: 'assets/img/micro-learning/chapter-5/activity-1.png'
      },
      {
        id: '1291520378236479029',
        title: 'Crossword - 1',
        description: 'Find and place the total 8 words',
        imageBanner: 'assets/img/micro-learning/chapter-5/activity-2.png'
      },
      {
        id: '1291520386703777689',
        title: 'Flashcards',
        description: 'Guess the right answer',
        imageBanner: 'assets/img/micro-learning/chapter-5/activity-3.png'
      },
      {
        id: '1291520392082752819',
        title: 'Crossword - 2',
        description: 'Find and place the total 10 words',
        imageBanner: 'assets/img/micro-learning/chapter-5/activity-4.png'
      },
      {
        id: '1291520400441430309',
        title: 'Quiz - 2',
        description: 'Answer the total 6 questions',
        imageBanner: 'assets/img/micro-learning/chapter-5/activity-5.png'
      },
      {
        id: '1291520425868105599',
        title: 'Quiz - 3',
        description: 'Answer the total 6 questions',
        imageBanner: 'assets/img/micro-learning/chapter-5/activity-6.png'
      },
      {
        id: '1291520428257244239',
        title: 'Memory Game',
        description: 'Remember and match the image',
        imageBanner: 'assets/img/micro-learning/chapter-5/activity-7.png'
      },
      {
        id: '1291520430293269079',
        title: 'Choose & Pick',
        description: 'Choose the correct image',
        imageBanner: 'assets/img/micro-learning/chapter-5/activity-8.png'
      }
    ],
    6: [
      {
        id: '1291520271192400909',
        title: 'Eat the frog',
        description: 'Start this topic with this interesting video',
        imageBanner: 'assets/img/micro-learning/chapter-6/etf.png'
      },
      {
        id: '1291511657126367679',
        title: 'Drag the Words',
        description: 'Drag and drop the correct word in correct place',
        imageBanner: 'assets/img/micro-learning/chapter-6/activity-1.png'
      },
      {
        id: '1291511669991234709',
        title: 'Quiz - 1',
        description: 'Answer the total 6 questions',
        imageBanner: 'assets/img/micro-learning/chapter-6/activity-2.png'
      },
      {
        id: '1291511654277718659',
        title: 'Memory Game',
        description: 'Remember and match the image',
        imageBanner: 'assets/img/micro-learning/chapter-6/activity-3.png'
      },
      {
        id: '1291511955766731989',
        title: 'Personality Quiz',
        description: 'Answer the total 15 questions',
        imageBanner: 'assets/img/micro-learning/chapter-6/activity-4.png'
      }
    ],
    7: [
      {
        id: '1291527526363047939',
        title: 'Flow',
        description: 'Start this topic with this interesting video',
        imageBanner: 'assets/img/micro-learning/chapter-7/flow.png'
      },
      {
        id: '1291522039864692159',
        title: 'Quiz - 1',
        description: 'Answer the total 6 questions',
        imageBanner: 'assets/img/micro-learning/chapter-7/activity-1.png'
      },
      {
        id: '1291522164669572449',
        title: 'Quiz - 2',
        description: 'Answer the total 6 questions',
        imageBanner: 'assets/img/micro-learning/chapter-7/activity-2.png'
      },
      {
        id: '1291522172949980109',
        title: 'Flashcards',
        description: 'Guess the right answer',
        imageBanner: 'assets/img/micro-learning/chapter-7/activity-3.png'
      },
      {
        id: '1291522175363101109',
        title: 'Choose & Pick',
        description: 'Choose the correct image',
        imageBanner: 'assets/img/micro-learning/chapter-7/activity-4.png'
      },
      {
        id: '1291522169481023999',
        title: 'Crossword',
        description: 'Find and place the total 6 words',
        imageBanner: 'assets/img/micro-learning/chapter-7/activity-5.png'
      },
      {
        id: '1291522168092118149',
        title: 'Image Sequencing',
        description: 'Sequence the steps to get to the flow state of mind',
        imageBanner: 'assets/img/micro-learning/chapter-7/activity-6.png'
      }
    ],
    8: [
      {
        id: '1291530701361422089',
        title: 'Pomodoro Technique',
        description: 'Start this topic with this interesting video',
        imageBanner: 'assets/img/micro-learning/chapter-8/pt.png'
      },
      {
        id: '1291532470682686939',
        title: 'Quiz - 1',
        description: 'Answer the total 6 questions',
        imageBanner: 'assets/img/micro-learning/chapter-8/activity-1.png'
      },
      {
        id: '1291532408724257079',
        title: 'Crossword',
        description: 'Find and place the total 6 words',
        imageBanner: 'assets/img/micro-learning/chapter-8/activity-2.png'
      },
      {
        id: '1291532464404377699',
        title: 'Image Sequencing',
        description: 'Sequence the steps to get to the flow state of mind',
        imageBanner: 'assets/img/micro-learning/chapter-8/activity-3.png'
      }
    ],
    9: [
      {
        id: '1291551739211949809',
        title: 'Power of Now',
        description: 'Start this topic with this interesting video',
        imageBanner: 'assets/img/micro-learning/chapter-9/pow.png'
      },
      {
        id: '1291533260766066109',
        title: 'Crossword',
        description: 'Find and place the total 8 words',
        imageBanner: 'assets/img/micro-learning/chapter-9/activity-1.png'
      },
      {
        id: '1291533263107317409',
        title: 'Image Sequencing',
        description: 'Sequence the steps to get to the flow state of mind',
        imageBanner: 'assets/img/micro-learning/chapter-9/activity-2.png'
      },
      {
        id: '1291533264093448739',
        title: 'Memory Game',
        description: 'Remember and match the image',
        imageBanner: 'assets/img/micro-learning/chapter-9/activity-3.png'
      },
      {
        id: '1291533339732620949',
        title: 'Quiz-1',
        description: 'Answer the total 7 questions',
        imageBanner: 'assets/img/micro-learning/chapter-9/activity-4.png'
      },
      {
        id: '1291533358602664959',
        title: 'Quiz-2',
        description: 'Answer the total 10 questions',
        imageBanner: 'assets/img/micro-learning/chapter-9/activity-5.png'
      },
      {
        id: '1291533516591897589',
        title: 'Quiz-3',
        description: 'Answer the total 9 questions',
        imageBanner: 'assets/img/micro-learning/chapter-9/activity-6.png'
      },
      {
        id: '1291534293203006839',
        title: 'Personality Quiz',
        description: 'Answer the total 18 questions',
        imageBanner: 'assets/img/micro-learning/chapter-9/activity-7.jpg'
      }
    ],
    10: [
      {
        id: '1291554825292236119',
        title: 'Excellence Formula',
        description: 'Start this topic with this interesting video',
        imageBanner: 'assets/img/micro-learning/chapter-10/ef.png'
      },
      {
        id: '1291554862419686549',
        title: 'Choose & Pick',
        description: 'Choose the correct image',
        imageBanner: 'assets/img/micro-learning/chapter-10/activity-1.png'
      },
      {
        id: '1291554865967692729',
        title: 'Quiz-1',
        description: 'Answer the total 5 questions',
        imageBanner: 'assets/img/micro-learning/chapter-10/activity-2.png'
      },
      {
        id: '1291554886671537569',
        title: 'Flashcards',
        description: 'Guess the right answer',
        imageBanner: 'assets/img/micro-learning/chapter-10/activity-3.png'
      },
      {
        id: '1291556668041074319',
        title: 'Quiz-2',
        description: 'Answer the total 5 questions',
        imageBanner: 'assets/img/micro-learning/chapter-10/activity-4.png'
      },
      {
        id: '1291556682541011079',
        title: 'Image Sequencing',
        description: 'Sequence the steps to get to the flow state of mind',
        imageBanner: 'assets/img/micro-learning/chapter-10/activity-5.png'
      }
    ]
  }
};
export const SOCKET_EVENTS = {
  ONLINE_USERS: 'online-users',
  SEND_MESSAGE: 'pvt-send-message',
  RECEIVE_MESSAGE: 'pvt-new-message',
  CONNECT_ERROR: 'connect_error'
};
export const ALLOWED_FILE_TYPES = {
  IMAGE: ['image/jpeg', 'image/png', 'image/svg+xml', 'image/webp', 'image/gif', 'image/tiff','image'],
  AUDIO: ['audio/mp3', 'audio/mp4', 'audio/mpeg', 'audio/webm'],
  VIDEO: ['video/mp4', 'video/avi', 'video/quicktime', 'video/webm', 'video/mpeg'],
  DOCUMENT: ['application/pdf', 'text/plain', 'text/html', '.doc', '.docx','.ppt','.pptx', '.xls', '.xlsx','.csv', 'application/vnd.ms-excel', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document','application/vnd.ms-powerpoint','application/vnd.openxmlformats-officedocument.presentationml.presentation'],
  EXCEL : ['.xlsx','.csv', 'application/vnd.ms-excel', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet','text/csv'],
  CSV : ['.csv', 'application/vnd.ms-excel', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet','text/csv']
};
export const MAIN_MODULE_URL = {
  ADMIN: '/auth/admin',
  STUDENT: '/auth/student',
  ONBOARD: '/onboard'
};
export const CHAT_TYPE = {
  ONE_TO_ONE: 'one-to-one',
  GROUP: 'group'
};
export const TESTIMONIALS_SLIDES = [
  {
    id: 1,
    type: 'video',
    url: 'https://dot-expressbucket-dev-apsouth1.s3.ap-south-1.amazonaws.com/uploads/VID-20220809-WA0002.mp4'
  }
];

export const TEACHER_ROW=[
      { role_name: 'Teachers Materials ',
        image_d_name: 'Materials',
        role_img: 'assets/img/trending-0.png',
        role_img_url: 'https://dotxtestbucketdileep.s3.amazonaws.com/uploads/activity/246a23ba-6a53-11ed-9abe-18037320ecf1.jpg',
        role_imgPlan: 'assets/img/trending-0.png',
        role_img_plan_url: "https://dotxtestbucketdileep.s3.amazonaws.com/uploads/lesson_document/3f24f9b6-c95b-11ed-ab5b-18037320ecf1.pdf",
        displayName:'Materials 1'
      },
      { role_name: 'Teachers Lesson Plan',
        image_d_name: 'Materials 2',
        role_img: 'assets/img/trending-0.png',
        role_img_url: 'https://dotxtestbucketdileep.s3.amazonaws.com/uploads/activity/246a23ba-6a53-11ed-9abe-18037320ecf1.jpg',
        role_imgPlan: 'assets/img/trending-0.png',
        role_img_plan_url: "https://dotxtestbucketdileep.s3.amazonaws.com/uploads/lesson_document/3f24f9b6-c95b-11ed-ab5b-18037320ecf1.pdf",
        displayName:'Materials 2'
      }
    ]
export const STUDENT_ROW=[
    { role_name: 'student Materials',
      image_d_name: 'Materials 1',
      role_img: 'assets/img/trending-0.png',
      role_img_url: 'https://dotxtestbucketdileep.s3.amazonaws.com/uploads/activity/246a23ba-6a53-11ed-9abe-18037320ecf1.jpg',
      role_imgPlan: 'assets/img/trending-0.png',
      role_img_plan_url: "https://dotxtestbucketdileep.s3.amazonaws.com/uploads/lesson_document/3f24f9b6-c95b-11ed-ab5b-18037320ecf1.pdf",
      displayName:'Materials 1'
    },
    { role_name: 'student Materials',
      image_d_name: 'Materials 2',
      role_img: 'assets/img/trending-0.png',
      role_img_url: 'https://dotxtestbucketdileep.s3.amazonaws.com/uploads/activity/246a23ba-6a53-11ed-9abe-18037320ecf1.jpg',
      role_imgPlan: 'assets/img/trending-0.png',
      role_img_plan_url: "https://dotxtestbucketdileep.s3.amazonaws.com/uploads/lesson_document/3f24f9b6-c95b-11ed-ab5b-18037320ecf1.pdf",
      displayName:'Materials 2'
    }
  ]
