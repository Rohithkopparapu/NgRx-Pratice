export const DATE_FORMAT = 'yyyy-MM-dd';
export const DATE_FORMAT_MOMENT = 'DD-MM-YYYY';
export const DATE_TIME_FORMAT = 'yyyy-MM-ddTHH:mm';
export const TIME_FORMAT = 'HH:mm';
export const ZONED_DATE_TIME_FORMAT = 'YYYY-MM-DDTHH:mm:ssZ';
export const DATE_TIME_DATE_PICKER_FORMAT = 'YYYY-MM-DDTHH:mm';
export const DATE_TIME_GRID_DISPLAY_FORMAT = 'dd-MM-yyyy HH:mm';
export const DATE_TIME_SECONDS_FORMAT = 'yyyy-MM-ddTHH:mm:ssZ';
export const NEWS_FEED_FILTER = [
  {
    id: 'ch1',
    name: 'Community',
    checkName: 'checkCommunity',
    searchKeyword: 'byCommunity',
    checked: false
  },
  {
    id: 'ch2',
    name: 'Challenge',
    checkName: 'checkChallenge',
    searchKeyword: 'byChallenges',
    checked: false
  },
  {
    id: 'ch3',
    name: 'Date Range',
    checkName: 'checkDate',
    searchKeyword: 'startDate&endDate',
    checked: false
  },
  {
    id: 'ch4',
    name: 'Challenge Winners',
    checkName: 'isWinner',
    searchKeyword: 'isWinner',
    checked: false
  },
  {
    id: 'ch5',
    name: 'My Group',
    checkName: 'checkgroup',
    searchKeyword: 'is_group_selected',
    checked: false
  },
  {
    id: 'ch6',
    name: 'My Buddies',
    checkName: 'checkBuddies',
    searchKeyword: 'buddy_id',
    checked: false
  },
  {
    id: 'ch7',
    name: 'My Class',
    checkName: 'checkclass',
    searchKeyword: 'my_class',
    checked: false
  }
];
export const REPORT_SERVICE_LIST = [

  {
    id: 0,
    name: 'Select',
    queryName: 'Select'
  },
  {
    id: 1,
    name: 'User Statistics',
    queryName: 'user_status'
  },
  {
    id: 2,
    name: 'Challenge Responses',
    queryName: 'weekly_response_view'
  },
  {
    id: 3,
    name: 'Activity Status',
    queryName: 'weekly_activities_status'
  },
  {
    id: 4,
    name: 'Community Level Status',
    queryName: 'communitywiseInfo'
  }
];

export interface ColumnViewDetails {
  keyColumn?: number;
  available?: number;
  key?: string;
  displayName?: string;
  type?: string;
  isActive?: boolean;
  isSortable?: boolean;
  sortType?: string;
}
export interface CreateNewField {
  role_name: any;
  dummyTag: any;
  image_load: any;
}
