import {AfterViewChecked, Directive, ElementRef, Input} from '@angular/core';

@Directive({
  selector: '[appQuestTracker]'
})
export class QuestTrackerDirective implements AfterViewChecked {

  @Input() appQuestTracker: any;

  constructor(private el: ElementRef) {}

  ngAfterViewChecked(): void {
    this.el.nativeElement.style.setProperty('--el-height', this.appQuestTracker.clientHeight + 'px');
  }

}
