import {Directive, ElementRef, Input, OnChanges, Renderer2, SimpleChanges} from '@angular/core';
import Hls from 'hls.js';

@Directive({
  selector: '[appVideoRender]'
})
export class VideoRenderDirective implements OnChanges {

  @Input() appVideoRender: string;

  constructor(private elementRef: ElementRef, private renderer: Renderer2) { }

  initVideo(url): void {
    if (url.indexOf('.m3u8') !== -1) {
      let hls = new Hls();
      // bind them together
      hls.attachMedia(this.elementRef.nativeElement);
      hls.on(Hls.Events.MEDIA_ATTACHED, () => {
        console.log('video and hls.js are now bound together !');
        hls.loadSource(url);
        hls.on(Hls.Events.MANIFEST_PARSED,  (event, data) => {
          console.log(
            'manifest loaded, found ' + data.levels.length + ' quality level'
          );
        });
      });
    } else {
      // let source = this.renderer.createElement('source');
      // source.src = url;
      // source.type = 'video/mp4';
      // this.renderer.appendChild(this.elementRef.nativeElement, source);
      this.renderer.setAttribute(this.elementRef.nativeElement, 'src', url);
    }
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['appVideoRender'].currentValue) {
      this.initVideo(this.appVideoRender);
    }
  }

}
