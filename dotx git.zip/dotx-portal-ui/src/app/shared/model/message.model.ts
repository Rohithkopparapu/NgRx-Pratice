import { Moment } from 'moment';

export interface IMessage {
  id?: number;
  from_user_id?: number;
  to_user_id?: number;
  message?: string;
  created_at?: Moment;
  display_name?: string;
  avatar_image_url?: string;
  chat_type?: string;
}

export class Message implements IMessage {
  constructor(
    public id?: number,
    public from_user_id?: number,
    public to_user_id?: number,
    public message?: string,
    public created_at?: Moment,
    public display_name?: string,
    public avatar_image_url?: string,
    public chat_type?: string
  ) {}
}
