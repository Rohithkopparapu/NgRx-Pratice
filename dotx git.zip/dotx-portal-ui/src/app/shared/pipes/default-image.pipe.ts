import {Pipe, PipeTransform} from '@angular/core';

@Pipe({
  name: 'defaultImagePipe',
  pure: true
})
export class DefaultImagePipe implements PipeTransform {

  transform(image: any, defaultImage: any): any {
    if (image) {
      return image;
    }
    return defaultImage;
  }
}
