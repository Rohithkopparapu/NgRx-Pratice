import { Pipe, PipeTransform } from '@angular/core';
@Pipe({
    name: 'ClassSearch'
})

export class ClassSearchPipe implements PipeTransform {
    transform(value: any, args?: any): any {
        if (!args) {
            return value;
        }
        return value.filter((val) => {
            let rVal = ((val['class']+ (val['section'] === null ? "" : val['section'].toLowerCase())).includes(args.toLowerCase()));            
            return rVal;
        })
    }
}