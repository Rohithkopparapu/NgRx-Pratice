import { Pipe, PipeTransform } from '@angular/core';
@Pipe({
    name: 'PhoneFilter'
})

export class PhoneSearchPipe implements PipeTransform {
    transform(value: any, args?: any): any {
        if (!args) {
            return value;
        }
        return value.filter((val) => {
            let rVal = (String(val.phone_number).includes(args));
            return rVal;
        })
    }
}