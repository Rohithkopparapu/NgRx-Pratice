import { Pipe, PipeTransform } from '@angular/core';
@Pipe({
    name: 'ColumnFilter'
})

export class SearchPipe implements PipeTransform {
    transform(value: any, args?: any): any {
        if (!args) {
            return value;
        }
        return value.filter((val) => {
            let rVal = (val['name'] === null? "": val['name'].toLowerCase().includes(args.toLowerCase()));
            return rVal;
        })
    }
}