import { Pipe, PipeTransform } from '@angular/core';
@Pipe({
    name: 'StatusFilter'
})

export class StatusSearchPipe implements PipeTransform {
    transform(value: any, args?: any): any {
        if (!args) {
            return value;
        }
        return value.filter((val) => {
            let rVal = (String(val.is_active).toLowerCase().includes(args));
            return rVal;
        })
    }
}