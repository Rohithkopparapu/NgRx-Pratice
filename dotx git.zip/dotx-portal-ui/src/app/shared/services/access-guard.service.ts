import {Injectable, OnDestroy} from '@angular/core';
import {ActivatedRouteSnapshot, CanActivateChild, RouterStateSnapshot, UrlTree} from '@angular/router';
import {Observable, Subject} from 'rxjs';
import {Authority} from '../constants/authority.constants';
import {takeUntil} from 'rxjs/operators';
import {Store} from '@ngrx/store';
import {AuthState} from '../store/auth.model';
import {userInfo} from '../store/auth.selector';

@Injectable({
  providedIn: 'root'
})
export class AccessGuardService implements CanActivateChild, OnDestroy {

  private subscriptions = new Subject<void>();
  private userInfo: any;

  constructor(private store$: Store<AuthState>) {
    this.store$.select(userInfo)
      .pipe(takeUntil(this.subscriptions))
      .subscribe(res => this.userInfo = res);
  }

  canActivateChild(childRoute: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean | UrlTree | Observable<boolean | UrlTree> | Promise<boolean | UrlTree> {
    return (this.userInfo.user_type === Authority.ADMIN && state.url.includes('/admin')) ||
      (this.userInfo.user_type === Authority.STUDENT || Authority.TEACHER && state.url.includes('/student'));
  }

  ngOnDestroy(): void {
    this.subscriptions.next();
    this.subscriptions.complete();
  }
}
