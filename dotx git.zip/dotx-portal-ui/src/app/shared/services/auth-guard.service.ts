import {Injectable, OnDestroy} from '@angular/core';
import {CanActivate} from '@angular/router';
import {Store} from '@ngrx/store';
import {AuthState} from 'src/app/shared/store/auth.model';
import {AuthLogout} from 'src/app/shared/store/auth.action';
import {Authority} from '../constants/authority.constants';
import {Subject} from 'rxjs';
import {takeUntil} from 'rxjs/operators';
import {accessToken, userInfo} from '../store/auth.selector';

@Injectable({
  providedIn: 'root'
})
export class AuthGuardService implements CanActivate, OnDestroy {

  private subscriptions = new Subject<void>();
  private userInfo: any;
  private accessToken: string;

  constructor(private store$: Store<AuthState>) {
    this.store$.select(userInfo)
      .pipe(takeUntil(this.subscriptions))
      .subscribe(res => this.userInfo = res);
    this.store$.select(accessToken)
      .pipe(takeUntil(this.subscriptions))
      .subscribe(res => this.accessToken = res);
  }

  canActivate(): boolean {
    if (this.userInfo) {
      if (this.accessToken && ((this.userInfo.user_type === Authority.ADMIN)
        || (this.userInfo.user_type === Authority.STUDENT && this.userInfo.is_email_verified && this.userInfo.display_name && this.userInfo.avatar_image_file) || 
        (this.userInfo.user_type === Authority.TEACHER && this.userInfo.is_email_verified && this.userInfo.display_name && this.userInfo.avatar_image_file))) {
        return true;
      }
      this.store$.dispatch(new AuthLogout());
    } else {
      this.store$.dispatch(new AuthLogout());
    }
  }

  ngOnDestroy(): void {
    this.subscriptions.next();
    this.subscriptions.complete();
  }
}
