import { HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { CONTENT_TYPE } from '../constants/constant';
import * as moment from 'moment';
import {BehaviorSubject, Subject} from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CommonApiService {
  hideCoverImage = new BehaviorSubject<boolean>(true);
  isResetPassword = new Subject<boolean>();

  constructor() {}

  getHeaders(): HttpHeaders {
    return new HttpHeaders()
      .set('Authorization', 'Basic ' + environment.oAuthHeader)
      .set('Content-Type', CONTENT_TYPE.APPLICATION_URL_ENCODED);
  }

  getFileHeaders(): HttpHeaders {
    return new HttpHeaders().set('Accept', 'multipart/form-data');
  }

  // getTokenHeaders(): HttpHeaders {
  //   return new HttpHeaders()
  //     .set('Authorization', 'bearer ' + sessionStorage.getItem('access_token'))
  //     .set('Content-Type', CONTENT_TYPE.APPLICATION_JSON);
  // }

  getDateDifference(date1, date2, type: string) {
    if (type === 'days') {
      const given = moment(date2).startOf('day');
      const current = moment().startOf('day');
      return given.diff(current, type);
    }
  }
}
