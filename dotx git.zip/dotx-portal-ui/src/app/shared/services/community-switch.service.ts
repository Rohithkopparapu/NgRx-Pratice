import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CommunitySwitchService {
  // Create a subject to communicate between components
  private refreshComSource = new Subject<void>();
  refreshComponentinfo$ = this.refreshComSource.asObservable();

  // Method to trigger component refresh
  triggerRefresh() {
    this.refreshComSource.next();
  }
}
