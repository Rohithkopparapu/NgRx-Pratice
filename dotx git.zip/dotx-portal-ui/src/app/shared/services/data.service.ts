import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class DataService {
  // Create a subject to communicate between components
  private refreshComponentSource = new Subject<void>();
  refreshComponent$ = this.refreshComponentSource.asObservable();

  // Method to trigger component refresh
  triggerRefresh() {
    this.refreshComponentSource.next();
  }
}
