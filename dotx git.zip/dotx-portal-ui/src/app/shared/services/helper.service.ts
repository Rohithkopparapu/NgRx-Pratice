import {Injectable} from '@angular/core';
import {DatePipe} from '@angular/common';
import {BehaviorSubject, Observable, throwError} from 'rxjs';
import {HttpClient} from '@angular/common/http';
import {catchError} from 'rxjs/operators';
import {snakeCase, mapKeys, rearg, camelCase} from 'lodash';
import {AbstractControl, FormControl, FormGroup} from '@angular/forms';
import * as moment from 'moment';
import {Role} from '../constants/authority.constants';
import {DELIMITERS, PLATFORM_START_DATE} from '../constants/constant';
import {ColumnViewDetails, DATE_FORMAT_MOMENT, DATE_TIME_GRID_DISPLAY_FORMAT} from '../constants/input.constants';

@Injectable({
  providedIn: 'root'
})
export class HelperService {
  LEADERBOARD_START_DATE = moment(PLATFORM_START_DATE, DATE_FORMAT_MOMENT, true);
  resourceUrl = '';
  isLoading = new BehaviorSubject(false);

  constructor(private httpClient: HttpClient, private datePipe: DatePipe) {}

  public uploadDocument(file: File, entityName: string): Observable<any> {
    const extUrl = `${this.resourceUrl}${entityName}/import`;
    const formData = new FormData();
    formData.append('file', file);
    return this.httpClient.post(extUrl, formData, { observe: 'response' }).pipe(catchError(err => throwError(err)));
  }

  public camelToSnakeCase(obj: any) {
    if (Array.isArray(obj)) {
      return obj.map(v => this.camelToSnakeCase(v));
    } else if (obj !== null && typeof obj === 'object') {
      return Object.keys(obj).reduce(
        (result, key) => ({
          ...result,
          [snakeCase(key)]: this.camelToSnakeCase(obj[key]),
        }),
        {}
      );
    }
    return obj;
  }

  public snakeToCamel(obj: any) {
    return mapKeys(obj, rearg(camelCase, 1));
  }

  public textToSnakeCase(value: any) {
    return snakeCase(value);
  }

  isValidField(control: AbstractControl) {
    if (control && control.touched && control.errors) {
      if (control.errors.ngbDate) {
        if (control.errors.ngbDate.invalid) {
          return true;
        }
      } else {
        return true;
      }
    }
  }

  getSpotlightFormattedStartMinDate() {
    const current = new Date();
    return {
      year: current.getFullYear(),
      month: current.getMonth() + 1,
      day: current.getDate()
    };
  }

  getLastDateByDays(days: number) {
    const current = new Date();
    return {
      year: current.getFullYear(),
      month: current.getMonth() + 1,
      day: current.getDate() - days
    };
  }

  getSpotlightFormattedEndMinDate(event, plusDays) {
    var current = new Date(event.year, event.month - 1, event.day);
    var nextday = new Date(current);
    nextday.setDate(current.getDate() + plusDays);
    return {
      year: nextday.getFullYear(),
      month: nextday.getMonth() + 1,
      day: nextday.getDate()
    };
  }

  getFormattedDateToBind({ day, month, year }) {
    month = month.toString().length > 1 ? month : '0' + month;
    day = day.toString().length > 1 ? day : '0' + day;
    return `${year}-${month}-${day}`;
  }

  getFormattedDateForAdminChall(dob) {
    const date = new Date(dob);
    return {
      day: date.getDate(),
      month: date.getMonth() + 1,
      year: date.getFullYear()
    };
  }

  getTodaysFormattedDate() {
    const date = moment().subtract(8, 'years').endOf('month');
    return {
      year: Number(moment(date).format('YYYY')),
      month: Number(moment(date).format('MM')),
      day: Number(moment(date).format('DD'))
    };
  }

  getOnlyImageFromChallenges(challenges: any[]): any[] {
    if (challenges && challenges.length) {
      challenges.forEach((v, i) => {
        const imageList = v.attachments.flatMap(s => s.type === 'challenge_image' || s.attachment_title === 'challenge_image' ? s.url : []);
        v['challenge_image'] = imageList && imageList.length ? imageList[0] : null;
      });
    }
    return challenges;
  }

  getImageOrVideoFromChallenges(challenges: any[]): any[] {
    if (challenges && challenges.length) {
      challenges.forEach(v => {
        const imageList = v.attachments.flatMap(s => s.type === 'challenge_image' ? s : []);
        const videoList = v.attachments.flatMap(s => s.type === 'challenge_video' ? s : []);
        v['filtered_attachments'] = videoList && videoList.length ? [{
          ...videoList[0],
          posterImage: imageList && imageList.length ? imageList[0].url : ''
        }] : imageList && imageList.length ? [...imageList[0]] : [];
      });
    }
    return challenges;
  }

  validateAllFormFields(formGroup: FormGroup) {
    Object.keys(formGroup.controls).forEach((field) => {
      const control = formGroup.get(field);
      if (control instanceof FormControl) {
        control.markAsTouched({ onlySelf: true });
      } else if (control instanceof FormGroup) {
        this.validateAllFormFields(control);
      }
    });
  }

  getAge(dob) {
    return moment().diff(dob, 'years');
  }

  getRole(roleName): string {
    return Role[roleName.toUpperCase()];
  }

  getWinnerNotes(response): string {
    const weekNo = moment(response.winner_of_the_week_date, 'DD-MM-YYYY').diff(this.LEADERBOARD_START_DATE, 'weeks');
    if (response.winner_of_the_week && response.winner_of_the_challenge && response.winner_of_the_week_date) {
      return `Winner of Week ${weekNo} and Challenge`;
    } else if (response.winner_of_the_week && response.winner_of_the_week_date) {
      return `Winner of Week ${weekNo}`;
    } else if (response.winner_of_the_challenge) {
      return `Winner of the Challenge`;
    }
  }

  calcDateDiff(endDay: Date): string {
    const dDay = endDay.valueOf();

    const milliSecondsInASecond = 1000;
    const hoursInADay = 24;
    const minutesInAnHour = 60;
    const secondsInAMinute = 60;

    const timeDifference = dDay - Date.now();

    const daysToDday = Math.floor(
      timeDifference /
      (milliSecondsInASecond * minutesInAnHour * secondsInAMinute * hoursInADay)
    );

    const hoursToDday = Math.floor(
      (timeDifference /
        (milliSecondsInASecond * minutesInAnHour * secondsInAMinute)) %
      hoursInADay
    );

    const minutesToDday = Math.floor(
      (timeDifference / (milliSecondsInASecond * minutesInAnHour)) %
      secondsInAMinute
    );

    const secondsToDday =
      Math.floor(timeDifference / milliSecondsInASecond) % secondsInAMinute;

    return daysToDday ? daysToDday + ' days ' + hoursToDday + ':' + minutesToDday + ':' + secondsToDday + ' hrs left' :
      hoursInADay ? hoursToDday + ':' + minutesToDday + ':' + secondsToDday + ' hrs left' :
        minutesToDday ? minutesToDday + ':' + secondsToDday + ' mins left'
          : secondsToDday + ' secs left';
  }

  extractColumnNamesFromObject(columnHeaders: any[] = []): Map<string, object> {
    const map = new Map();
    if (columnHeaders.length) {
      columnHeaders.forEach((element: string, index: any) => {
        const array = element.split(DELIMITERS.VIEW_QUERY_COLUMN_SEPARATOR);
        const elementObject: ColumnViewDetails = {
          keyColumn: array[0] === '00' ? 1 : 0,
          available: array[0].substr(1, 1) === '1' ? 1 : 0,
          // key: array[1] ? array[1] : 'key',
          type: array.length > 2 && array[1] ? array[1] : 'String',
          displayName: array.length > 2 && array[2] ? array[2] : 'Column ' + (index + 1),
          isActive: true
        };
        map.set(element, elementObject);
      });
    }
    return map;
  }

  formatDateTimeInListIfExists(inputList: any[] = [], inputKeys: any[] = []): any[] {
    if (!inputList || !inputKeys) { return inputList; }
    inputList.forEach(record => {
      inputKeys.forEach(attribute => {
        record[attribute] = this.datePipe.transform(record[attribute], DATE_TIME_GRID_DISPLAY_FORMAT);
      });
    });
    return inputList;
  }

  checkOfferDate(community: any): boolean {
    return moment(moment().format('YYYY-MM-DD')).isSameOrBefore(moment(community.offer_end_date).format('YYYY-MM-DD'));
  }
}
