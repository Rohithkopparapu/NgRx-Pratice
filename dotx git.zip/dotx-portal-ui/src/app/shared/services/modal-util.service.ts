import {Injectable, OnDestroy} from '@angular/core';
import {MySpaceComponent} from '../../modules/student-dashboard/header-section/my-space/my-space.component';
import {ViewOtherProfileComponent} from '../component/view-other-profile/view-other-profile.component';
import {NgbModal, NgbModalRef} from '@ng-bootstrap/ng-bootstrap';
import {ResetPasswordPopupComponent} from '../component/reset-password-popup/reset-password-popup.component';
import {takeUntil} from 'rxjs/operators';
import {Store} from '@ngrx/store';
import {AuthState} from '../store/auth.model';
import { userInfo } from '../store/auth.selector';
import {Subject} from 'rxjs';
import {ContactUsComponent} from '../component/contact-us/contact-us.component';

@Injectable({
  providedIn: 'root'
})
export class ModalUtilService implements OnDestroy {

  private subscriptions = new Subject<void>();
  userInfo: any;

  constructor(private modalService: NgbModal, private store$: Store<AuthState>) {
    this.store$.select(userInfo)
      .pipe(takeUntil(this.subscriptions))
      .subscribe(res => this.userInfo = res);
  }

  openBuddyProfile(buddie): NgbModalRef {
    const modalRef = this.modalService.open(buddie.user_id == this.userInfo.user_id ? MySpaceComponent : ViewOtherProfileComponent, {
      centered: true,
      backdrop: 'static',
      size: 'xl',
      windowClass: 'custom-modal'
    });
    if (buddie.user_id != this.userInfo.user_id) {
      modalRef.componentInstance.data = { userId: buddie.user_id };
    }
    return modalRef;
  }

  openResetPasswordPopup(): NgbModalRef {
    return this.modalService.open(ResetPasswordPopupComponent, {
      centered: true,
      backdrop: 'static',
      keyboard: false,
      size: 'lg',
      windowClass: 'modal-holder'
    });
  }

  openContactUsPopup(): NgbModalRef {
    return this.modalService.open(ContactUsComponent, {
      centered: true,
      backdrop: 'static',
      windowClass: 'modal-cover modal-cover-fluid'
    });
  }

  ngOnDestroy(): void {
    this.subscriptions.next();
    this.subscriptions.complete();
  }
}
