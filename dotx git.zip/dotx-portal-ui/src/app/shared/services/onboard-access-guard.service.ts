import {Injectable, OnDestroy} from '@angular/core';
import {ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot, UrlTree} from '@angular/router';
import {Observable, Subject} from 'rxjs';
import {takeUntil} from 'rxjs/operators';
import {AuthState} from '../store/auth.model';
import {Store} from '@ngrx/store';
import {userInfo} from '../store/auth.selector';
import {AuthLogout} from '../store/auth.action';

@Injectable({
  providedIn: 'root'
})
export class OnboardAccessGuardService implements CanActivate, OnDestroy {

  private subscriptions = new Subject<void>();
  private userInfo: any;

  constructor(private store$: Store<AuthState>, private router: Router) {
    this.store$.select(userInfo)
      .pipe(takeUntil(this.subscriptions))
      .subscribe(res => this.userInfo = res);
  }

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {
    if (this.userInfo) { // Need to check for Role access
      if (route.queryParamMap.get('access_key')) {
        return true;
      } else if (!this.userInfo.is_email_verified || !this.userInfo.display_name || !this.userInfo.avatar_image_file) {
        return true;
      } else {
        this.router.navigate(['/auth/student/community/join']);
      }
    } else {
      this.store$.dispatch(new AuthLogout());
    }
  }

  ngOnDestroy(): void {
    this.subscriptions.next();
    this.subscriptions.complete();
  }
}
