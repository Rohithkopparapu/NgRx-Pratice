import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class PostRefreshService {
  // Create a subject to communicate between components
  private postRefreshComponentSource = new Subject<void>();
  postrefreshComponent$ = this.postRefreshComponentSource.asObservable();

  // Method to trigger component refresh
  triggerRefresh() {
    this.postRefreshComponentSource.next();
  }
}
