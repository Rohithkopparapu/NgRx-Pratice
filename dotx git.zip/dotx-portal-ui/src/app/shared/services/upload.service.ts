import { HttpClient, HttpEvent, HttpHeaders, HttpParams, HttpRequest } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class UploadService {

  private static FILE_URL = `${environment.baseURL}/dot-files`;
  private static FILE_ADMIN_DAILY_RECORDS_DOT_URL = `${environment.baseURL}/dot-admin-daily-dot-records`;
  private static EXCEL_URL = `${environment.baseURL}/dot-user-details`;

  constructor(
    private httpClient: HttpClient
  ) { }

  uploadDocument(file, fileType: string): Observable<any> {
    const uploadResourceUrl = `${UploadService.FILE_URL}/upload`;
    const formData = new FormData();
    file.forEach(element => {
      formData.append('file', element);
    });
    formData.append('type', fileType);
    return this.httpClient.post(uploadResourceUrl, formData)
      .pipe(catchError(err => throwError(err)));
  }

  uploadDailyDot(file): Observable<any> {
    const uploadResourceUrl = `${UploadService.FILE_ADMIN_DAILY_RECORDS_DOT_URL}/import`;
    const formData = new FormData();
    file.forEach(element => {
      formData.append('file', element);
    });
    return this.httpClient.post(uploadResourceUrl, formData)
      .pipe(catchError(err => throwError(err)));
  }

  uploadDotCoinBadge(file): Observable<any> {
    const uploadResourceUrl = `${UploadService.FILE_URL}/upload`;
    const formData = new FormData();
    formData.append('type', 'reward_badge');
    file.forEach(element => {
      formData.append('file', element);
    });

    return this.httpClient.post(uploadResourceUrl, formData)
      .pipe(catchError(err => throwError(err)));
  }

   // excel upload
   excelFile(file,id,school): Observable<any> {
    const uploadUrl = `${UploadService.EXCEL_URL}/bulk-user-registration`;
    const formData = new FormData();
    formData.append('type', 'Upload User Details');
    formData.append('file', file);
    formData.append('registration_id', id);
    formData.append('school_name', school);
    // const headers = new HttpHeaders({ 'enctype': 'multipart/form-data' });
    return this.httpClient.post(uploadUrl, formData);
    // return this.httpClient.post(uploadUrl, formData,{headers})
    //   .pipe(catchError(err => throwError(err)));
  }

  public uploadfile(file: File) {
    const url = `${UploadService.EXCEL_URL}/bulk-user-registration`;
    let formParams = new FormData();
    formParams.append('file', file)
    return this.httpClient.post(url, formParams)
  }
}
