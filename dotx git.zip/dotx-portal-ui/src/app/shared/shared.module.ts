/* Modules */
import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {RouterModule} from '@angular/router';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';
import {NgbModule} from '@ng-bootstrap/ng-bootstrap';
import {CKEditorModule} from 'ckeditor4-angular';
import {SlickCarouselModule} from 'ngx-slick-carousel';
import {NgxEmojiPickerModule} from 'ngx-emoji-picker';
import {NgxDocViewerModule} from 'ngx-doc-viewer';
import {TableModule} from './table/table.module';
/* Components & Pipes */
import {ControlMessagesComponent} from './component/control-messages/control-messages.component';
import {DeleteComponent} from './component/delete/delete.component';
import {LoaderComponent} from './component/loader/loader.component';
import {FileUploadComponent} from './component/file-upload/file-upload.component';
import {SafePipe} from './pipes/safe.pipe';
import {FileDragNDropDirective} from './directives/file-drag-n-drop.directive';
import {SendMessagePopupComponent} from './component/send-message-popup/send-message-popup.component';
import {MyChallengesPopupComponent} from './component/my-challenges-popup/my-challenges-popup.component';
import {DefaultImagePipe} from './pipes/default-image.pipe';
import {ImageVideoViewComponent} from './component/image-video-view/image-video-view.component';
import {MyQuestPopupComponent} from './component/my-quest-popup/my-quest-popup.component';
import {MySkillsListComponent} from './component/my-skills-list/my-skills-list.component';
import {CommonLoaderComponent} from './component/common-loader/common-loader.component';
import {ResetPasswordComponent} from './component/reset-password/reset-password.component';
import {SoloChallengeModelComponent} from './component/solo-challenge-model/solo-challenge-model.component';
import {GroupChallengeModelComponent} from './component/group-challenge-model/group-challenge-model.component';
import {ViewResponsesComponent} from './component/view-responses/view-responses.component';
import {InviteBuddyByEmailComponent} from './component/invite-buddy-by-email/invite-buddy-by-email.component';
import {ViewOtherProfileComponent} from './component/view-other-profile/view-other-profile.component';
import {VjsPlayerComponent} from './component/vjs-player/vjs-player.component';
import {VideoRenderDirective} from './directives/video-render.directive';
import {PasswordStrengthBarComponent} from './component/passwordStrength.component';
import {BadgesDotcoinsPopupComponent} from './component/badges-dotcoins-popup/badges-dotcoins-popup.component';
import {AboutUsComponent} from './component/about-us/about-us.component';
import {ResetPasswordPopupComponent} from './component/reset-password-popup/reset-password-popup.component';
import {TimeAgoPipe} from './pipes/time-ago.pipe';
import {SearchFilter} from './pipes/filter.pipe';
import {ContactUsComponent} from './component/contact-us/contact-us.component';
import {NotificationPopupComponent} from './component/notification-popup/notification-popup.component';
import {HeaderComponent} from '../home/header/header.component';
import {FestModalComponent} from './component/fest-modal/fest-modal.component';
import {CommonFooterComponent} from './component/common-footer/common-footer.component';
import {AnnouncementResponsesComponent} from './component/announcement-responses/announcement-responses.component';
import {SplitCamelCasePipe} from './pipes/split-camel-case.pipe';
import {CertificationsPopupComponent} from './component/certifications-popup/certifications-popup.component';
import {LeaderBoardSectionComponent} from './component/leader-board-section/leader-board-section.component';
import { QuestTrackerDirective } from './directives/quest-tracker.directive';
import { ChallengeCompletedComponent } from './component/level-completed/challenge-completed.component';


@NgModule({
  declarations: [
    HeaderComponent,
    ControlMessagesComponent,
    DeleteComponent,
    LoaderComponent,
    FileUploadComponent,
    SafePipe,
    SearchFilter,
    FileDragNDropDirective,
    SendMessagePopupComponent,
    MyChallengesPopupComponent,
    DefaultImagePipe,
    ImageVideoViewComponent,
    MyQuestPopupComponent,
    MySkillsListComponent,
    CommonLoaderComponent,
    ResetPasswordComponent,
    SoloChallengeModelComponent,
    GroupChallengeModelComponent,
    ViewResponsesComponent,
    InviteBuddyByEmailComponent,
    ViewOtherProfileComponent,
    VjsPlayerComponent,
    VideoRenderDirective,
    PasswordStrengthBarComponent,
    BadgesDotcoinsPopupComponent,
    ResetPasswordPopupComponent,
    AboutUsComponent,
    TimeAgoPipe,
    ContactUsComponent,
    NotificationPopupComponent,
    FestModalComponent,
    CommonFooterComponent,
    AnnouncementResponsesComponent,
    SplitCamelCasePipe,
    CertificationsPopupComponent,
    LeaderBoardSectionComponent,
    QuestTrackerDirective,
    ChallengeCompletedComponent
  ],
  imports: [
    CommonModule,
    RouterModule,
    FormsModule,
    ReactiveFormsModule,
    NgbModule,
    CKEditorModule,
    SlickCarouselModule,
    NgxEmojiPickerModule,
    NgxDocViewerModule,
    TableModule
  ],
  entryComponents: [
    MyChallengesPopupComponent,
    MyQuestPopupComponent,
    SendMessagePopupComponent,
    DeleteComponent,
    FileUploadComponent,
    SoloChallengeModelComponent,
    GroupChallengeModelComponent,
    ViewResponsesComponent,
    AnnouncementResponsesComponent,
    ImageVideoViewComponent,
    InviteBuddyByEmailComponent,
    ViewOtherProfileComponent,
    BadgesDotcoinsPopupComponent,
    ResetPasswordPopupComponent,
    ContactUsComponent,
    NotificationPopupComponent,
    FestModalComponent,
    CertificationsPopupComponent,
    ChallengeCompletedComponent
  ],
    exports: [
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        NgbModule,
        CKEditorModule,
        SlickCarouselModule,
        NgxEmojiPickerModule,
        NgxDocViewerModule,
        TableModule,
        SafePipe,
        DefaultImagePipe,
        TimeAgoPipe,
        SplitCamelCasePipe,
        VideoRenderDirective,
        HeaderComponent,
        ControlMessagesComponent,
        LoaderComponent,
        CommonLoaderComponent,
        MySkillsListComponent,
        ResetPasswordComponent,
        PasswordStrengthBarComponent,
        CommonFooterComponent,
        LeaderBoardSectionComponent,
        QuestTrackerDirective
    ],
  providers: []
})
export class SharedModule {
}
