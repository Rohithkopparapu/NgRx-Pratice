import {Action} from '@ngrx/store';
import {TokenResponse} from './auth.model';


export class LoginDetails {
  email: string;
  password: string;
}

export enum AuthActionTypes {
  AuthLoginType = '[Auth] Login',
  AuthLoginSuccessType = '[Auth] Login Success',
  AuthLoginFailType = '[Auth] Login Fail',
  AuthLogoutType = '[Auth] Logout',
  RefreshTokenType = '[Auth] Refresh Token',
  SetUserResponse = '[Auth] User Response',
  UserDetailsAction = '[Auth] User Action',
  SetUserDetailsType = '[Auth] User Details',
  AuthRefreshTokenSuccessType = '[Auth] Refresh Token Success',
  SetUserPreference = '[Auth] User Preference Details',
  CheckIsFirstTime = '[Auth] Check Is First Time Logged In',
  NavigateAction = '[App] Navigate Action',
  ChallengeViewTab = '[App] Challenge View Tab',
  SetOnlineUsers = '[Chat] Online Connected Socket users',
  SetMyPortfolio = '[App] My Portfolio',
  SetCartItems = '[App] Cart Items'
}

export class AuthLogin implements Action {
  readonly type = AuthActionTypes.AuthLoginType;
  constructor(public payload: LoginDetails) {
  }
}

export class AuthLoginSuccess implements Action {
  readonly type = AuthActionTypes.AuthLoginSuccessType;
  constructor(public payload: TokenResponse) {
  }
}

export class AuthLoginFail implements Action {
  readonly type = AuthActionTypes.AuthLoginFailType;
  constructor(public payload?: any) {
  }
}

export class AuthLogout implements Action {
  readonly type = AuthActionTypes.AuthLogoutType;
  constructor() {
  }
}

export class RefreshToken implements Action {
  readonly type = AuthActionTypes.RefreshTokenType;
  constructor() {
  }
}

export class SetUser implements Action {
  readonly type = AuthActionTypes.SetUserResponse;
  constructor(public payload: any) {
  }
}

export class SetUserDetail implements Action {
  readonly type = AuthActionTypes.SetUserDetailsType;
  constructor(public payload: any) {
  }
}

export class SetUserPreference implements Action {
  readonly type = AuthActionTypes.SetUserPreference;
  constructor(public payload: any) {
  }
}

export class UserDetailsAction implements Action {
  readonly type = AuthActionTypes.UserDetailsAction;
  constructor(public payload: any) {
  }
}

export class CheckIsFirstTime implements Action {
  readonly type = AuthActionTypes.CheckIsFirstTime;
  constructor(public payload: any) {
  }
}

export class NavigateAction implements Action {
  readonly type = AuthActionTypes.NavigateAction;
  constructor(public payload: any) {
  }
}

export class ChallengeViewTab implements Action {
  readonly type = AuthActionTypes.ChallengeViewTab;
  constructor(public payload: any) {
  }
}

export class SetOnlineUsers implements Action {
  readonly type = AuthActionTypes.SetOnlineUsers;
  constructor(public payload: any) {
  }
}

export class SetMyPortfolio implements Action {
  readonly type = AuthActionTypes.SetMyPortfolio;
  constructor(public payload: any) {
  }
}

export class SetCartItems implements Action {
  readonly type = AuthActionTypes.SetCartItems;
  constructor(public payload: any) {
  }
}

export type AuthActions =
  | AuthLogin
  | AuthLoginSuccess
  | AuthLoginFail
  | AuthLogout
  | SetUser
  | UserDetailsAction
  | SetUserDetail
  | RefreshToken
  | SetUserPreference
  | CheckIsFirstTime
  | NavigateAction
  | ChallengeViewTab
  | SetOnlineUsers
  | SetMyPortfolio
  | SetCartItems;
