import { Injectable } from '@angular/core';
import {AuthActions, AuthActionTypes, AuthLoginFail, AuthLogout, NavigateAction, SetUserDetail} from './auth.action';
import {Actions, Effect, ofType} from '@ngrx/effects';
import {catchError, map, pluck, switchMap, tap} from 'rxjs/operators';
import {StudentHelperService} from '../../modules/student-dashboard/student-helper.service';
import {AuthState} from './auth.model';
import {Store} from '@ngrx/store';
import {Router} from '@angular/router';
import {REFRESH_PAGES} from "../constants/constant";

@Injectable()
export class AuthEffects {

  constructor(private actions$: Actions<AuthActions>, private studentHelperService: StudentHelperService, private store$: Store<AuthState>, private router: Router) {}

  // TODO: Token expire
  @Effect() userDetailsAction$ = this.actions$.pipe(
    ofType(AuthActionTypes.UserDetailsAction),
    pluck('payload'),
    switchMap((action: any): any => {
      return this.studentHelperService.getUserInfo(action.userId).pipe(
        map((res: any) => {
          if (res) {
            sessionStorage.setItem("school_name", res.school_name !== null ? res.school_name : "");
            this.store$.dispatch(new SetUserDetail(res));
            return new NavigateAction({...res, _page: action._page});
          }
        }),
        catchError(() => {
          return [new AuthLoginFail(), new AuthLogout()];
        }));
    })
  );

  @Effect({ dispatch: false }) navigateAction = this.actions$.pipe(
    ofType(AuthActionTypes.NavigateAction),
    pluck('payload'),
    map((res: any): any => {
      if (res._page === 'community') {
        this.router.navigate(['/auth/student/quest']);
      } else if (REFRESH_PAGES.includes(res._page)) {
        this.studentHelperService.isRefreshHubPage.next({_page: res._page});
      }
    })
  );

  @Effect({ dispatch: false }) authLoginFailed$ = this.actions$.pipe(
    ofType(AuthActionTypes.AuthLogoutType || AuthActionTypes.AuthLoginFailType),
    tap(() => {
      sessionStorage.clear();
      localStorage.clear();
      this.router.navigate(['/home']);
    })
  );
}
