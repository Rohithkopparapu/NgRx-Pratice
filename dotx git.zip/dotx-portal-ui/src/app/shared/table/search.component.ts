import {Component, EventEmitter, Output} from '@angular/core';

@Component({
  selector: 'app-search',
  template: `
    <input type="text" class="form-control" placeholder="Search..." [(ngModel)]="searchValue" (ngModelChange)="onChangeValue()" autocomplete="disabled">
    <button class="btn btn-link search-icon" type="button">
      <img src="assets/img/search-icon.png" alt="">
    </button>
  `
})
export class SearchComponent {

  @Output() searchEmitter = new EventEmitter<string>();
  searchValue: string;

  constructor() {}

  onChangeValue(): void {
    this.searchEmitter.emit(this.searchValue);
  }
}
