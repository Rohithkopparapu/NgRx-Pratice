import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TableFilterPipe } from './table-filter.pipe';
import { SearchComponent } from './search.component';
import { AppPaginationComponent } from './app-pagination/app-pagination.component';
import { PaginationPipe } from './app-pagination/paginate.pipe';


@NgModule({
  declarations: [
    TableFilterPipe,
    SearchComponent,
    AppPaginationComponent,
    PaginationPipe
  ],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule
  ],
  exports: [
    TableFilterPipe,
    SearchComponent,
    AppPaginationComponent,
    PaginationPipe
  ]
})
export class TableModule { }
