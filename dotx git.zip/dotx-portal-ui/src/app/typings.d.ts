// declare module '@ckeditor/ckeditor5-build-classic' {
//     const ClassicEditorBuild: any;

//     export = ClassicEditorBuild;
// }


declare module '@ckeditor/ckeditor5-build-decoupled-document' {
    const DecoupledEditor: any;

    export = DecoupledEditor;
}


// declare module 'ckeditor5' {
//     const Editor: any;

//     export = Editor;
// }
