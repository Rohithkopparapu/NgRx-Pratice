// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.
export const EndPoints = {
  baseIP: 'http://192.168.32.12/lifeskills',
  userDataPort: 'api',
  googleUserDataPort: 'auth'
};
export const environment = Object.freeze({
  production: false,
  // cmsUrl: `http://localhost:4200/`,
  // cmsLandingUrl:`http://localhost:4200/`,
  cmsUrl: `http://192.168.32.12/lifeskills`,
  cmsLandingUrl:`http://192.168.32.12`,
  homePageUrl: `http://192.168.32.12/`,
  fetchUrl: `${EndPoints.baseIP}`,  
  baseURL: `${EndPoints.baseIP}/${EndPoints.userDataPort}/v1`,
  joinAuthJoinCode: `${EndPoints.baseIP}/${EndPoints.googleUserDataPort}/joincode_auth`,
  SOCKET_URL: `${EndPoints.baseIP}/${EndPoints.googleUserDataPort}`,
  signWithGoogle: `${EndPoints.baseIP}/${EndPoints.googleUserDataPort}/google_auth`,
  googleClientId: '762815222195-5gjne2mraskul3c62moarffach7csgf4.apps.googleusercontent.com',
  oAuthHeader: 'MkhUNmlYanVjVVJMbFlKVDJSMlgyTFZkOklJS3ZnZ1R3V0phTUdiWDl0cERjNGF4WUZXRVlCOFlBczM3akxPYnBPdGpONDNjZQ==',
});



