export const EndPoints = {
  // baseIP: location.protocol + '//dotx.gg/lifeskills',
  baseIP:'https://www.dotx.gg/lifeskills',
  userDataPort: 'api',
  googleUserDataPort: 'auth',
};
export const environment = Object.freeze({
  production: true,
  cmsUrl: `https://www.dotx.gg/lifeskills`,
  cmsLandingUrl:`https://dotx.gg`,
  homePageUrl : `https://www.dotx.gg/`,
  fetchUrl: `${EndPoints.baseIP}`,  
  baseURL: `${EndPoints.baseIP}/${EndPoints.userDataPort}/v1`,
  joinAuthJoinCode: `${EndPoints.baseIP}/${EndPoints.googleUserDataPort}/joincode_auth`,
  SOCKET_URL: `${EndPoints.baseIP}/${EndPoints.googleUserDataPort}`,
  signWithGoogle: `${EndPoints.baseIP}/${EndPoints.googleUserDataPort}/google_auth`,
  googleClientId: '1091261426815-s0idfhsskt99g76ra5igek0al63p1lf7.apps.googleusercontent.com',
  oAuthHeader: 'MkhUNmlYanVjVVJMbFlKVDJSMlgyTFZkOklJS3ZnZ1R3V0phTUdiWDl0cERjNGF4WUZXRVlCOFlBczM3akxPYnBPdGpONDNjZQ==',
});
