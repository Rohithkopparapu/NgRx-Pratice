// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.
// export const EndPoints = {
//     baseIP: 'https://app.dev.dotx.gg',
//     // baseIP: location.protocol + '//app.dev.dotx.gg',
//     userDataPort: 'api',
//     googleUserDataPort: 'auth'
//   };
//   export const environment = Object.freeze({
//     production: false,
//     cmsUrl: `https://app.dev.dotx.gg`,
//     cmsLandingUrl:`https://dev.dotx.gg`,
//     baseURL: `${EndPoints.baseIP}/${EndPoints.userDataPort}/v1`,
//     joinAuthJoinCode: `${EndPoints.baseIP}/${EndPoints.googleUserDataPort}/joincode_auth`,
//     SOCKET_URL: `${EndPoints.baseIP}/${EndPoints.googleUserDataPort}`,
//     signWithGoogle: `${EndPoints.baseIP}/${EndPoints.googleUserDataPort}/google_auth`,
//     googleClientId: '762815222195-5gjne2mraskul3c62moarffach7csgf4.apps.googleusercontent.com',
//     oAuthHeader: 'MkhUNmlYanVjVVJMbFlKVDJSMlgyTFZkOklJS3ZnZ1R3V0phTUdiWDl0cERjNGF4WUZXRVlCOFlBczM3akxPYnBPdGpONDNjZQ==',
//   });
// for UAT deployment
export const EndPoints = {
  baseIP: 'https://dev.dotx.gg/lifeskills',
  // baseIP: location.protocol + '//app.dev.dotx.gg',    
  userDataPort: 'api',
  googleUserDataPort: 'auth'  };
export const environment = Object.freeze({
  production: false,
  cmsUrl: `https://dev.dotx.gg/lifeskills`,
  cmsLandingUrl:`https://dev.dotx.gg`,
  homePageUrl : `https://dev.dotx.gg/`,
  fetchUrl: `${EndPoints.baseIP}`,  
  baseURL: `${EndPoints.baseIP}/${EndPoints.userDataPort}/v1`,
  joinAuthJoinCode: `${EndPoints.baseIP}/${EndPoints.googleUserDataPort}/joincode_auth`,
  SOCKET_URL: `${EndPoints.baseIP}/${EndPoints.googleUserDataPort}`,
  signWithGoogle: `${EndPoints.baseIP}/${EndPoints.googleUserDataPort}/google_auth`,
  googleClientId: '762815222195-5gjne2mraskul3c62moarffach7csgf4.apps.googleusercontent.com',
  oAuthHeader: 'MkhUNmlYanVjVVJMbFlKVDJSMlgyTFZkOklJS3ZnZ1R3V0phTUdiWDl0cERjNGF4WUZXRVlCOFlBczM3akxPYnBPdGpONDNjZQ==',
});
