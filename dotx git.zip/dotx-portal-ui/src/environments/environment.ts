
export const EndPoints = {
  baseIP: 'https://dev.dotx.gg/lifeskills',
  // baseIP: 'https://app.dotx.gg',
  //  baseIP: 'http://192.168.32.173',
  // baseIP: location.protocol + '//app.dotx.gg',
  //  UAT IP
  userDataPort: 'api',
  googleUserDataPort: 'auth'
};
export const environment = Object.freeze({
  production: true,
  cmsUrl: `http://localhost:4200/`,
  cmsLandingUrl:`http://localhost:4200/`,
  homePageUrl : `https://dev.dotx.gg/`,
  // cmsUrl: `http://192.168.32.173`,
  // cmsLandingUrl:`http://192.168.32.173`,
  fetchUrl: `${EndPoints.baseIP}`,  
  baseURL: `${EndPoints.baseIP}/${EndPoints.userDataPort}/v1`,
  joinAuthJoinCode: `${EndPoints.baseIP}/${EndPoints.googleUserDataPort}/joincode_auth`,
  SOCKET_URL: `${EndPoints.baseIP}/${EndPoints.googleUserDataPort}`,
  signWithGoogle: `${EndPoints.baseIP}/${EndPoints.googleUserDataPort}/google_auth`,
  googleClientId: '1091261426815-s0idfhsskt99g76ra5igek0al63p1lf7.apps.googleusercontent.com',
  oAuthHeader: 'MkhUNmlYanVjVVJMbFlKVDJSMlgyTFZkOklJS3ZnZ1R3V0phTUdiWDl0cERjNGF4WUZXRVlCOFlBczM3akxPYnBPdGpONDNjZQ==',
});

// export const EndPoints = {
//   baseIP: 'https://dev.dotx.gg/beta',
//   // baseIP: location.protocol + '//app.dev.dotx.gg',    
//   userDataPort: 'api',
//   googleUserDataPort: 'auth'  };
// export const environment = Object.freeze({
//   production: false,
//   cmsUrl: `https://dev.dotx.gg/beta`,
//   cmsLandingUrl:`https://dev.dotx.gg`,
//   baseURL: `${EndPoints.baseIP}/${EndPoints.userDataPort}/v1`,
//   joinAuthJoinCode: `${EndPoints.baseIP}/${EndPoints.googleUserDataPort}/joincode_auth`,
//   SOCKET_URL: `${EndPoints.baseIP}/${EndPoints.googleUserDataPort}`,
//   signWithGoogle: `${EndPoints.baseIP}/${EndPoints.googleUserDataPort}/google_auth`,
//   googleClientId: '762815222195-5gjne2mraskul3c62moarffach7csgf4.apps.googleusercontent.com',
//   oAuthHeader: 'MkhUNmlYanVjVVJMbFlKVDJSMlgyTFZkOklJS3ZnZ1R3V0phTUdiWDl0cERjNGF4WUZXRVlCOFlBczM3akxPYnBPdGpONDNjZQ==',
// });
